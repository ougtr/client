package ma.axa.outer.bff.website.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import ma.axa.outer.bff.website.dto.RenewalContractValidationInput;
import ma.axa.outer.bff.website.dto.request.AllQuotationsDto;
import ma.axa.outer.bff.website.dto.request.Devis;
import ma.axa.outer.bff.website.service.QuotationService;
import ma.axa.outer.bff.website.util.DataGenerator;
import ma.axa.outer.bff.website.util.Paths;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(QuotationApi.class)
@ExtendWith(SpringExtension.class)
public class QuotationApiTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private QuotationService quotationService;
    private static final String QUOTATION_SIM_URI = Paths.QUOTATION_WEB_SITE;


    @Test
    void get_quotation_prime() throws Exception {
        AllQuotationsDto anObject = DataGenerator.quoatationInput();
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(anObject);
        mockMvc.perform(
                MockMvcRequestBuilders.post(QUOTATION_SIM_URI).content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void update_quotation_prime() throws Exception {
        AllQuotationsDto anObject = DataGenerator.quoatationInput();
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(anObject);
        mockMvc.perform(
                MockMvcRequestBuilders.put(QUOTATION_SIM_URI+"/1234").content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void validate_quotation() throws Exception {
        Devis anObject = DataGenerator.validationInput();
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(anObject);
        mockMvc.perform(
                MockMvcRequestBuilders.post(QUOTATION_SIM_URI+"/1234/validate").content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}
