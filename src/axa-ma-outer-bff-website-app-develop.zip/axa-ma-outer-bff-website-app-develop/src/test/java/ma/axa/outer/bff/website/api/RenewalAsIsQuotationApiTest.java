package ma.axa.outer.bff.website.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.RenewalContractValidationInput;
import ma.axa.outer.bff.website.service.RenewalService;
import ma.axa.outer.bff.website.util.DataGenerator;
import ma.axa.outer.bff.website.util.Paths;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(RenewalAsIsQuotationApi.class)
@ExtendWith(SpringExtension.class)
public class RenewalAsIsQuotationApiTest {
    private static final String QUOTATION_RENEWAL_URI = Paths.QUOTATION_RENEW;

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RenewalService renewalService;
    @MockBean
    private ICaptchaService captchaService;
    @BeforeEach
    void initMockServices() {
        try {
            when(renewalService.getRenewalData(any())).thenReturn(DataGenerator.renewalDataResponse());
            when(renewalService.validateRenewalContract(any())).thenReturn(ApiMessageWrapper.builder().message("ok").build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void get_renewal_data() throws Exception {
        mockMvc.perform(
                MockMvcRequestBuilders.get(QUOTATION_RENEWAL_URI + "/data?policyNumber=1234556")
                        .param("g-recaptcha-response", "test").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }

    @Test
    void validateRenewalContract() throws Exception {
        RenewalContractValidationInput anObject = DataGenerator.renewalContractValidationInputRequest();
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(anObject);
        mockMvc.perform(
                MockMvcRequestBuilders.post(QUOTATION_RENEWAL_URI + "/validate").content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}
