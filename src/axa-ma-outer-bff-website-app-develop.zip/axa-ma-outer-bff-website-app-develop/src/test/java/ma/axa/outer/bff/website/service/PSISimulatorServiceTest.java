package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.client.InnerSFDCProxy;
import ma.axa.outer.bff.website.dto.LeadRequestDto;
import ma.axa.outer.bff.website.dto.PSIProspectDto;
import ma.axa.outer.bff.website.exception.GlobalException;
import ma.axa.outer.bff.website.mapper.LeadMapper;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.xml.crypto.Data;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class PSISimulatorServiceTest {
    @Mock
    InnerSFDCProxy innerSFDCProxy;

    @InjectMocks
    private PSISimulatorService psiSimulatorService;

    @Mock
    private LeadMapper leadMapper;

    @Test
    @DisplayName("Test service save prospect")
    void save_prospect() throws Exception{
        when(innerSFDCProxy.createLead(any())).thenReturn(DataGenerator.createLead());
        assertNotNull(psiSimulatorService.saveProspect(new PSIProspectDto()));
    }

    @Test
    @DisplayName("Test service save prospect")
    void save_psi_prospect() throws Exception{
        when(innerSFDCProxy.createLead(any())).thenReturn(DataGenerator.createLead());
        assertNotNull(psiSimulatorService.savePsiProspect(new LeadRequestDto()));
    }
    @Test
    @DisplayName("Test service update prospect")
    void update_prospect() throws Exception{
        when(innerSFDCProxy.updateLead(any(), any())).thenReturn(DataGenerator.createLead());
        assertNotNull(psiSimulatorService.updateProspect(DataGenerator.constructPSIProspect()));
    }

    @Test
    @DisplayName("Test service update prospect")
    void update_psi_prospect() throws Exception{
        when(innerSFDCProxy.updateLead(any(), any())).thenReturn(DataGenerator.createLead());
        assertNotNull(psiSimulatorService.updatePsiProspect(DataGenerator.buildLeadRequestDtoPsi(), "12345"));
    }

    @Test
    void Should_Throw_Exception_Id_Null() {
        GlobalException thrown = assertThrows(GlobalException.class, () -> psiSimulatorService.updateProspect(new PSIProspectDto()));
        assertEquals("Lead Id cannot be null", thrown.getType());
    }


}
