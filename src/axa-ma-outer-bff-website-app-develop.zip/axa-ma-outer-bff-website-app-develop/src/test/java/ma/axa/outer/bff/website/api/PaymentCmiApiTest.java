package ma.axa.outer.bff.website.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import ma.axa.outer.bff.website.service.PaymentCmiService;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(PaymentCmiApi.class)
@ExtendWith(SpringExtension.class)
public class PaymentCmiApiTest {
    private static final String PAYMENT_URL = "/v1/payment/cmi";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PaymentCmiService paymentCmiService;

    @Test
    void create_payment_request_should_be_ok() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(DataGenerator.buildPaymentRequestDto());
        mockMvc.perform(
                        MockMvcRequestBuilders.post(PAYMENT_URL+"/payment-request")
                                .content(requestJson)
                                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isCreated());
    }
    @Test
    void get_payment_request_should_be_ok() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(DataGenerator.buildPaymentRequestDto());
        mockMvc.perform(
                        MockMvcRequestBuilders.get(PAYMENT_URL+"/payment-request/2015487")
                                .content(requestJson)
                                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk());
    }
    @Test
    void refresh_status_payment_request_should_be_ok() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(DataGenerator.buildPaymentRequestDto());
        mockMvc.perform(
                        MockMvcRequestBuilders.get(PAYMENT_URL+"/payment-request/2015487/refresh-status")
                                .content(requestJson)
                                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk());
    }
}
