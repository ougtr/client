package ma.axa.outer.bff.website.api;

import ma.axa.outer.bff.website.service.HealthContractService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(HealthContractApi.class)
@ExtendWith(SpringExtension.class)
public class HealthContractApiTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private HealthContractService healthContractService;

    @Test
    void getBenefeciariesOk() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/dabadoc/beneficiaries?policyNumber=333&cin=234589764&cnss=179262699&birthDate=1996-08-09")).andExpect(status().isOk());
    }
}