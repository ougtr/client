package ma.axa.outer.bff.website.mapper;


import ma.axa.outer.bff.website.dto.*;
import ma.axa.outer.bff.website.dto.response.GuaranteesDetailsDto;
import ma.axa.outer.bff.website.dto.response.GuaranteesDto;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class LeadMapperTest {

    @Test
    @DisplayName("Test Mapping Claim Request to Lead Request")
    void serviceMapClaimToLead() {
        LeadRequestDto leadObject = LeadMapper.toLeadRequest(ClaimRequest.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .city("City")
                .emailAddress("Email")
                .city("City")
                .isClient(true)
                .subject("Subject")
                .message("Message").build());
        assertThat(leadObject).isNotNull();
        assertEquals("firstName", leadObject.getFirstName());
        assertEquals("lastName", leadObject.getLastName());
        assertEquals("Phone", leadObject.getPhone());
        assertEquals("City", leadObject.getCity());
        assertEquals("Email", leadObject.getEmail());
        assertEquals("Subject: Subject | Message: Message", leadObject.getDescription());
    }

    @Test
    @DisplayName("Test Mapping Contact Us Request to Lead Request")
    void serviceMapContactUsToLead() {
        LeadRequestDto leadObject = LeadMapper.toLeadRequest(ContactRequest.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .city("City")
                .emailAddress("Email")
                .city("City")
                .subject("Subject")
                .message("Message").build());
        assertThat(leadObject).isNotNull();
        assertEquals("firstName", leadObject.getFirstName());
        assertEquals("lastName", leadObject.getLastName());
        assertEquals("Phone", leadObject.getPhone());
        assertEquals("City", leadObject.getCity());
        assertEquals("Email", leadObject.getEmail());
        assertEquals("Subject: Subject | Message: Message", leadObject.getDescription());
    }

    @Test
    @DisplayName("Test Mapping Call me back Request to Lead Request")
    void serviceMapCallMeBackContactRequest() {
        LeadRequestDto leadObject = LeadMapper.toLeadRequest(CallMeBackContactRequest.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .emailAddress("Email")
                .subject("Subject")
                .message("Message").build());
        assertThat(leadObject).isNotNull();
        assertEquals("firstName", leadObject.getFirstName());
        assertEquals("lastName", leadObject.getLastName());
        assertEquals("Phone", leadObject.getPhone());
        assertEquals("Email", leadObject.getEmail());
        assertEquals("Subject: Subject | Message: Message", leadObject.getDescription());
    }

    @Test
    @DisplayName("Test Mapping PSI Prospect to Lead Request")
    void serviceMapPSILeadRequest() {
        LeadRequestDto leadObject = LeadMapper.toPSILeadRequest(PSIProspectDto.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .emailAddress("Email")
                .cityLabel("City")
                .birthDate("01011995")
                .coveredInUSA(true)
                .liveInMorocco(true)
                .joints(Arrays.asList(new ProspectJointDto("01011990"))).build());
        assertThat(leadObject).isNotNull();
        assertEquals("firstName", leadObject.getFirstName());
        assertEquals("lastName", leadObject.getLastName());
        assertEquals("Phone", leadObject.getPhone());
        assertEquals("Email", leadObject.getEmail());
        assertEquals("City", leadObject.getVille());
        assertEquals("01011995", leadObject.getBirthDate());
        assertEquals(true, leadObject.getCoveredInUSA());
        assertEquals(true, leadObject.getLiveInMorocco());
    }

    @ParameterizedTest
    @ValueSource(strings = {"owner", "tenant","co-owner" })
    @DisplayName("Test Mapping MRH Prospect to Lead Request")
    void serviceMapMRHLeadRequest(String param) {
        LeadRequestDto leadObject = LeadMapper.toMRHLeadRequest(MRHProspectDto.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .emailAddress("Email")
                .propertyNature("propertyNature")
                .propertyType("propertyType")
                .insuredValue("insuredValue")
                .owner(param).build());
        assertThat(leadObject).isNotNull();
        assertEquals("firstName", leadObject.getFirstName());
        assertEquals("lastName", leadObject.getLastName());
        assertEquals("Phone", leadObject.getPhone());
        assertEquals("Email", leadObject.getEmail());
    }

    @ParameterizedTest
    @ValueSource(strings = {"principal", "secondary" })
    @DisplayName("Test Mapping MRH Prospect to Lead Request : nature Bien")
    void serviceMapMRHLeadRequestNature(String param) {
        LeadRequestDto leadObject = LeadMapper.toMRHLeadRequest(MRHProspectDto.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .emailAddress("Email")
                .propertyNature("propertyNature")
                .propertyType("propertyType")
                .insuredValue("insuredValue")
                .propertyNature(param).build());
        assertThat(leadObject).isNotNull();
        assertEquals("firstName", leadObject.getFirstName());
        assertEquals("lastName", leadObject.getLastName());
        assertEquals("Phone", leadObject.getPhone());
        assertEquals("Email", leadObject.getEmail());
    }

    @ParameterizedTest
    @ValueSource(strings = {"house", "appartement", "bungalow", "villa", "duplex" })
    @DisplayName("Test Mapping MRH Prospect to Lead Request : type Bien")
    void serviceMapMRHLeadRequestType(String param) {
        LeadRequestDto leadObject = LeadMapper.toMRHLeadRequest(MRHProspectDto.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .emailAddress("Email")
                .propertyNature("propertyNature")
                .propertyType("propertyType")
                .insuredValue("insuredValue")
                .propertyType(param).build());
        assertThat(leadObject).isNotNull();
        assertEquals("firstName", leadObject.getFirstName());
        assertEquals("lastName", leadObject.getLastName());
        assertEquals("Phone", leadObject.getPhone());
        assertEquals("Email", leadObject.getEmail());
    }

    @Test
    @DisplayName("test Lead mapper")
    void leadMapperTest() {
        LeadRequestDto leadRequestDto = LeadMapper.autoToLeadDto(DataGenerator.quoatationInput());
        assertEquals("John", leadRequestDto.getFirstName());
        assertEquals("Doe", leadRequestDto.getLastName());
        assertEquals("0600112233", leadRequestDto.getPhone());
        assertEquals("Paris", leadRequestDto.getVille());
        assertEquals("", leadRequestDto.getCin());
        assertEquals("1990-01-01", leadRequestDto.getBirthDate());
        assertEquals("2020-01-01", leadRequestDto.getDateMiseEnCirculation());
        assertEquals("Essence", leadRequestDto.getTypeCarburant());

        assertEquals("6", leadRequestDto.getPuissanceFiscale());
        assertEquals(5, leadRequestDto.getNombrePlace());
        assertEquals(25000.00, leadRequestDto.getValeurNeuf());
        assertEquals(17000.00, leadRequestDto.getValeurVenale());
        assertEquals("AB123CD", leadRequestDto.getImmatriculation());
    }

    @ParameterizedTest
    @ValueSource(strings = {"2", "5", "8", "11" })
    void autoUpdateToLeadDtoTest(String val) {
       List<GuaranteesDto> guaranteesDtos = List.of(GuaranteesDto.builder().packName("basic").guarantees(List.of(GuaranteesDetailsDto.builder().code("1").label("c").formules(List.of(RefDataResponse.builder().code("1").label("test").build())).build())).build(),
                GuaranteesDto.builder().packName("basic").guarantees(List.of(GuaranteesDetailsDto.builder().code("33").label("c").formules(List.of(RefDataResponse.builder().code(val).label("test").build())).build())).build(),
                GuaranteesDto.builder().packName("basic").guarantees(List.of(GuaranteesDetailsDto.builder().code("1").label("c").formules(List.of(RefDataResponse.builder().code("1").label("test").build())).build())).build(),
                GuaranteesDto.builder().packName("basic").guarantees(List.of(GuaranteesDetailsDto.builder().code("1").label("c").formules(List.of(RefDataResponse.builder().code("1").label("test").build())).build())).build());


        LeadRequestDto leadRequestDto = LeadMapper.autoUpdateToLeadDto(DataGenerator.quotationDtoData(), guaranteesDtos.get(0), "1235");

        assertEquals("John", leadRequestDto.getFirstName());
        assertEquals("Doe", leadRequestDto.getLastName());
        assertEquals("", leadRequestDto.getCin());
        assertEquals("1990-01-01", leadRequestDto.getBirthDate());
        assertEquals("2020-01-01", leadRequestDto.getDateMiseEnCirculation());
        assertEquals("Essence", leadRequestDto.getTypeCarburant());
        assertEquals("6", leadRequestDto.getPuissanceFiscale());
        assertEquals(5, leadRequestDto.getNombrePlace());
        assertEquals(25000.00, leadRequestDto.getValeurNeuf());
        assertEquals(17000.00, leadRequestDto.getValeurVenale());
        assertEquals("AB123CD", leadRequestDto.getImmatriculation());

    }


    @ParameterizedTest
    @ValueSource(strings = {"B", "C"})
    public void toMRHLeadRequest_withValidInput_returnsCorrectResult(String parameter) {
        // Arrange
        MRHSimulationRequestDto requestDto = new MRHSimulationRequestDto();
        requestDto.setModeAssurance(parameter);
        MRHSimulationResponseDto responseDto = new MRHSimulationResponseDto();
        responseDto.setBuildingCapital(BigDecimal.valueOf(1000));
        responseDto.setContentCapital(BigDecimal.valueOf(500));
        responseDto.setObjectsOfValue(BigDecimal.valueOf(9000));
        responseDto.setTotalPrime(BigDecimal.valueOf(200));

        // Act
        LeadRequestDto result = LeadMapper.toMRHLeadRequest(requestDto, responseDto);

        // Assert
        assertEquals("B".equals(parameter) ? "Bâtiment": "Contenu Mobilier", result.getValeurAssuree());
        assertEquals(BigDecimal.valueOf(1000), result.getValeurDuBien());
        assertEquals(BigDecimal.valueOf(500), result.getValeurDuMobilier());
        assertEquals(BigDecimal.valueOf(9000), result.getObjetDeValeur());
        assertEquals(Double.valueOf(200), result.getAnnualPremium());
    }
    
    @Test
    @DisplayName("Test toMRHV2LeadRequest with null prospect")
    void testToMRHV2LeadRequestWithNullProspect() {
        assertThrows(NullPointerException.class, () -> {
            LeadMapper.toMRHV2LeadRequest(null);
        });
    }
    
    @Test
    @DisplayName("Test toMRHV2LeadRequest with valid inputs")
    void testToMRHV2LeadRequestValidInputs() {
    	MRHV2ProspectDto prospect = MRHV2ProspectDto.builder()
    	        .lastName("Doe")
    	        .firstName("John")
    	        .phoneNumber("123456789")
    	        .emailAddress("john.doe@example.com")
    	        .city("Paris")
    	        .owner("owner")
    	        .title("Mr.")
    	        .propertyNature("apartment")
    	        .propertyType("villa")
    	        .insuredContentValue("10000")
    	        .insuredValue("20000")
    	        .prime(BigDecimal.valueOf(1200))
    	        .build();
    	
        LeadRequestDto result = LeadMapper.toMRHV2LeadRequest(prospect);

        assertNotNull(result);
        assertEquals("John", result.getFirstName());
        assertEquals("Doe", result.getLastName());
        assertEquals("123456789", result.getPhone());
        assertEquals("john.doe@example.com", result.getEmail());
        assertEquals("Paris", result.getCity());
        assertEquals("Multirisque Habitation", result.getProductCode());
        assertEquals(true, result.getIsSimulator());
        assertEquals("Prospect", result.getStatus());
        assertEquals("Simulateur", result.getLeadSource());
        assertEquals(new BigDecimal("10000"), result.getValeurDuMobilier());
        assertEquals(new BigDecimal("20000"), result.getValeurDuBien());
        assertEquals(1200.0, result.getAnnualPremium());
    }
    
    
    @Test
    @DisplayName("Test toMRHV2LeadRequest with null optional fields using Builder")
    void testToMRHV2LeadRequestNullFields() {
        MRHV2ProspectDto prospect = MRHV2ProspectDto.builder()
            .lastName("Doe")
            .firstName("John")
            .phoneNumber("123456789")
            .emailAddress("john.doe@example.com")
            .city("Paris")
            .prime(new BigDecimal(0))
            .build(); // omitting optional fields such as owner, title, propertyNature, propertyType
        LeadRequestDto result = LeadMapper.toMRHV2LeadRequest(prospect);

        assertNotNull(result);
        assertNull(result.getJeSuis());
        assertNull(result.getNatureDuBien());
        assertNull(result.getTypeDuBien());
        assertNull(result.getValeurDuMobilier());
        assertNull(result.getValeurDuBien());
    }
    
    @Test
    @DisplayName("Test toMRHV2LeadRequest with boundary values using Builder")
    void testToMRHV2LeadRequestBoundaryValues() {
        MRHV2ProspectDto prospect = MRHV2ProspectDto.builder()
            .lastName("Doe")
            .firstName("John")
            .phoneNumber("123456789")
            .emailAddress("john.doe@example.com")
            .city("Paris")
            .owner("owner")
            .title("Mr.")
            .propertyNature("apartment")
            .propertyType("villa")
            .insuredContentValue("0")
            .insuredValue("999999999")
            .prime( BigDecimal.ZERO)
            .build();
        LeadRequestDto result = LeadMapper.toMRHV2LeadRequest(prospect);

        assertNotNull(result);
        assertEquals(new BigDecimal("0"), result.getValeurDuMobilier());
        assertEquals(new BigDecimal("999999999"), result.getValeurDuBien());
        assertEquals(0.0, result.getAnnualPremium());
    }

}