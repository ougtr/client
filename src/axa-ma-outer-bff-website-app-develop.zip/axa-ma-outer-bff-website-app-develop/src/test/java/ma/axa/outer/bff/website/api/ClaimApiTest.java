package ma.axa.outer.bff.website.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.ContactRequest;
import ma.axa.outer.bff.website.service.ClaimService;
import ma.axa.outer.bff.website.service.EmailContentProtectionService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ClaimApi.class)
@ExtendWith(SpringExtension.class)
public class ClaimApiTest {
    private static final String CLAIMS_URI = "/v1/claims";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ClaimService claimService;
    @MockBean
    private ICaptchaService captchaService;
    @MockBean
    private EmailContentProtectionService emailContentProtectionService;

    @Test
    void create_claim() throws Exception {
        ContactRequest contactRequest = new ContactRequest();
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(contactRequest);
        mockMvc.perform(
                MockMvcRequestBuilders.post(CLAIMS_URI).param("g-recaptcha-response", "test")
                        .content(requestJson)
                        //.with(csrf())
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isCreated());

    }

}
