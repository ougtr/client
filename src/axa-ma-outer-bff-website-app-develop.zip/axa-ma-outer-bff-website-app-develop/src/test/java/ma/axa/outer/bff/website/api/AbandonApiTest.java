package ma.axa.outer.bff.website.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import ma.axa.outer.bff.website.dto.AbandonRequest;
import ma.axa.outer.bff.website.service.EmailContentProtectionService;
import ma.axa.outer.bff.website.service.AbandonService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AbandonApi.class)
@ExtendWith(SpringExtension.class)
public class AbandonApiTest {
    private static final String ABANDON_URI = "/v1/abandon";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AbandonService abandonService;
    @MockBean
    private EmailContentProtectionService emailContentProtectionService;

    @Test
    void create_abandon() throws Exception {
        AbandonRequest abandonRequest = new AbandonRequest();
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(abandonRequest);
        mockMvc.perform(
                MockMvcRequestBuilders.post(ABANDON_URI)
                        .content(requestJson)
                        //.with(csrf())
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isCreated());

    }

}
