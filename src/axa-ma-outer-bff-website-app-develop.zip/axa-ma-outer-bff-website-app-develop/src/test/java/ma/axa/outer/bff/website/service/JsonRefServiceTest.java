package ma.axa.outer.bff.website.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import ma.axa.outer.bff.website.config.JsonProperties;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class JsonRefServiceTest {

    @Mock
    private JsonProperties jsonProperties;
    @Spy
    ObjectMapper mapper;
    @InjectMocks
    private JsonRefService jsonRefService;



    @Test
    void test_get_assistance_headers() throws Exception {
        assertNotNull(jsonRefService.getAssistanceHeaders());
    }

    @Test
    void test_get_assistance_packs() throws Exception {
        assertNotNull(jsonRefService.getAssistancePack());
    }

    @Test
    void test_get_guarantees_packs() throws Exception {
        assertNotNull(jsonRefService.getGuaranteesPacks());
    }

    @Test
    void test_get_health_product_details()  throws Exception {
        assertNotNull(jsonRefService.getHealthProductOptions());
    }

    @Test
    void test_get_health_product_sehassur_details()  throws Exception {
        assertNotNull(jsonRefService.getSehassurOptionDetails());
    }
}
