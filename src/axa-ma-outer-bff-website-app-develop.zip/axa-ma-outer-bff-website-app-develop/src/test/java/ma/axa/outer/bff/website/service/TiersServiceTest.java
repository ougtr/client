package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.client.InnerTiersProxy;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class TiersServiceTest {
    @Mock
    InnerTiersProxy innerTiersProxy;

    @InjectMocks
    private TiersService tiersService;

    @Test
    @DisplayName("Test service get garages")
    void ServiceGetGarages() throws Exception{
        when(innerTiersProxy.getGaragesList(any(), any(), any())).thenReturn(DataGenerator.garagesListResponseEntity());
        assertNotNull(tiersService.getGaragesList("780", "Garage"));
    }

    @Test
    @DisplayName("Test service get intermediaries")
    void ServiceGetIntermediaries() throws Exception{
        when(innerTiersProxy.getIntermediariesList(any(), any(), any(), any(), any())).thenReturn(DataGenerator.intermediariesListResponseEntity());
        assertNotNull(tiersService.getIntermediariesList("780"));
    }

    @Test
    @DisplayName("Test service get intermediaries")
    void ServiceGetClinicsList() throws Exception{
        when(innerTiersProxy.getSFClinicsList(any(), any())).thenReturn(DataGenerator.ReponseEntitySfClinicsListResponse());
        assertNotNull(tiersService.getClinicsList(null, null));
    }
}
