package ma.axa.outer.bff.website.api;

import ma.axa.outer.bff.website.service.JsonRefService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(RefAutoApi.class)
@ExtendWith(SpringExtension.class)
public class RefAutoApiTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private JsonRefService jsonRefService;

    @Test
    void getAssistanceHeaders_return_success() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/auto/assistance/packs")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }

    @Test
    void getAssistancePack_return_success() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/auto/assistance/details")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }

    @Test
    void getGuaranteesPacks_return_success() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/auto/guarantees/packs")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }
}
