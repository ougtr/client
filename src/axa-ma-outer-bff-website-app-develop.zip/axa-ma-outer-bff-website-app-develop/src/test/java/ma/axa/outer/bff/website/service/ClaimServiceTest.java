package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.dto.ClaimRequest;
import ma.axa.outer.bff.website.mapper.LeadMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class ClaimServiceTest {
    @Mock
    private InnerNotificationProxy innerNotificationProxy;

    @InjectMocks
    private ClaimService claimService;

    @Mock
    private LeadMapper leadMapper;

    @Test
    @DisplayName("Test service save claim")
    void save_claim() throws Exception{
        //when(innerSFDCProxy.createLead(any())).thenReturn(DataGenerator.createLead());
        assertNotNull(claimService.createClaim(new ClaimRequest()));
    }


}
