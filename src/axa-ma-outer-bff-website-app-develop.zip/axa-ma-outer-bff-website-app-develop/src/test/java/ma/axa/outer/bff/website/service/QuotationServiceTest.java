package ma.axa.outer.bff.website.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import ma.axa.outer.bff.website.client.InnerCarQuotationProxy;
import ma.axa.outer.bff.website.client.InnerQuotationProxy;
import ma.axa.outer.bff.website.dto.request.ContratDto;
import ma.axa.outer.bff.website.dto.request.LeadInfos;
import ma.axa.outer.bff.website.dto.request.QuotationDto;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
public class QuotationServiceTest {
    @Mock
    InnerQuotationProxy innerQuotationProxy;

    @Mock
    InnerCarQuotationProxy innerCarQuotationProxy;
    @Mock
    JsonRefService jsonRefService;
    @Mock
    LeadService leadService;
    @Spy
    ObjectMapper mapper;
    @InjectMocks
    private QuotationService quotationService;

    @Test
    void test_create_quotation() throws Exception {
        when(jsonRefService.getGuaranteesPacks()).thenReturn(DataGenerator.getGuaranteesList());
        when(innerCarQuotationProxy.createQuotationAuto(any())).thenReturn(DataGenerator.quotationResponse());
        when(innerCarQuotationProxy.updateQuotation(any(), any())).thenReturn(DataGenerator.quotationResponse());
        when(leadService.saveAutoProspect(any())).thenReturn(DataGenerator.createLead().getBody());
        assertNotNull( quotationService.createQuotation(DataGenerator.quoatationInput()));
    }

    @Test
    void test_update_quotation() throws Exception {
        when(innerCarQuotationProxy.updateQuotation(any(), any())).thenReturn(DataGenerator.quotationResponse());
        when(leadService.updateAutoProspect(any(), any())).thenReturn(DataGenerator.createLead().getBody());
        assertEquals(BigDecimal.valueOf(123), quotationService.updateQuotation(QuotationDto.builder().contrat(ContratDto.builder().build()).leadInfos(LeadInfos.builder().intermediateName("qualif205").build()).idLead("1234").build(), null).getPrimeNetAnnuel());
    }

    @Test
    void test_validate_quotation() throws Exception {
        when(innerCarQuotationProxy.validerQuotation(any(), any())).thenReturn(DataGenerator.validationOutput());
        assertEquals(BigDecimal.valueOf(12345), quotationService.validerQuotation(DataGenerator.validationInput(), BigDecimal.valueOf(11245)).getNumeroDevis());
    }
}
