package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.client.InnerHealthProductProxy;
import ma.axa.outer.bff.website.client.InnerHealthProxy;
import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.dto.response.TarifResponseDto;
import ma.axa.outer.bff.website.dto.request.SehassurPremiumSimulationRequest;
import ma.axa.outer.bff.website.mapper.PsiPremiumMapper;
import ma.axa.outer.bff.website.util.DataGenerator;
import ma.axa.outer.bff.website.util.constants.GlobalConstants;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class HealthServiceTest {
    @Mock
    InnerHealthProxy innerHealthProxy;
    @Mock
    private InnerHealthProductProxy innerHealthProductProxy;
    @Mock
    private PsiPremiumMapper psiPremiumMapper;
    @Mock
    private PSISimulatorService psiSimulatorService;
    @Mock
    private PrintingService printingService;
    @Mock
    private InnerNotificationProxy innerNotificationProxy;
    @Mock
    private HealthProductService healthProductService;
    @Mock
    private QuotationAccessTokenService quotationAccessTokenService;
    @Mock
    private JsonRefService jsonRefService;
    @Mock
    private EmailContentProtectionService emailContentProtectionService;
    @InjectMocks
    private HealthService healthService;

    @Test
    @DisplayName("Test service get prime PSI")
    void test_service_get_prime_psi_ok() throws Exception {
        when(innerHealthProxy.getSimulation(any())).thenReturn(DataGenerator.psiSimulationDataResponseEntity());
        assertThat(healthService.getPsiSimulation(DataGenerator.buildInputPsiSimulationRequest())).isNotNull();

    }

    @Test
    @DisplayName("Test service get premium PSI")
    void test_service_get_premium_psi_ok() throws Exception {
        when(innerHealthProductProxy.getAllProducts(any(), any())).thenReturn(DataGenerator.buildProductData());
        when(innerHealthProxy.createQuotation(any())).thenReturn(DataGenerator.buildPsiQuotationResponse());
        when(innerHealthProxy.createPac(any(), any())).thenReturn(DataGenerator.buildSharedResponse());
        when(innerHealthProxy.calculTarif(any(), any())).thenReturn(DataGenerator.buildTarif());
        when(psiPremiumMapper.toPsiQuotationRequest(any(), any())).thenReturn(DataGenerator.buildPsiQuotationRequest());
        when(psiPremiumMapper.toPacCreationRequest(any())).thenReturn(DataGenerator.buildPacCreationRequest());
        when(psiPremiumMapper.toLeadRequestDto(any())).thenReturn(DataGenerator.buildLeadRequestDto());
        when(psiPremiumMapper.toTarifResponseDto(any(), any(), any())).thenReturn(DataGenerator.buildTarifResponseDto());
        when(psiPremiumMapper.toCalculTarifRequest(any(), any())).thenReturn(DataGenerator.buildCalculTarifRequest());
        when(psiSimulatorService.savePsiProspect(any())).thenReturn(DataGenerator.buildProspectResponseDto());
        when(quotationAccessTokenService.generateHealthQuotationToken(any())).thenReturn("signed-token");
        TarifResponseDto response = healthService.calculatePsiPremium(DataGenerator.buildInputPsiPremiumSimulationRequest());
        assertThat(response).hasFieldOrProperty("premium");
        assertThat(response.getQuotationId()).isEqualTo("signed-token");


    }

    @Test
    @DisplayName("Test service get Sehassur simulation premium")
    void test_service_get_premium_sehassur_ok() throws Exception {
        when(innerHealthProductProxy.getAllProducts(any(), any())).thenReturn(DataGenerator.buildProductData());
        when(innerHealthProxy.createQuotation(any())).thenReturn(DataGenerator.buildPsiQuotationResponse());
        when(innerHealthProxy.calculTarif(any(), any())).thenReturn(DataGenerator.buildTarif());
        when(psiPremiumMapper.toTarifResponseDto(any(), any(), any())).thenReturn(DataGenerator.buildTarifResponseDto());
        when(psiSimulatorService.savePsiProspect(any())).thenReturn(DataGenerator.buildProspectResponseDto());
        when(psiPremiumMapper.toPacCreationRequest(any())).thenReturn(DataGenerator.buildPacCreationRequest());
        when(psiPremiumMapper.toSehassurLeadRequestDto(any())).thenReturn(DataGenerator.buildLeadRequestDto());
        when(innerHealthProxy.createPac(any(), any())).thenReturn(DataGenerator.buildSharedResponse());
        when(innerHealthProxy.updateCapital(any(),any(), any())).thenReturn(DataGenerator.buildSharedResponse());
        when(quotationAccessTokenService.generateSehassurQuotationToken(any())).thenReturn("sehassur-signed-token");
        TarifResponseDto response = healthService.calculateSehassurPremium(DataGenerator.constructSehassurPremiumSimulationRequestData());
        assertThat(response).hasFieldOrProperty("premium");
        assertThat(response.getQuotationId()).isEqualTo("sehassur-signed-token");
    }

    @Test
    @DisplayName("Test add Decease Capital service")
    void test_service_add_decease_capital() throws Exception {
        healthService.addDeathCapital(DataGenerator.buildCapDesDtoRequest());
        verify(innerHealthProxy, times(1)).addCapDes(DataGenerator.buildCapDesDtoRequest());
    }


    @Test
    @DisplayName("Test update Decease Capital service")
    void  test_service_update_diseas_capital() throws  Exception{
        when(innerHealthProxy.updateCapital(any(), any(), any())).thenReturn(DataGenerator.diseasDataResponse());
        assertThat(healthService.updateCapital(new BigDecimal(123), new BigDecimal(1), DataGenerator.diseasData()));
    }




    @Test
    @DisplayName("Test send mail")
    void test_service_send_mail() throws Exception {
        when(printingService.getDevisFile(any())).thenReturn(new ByteArrayResource("data".getBytes(StandardCharsets.UTF_8)));
        when(emailContentProtectionService.toTemplateVariablesJson(any(), any())).thenReturn("{\"name\":\"oualid cherkaoui\"}");
        assertThat(healthService.sendMail("123154", "test@test.com", "oualid cherkaoui")).hasFieldOrProperty("message");
    }

    @Test
    public void testSendSehassurMail_SuccessfulEmail() {
        // Arrange
        String quotationId = "123";
        SehassurPremiumSimulationRequest mockRequest = DataGenerator.constructSehassurPremiumSimulationRequestData();
        when(innerHealthProductProxy.getAllProducts(any(), any())).thenReturn(DataGenerator.buildProductData());
        when(innerHealthProductProxy.getAllProducts(any(), any())).thenReturn(DataGenerator.getAllHealthProductsData());
        when(healthProductService.getAllPacksSehassur()).thenReturn(DataGenerator.getHealthSehassurPacksResponseData());
        when(innerHealthProxy.calculAllFractionTarif(any(), any())).thenReturn(DataGenerator.getHAllFractionTarif());
        when(printingService.getSehassurDevisFile(any())).thenReturn(new ByteArrayResource("data".getBytes(StandardCharsets.UTF_8)));
        when(emailContentProtectionService.toTemplateVariablesJson(any(), any())).thenReturn("{\"name\":\"sehassur\"}");

        // Act
        healthService.sendSehassurMail(quotationId, mockRequest);

        // Assert
        verify(innerNotificationProxy).sendEmail(anyList(), eq(null), eq(GlobalConstants.PSI_MAIL_TEMPLATE),
                eq("simulation PSI"), eq("{\"name\":\"sehassur\"}"),
                eq(null), any(MultipartFile[].class));
    }

    @Test
    public void testSendEmptySehassurMail_SuccessfulEmail() {
        // Arrange
        String quotationId = "123";
        SehassurPremiumSimulationRequest mockRequest = DataGenerator.constructSehassurPremiumSimulationRequestData();
        when(innerHealthProductProxy.getAllProducts(any(), any())).thenReturn(DataGenerator.buildProductData());
        when(innerHealthProductProxy.getAllProducts(any(), any())).thenReturn(DataGenerator.getAllHealthProductsData());
        when(healthProductService.getAllPacksSehassur()).thenReturn(DataGenerator.getHealthSehassurPacksResponseData());
        when(innerHealthProxy.calculAllFractionTarif(any(), any())).thenReturn(DataGenerator.getEmptyFractionTarif());
        when(printingService.getSehassurDevisFile(any())).thenReturn(new ByteArrayResource("data".getBytes(StandardCharsets.UTF_8)));
        when(emailContentProtectionService.toTemplateVariablesJson(any(), any())).thenReturn("{\"name\":\"sehassur\"}");

        // Act
        healthService.sendSehassurMail(quotationId, mockRequest);

        // Assert
        verify(innerNotificationProxy).sendEmail(anyList(), eq(null), eq(GlobalConstants.PSI_MAIL_TEMPLATE),
                eq("simulation PSI"), eq("{\"name\":\"sehassur\"}"),
                eq(null), any(MultipartFile[].class));
    }


}
