package ma.axa.outer.bff.website.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.PsiSimulationRequestDto;
import ma.axa.outer.bff.website.service.QuotationAccessTokenService;
import ma.axa.outer.bff.website.dto.request.PsiPremiumSimulationRequest;
import ma.axa.outer.bff.website.service.EmailContentProtectionService;
import ma.axa.outer.bff.website.service.HealthService;
import ma.axa.outer.bff.website.service.PrintingService;
import ma.axa.outer.bff.website.service.PrintingServiceTest;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.nio.charset.StandardCharsets;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(HealthQuotationApi.class)
@ExtendWith(SpringExtension.class)
public class HealthQuotationApiTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private HealthService healthService;
    @MockBean
    private ICaptchaService captchaService;
    @MockBean
    private PrintingService printingService;
    @MockBean
    private QuotationAccessTokenService quotationAccessTokenService;
    @MockBean
    private EmailContentProtectionService emailContentProtectionService;
    @BeforeEach
    void initMockServices() {
        try {
            when(healthService.getPsiSimulation(any())).thenReturn(DataGenerator.psiSimulationData());
            when(quotationAccessTokenService.extractHealthQuotationId(any())).thenReturn("202300002976");
            when(emailContentProtectionService.sanitizeDisplayName(any(), any())).thenReturn("oualid");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void getPsiPrimeOK() throws Exception {
        PsiSimulationRequestDto anObject = DataGenerator.buildInputPsiSimulationRequest();
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson=ow.writeValueAsString(anObject );
        mockMvc.perform(MockMvcRequestBuilders.post("/v1/health/simulation").content(requestJson).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }

    @Test
    void getPsiPremiumOK() throws Exception {
        PsiPremiumSimulationRequest anObject = DataGenerator.buildPsiPremiumSimulationRequest();
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson=ow.writeValueAsString(anObject );
        mockMvc.perform(MockMvcRequestBuilders.post("/v1/health/calculate-premium").param("g-recaptcha-response", "test").content(requestJson).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }

    @Test
    void getDevisFile() throws Exception {
        when(printingService.getDevisFile(any())).thenReturn(new ByteArrayResource("data".getBytes(StandardCharsets.UTF_8)));
 mockMvc.perform(MockMvcRequestBuilders.get("/v1/health/devis?quotationId=signed-token")).andExpect(status().isOk());
    }

    @Test
    void sendMail() throws Exception{
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/health/send-mail?quotationId=signed-token&mailAddress=ahmedoualid.cherkaoui.externe@axa.ma&name=oualid")).andExpect(status().isOk());
    }
}
