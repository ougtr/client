package ma.axa.outer.bff.website.mapper;


import ma.axa.outer.bff.website.dto.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class EmailMapperTest {

    @Test
    @DisplayName("Test Mapping Claim Request to Email")
    void serviceMapClaimToEmail() {
        EmailDto email = EmailMapper.toEmail(ClaimRequest.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .emailAddress("Email")
                .city("City")
                .subject("Subject")
                .message("Message").build());
        assertThat(email).isNotNull();
        assertEquals(7, email.getVariables().size());
        assertEquals("Réclamation", email.getSubject());
    }

    @Test
    @DisplayName("Test Mapping Contact Us Request  to Email")
    void serviceMapContactUsToLead() {
        EmailDto email = EmailMapper.toEmail(ContactRequest.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .emailAddress("Email")
                .subject("Subject")
                .message("Message").build());
        assertThat(email).isNotNull();
        assertEquals(6, email.getVariables().size());
        assertEquals("Contactez-nous", email.getSubject());
    }

    @Test
    @DisplayName("Test Mapping Call me back Request to Email")
    void serviceMapCallMeBackContactRequest() {
        EmailDto email = EmailMapper.toEmail(CallMeBackContactRequest.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .emailAddress("Email")
                .subject("Subject")
                .message("Message").build());
        assertThat(email).isNotNull();
        assertEquals(6, email.getVariables().size());
        assertEquals("Contactez-moi", email.getSubject());
    }

    @Test
    @DisplayName("Test Mapping Renouvellement Abandon to Email")
    void serviceMapPSILeadRequest() {
        EmailDto email = EmailMapper.toEmail(AbandonRequest.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .emailAddress("Email").build());
        assertThat(email).isNotNull();
        assertEquals(4, email.getVariables().size());
        assertEquals("Abandon de renouvellement", email.getSubject());
    }

}
