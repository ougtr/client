package ma.axa.outer.bff.website.mapper;

import ma.axa.outer.bff.website.dto.LeadRequestDto;
import ma.axa.outer.bff.website.dto.request.*;
import ma.axa.outer.bff.website.dto.response.Product;
import ma.axa.outer.bff.website.dto.response.Tarif;
import ma.axa.outer.bff.website.dto.response.TarifResponseDto;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)

public class PsiPremiumMapperTest {
@InjectMocks
    private PsiPremiumMapper psiPremiumMapper;

    @Test
    @DisplayName("Test Mapping PSI Request")
    void toPsiQuotationRequestTest() {
        PsiQuotationRequest psiQuotationRequest = psiPremiumMapper.toPsiQuotationRequest(PsiPremiumSimulationRequest.builder().
                firstName("oualid").lastName("cherkaoui").birthDate(LocalDate.now()).city("casablanca").pack(PsiSimulationPackRequest.
                builder().packCode("001").franchiseCode("F01").fraction("A").build()).build(), Product.builder().code("0337").build());
        assertThat(psiQuotationRequest).isNotNull();
        assertEquals("A", psiQuotationRequest.getFraction());

    }

    @Test
    @DisplayName("Test Mapping Pac")
    void toPacCreationRequestTest() {
        PacCreationRequest pacCreationRequest = psiPremiumMapper.toPacCreationRequest(DependentsPeopleRequestDto.builder().type("C").birthDate(LocalDate.now()).build());

        assertThat(pacCreationRequest).isNotNull();
        assertEquals("C", pacCreationRequest.getLienParente());
    }

    @Test
    @DisplayName("Test Mapping Premium Request")
    void toCalculTarifRequestTest() {
        CalculTarifRequest calculTarifRequest = psiPremiumMapper.toCalculTarifRequest(PsiQuotationRequest.builder().fraction("A").optionCode("001").franchiseCode("F01").build(), PsiPremiumSimulationRequest.builder().birthDate(LocalDate.now()).build());
        assertThat(calculTarifRequest).isNotNull();
        assertEquals("A",calculTarifRequest.getFraction());
    }

    @Test
    @DisplayName("Test Mapping Lead Request")
    void toLeadRequestDtoTest() {
        LeadRequestDto leadObject = psiPremiumMapper.toLeadRequestDto(PsiPremiumSimulationRequest.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .mail("Email")
                .cityLabel("City").pack(PsiSimulationPackRequest.builder().fraction("A").packCode("001").franchiseCode("F01").build())
                .birthDate(LocalDate.now()).dependents(List.of(DependentsPeopleRequestDto.builder().birthDate(LocalDate.now()).type("C").build())).build());
        assertThat(leadObject).isNotNull();
        assertEquals("firstName", leadObject.getFirstName());
        assertEquals("lastName", leadObject.getLastName());
        assertEquals("Phone", leadObject.getPhone());
        assertEquals("Email", leadObject.getEmail());
        assertEquals("City", leadObject.getVille());
    }

    @Test
    @DisplayName("Test Mapping Tarif")
    void toTarifResponseDtoTest() {
        TarifResponseDto tarifResponseDto = psiPremiumMapper.toTarifResponseDto(Tarif.builder().mntTotal(new BigDecimal(123)).build(), "12345", "12345");
        assertThat(tarifResponseDto).isNotNull();
        assertEquals("123", tarifResponseDto.getPremium());
    }

    @Test
    @DisplayName("Test mapping PsiQuotationRequest")
    void toSehassurQuotationRequest() {
        PsiQuotationRequest psiQuotationRequest = psiPremiumMapper.toSehassurQuotationRequest(SehassurPremiumSimulationRequest.builder().
                firstName("oualid").lastName("cherkaoui").birthDate(LocalDate.now()).city("casablanca").pack(SehassurSimulationPackRequest.
                builder().packCode("001").fraction("A").build()).build(), Product.builder().code("0337").build());
        assertThat(psiQuotationRequest).isNotNull();
        assertEquals("A", psiQuotationRequest.getFraction());
    }

    @Test
    @DisplayName("Test mapping toSehassurCalculTarifRequest")
    void toSehassurCalculTarifRequest() {
        CalculTarifRequest calculTarifRequest = psiPremiumMapper.toSehassurCalculTarifRequest(PsiQuotationRequest.builder().fraction("A").optionCode("001").franchiseCode("F01").disease("T01").build(),
                SehassurPremiumSimulationRequest.builder().birthDate(LocalDate.now()).pack(SehassurSimulationPackRequest.builder().rembRate("T01").packCode("01").disease("B01").rembBase("B01").deathCapital("B01").build()).build());
        assertThat(calculTarifRequest).isNotNull();
        assertEquals("A",calculTarifRequest.getFraction());
    }

    @Test
    @DisplayName("Test Mapping toSehassurLeadRequestDto")
    void toSehassurLeadRequestDto() {
        LeadRequestDto leadObject = psiPremiumMapper.toSehassurLeadRequestDto(SehassurPremiumSimulationRequest.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .mail("Email")
                .cityLabel("City").pack(SehassurSimulationPackRequest.builder().fraction("S").packCode("001").build())
                .birthDate(LocalDate.now()).dependents(List.of(SehassurDependentsRequestDto.builder()
                        .deathCapital("12345")
                        .birthDate(LocalDate.now()).type("C").build())).packLead(PackLead.builder().deathCapitalValue("123").diseaseValue("123").rembBaseValue("123").rembRateValue("90%").build()).build());
        psiPremiumMapper.toSehassurLeadRequestDto(SehassurPremiumSimulationRequest.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .mail("Email")
                .cityLabel("City").pack(SehassurSimulationPackRequest.builder().fraction("A").packCode("001").build())
                .birthDate(LocalDate.now()).dependents(List.of(SehassurDependentsRequestDto.builder().birthDate(LocalDate.now()).type("C").build())).packLead(PackLead.builder().deathCapitalValue("123").diseaseValue("123").rembBaseValue("123").rembRateValue("90%").build()).build());
        psiPremiumMapper.toSehassurLeadRequestDto(SehassurPremiumSimulationRequest.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .mail("Email")
                .cityLabel("City").pack(SehassurSimulationPackRequest.builder().fraction("M").packCode("001").build())
                .birthDate(LocalDate.now()).dependents(List.of(SehassurDependentsRequestDto.builder().birthDate(LocalDate.now()).type("C").build())).packLead(PackLead.builder().deathCapitalValue("123").diseaseValue("123").rembBaseValue("123").rembRateValue("90%").build()).build());
        psiPremiumMapper.toSehassurLeadRequestDto(SehassurPremiumSimulationRequest.builder()
                .firstName("firstName")
                .lastName("lastName")
                .phoneNumber("Phone")
                .mail("Email")
                .cityLabel("City").pack(SehassurSimulationPackRequest.builder().fraction("T").packCode("001").build())
                .birthDate(LocalDate.now()).dependents(List.of(SehassurDependentsRequestDto.builder().birthDate(LocalDate.now()).type("C").build())).packLead(PackLead.builder().deathCapitalValue("123").diseaseValue("123").rembBaseValue("123").rembRateValue("90%").build()).build());
        assertThat(leadObject).isNotNull();
        assertEquals("firstName", leadObject.getFirstName());
        assertEquals("lastName", leadObject.getLastName());
        assertEquals("Phone", leadObject.getPhone());
        assertEquals("Email", leadObject.getEmail());
        assertEquals("City", leadObject.getVille());
    }
}