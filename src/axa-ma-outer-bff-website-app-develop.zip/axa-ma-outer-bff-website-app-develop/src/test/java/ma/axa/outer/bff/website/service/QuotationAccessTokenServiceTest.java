package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.exception.InvalidSignedTokenException;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class QuotationAccessTokenServiceTest {

    private static final String SECRET = "secret";
    private final QuotationAccessTokenService quotationAccessTokenService = new QuotationAccessTokenService();

    QuotationAccessTokenServiceTest() {
        ReflectionTestUtils.setField(quotationAccessTokenService, "secretKey", SECRET);
        ReflectionTestUtils.setField(quotationAccessTokenService, "expirationDurationInSeconds", 300L);
    }

    @Test
    void shouldGenerateAndValidateHealthQuotationToken() {
        String token = quotationAccessTokenService.generateHealthQuotationToken("202300002976");

        assertThat(quotationAccessTokenService.extractHealthQuotationId(token)).isEqualTo("202300002976");
    }

    @Test
    void shouldGenerateAndValidateSehassurQuotationToken() {
        String token = quotationAccessTokenService.generateSehassurQuotationToken("202300002976");

        assertThat(quotationAccessTokenService.extractSehassurQuotationId(token)).isEqualTo("202300002976");
    }

    @Test
    void shouldGenerateAndValidateGreenCardQuotationToken() {
        String token = quotationAccessTokenService.generateGreenCardQuotationToken("202300002976");

        assertThat(quotationAccessTokenService.extractGreenCardQuotationId(token)).isEqualTo("202300002976");
    }

    @Test
    void shouldRejectTamperedHealthQuotationToken() {
        String token = quotationAccessTokenService.generateHealthQuotationToken("202300002976");
        String tamperedToken = token.substring(0, token.length() - 1) + "x";

        assertThatThrownBy(() -> quotationAccessTokenService.extractHealthQuotationId(tamperedToken))
                .isInstanceOf(InvalidSignedTokenException.class)
                .hasMessage("Invalid signed token");
    }

    @Test
    void shouldRejectExpiredHealthQuotationToken() {
        ReflectionTestUtils.setField(quotationAccessTokenService, "expirationDurationInSeconds", -1L);
        String token = quotationAccessTokenService.generateHealthQuotationToken("202300002976");

        assertThatThrownBy(() -> quotationAccessTokenService.extractHealthQuotationId(token))
                .isInstanceOf(InvalidSignedTokenException.class)
                .hasMessage("Expired signed token");
    }

    @Test
    void shouldRejectTokenWithWrongScope() {
        String token = quotationAccessTokenService.generateHealthQuotationToken("202300002976");

        assertThatThrownBy(() -> quotationAccessTokenService.extractSehassurQuotationId(token))
                .isInstanceOf(InvalidSignedTokenException.class)
                .hasMessage("Invalid signed token");
    }

    @Test
    void shouldRejectBlankToken() {
        assertThatThrownBy(() -> quotationAccessTokenService.extractHealthQuotationId(" "))
                .isInstanceOf(InvalidSignedTokenException.class)
                .hasMessage("Invalid signed token");
    }

    @Test
    void shouldRejectMalformedTokenWithoutSeparator() {
        assertThatThrownBy(() -> quotationAccessTokenService.extractHealthQuotationId("abc"))
                .isInstanceOf(InvalidSignedTokenException.class)
                .hasMessage("Invalid signed token");
    }

    @Test
    void shouldRejectTokenWithInvalidPayloadEncoding() {
        String token = "%%%." + sign("%%%");

        assertThatThrownBy(() -> quotationAccessTokenService.extractHealthQuotationId(token))
                .isInstanceOf(InvalidSignedTokenException.class)
                .hasMessage("Invalid signed token");
    }

    @Test
    void shouldRejectTokenWithMissingQuotationId() {
        String token = buildToken("scope=psi:quotation:access\nquotationId=\nexpiresAt=9999999999999");

        assertThatThrownBy(() -> quotationAccessTokenService.extractHealthQuotationId(token))
                .isInstanceOf(InvalidSignedTokenException.class)
                .hasMessage("Invalid signed token");
    }

    @Test
    void shouldRejectTokenWithMissingExpiration() {
        String token = buildToken("scope=psi:quotation:access\nquotationId=202300002976\nexpiresAt=");

        assertThatThrownBy(() -> quotationAccessTokenService.extractHealthQuotationId(token))
                .isInstanceOf(InvalidSignedTokenException.class)
                .hasMessage("Invalid signed token");
    }

    @Test
    void shouldRejectTokenWithInvalidExpirationFormat() {
        String token = buildToken("scope=psi:quotation:access\nquotationId=202300002976\nexpiresAt=invalid");

        assertThatThrownBy(() -> quotationAccessTokenService.extractHealthQuotationId(token))
                .isInstanceOf(InvalidSignedTokenException.class)
                .hasMessage("Invalid signed token");
    }

    private String buildToken(String payload) {
        String encodedPayload = Base64.getUrlEncoder().withoutPadding()
                .encodeToString(payload.getBytes(StandardCharsets.UTF_8));
        return encodedPayload + "." + sign(encodedPayload);
    }

    private String sign(String encodedPayload) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] signature = mac.doFinal(encodedPayload.getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(signature);
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }
}
