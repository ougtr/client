package ma.axa.outer.bff.website.api;

import ma.axa.outer.bff.website.service.TiersService;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(TiersReferentielApi.class)
@ExtendWith(SpringExtension.class)
public class TiersReferentielApiTest {
    private static final String TIERS_REFERENTIEL_URI = "/v1/referentiel";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private TiersService tiersService;

    @BeforeEach
    void initMockServices() {
        try {
            when(tiersService.getGaragesList(anyString(), anyString())).thenReturn(DataGenerator.garagesListResponse());
            when(tiersService.getIntermediariesList(anyString())).thenReturn(DataGenerator.intermediariesList());
            when(tiersService.getClinicsList(anyString(), anyString())).thenReturn(DataGenerator.sfClinicsListResponse());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void get_garages_list() throws Exception {
        mockMvc.perform(
                MockMvcRequestBuilders.get(TIERS_REFERENTIEL_URI+ "/garages")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }

    @Test
    void get_intermediaries_list() throws Exception {
        mockMvc.perform(
                MockMvcRequestBuilders.get(TIERS_REFERENTIEL_URI+ "/intermediaires")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }
    @Test
    void get_clinics_list() throws Exception {
        mockMvc.perform(
                MockMvcRequestBuilders.get(TIERS_REFERENTIEL_URI+ "/cliniques")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }

}
