package ma.axa.outer.bff.website.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import ma.axa.outer.bff.website.client.InnerSFDCProxy;
import ma.axa.outer.bff.website.dto.request.QuotationDto;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class LeadServiceTest {
    @Mock
    InnerSFDCProxy innerSFDCProxy;
    @Spy
    ObjectMapper mapper;
    @Mock
    JsonRefService jsonRefService;

    @InjectMocks
    LeadService leadService;

    @BeforeEach
    public void initiate() {
        when(innerSFDCProxy.createLead(any())).thenReturn(DataGenerator.createLead());
        when(innerSFDCProxy.updateLead(any(), any())).thenReturn(DataGenerator.createLead());
    }

    @Test
    void test_create_lead_service() throws Exception {
        when(jsonRefService.getGuaranteesPacks()).thenReturn(DataGenerator.getGuaranteesList());
        assertEquals("123", leadService.saveAutoProspect(DataGenerator.quoatationInput()).getId());
        assertEquals("123", leadService.updateAutoProspect(DataGenerator.quotationDtoData(), "12345").getId());

    }
}
