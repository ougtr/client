package ma.axa.outer.bff.website.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.client.InnerPcProductProxy;
import ma.axa.outer.bff.website.client.InnerPrintingProxy;
import ma.axa.outer.bff.website.client.InnerQuotationProxy;
import ma.axa.outer.bff.website.client.InnerSFDCProxy;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.MRHProspectDto;
import ma.axa.outer.bff.website.dto.MRHSimulationRequestDto;
import ma.axa.outer.bff.website.dto.MRHV2ProspectDto;
import ma.axa.outer.bff.website.dto.quotation.MrhMinimalistSimulationResponse;
import ma.axa.outer.bff.website.dto.quotation.request.MrhMinimalistSimulationRequest;
import ma.axa.outer.bff.website.exception.GlobalException;
import ma.axa.outer.bff.website.mapper.LeadMapper;
import ma.axa.outer.bff.website.util.DataGenerator;

@ExtendWith(MockitoExtension.class)
public class MRHSimulatorServiceTest {
    @Mock
    private InnerSFDCProxy innerSFDCProxy;

    @Mock
    private InnerQuotationProxy innerQuotationProxy;
    
    @Mock
    private  InnerPcProductProxy innerPcProductProxy;

    @InjectMocks
    private MRHSimulatorService mrhSimulatorService;

    @Mock
    private LeadMapper leadMapper;
    
    @Mock
    private InnerPrintingProxy innerPrintingProxy;
    
    @Mock
    private InnerNotificationProxy innerNotificationProxy;
    @Mock
    private EmailContentProtectionService emailContentProtectionService;

    @Test
    @DisplayName("Test service save prospect")
    void save_prospect() throws Exception{
        when(innerSFDCProxy.createLead(any())).thenReturn(DataGenerator.createLead());
        assertNotNull(mrhSimulatorService.saveProspect(new MRHProspectDto()));
    }
    @Test
    @DisplayName("Test service update prospect")
    void update_prospect() throws Exception{
        when(innerSFDCProxy.updateLead(any(), any())).thenReturn(DataGenerator.createLead());
        assertNotNull(mrhSimulatorService.updateProspect(DataGenerator.constructMRHProspect()));
    }

    @Test
    void Should_Throw_Exception_Id_Null() {
        GlobalException thrown = assertThrows(GlobalException.class, () -> mrhSimulatorService.updateProspect(new MRHProspectDto()));
        assertEquals("Lead Id cannot be null", thrown.getType());
    }
    @Test
    @DisplayName("Test service getMRHSimulation")
    void getMRHSimulation() throws Exception{
        when(innerQuotationProxy.getSimulation(any())).thenReturn(DataGenerator.getSimulationResponse());
        when(innerSFDCProxy.updateLead(any(), any())).thenReturn(DataGenerator.createLead());
        assertNotNull(mrhSimulatorService.getMRHSimulation(MRHSimulationRequestDto.builder().leadId("31233").build()));
    }
    @Test
    @DisplayName("Test service getMRHCapitalList")
    void getMRHCapitalList() throws Exception{
        when(innerQuotationProxy.getMRHCapitalList()).thenReturn(DataGenerator.getMRHCapitalListResponse());
        assertNotNull(mrhSimulatorService.getMRHCapitalList());
    }
    
    @Test
    @DisplayName("Test tarification with null request throws IllegalArgumentException")
    void testTarificationWithNullRequest() {
        assertThrows(IllegalArgumentException.class, () -> mrhSimulatorService.tarification(null),
                     "Expected to throw IllegalArgumentException when request is null");
    }
    
    @Test
    @DisplayName("Test successful tarification process")
    void testSuccessfulTarification() throws Exception {
        MrhMinimalistSimulationRequest request = DataGenerator.buildMrhMinimalistSimulationRequest(); // Populate with necessary fields
        //ContratMrh contrat = DataGenerator.buildContratMrh();
        //AvenantData avenant = AvenantData.builder().intermediaryCode("0").utilisateur("").step(0).build();
        //QuotationMrhRequest quotationRequest = DataGenerator.buildInputQuotationMrh();
        when(innerPcProductProxy.getTypeOccupants(any())).thenReturn(DataGenerator.getTypeOccupantsResponse());
   	 	when(innerPcProductProxy.getTypeHabitations(any())).thenReturn(DataGenerator.getTypeHabResponse());
        when(innerSFDCProxy.updateLead(any(), any())).thenReturn(DataGenerator.createLead());
        when(innerQuotationProxy.getGaranties(any(), any(),any())).thenReturn(DataGenerator. getGarantiesReponse());
        when(innerQuotationProxy.createQuotation(any())).thenReturn(DataGenerator.createOrUpdateQuotationMrhResponse());
        when(innerQuotationProxy.calculePrimeMrh(any(), any())).thenReturn(DataGenerator.calculatePrice());

        MrhMinimalistSimulationResponse response = mrhSimulatorService.tarification(request);
        
        assertNotNull(response);
        assertEquals(new BigDecimal("1205478"), response.getIdQuotation());
        request.setIdQuotation(new BigDecimal("1205478"));
        
        response = mrhSimulatorService.tarification(request);
        assertNotNull(response);
        assertEquals(new BigDecimal("1205478"), response.getIdQuotation());
        
        request.getMrhProspect().setLeadId("");
        response = mrhSimulatorService.tarification(request);
        assertNotNull(response);

    }
    
    @Test
	@DisplayName("Test service create quotation ok ")
    void create_mrh_quotation_ok(){
    	 when(innerQuotationProxy.createQuotation(any())).thenReturn(DataGenerator.createOrUpdateQuotationMrhResponse());
    	 assertThat(mrhSimulatorService.createMrhQuotation(DataGenerator.buildInputQuotationMrh())).isNotNull() ;
    }
    
    @Test
	@DisplayName("Test service get garanties ok ")
    void get_Garanties_ok(){
    	 when(innerQuotationProxy.getGaranties(BigDecimal.valueOf(10000),LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")),"")).thenReturn(DataGenerator.getGarantiesReponse());
    	 assertThat(mrhSimulatorService.getGaranties(BigDecimal.valueOf(10000)).getPack().getGaranties()).isNotNull() ;
    }
    
    @Test
	@DisplayName("Test service get Type Occupants ok ")
    void get_TypeOccupants_ok(){
    	 when(innerPcProductProxy.getTypeOccupants(any())).thenReturn(DataGenerator.getTypeOccupantsResponse());
    	 assertThat(mrhSimulatorService.getTypeOccupants()).hasSize(3) ;
    }
    
    @Test
	@DisplayName("Test service get Type Habitations ok ")
    void get_TypeHabitations_ok(){
    	 when(innerPcProductProxy.getTypeHabitations(any())).thenReturn(DataGenerator.getTypeHabResponse());
    	 assertThat(mrhSimulatorService.getTypeHabitations()).hasSize(3) ;
    }
    
    @Test
    @DisplayName("Test service save prospect")
    void save_saveProspectV2() throws Exception{
        when(innerSFDCProxy.createLead(any())).thenReturn(DataGenerator.createLead());
        assertNotNull(mrhSimulatorService.saveProspectV2(new MRHV2ProspectDto()));
    }
    
    @Test
    @DisplayName("Test successful MRH Devis generation")
    void testGetMRHDevisSuccess() {
        // Given
    	when(innerPcProductProxy.getTypeOccupants(any())).thenReturn(DataGenerator.getTypeOccupantsResponse());
   	 	when(innerPcProductProxy.getTypeHabitations(any())).thenReturn(DataGenerator.getTypeHabResponse());
        MrhMinimalistSimulationRequest request = new MrhMinimalistSimulationRequest(); // appropriately initialized
        request.setMrhProspect(new MRHV2ProspectDto()); // ensure this is not null to avoid exception
        request.setIdQuotation(BigDecimal.valueOf(12345));
        request.setTypeHabitation("3");
        request.setTypeOccupant("3");
        request.setValeurBatiment("10000");

        when(innerQuotationProxy.getGaranties(any(), any(),any())).thenReturn(DataGenerator. getGarantiesReponse());

        Resource expectedResource = Mockito.mock(Resource.class);
        when(innerPrintingProxy.printMrhDevis(any())).thenReturn(new ResponseEntity<>(expectedResource, HttpStatus.OK));

        // When
        Resource actualResource = mrhSimulatorService.getMRHDevis(request);

        // Then
        assertNotNull(actualResource);
        Mockito.verify(innerQuotationProxy,  Mockito.times(1)).getGaranties(any(), any(),any());
        Mockito.verify(innerPrintingProxy,  Mockito.times(1)).printMrhDevis(any());
    }
    
    @Test
    @DisplayName("Test MRH Devis generation throws exception when prospect is null")
    void testGetMRHDevisThrowsException() {
        // Given
        MrhMinimalistSimulationRequest request = new MrhMinimalistSimulationRequest(); // appropriately initialized
        request.setMrhProspect(null); // set to null to trigger the exception

        // When & Then
        assertThrows(GlobalException.class, () -> mrhSimulatorService.getMRHDevis(request));
    }
    
    @Test
    @DisplayName("Test successful MRH Devis email sending")
    void testSendMrhDevisMailSuccess() throws IOException {
        // Given
        MrhMinimalistSimulationRequest request = DataGenerator.buildMrhMinimalistSimulationRequest();
        request.setIdQuotation(new BigDecimal(1));
      

        
        
        when(innerPcProductProxy.getTypeOccupants(any())).thenReturn(DataGenerator.getTypeOccupantsResponse());
   	 	when(innerPcProductProxy.getTypeHabitations(any())).thenReturn(DataGenerator.getTypeHabResponse());
   	 	when(innerQuotationProxy.getGaranties(any(), any(),any())).thenReturn(DataGenerator. getGarantiesReponse());

   	 	Resource expectedResource = Mockito.mock(Resource.class);
   	 	ByteArrayInputStream bais = new ByteArrayInputStream("PDF content".getBytes());
   	 	when(expectedResource.getInputStream()).thenReturn(bais);
   	 	when(innerPrintingProxy.printMrhDevis(any())).thenReturn(new ResponseEntity<>(expectedResource, HttpStatus.OK));
        when(emailContentProtectionService.toTemplateVariablesJson(any(), any())).thenReturn("{\"name\":\"mrh\"}");
   	 	
   	 	//Resource mockFile = Mockito.mock(Resource.class);
   	 	//when(mrhSimulatorService.getMRHDevis(request)).thenReturn(mockFile);
   	 	
   	 	
        // When
        ApiMessageWrapper result = mrhSimulatorService.sendMrhDevisMail(request);

        // Then
        assertNotNull(result);
        assertEquals("OK", result.getMessage());
        
    }

}
