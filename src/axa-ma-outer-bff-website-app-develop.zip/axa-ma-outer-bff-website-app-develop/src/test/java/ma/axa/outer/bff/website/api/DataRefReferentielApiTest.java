package ma.axa.outer.bff.website.api;

import ma.axa.outer.bff.website.service.ReferentialService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(DataRefReferentielApi.class)
@ExtendWith(SpringExtension.class)
public class DataRefReferentielApiTest {
    private static final String REFERENTIAL_ENDPOINT_URI = "/v1/referentiel";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ReferentialService refentialService;

    @Test
    void getCities_return_success() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get(REFERENTIAL_ENDPOINT_URI + "/cities")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }

    @Test
    void getBrands_test() throws  Exception {
        mockMvc.perform(MockMvcRequestBuilders.get(REFERENTIAL_ENDPOINT_URI + "/brands")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }

    @Test
    void getFuel_test() throws  Exception {
        mockMvc.perform(MockMvcRequestBuilders.get(REFERENTIAL_ENDPOINT_URI + "/fuel")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }

}
