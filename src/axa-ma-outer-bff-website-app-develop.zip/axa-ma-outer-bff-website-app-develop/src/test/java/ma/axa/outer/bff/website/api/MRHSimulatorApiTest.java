package ma.axa.outer.bff.website.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.MRHProspectDto;
import ma.axa.outer.bff.website.dto.MRHSimulationRequestDto;
import ma.axa.outer.bff.website.dto.MRHV2ProspectDto;
import ma.axa.outer.bff.website.dto.PSIProspectDto;
import ma.axa.outer.bff.website.dto.ProspectResponseDto;
import ma.axa.outer.bff.website.dto.RefDataResponse;
import ma.axa.outer.bff.website.dto.quotation.MrhMinimalistSimulationResponse;
import ma.axa.outer.bff.website.dto.quotation.request.MrhMinimalistSimulationRequest;
import ma.axa.outer.bff.website.service.EmailContentProtectionService;
import ma.axa.outer.bff.website.service.MRHSimulatorService;
import ma.axa.outer.bff.website.util.DataGenerator;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.ByteArrayInputStream;
import java.util.Arrays;
import java.util.List;

@WebMvcTest(MRHSimulatorApi.class)
@ExtendWith(SpringExtension.class)
public class MRHSimulatorApiTest {
    private static final String MRH_SIMULATOR_URI = "/v1/mrh/";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MRHSimulatorService mrhSimulatorService;
    @MockBean
    private ICaptchaService captchaService;
    @MockBean
    private EmailContentProtectionService emailContentProtectionService;
    @Test
    void save_prospect() throws Exception {
        MRHProspectDto mrhProspectDto = new MRHProspectDto();
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(mrhProspectDto);
        mockMvc.perform(
                MockMvcRequestBuilders.post(MRH_SIMULATOR_URI+"prospect")
                        .param("g-recaptcha-response", "test").content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isCreated());
    }

    @Test
    void update_prospect() throws Exception {
        PSIProspectDto psiProspectDto = new PSIProspectDto();
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(psiProspectDto);
        mockMvc.perform(
                MockMvcRequestBuilders.put(MRH_SIMULATOR_URI+"prospect/12345")
                        .param("g-recaptcha-response", "test")
                        .content(requestJson).content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk());

    }

    @Test
    void getMRHSimulation() throws Exception {
        MRHSimulationRequestDto psiProspectDto = new MRHSimulationRequestDto();
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(psiProspectDto);
        mockMvc.perform(
                MockMvcRequestBuilders.post(MRH_SIMULATOR_URI+"/simulation")
                        .content(requestJson).content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk());

    }

    @Test
    void getMRHCapitalList() throws Exception {
        mockMvc.perform(
                MockMvcRequestBuilders.get(MRH_SIMULATOR_URI+"/capitals")
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk());

    }
    
    
    @Test
    void getBuildingTypes() throws Exception {
        List<RefDataResponse> typeHabitations = Arrays.asList(new RefDataResponse ("Villa","1"), new RefDataResponse("Maison","0"));
        Mockito.when(mrhSimulatorService.getTypeHabitations()).thenReturn(typeHabitations);

        mockMvc.perform(MockMvcRequestBuilders.get(MRH_SIMULATOR_URI + "building-types")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk());
    }
    
    @Test
    void getOccupantTypes() throws Exception {
        Mockito.when(mrhSimulatorService.getTypeOccupants()).thenReturn(DataGenerator.getTypesOccupants());

        mockMvc.perform(MockMvcRequestBuilders.get(MRH_SIMULATOR_URI + "occupant-types")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$", hasSize(3)));
    }
    
    @Test
    void getGaranties() throws Exception {
    	
    	Mockito.when(mrhSimulatorService.getGaranties(any())).thenReturn(DataGenerator.listGaranties().getQuotationCouvert());

        mockMvc.perform(MockMvcRequestBuilders.get(MRH_SIMULATOR_URI + "garanties")
                .param("capital", "100000")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON));
    }
    
    @Test
    void createProspectV2() throws Exception {
        Mockito.when(mrhSimulatorService.saveProspectV2(new MRHV2ProspectDto())).thenReturn(new ProspectResponseDto());

        ObjectMapper mapper = new ObjectMapper();
        String requestJson = mapper.writeValueAsString(new MRHV2ProspectDto());

        mockMvc.perform(MockMvcRequestBuilders.post(MRH_SIMULATOR_URI + "prospectV2")
                .content(requestJson)
                .param("g-recaptcha-response", "test-captcha-response")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isCreated());
    }
    
    
    @Test
    void updateProspect() throws Exception {
        MRHV2ProspectDto prospect = new MRHV2ProspectDto();
        prospect.setLeadId("12345");
        ProspectResponseDto responseDto = new ProspectResponseDto();
        Mockito.when(mrhSimulatorService.updateProspectV2(prospect)).thenReturn(responseDto);

        ObjectMapper mapper = new ObjectMapper();
        String requestJson = mapper.writeValueAsString(prospect);

        mockMvc.perform(MockMvcRequestBuilders.put(MRH_SIMULATOR_URI + "prospectV2/12345")
                .content(requestJson)
                .param("g-recaptcha-response", "test-captcha-response")
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk());
    }

    
    @Test
    void calculePrimeMrh() throws Exception {
        // Create a request object and response object
        MrhMinimalistSimulationRequest request = new MrhMinimalistSimulationRequest();
        MrhMinimalistSimulationResponse response = new MrhMinimalistSimulationResponse();

        // Mock the service method to return a specific result when called
        Mockito.when(mrhSimulatorService.tarification(request)).thenReturn(response);

        // Convert request object to JSON
        ObjectMapper mapper = new ObjectMapper();
        String requestJson = mapper.writeValueAsString(request);

        // Perform the POST request
        mockMvc.perform(MockMvcRequestBuilders.post(MRH_SIMULATOR_URI + "tarification")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestJson)
                .param("g-recaptcha-response", "test-captcha-response"))
            .andDo(MockMvcResultHandlers.print())
            .andExpect(MockMvcResultMatchers.status().isOk())
            .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON));
    }
    
    @Test
    public void testSendDevis() throws Exception {
        MrhMinimalistSimulationRequest request = new MrhMinimalistSimulationRequest(); // populate request as needed
        ApiMessageWrapper expectedResponse =  ApiMessageWrapper.builder().message(MRH_SIMULATOR_URI).build(); // ("Success", "Email sent successfully.");

        Mockito.when(mrhSimulatorService.sendMrhDevisMail(any(MrhMinimalistSimulationRequest.class)))
            .thenReturn(expectedResponse);

        ObjectMapper mapper = new ObjectMapper();
        String requestJson = mapper.writeValueAsString(request);
        mockMvc.perform(MockMvcRequestBuilders.post(MRH_SIMULATOR_URI + "send-devis-mail")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestJson).param("g-recaptcha-response", "test-captcha-response"))
            .andExpect(MockMvcResultMatchers.status().isOk())
            .andExpect(status().isOk());
    }

    @Test
    public void testGenerateDevis() throws Exception {
        MrhMinimalistSimulationRequest request = new MrhMinimalistSimulationRequest(); // populate request as needed
        Resource mockResource = Mockito.mock(Resource.class); // create a mock resource as expected response
        Mockito.when(mrhSimulatorService.getMRHDevis(any(MrhMinimalistSimulationRequest.class)))
            .thenReturn(mockResource);
        ByteArrayInputStream inputStream = new ByteArrayInputStream("Mock PDF content".getBytes());
        Mockito.when(mockResource.getInputStream()).thenReturn(inputStream);
        ObjectMapper mapper = new ObjectMapper();
        mockMvc.perform(MockMvcRequestBuilders.post(MRH_SIMULATOR_URI + "/generate-devis-mrh")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(request)))
            .andExpect(status().isOk());
    }
}
