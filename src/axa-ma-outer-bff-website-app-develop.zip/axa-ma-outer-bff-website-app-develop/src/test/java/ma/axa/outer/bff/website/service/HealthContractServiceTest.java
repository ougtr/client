package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.client.HealthContractProxy;
import ma.axa.outer.bff.website.dto.request.BeneficiaryRequestDto;
import ma.axa.outer.bff.website.mapper.HealthContractMapper;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class HealthContractServiceTest {
    @Mock
    private HealthContractProxy healthContractProxy;
    @Mock
    private HealthContractMapper healthContractMapper;
    @InjectMocks
    private HealthContractService healthContractService;

    @BeforeEach
    public void setVariable() {
        ReflectionTestUtils.setField(healthContractService, "sharedSecretKey", "sharedSecretKey");
    }

    @Test
    @DisplayName("Test get beneficiaries")
    void test_get_beneficiaries() throws Exception {
        when(healthContractProxy.getBeneficiaires(any())).thenReturn(DataGenerator.getBeneficiariesData());
        when(healthContractMapper.toBeneficiaireRequest(any())).thenReturn(DataGenerator.toBeneficiaireRequestMapperData());
        when(healthContractMapper.toBeneficiaryDtos(any())).thenReturn(DataGenerator.toBeneficiaryDtosMapperData());
        assertEquals("oualid",healthContractService.getBeneficiariesDetails(BeneficiaryRequestDto.builder().policyNumber("123456").build()).get(0).getFirstName());
    }
}