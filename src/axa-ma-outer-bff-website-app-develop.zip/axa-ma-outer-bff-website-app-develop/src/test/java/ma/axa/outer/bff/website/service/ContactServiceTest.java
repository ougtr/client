package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.dto.CallMeBackContactRequest;
import ma.axa.outer.bff.website.dto.ContactRequest;
import ma.axa.outer.bff.website.mapper.LeadMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class ContactServiceTest {
    @Mock
    private InnerNotificationProxy innerNotificationProxy;

    @InjectMocks
    private ContactService contactService;

    @Mock
    private LeadMapper leadMapper;

    @Test
    @DisplayName("Test service contact us")
    void save_contact_us_data() throws Exception{
        assertNotNull(contactService.contactUs(new ContactRequest()));
    }

    @Test
    @DisplayName("Test service Call me back")
    void call_me_back_test() throws Exception{
        assertNotNull(contactService.callMeBack(new CallMeBackContactRequest()));
    }


}
