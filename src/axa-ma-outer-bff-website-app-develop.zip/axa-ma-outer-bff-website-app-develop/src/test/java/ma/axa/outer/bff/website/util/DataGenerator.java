package ma.axa.outer.bff.website.util;

import lombok.experimental.UtilityClass;
import ma.axa.outer.bff.website.dto.*;
import ma.axa.outer.bff.website.dto.error.ApiError;
import ma.axa.outer.bff.website.dto.payment.cmi.*;
import ma.axa.outer.bff.website.dto.quotation.AvenantData;
import ma.axa.outer.bff.website.dto.quotation.ContratMrh;
import ma.axa.outer.bff.website.dto.quotation.PackMrhDto;
import ma.axa.outer.bff.website.dto.quotation.Primes;
import ma.axa.outer.bff.website.dto.quotation.QuotationCouvertureMrhDto;
import ma.axa.outer.bff.website.dto.quotation.QuotationGarantiesElementsMrhDto;
import ma.axa.outer.bff.website.dto.quotation.QuotationGuarentee;
import ma.axa.outer.bff.website.dto.quotation.QuotationMrhResponse;
import ma.axa.outer.bff.website.dto.quotation.QuotationParamsMrhDto;
import ma.axa.outer.bff.website.dto.quotation.QuotationResponseMrh;
import ma.axa.outer.bff.website.dto.quotation.request.MrhMinimalistSimulationRequest;
import ma.axa.outer.bff.website.dto.quotation.request.QuotationMrhContrat;
import ma.axa.outer.bff.website.dto.quotation.request.QuotationMrhRequest;
import ma.axa.outer.bff.website.dto.request.*;
import ma.axa.outer.bff.website.dto.response.*;
import ma.axa.outer.bff.website.enums.PaymentStatus;
import ma.axa.outer.bff.website.exception.InnerClientException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@UtilityClass
public class DataGenerator {

    public static GaragesListResponseDto garagesListResponse() {
        List<GaragesResponseDto> garages = List.of(GaragesResponseDto.builder().address("Rue xxx").city("ouarzazate").RS("CHERKAOUI Garages").phoneNumber("0666666666").build(),
                GaragesResponseDto.builder().address("Rue xxx").city("khouribga").RS("CHERKAOUI Garages").phoneNumber("0666666666").build()
        );
        return GaragesListResponseDto.builder().totalSize(2).garagesList(garages).build();
    }

    public static ResponseEntity<GaragesListResponseDto> garagesListResponseEntity() {
        return new ResponseEntity<>(garagesListResponse(), HttpStatus.OK);
    }

    public static IntermediariesListDto intermediariesList() {
        List<IntermediariesDto> intermediaries = List.of(IntermediariesDto.builder().intermediaryCode("400").build(), IntermediariesDto.builder().intermediaryCode("500").build());
        return IntermediariesListDto.builder().intermediariesList(intermediaries).totalSize(2).build();
    }

    public static ResponseEntity<IntermediariesListDto> intermediariesListResponseEntity() {
        return new ResponseEntity<>(intermediariesList(), HttpStatus.OK);
    }

    public static ResponseEntity<IntermediariesDto> intermediaryResponseEntity() {
        return new ResponseEntity<>(IntermediariesDto.builder().intermediaryCode("400").address("rue xx").city("casablanca").latitude("3400").longitude("444").mail("test@test.com").phoneNumber("0666666666").name("inter").build(), HttpStatus.OK);
    }

    public static RenewalDataResponseDto renewalDataResponse() {
        return RenewalDataResponseDto.builder().idQuotation("12345").contractInfos(RenewalContract.builder().intermediaryCode("123").build()).build();
    }

    public static ResponseEntity<RenewalDataResponseDto> renewalDataResponseEntity() {
        return new ResponseEntity<>(renewalDataResponse(), HttpStatus.OK);
    }

    public static List<RefDataResponse> citiesResponse() {
        return List.of(RefDataResponse.builder().code("10").label("AGADIR").build(),
                RefDataResponse.builder().code("945").label("CASA AEROPORT").build(),
                RefDataResponse.builder().code("938").label("CASA AIN SEBAA").build());
    }

    public static ProspectResponseDto buildProspectResponseDto() {
        return ProspectResponseDto.builder().leadId("134").build();
    }

    public static ResponseEntity<List<RefDataResponse>> citiesResponseEntity() {
        return new ResponseEntity<>(citiesResponse(), HttpStatus.OK);
    }

    public static SFClinicsListDto sfClinicsListResponse() {
        ArrayList<SFClinicsDto> clinics = new ArrayList<>();
        SFClinicsDto c1 = SFClinicsDto.builder().address("rue arcachon").city("oued zem").name("oualid").phone("0666666666").build();
        SFClinicsDto c2 = SFClinicsDto.builder().address("rue arcachon").city("casablanca").name("oualid").phone("0666666666").build();
        clinics.add(c1);
        clinics.add(c2);
        return SFClinicsListDto.builder().clinicsList(clinics).totalSize(2).build();
    }

    public static ResponseEntity<SFClinicsListDto> ReponseEntitySfClinicsListResponse() {
        return new ResponseEntity<>(sfClinicsListResponse(), HttpStatus.OK);
    }

    public static ResponseEntity<LeadResponseDto> createLead() {
        return new ResponseEntity<>(LeadResponseDto.builder().id("123").build(), HttpStatus.OK);
    }

    public static LeadRequestDto buildLeadRequestDtoPsi() {
        return LeadRequestDto.builder().firstName("oualid").build();
    }

    public static ResponseEntity<ApiMessageWrapper> generateOTO() {
        return new ResponseEntity<>(ApiMessageWrapper.builder().message("OTP CREATED").build(), HttpStatus.OK);
    }

    public static InnerClientException generateExistingOTO() {
        InnerClientException exception = new InnerClientException("", ApiError.builder().type("{\n" +
                "    \"type\": \"An existant OTP still valid!\",\n" +
                "    \"title\": \"Bad Request\",\n" +
                "    \"detail\": \"BE-STILLVALID\",\n" +
                "    \"instance\": null,\n" +
                "    \"status\": 400,\n" +
                "    \"errors\": null\n" +
                "}").status(400).build());
        return exception;
    }

    public static PsiSimulationResponseDto psiSimulationData() {
        PsiOfferResponseDto standard = PsiOfferResponseDto.builder().description("test").prime("12132").threshold("13132").build();
        PsiOfferResponseDto comprehensive = PsiOfferResponseDto.builder().description("test").prime("12132").threshold("13132").build();
        PsiOfferResponseDto prestige = PsiOfferResponseDto.builder().description("test").prime("12132").threshold("13132").build();
        PsiOfferResponseDto prestigePlus = PsiOfferResponseDto.builder().description("test").prime("12132").threshold("13132").build();

        return PsiSimulationResponseDto.builder().comprehensive(comprehensive).prestige(prestige).prestigePlus(prestigePlus).standard(standard).build();
    }

    public static ResponseEntity<PsiSimulationResponseDto> psiSimulationDataResponseEntity() {
        return new ResponseEntity<>(psiSimulationData(), HttpStatus.OK);
    }

    public static ResponseEntity<List<Product>> buildProductData() {
        return new ResponseEntity<>(List.of(Product.builder().code("0337").build()), HttpStatus.OK);
    }

    public static ResponseEntity<Tarif> buildTarif() {
        return new ResponseEntity<>(Tarif.builder().mntTotal(new BigDecimal(12345)).build(), HttpStatus.OK);
    }

    public static PsiQuotationRequest buildPsiQuotationRequest() {
        return PsiQuotationRequest.builder().franchiseCode("F01").optionCode("001").fraction("A").build();
    }

    public static PacCreationRequest buildPacCreationRequest() {
        return PacCreationRequest.builder().nom("cherkaoui").build();
    }

    public static LeadRequestDto buildLeadRequestDto() {
        return LeadRequestDto.builder().firstName("oualid").build();
    }

    public static TarifResponseDto buildTarifResponseDto() {
        return TarifResponseDto.builder().premium("2122").build();
    }

    public static CalculTarifRequest buildCalculTarifRequest() {
        return CalculTarifRequest.builder().franshise("F01").option("001").build();
    }

    public static CapDesDtoRequest buildCapDesDtoRequest() {
        return CapDesDtoRequest.builder().capdes("C01").build();
    }

    public static ResponseEntity<PsiQuotationResponse> buildPsiQuotationResponse() {
        return new ResponseEntity<>(PsiQuotationResponse.builder().idQuotation("12345").build(), HttpStatus.OK);
    }

    public static ResponseEntity<SharedResponse> buildSharedResponse() {
        return new ResponseEntity<>(SharedResponse.builder().cotationId(new BigDecimal(1345)).build(), HttpStatus.OK);
    }

    public static PsiSimulationRequestDto buildInputPsiSimulationRequest() {
        return PsiSimulationRequestDto.builder().assuredInUsa(true).birthdates(List.of("1999-03-05", "1569-12-30")).build();
    }

    public static PsiPremiumSimulationRequest buildInputPsiPremiumSimulationRequest() {
        return PsiPremiumSimulationRequest.builder().pack(PsiSimulationPackRequest.builder().fraction("M").build()).firstName("oualid").dependents(List.of(DependentsPeopleRequestDto.builder().type("C").build())).build();
    }

    public static PsiPremiumSimulationRequest buildPsiPremiumSimulationRequest() {
        return PsiPremiumSimulationRequest.builder().firstName("oualid").build();
    }

    public static RenewalContractValidationInput renewalContractValidationInputRequest() {
        return RenewalContractValidationInput.builder().paymentMode("test").idQuotation("test").phoneNumber("test").shippingMode("test").shippingAddress("test").shippingCity("test").build();
    }

    public static ResponseEntity<ApiMessageWrapper> innerQuotationContractValidation() {
        return new ResponseEntity<>(ApiMessageWrapper.builder().message("ok").build(), HttpStatus.OK);
    }

    public static PSIProspectDto constructPSIProspect() {
        PSIProspectDto prospect = new PSIProspectDto();
        prospect.setLeadId("123456");
        prospect.setJoints(Arrays.asList(new ProspectJointDto("123456")));
        return prospect;
    }

    public static MRHProspectDto constructMRHProspect() {
        MRHProspectDto prospect = new MRHProspectDto();
        prospect.setLeadId("123456");
        return prospect;
    }

    public static ResponseEntity<MRHSimulationResponseDto> getSimulationResponse() {
        return new ResponseEntity<>(MRHSimulationResponseDto.builder().totalPrime(BigDecimal.ONE).buildingCapital(BigDecimal.ONE).build(), HttpStatus.OK);
    }

    public static ResponseEntity<List<PublicCapitalDto>> getMRHCapitalListResponse() {
        return new ResponseEntity<>(Arrays.asList(PublicCapitalDto.builder().buildingCapital(BigDecimal.ONE).build()), HttpStatus.OK);
    }

    public static ResponseEntity<List<RefDataResponse>> brandsVehicle() {
        return new ResponseEntity<>(List.of(RefDataResponse.builder().code("a").label("b").build()), HttpStatus.OK);
    }

    public static List<FuelDto> fuelData() {
        return List.of(FuelDto.builder().label("Essence").code("E").build());
    }

    public static ResponseEntity<PrimeDto> quotationResponse() {
        return new ResponseEntity<>(PrimeDto.builder().primeNetAnnuel(BigDecimal.valueOf(123)).primeTotaleAnnuel(BigDecimal.valueOf(123)).idLead("12").primeTotaleComptant(BigDecimal.valueOf(123)).build(), HttpStatus.OK);
    }

    public static AllQuotationsDto quoatationInput() {
        ContratDto contratDto = ContratDto.builder()
                .identifiant("1234AB")
                .nom("Doe")
                .prenom("John")
                .dateNaissanceAssure("01-01-1990")
                .codeIntermediaire(BigDecimal.valueOf(123))
                .build();

        VehiculeQuotationDto vehiculeQuotationDto = VehiculeQuotationDto.builder()
                .energie('D')
                .puissanceFiscale(6)
                .codeMarque(1)
                .nombrePlace(5)
                .dateMisCirculation("01-01-2020")
                .valeurNeuf(BigDecimal.valueOf(25000.00))
                .valeurVenale(BigDecimal.valueOf(17000.00))
                .matricule("AB123CD")
                .build();

        LeadInfos leadInfos = LeadInfos.builder()
                .phoneNumber("0600112233")
                .city("Paris")
                .licenceDate("2010-05-01")
                .build();

        AllQuotationsDto allQuotationsDto = AllQuotationsDto.builder()
                .contrat(contratDto)
                .vehicule(vehiculeQuotationDto)
                .leadInfos(leadInfos)
                .build();
        return allQuotationsDto;
    }

    public static QuotationDto quotationDtoData() {
        ContratDto contratDto = ContratDto.builder()
                .identifiant("1234AB")
                .nom("Doe")
                .prenom("John")
                .dateNaissanceAssure("01-01-1990")
                .codeIntermediaire(BigDecimal.valueOf(123))
                .build();

        VehiculeQuotationDto vehiculeQuotationDto = VehiculeQuotationDto.builder()
                .energie('D')
                .puissanceFiscale(6)
                .codeMarque(1)
                .nombrePlace(5)
                .dateMisCirculation("01-01-2020")
                .valeurNeuf(BigDecimal.valueOf(25000.00))
                .valeurVenale(BigDecimal.valueOf(17000.00))
                .matricule("AB123CD")
                .build();

        QuotationDto allQuotationsDto = QuotationDto.builder()
                .contrat(contratDto)
                .vehicule(vehiculeQuotationDto)
                .garanties(List.of(GarantieDto.builder().typeVehcile(1).codeGarantie(33).formule(2).build()))
                .idPack(2).build();

        return allQuotationsDto;
    }

    public static SehassurPremiumSimulationRequest constructSehassurPremiumSimulationRequestData() {
        return SehassurPremiumSimulationRequest.builder()
                .birthDate(LocalDate.now())
                .mail("email")
                .packLead(PackLead.builder().deathCapitalValue("123").diseaseValue("123").rembBaseValue("123").rembRateValue("90%").build())
                .pack(SehassurSimulationPackRequest.builder().rembRate("T01").packCode("001").disease("B01").rembBase("B01").deathCapital("B01").build())
                .firstName("oualid").dependents(List.of(SehassurDependentsRequestDto.builder().deathCapital("M01").birthDate(LocalDate.now()).type("C").build())).build();
    }

    public static List<GuaranteesDto> getGuaranteesList() {
        return List.of(GuaranteesDto.builder().packName("basic").guarantees(List.of(GuaranteesDetailsDto.builder().code("1").label("c").formules(List.of(RefDataResponse.builder().code("1").label("test").build())).build())).build(),
                GuaranteesDto.builder().packName("basic").guarantees(List.of(GuaranteesDetailsDto.builder().code("1").label("c").formules(List.of(RefDataResponse.builder().code("1").label("test").build())).build())).build(),
                GuaranteesDto.builder().packName("basic").guarantees(List.of(GuaranteesDetailsDto.builder().code("1").label("c").formules(List.of(RefDataResponse.builder().code("1").label("test").build())).build())).build(),
                GuaranteesDto.builder().packName("basic").guarantees(List.of(GuaranteesDetailsDto.builder().code("1").label("c").formules(List.of(RefDataResponse.builder().code("1").label("test").build())).build())).build());
    }

    public static Devis validationInput() {
        return Devis.builder().assure(null).conducteur(null).idQuotation(BigDecimal.valueOf(12345)).infoCNT(null).build();
    }

    public static ResponseEntity<DevisResponse> validationOutput() {
        return new ResponseEntity<>(DevisResponse.builder().numeroDevis(BigDecimal.valueOf(12345)).build(), HttpStatus.OK);
    }

    public static List<OptionDetails> getHealthProductOptionsData() {
        return List.of(OptionDetails.builder().code("001").description("this is a test").carence(CarencePeriod.builder().general("12").build()).build());
    }

    public static List<OptionSehassurDetails> getHealthSehassurOptionsData() {
        return List.of(OptionSehassurDetails.builder().code("001").description("This is a test").build());
    }

    public static ResponseEntity<List<Product>> getAllHealthProductsData() {
        return new ResponseEntity<>(List.of(Product.builder().code("0337").listCapitalMalRedoute(List.of(Capital.builder().code("M01").libelle("50 000").build())).build()), HttpStatus.OK);
    }

    public static ResponseEntity<List<Option>> getHealthOptionData() {
        return new ResponseEntity<>(List.of(Option.builder().code("001").libelleZoneGeo("usa, maroc").libelle("standard").plafondIndividuel(new BigDecimal(1213)).libelleZoneGeo("usa, maroc").ageAssureConjoint(new BigDecimal(70)).ageEnfant(new BigDecimal(14)).build()), HttpStatus.OK);
    }

    public static ResponseEntity<OptionParams> getHealthOptionsParamsData() {
        return new ResponseEntity<>(OptionParams.builder().codeOption("001").listFranchise(List.of(Franchise.builder().code("F001").libelle("franchise1").montant(new BigDecimal(100000)).build())).listBaseRemb(List.of(BaseRembAMC.builder().base(Double.valueOf(12345)).code("01").libelle("test").build())).listTauxRemb(List.of(TauxRembAMC.builder().taux(Double.valueOf(12345)).code("01").libelle("test").build())).listCapitalDeces(List.of(Capital.builder().code("01").libelle("test").mntCapital(Double.valueOf(12345)).build())).build(), HttpStatus.OK);
    }

    public static ResponseEntity<List<Beneficiaire>> getBeneficiariesData() {
        return new ResponseEntity<>(List.of(Beneficiaire.builder().nom("cherkaoui").prenom("oualid").resteTC(new BigDecimal(12)).build()), HttpStatus.OK);
    }

    public static  List<BeneficiaryResponseDto> toBeneficiaryDtosMapperData() {
        return List.of(BeneficiaryResponseDto.builder().firstName("oualid").lastName("Toto")
                .affiliateNumber(BigDecimal.valueOf(123456)).rang(BigDecimal.valueOf(0))
                .build());
    }

    public static BeneficiaireRequest toBeneficiaireRequestMapperData() {
        return BeneficiaireRequest.builder().build();
    }

    public static PacModifCapitalRequest diseasData() {
        return PacModifCapitalRequest.builder().capitalDeces("123").build();
    }

    public static ResponseEntity<SharedResponse> diseasDataResponse() {
        return new ResponseEntity<>(SharedResponse.builder().cotationId(new BigDecimal(123)).build(), HttpStatus.OK);
    }

    public static List<HealthSehassurPacksResponseDto> getHealthSehassurPacksResponseData() {
        return List.of(HealthSehassurPacksResponseDto.builder().code("001").rembRate(List.of(RefDataResponse.builder().code("001").label("80%").build()
                , RefDataResponse.builder().code("002").label("90%").build(), RefDataResponse.builder().code("003").label("95%").build())).build());
    }

    public static ResponseEntity<Map<String, Tarif>> getHAllFractionTarif() {
        Map<String, Tarif> tarrifs  = new HashMap<String, Tarif>() {{
            put("A", Tarif.builder().mntTotal(BigDecimal.TEN).build());
            put("M", Tarif.builder().mntTotal(BigDecimal.TEN).build());
            put("T", Tarif.builder().mntTotal(BigDecimal.TEN).build());
            put("S", Tarif.builder().mntTotal(BigDecimal.TEN).build());
        }};
        return new ResponseEntity<>(tarrifs, HttpStatus.OK);
    }
    public static ResponseEntity<Map<String, Tarif>> getEmptyFractionTarif() {
        Map<String, Tarif> tarrifs  = new HashMap<String, Tarif>();
        return new ResponseEntity<>(tarrifs, HttpStatus.OK);
    }

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static ContratMrh buildContratMrh() {
        LocalDate now = LocalDate.now();
        return ContratMrh.builder()
            .effectDate(now.format(DATE_FORMAT))
            .expirationDate(now.plusYears(1).format(DATE_FORMAT))
            .anniversaryDate(now.plusYears(1).format(DATE_FORMAT))
            .natureHabitation("Apartment") 
            .typeHabitation("Rent") 
            .typeOccupant("Owner") 
            .adresseRisque("123 Main St")
            .localite("Central City")
            .ville("Metropolis")
            .pays("CountryCode") 
            .hasContratAuto(false)
            .numPoliceAuto(BigDecimal.ZERO)
            .hasCompanieAssurance(false) 
            .contratInfoComp(null) 
            .hasDelegBancaire(false) 
            .delegationBancaire(null) 
            .contratSigne(false) 
            .build();
    }
    
    public static QuotationMrhRequest buildInputQuotationMrh() {

		return QuotationMrhRequest.builder()
				.avenant(AvenantData.builder().policyNumber("0").intermediaryCode("205").productCode("22660")
						.subType("1").type("1").step(1).build())
				.capitalAssure(CapitalAssure.builder().valeurBatiment(BigDecimal.valueOf(250000))
						.valeurContenu(BigDecimal.valueOf(32000)).valeurObject(BigDecimal.valueOf(0)).build())
				.idQuotation(BigDecimal.valueOf(13923285))
				.contrat(ContratMrh.builder().effectDate("01-01-2024").expirationDate("31-12-2024")
						.natureHabitation("P").typeHabitation("1").typeOccupant("L")
						.adresseRisque("adresse  RisMLMque 123456").localite("20000").ville("780").pays("212")
						.hasContratAuto(false).numPoliceAuto(BigDecimal.valueOf(0)).build())
				.quotationCouvert(listGaranties().getQuotationCouvert()).build();

	}

	public static QuotationMrhContrat listGaranties() {
		QuotationCouvertureMrhDto quotationCouverture = new QuotationCouvertureMrhDto();
		PackMrhDto packMrhDto = new PackMrhDto();
		packMrhDto.setGaranties(getGaranties());
		quotationCouverture.setPack(packMrhDto);
		QuotationMrhContrat.builder().quotationCouvert(quotationCouverture).build(); 
		return QuotationMrhContrat.builder().quotationCouvert(quotationCouverture).build();
	}

	public static List<QuotationGuarentee> getGaranties() {
		return List.of(QuotationGuarentee.builder().code("G1").label("INCENDIE").technicalElements(getElts()).build());
	}

	public static List<QuotationGarantiesElementsMrhDto> getElts() {
		List<FormuleMrhDto> formules = List.of(FormuleMrhDto.builder().code("G1").disabled(false).label("INCENDIE").build());;
		return List.of(
				QuotationGarantiesElementsMrhDto.builder().formules(formules).code("3").label("INCENDIE- EXPLOSIONS BATIMEN").build(),
				QuotationGarantiesElementsMrhDto.builder().formules(formules).code("7").label("INCENDIE- EXPLOSIONS BATIMEN").build());

	}
	
	
	public static ResponseEntity<QuotationResponseMrh>  createOrUpdateQuotationMrhResponse() {
		  QuotationResponseMrh response =  QuotationResponseMrh.builder().retCode("OK").idQuotation(new BigDecimal("1205478")).parmAvenant(QuotationParamsMrhDto.builder()
				.maxEffectDate("01-01-2024").build()).build() ;
		  return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	public static ResponseEntity<QuotationMrhResponse>  calculatePrice() {
		  return new ResponseEntity<>(QuotationMrhResponse.builder().idQuotation(new BigDecimal("52415")).primesTotals(
					Primes.builder().annualNetPrice(new BigDecimal(201544d)).annualTaxes(new BigDecimal(2016))
							.annualPrice(new BigDecimal(201544d)).build()
					).build(), HttpStatus.OK);
	}
	
	
	public static MrhMinimalistSimulationRequest buildMrhMinimalistSimulationRequest() {
        MrhMinimalistSimulationRequest request = MrhMinimalistSimulationRequest.builder()
                //.idQuotation(new BigDecimal("1205478"))
        		.idQuotation(null)
                .typeHabitation("2,Maison")
                .natureHabitation("P")  // Assuming "P" stands for principal
                .optionnelGarantiesId(Arrays.asList("G1", "G2"))
                .typeOccupant("P")  // Assuming "P" stands for Propriétaire
                .valeurBatiment("500000")
                .valeurContenu("200000")
                .valeurObject("40000")  // Typically this should be calculated as 20% of valeurContenu
                .mrhProspect(MRHV2ProspectDto.builder()  // Assuming MRHV2ProspectDto is similarly set up for builder
                    .firstName("John")
                    .leadId("SFDC1554745")
                    .lastName("Doe")
                    .phoneNumber("1234567890")
                    .emailAddress("john.doe@example.com")
                    .city("Paris")
                    .owner("owner")
                    .title("Mr.")
                    .propertyNature("apartment")
                    .propertyType("villa")
                    .insuredContentValue("200000")
                    .insuredValue("500000")
                    .build())
                .build();

       return request;
    }
	
	public static ResponseEntity<QuotationMrhContrat>  getGarantiesReponse() {
		  return new ResponseEntity<>(listGaranties(), HttpStatus.OK);
	}
	
    public static ResponseEntity<List<RefDataResponse>> getTypeOccupantsResponse() {
    	return new ResponseEntity<>(getTypesOccupants(), HttpStatus.OK) ;
    }
    
    public static List<RefDataResponse> getTypesOccupants() {
    	return List.of(RefDataResponse.builder().code("3").label("Proprietaire").build(),
    			RefDataResponse.builder().code("2").label("Proprietaire").build(),
    			RefDataResponse.builder().code("5").label("Proprietaire").build()) ;
    }
    
    
    public static ResponseEntity<List<RefDataResponse>> getTypeHabResponse() {
    	return new ResponseEntity<>(getTypesHAb(), HttpStatus.OK) ;
    }
    
    public static List<RefDataResponse> getTypesHAb() {
    	return List.of(RefDataResponse.builder().code("3").label("villa").build(),
    			RefDataResponse.builder().code("2").label("appartement").build(),
    			RefDataResponse.builder().code("5").label("riad").build()) ;
    }
    public static PaymentRequestDto buildPaymentRequestDto(){
        return PaymentRequestDto.builder().paymentMode("PEL").quotationId("12054")
                .clientInfo(PaymentClientInfoDto.builder().name("test").build())
                .policyNumber("5464646").build() ;
    }
    public static PaymentRequestBffDto buildPaymentRequestBffDto(){
        return PaymentRequestBffDto.builder().paymentMode("PEL").quotationId("12054")
                .policyNumber("5464646").build() ;
    }
    public static PaymentRequestDetailDto buildPaymentRequestDetailsDto(){
        return PaymentRequestDetailDto.builder().paymentMode("PEL")
                .policyNumber("5464646")
                .clientInfo(PaymentClientInfoDto.builder().name("test").build()).build() ;
    }
    public static PaymentObjectDto buildPaymentResponseDto(){
        return PaymentObjectDto.builder().status(PaymentStatus.CREATED).build() ;
    }
}