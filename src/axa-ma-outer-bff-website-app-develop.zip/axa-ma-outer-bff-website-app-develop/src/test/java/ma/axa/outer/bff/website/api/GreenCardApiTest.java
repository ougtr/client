package ma.axa.outer.bff.website.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import ma.axa.outer.bff.website.captcha.CaptchaService;
import ma.axa.outer.bff.website.client.InnerQuotationProxy;
import ma.axa.outer.bff.website.dto.request.GreenCardDetailsRequest;
import ma.axa.outer.bff.website.dto.request.GreenCardRequest;
import ma.axa.outer.bff.website.dto.response.GreenCardDetailsResponse;
import ma.axa.outer.bff.website.service.GreenCardService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import java.nio.charset.StandardCharsets;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(GreenCardApi.class)
@ExtendWith(SpringExtension.class)
public class GreenCardApiTest {

    private static final String GREEN_CARD_URI = "/v1/green-card";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private GreenCardService greenCardService;

    @MockBean
    private CaptchaService captchaService;

    private ObjectMapper mapper;
    private GreenCardRequest greenCardRequest;
    private Resource resource;

    @BeforeEach
    void setUp() {
        mapper = new ObjectMapper();
        greenCardRequest = new GreenCardRequest();
        resource = new ByteArrayResource("Test test".getBytes(StandardCharsets.UTF_8));
    }

    @Test
    void get_green_card_details_should_return_green_card_details() throws Exception {
        String captchaResponse = "129939493882833";
        String policyNumber = "19392939923433";
        String vehicleNumber = "1834-B -343";
        GreenCardDetailsResponse greenCardResponse = new GreenCardDetailsResponse();
        greenCardResponse.setAssureNom("Test Hello");

        GreenCardDetailsRequest greenCardDetailsRequest = new GreenCardDetailsRequest();
        greenCardDetailsRequest.setPolicyNumber(policyNumber);
        greenCardDetailsRequest.setVehicleImmatNumber(vehicleNumber);

        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(greenCardDetailsRequest);

        doNothing().when(captchaService).processResponse(eq(captchaResponse));
        doReturn(ResponseEntity.ok(greenCardResponse)).when(greenCardService).greenCardDetails(eq(greenCardDetailsRequest));

        mockMvc.perform(MockMvcRequestBuilders.post(GREEN_CARD_URI + "/")
                        .param("g-recaptcha-response", captchaResponse)
                        .content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(jsonPath("$.assureNom", is("Test Hello")))
                .andExpect(status().isOk());

        verify(greenCardService, times(1)).greenCardDetails(eq(greenCardDetailsRequest));
        verify(captchaService, times(1)).processResponse(eq(captchaResponse));
    }

    @Test
    void should_produce_green_card() throws Exception {
        String orderId = "9e8b7014-f7aa-4eac-a129-4c3df83f791d";
        ResponseEntity<Resource> responseEntity = ResponseEntity.ok(resource);
        doReturn(responseEntity).when(greenCardService).launchGreenCardProduction(orderId);
        mockMvc.perform(MockMvcRequestBuilders.post(GREEN_CARD_URI + "/produce/" + orderId))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(content().bytes("Test test".getBytes(StandardCharsets.UTF_8)))
                .andExpect(status().isOk());
        verify(greenCardService, times(1)).launchGreenCardProduction(eq(orderId));

    }

    @Test
    void should_redirect_to_sucess_page() throws Exception {
        String orderId = "9e8b7014-f7aa-4eac-a129-4c3df83f791d";
        mockMvc.perform(MockMvcRequestBuilders.post(GREEN_CARD_URI + "/payment/success?orderId=" + orderId))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isFound());
    }
    @Test
    void should_redirect_to_fail_page() throws Exception {
        String orderId = "9e8b7014-f7aa-4eac-a129-4c3df83f791d";
        mockMvc.perform(MockMvcRequestBuilders.post(GREEN_CARD_URI + "/payment/fail?orderId=" + orderId))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isFound());
    }
}