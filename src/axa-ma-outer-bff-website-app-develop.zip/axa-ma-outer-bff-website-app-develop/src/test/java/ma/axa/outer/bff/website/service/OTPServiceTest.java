package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.dto.OTPRequestDto;
import ma.axa.outer.bff.website.dto.ValidationOTPDto;
import ma.axa.outer.bff.website.exception.ControllerBusinessException;
import ma.axa.outer.bff.website.exception.InnerClientException;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class OTPServiceTest {
    @Mock
    InnerNotificationProxy innerNotificationProxy;

    @InjectMocks
    private OTPService otpService;

    @Test
    @DisplayName("Test service create OTP")
    void create_otp() {
        when(innerNotificationProxy.createOTP(any())).thenReturn(DataGenerator.generateOTO());
        assertNotNull(otpService.generateOTP(new OTPRequestDto()));
    }

    @Test
    @DisplayName("Test service create OTP With Exception")
    void create_otp_existing() {
        when(innerNotificationProxy.createOTP(any())).thenThrow(DataGenerator.generateExistingOTO());
        ControllerBusinessException thrown = assertThrows(ControllerBusinessException.class, () -> otpService.generateOTP(new OTPRequestDto()));
        assertEquals(1, thrown.getApiErrorItem().size());
    }

    @Test
    @DisplayName("Test service validate OTP")
    void validate_otp() {
        when(innerNotificationProxy.validateOTP(any())).thenReturn(DataGenerator.generateOTO());
        assertNotNull(otpService.validateOTP(new ValidationOTPDto()));
    }


}
