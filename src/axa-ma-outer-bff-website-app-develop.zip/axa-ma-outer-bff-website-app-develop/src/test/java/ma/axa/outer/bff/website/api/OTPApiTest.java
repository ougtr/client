package ma.axa.outer.bff.website.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import ma.axa.outer.bff.website.dto.OTPRequestDto;
import ma.axa.outer.bff.website.dto.ValidationOTPDto;
import ma.axa.outer.bff.website.service.OTPService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(OTPApi.class)
@ExtendWith(SpringExtension.class)
public class OTPApiTest {
    private static final String OTP_URI = "/v1/otp";
    private static final String OTP_VALIDATE_URI = "/v1/otp/validate";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OTPService otpService;

    @Test
    void create_otp() throws Exception {
        OTPRequestDto otpRequestDto = new OTPRequestDto("212666666666");
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(otpRequestDto);
        mockMvc.perform(
                MockMvcRequestBuilders.post(OTP_URI)
                        .content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isCreated());

    }

    @Test
    void validate_otp() throws Exception {
        ValidationOTPDto validationOTPDto = new ValidationOTPDto("212666666666", "123456");
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(validationOTPDto);
        mockMvc.perform(
                MockMvcRequestBuilders.post(OTP_VALIDATE_URI)
                        .content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk());

    }

}
