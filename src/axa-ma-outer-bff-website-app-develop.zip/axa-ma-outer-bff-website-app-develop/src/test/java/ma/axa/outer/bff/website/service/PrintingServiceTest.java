package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.client.InnerPrintingProxy;
import ma.axa.outer.bff.website.dto.sehassur.DevisSehassurPrinting;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)

public class PrintingServiceTest {
    @Mock
    private InnerPrintingProxy innerPrintingProxy;

    @InjectMocks
    private PrintingService printingService;

    @Test
    @DisplayName("Test service devis printing")
    void print_devis() throws Exception{
        when(innerPrintingProxy.printDevis(any(), any(), any(), any(), any())).thenReturn(new ResponseEntity<>(new ByteArrayResource("data".getBytes(StandardCharsets.UTF_8)), HttpStatus.OK));
        assertNotNull(printingService.getDevisFile("12345"));
    }

    @Test
    @DisplayName("Test service Sehassur devis printing")
    void print_sehassur_devis() throws Exception{
        when(innerPrintingProxy.printSehassurDevis(any())).thenReturn(new ResponseEntity<>(new ByteArrayResource("data".getBytes(StandardCharsets.UTF_8)), HttpStatus.OK));
        assertNotNull(printingService.getSehassurDevisFile(DevisSehassurPrinting.builder().build()));
    }
}