package ma.axa.outer.bff.website;

import static org.assertj.core.api.Assertions.assertThatNoException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AxaMaOuterBffWebsiteApplicationTests {

	/*@Test
	void contextLoads() {
		// ignore java:S2699
		//assertThatNoException().isThrownBy(() -> System.out.println("Testing"));
	}*/
}
