package ma.axa.outer.bff.website.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.PSIProspectDto;
import ma.axa.outer.bff.website.service.HealthProductService;
import ma.axa.outer.bff.website.service.PSISimulatorService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(PSISimulatorApi.class)
@ExtendWith(SpringExtension.class)
public class PSISimulatorApiTest {
    private static final String PSI_SIMULATOR_URI = "/v1/psi";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PSISimulatorService psiSimulatorService;
    @MockBean
    private ICaptchaService captchaService;
    @MockBean
    private HealthProductService healthProductService;

    @Test
    void save_prospect() throws Exception {
        PSIProspectDto psiProspectDto = new PSIProspectDto();
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(psiProspectDto);
        mockMvc.perform(
                MockMvcRequestBuilders.post(PSI_SIMULATOR_URI + "/prospect")
                        .param("g-recaptcha-response", "test")
                        .content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isCreated());

    }

    @Test
    void update_prospect() throws Exception {
        PSIProspectDto psiProspectDto = new PSIProspectDto();
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(psiProspectDto);
        mockMvc.perform(
                MockMvcRequestBuilders.put(PSI_SIMULATOR_URI + "/prospect/12345")
                        .param("g-recaptcha-response", "test").content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk());

    }

    @Test
    void get_health_product_packs() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get(PSI_SIMULATOR_URI + "/packs").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }
}
