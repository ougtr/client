package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.client.InnerCarQuotationProxy;
import ma.axa.outer.bff.website.client.InnerPaymentCmiProxy;
import ma.axa.outer.bff.website.config.AxaCmiUrlsProps;
import ma.axa.outer.bff.website.dto.payment.cmi.*;
import ma.axa.outer.bff.website.exception.InvalidSignedTokenException;
import ma.axa.outer.bff.website.mapper.GreenCardMapper;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
public class PaymentCmiServiceTest {
    @Mock
    private InnerPaymentCmiProxy innerPaymentProxy ;
    @Mock
    private AxaCmiUrlsProps axaCmiUrlsProps ;
    @InjectMocks
    PaymentCmiService paymentCmiService ;
    @Mock
    GreenCardMapper greenCardMapper ;

    @Mock InnerCarQuotationProxy innerCarQuotationProxy ;
    @Mock QuotationAccessTokenService quotationAccessTokenService ;

    @Test
    public void create_payment_request_should_return_ok( ) {
        String signedQuotationToken = "signed-green-card-token";
        String quotationId = "12054";
        PaymentRequestBffDto paymentRequestBffDto = DataGenerator.buildPaymentRequestBffDto();
        paymentRequestBffDto.setQuotationId(signedQuotationToken);
        PaymentRequestDto paymentRequestDto = DataGenerator.buildPaymentRequestDto();
        paymentRequestDto.setQuotationId(signedQuotationToken);
        when(quotationAccessTokenService.extractGreenCardQuotationId(signedQuotationToken)).thenReturn(quotationId);
        when(innerCarQuotationProxy.getPaymentDetails(any())).thenReturn(GreenCardPaymentDto.builder().totalAmount(new BigDecimal("500.00"))
                        .items(List.of(GreenCardPaymentItemDto.builder().amount(new BigDecimal("500.00")).build()))
                .clientInfo(GreenCardPaymentClientDto.builder().address("casa").build()).build());
          when(innerPaymentProxy.
                  createPaymentRequest(any()))
                  .thenReturn(DataGenerator.buildPaymentResponseDto()) ;
         when(greenCardMapper.mapToPaymentRequestBffDto(any())).thenReturn(paymentRequestDto) ;
          when(greenCardMapper.mapToPaymentClientInfoDto(any())).thenReturn(PaymentClientInfoDto.builder().build()) ;
          var result  = paymentCmiService.createPaymentRequest(paymentRequestBffDto) ;
         assertNotNull(result) ;
         verify(innerCarQuotationProxy).getPaymentDetails(quotationId);
         ArgumentCaptor<PaymentRequestDto> paymentRequestCaptor = ArgumentCaptor.forClass(PaymentRequestDto.class);
         verify(innerPaymentProxy).createPaymentRequest(paymentRequestCaptor.capture());
         assertEquals(quotationId, paymentRequestCaptor.getValue().getQuotationId());
     }

    @Test
    public void create_payment_request_should_reject_invalid_signed_token( ) {
        PaymentRequestBffDto paymentRequestBffDto = DataGenerator.buildPaymentRequestBffDto();
        when(quotationAccessTokenService.extractGreenCardQuotationId(paymentRequestBffDto.getQuotationId()))
                .thenThrow(new InvalidSignedTokenException("Invalid signed token"));

        assertThrows(InvalidSignedTokenException.class, () -> paymentCmiService.createPaymentRequest(paymentRequestBffDto));
        verifyNoInteractions(innerCarQuotationProxy, innerPaymentProxy);
    }
    @Test
    public void get_payment_request_should_return_ok( ) {
        when(innerPaymentProxy.
                fetchPaymentRequest("2514"))
                .thenReturn(DataGenerator.buildPaymentRequestDetailsDto()) ;
        assertNotNull(paymentCmiService.fetchPaymentRequest("2514") ) ;
    }
    @Test
    public void refresh_payment_request_status_should_return_ok( ) {
        when(innerPaymentProxy.
                refreshStatus("2514"))
                .thenReturn(DataGenerator.buildPaymentRequestDetailsDto()) ;
        assertNotNull(paymentCmiService.refreshStatus("2514") ) ;
    }
    @Test
    public void update_payment_request_with_contract_details_should_return_ok( ) {
        when(innerPaymentProxy.
                updatePaymentRequestWithContractDetails(any(),any())).thenReturn(PaymentRequestDetailDto.builder().build())
                .thenReturn(DataGenerator.buildPaymentRequestDetailsDto()) ;
        assertNotNull(paymentCmiService.updatePaymentRequestWithContractDetails(any(),any()) ) ;
    }
}
