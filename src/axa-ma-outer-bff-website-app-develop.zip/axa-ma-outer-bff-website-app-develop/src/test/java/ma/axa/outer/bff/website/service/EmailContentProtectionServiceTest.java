package ma.axa.outer.bff.website.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ma.axa.outer.bff.website.dto.AbandonRequest;
import ma.axa.outer.bff.website.dto.CallMeBackContactRequest;
import ma.axa.outer.bff.website.dto.ClaimRequest;
import ma.axa.outer.bff.website.dto.ContactRequest;
import ma.axa.outer.bff.website.dto.MRHV2ProspectDto;
import ma.axa.outer.bff.website.dto.request.SehassurPremiumSimulationRequest;
import ma.axa.outer.bff.website.dto.quotation.request.MrhMinimalistSimulationRequest;
import ma.axa.outer.bff.website.exception.ControllerBusinessException;
import ma.axa.outer.bff.website.exception.GlobalException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class EmailContentProtectionServiceTest {

    @Mock
    private ObjectMapper objectMapper;

    private final EmailContentProtectionService service = new EmailContentProtectionService(new ObjectMapper());

    @Test
    @DisplayName("sanitize should neutralize links and html in free text")
    void sanitizeShouldNeutralizeLinksInFreeText() {
        ContactRequest request = ContactRequest.builder()
                .firstName("Jean")
                .lastName("Dupont")
                .subject("Question")
                .message("Voir https://evil.test <script>alert(1)</script>\n\n\n   suite")
                .build();

        ContactRequest sanitized = service.sanitize(request);

        assertThat(sanitized.getMessage()).doesNotContain("https://evil.test");
        assertThat(sanitized.getMessage()).contains("[link removed]");
        assertThat(sanitized.getMessage()).doesNotContain("<script>");
        assertThat(sanitized.getMessage()).contains("alert(1)");
        assertThat(sanitized.getMessage()).doesNotContain("\n\n\n");
    }

    @Test
    @DisplayName("sanitize should preserve email addresses and trim spaces")
    void sanitizeShouldPreserveEmailAddresses() {
        ContactRequest request = ContactRequest.builder()
                .firstName("  Jean  ")
                .lastName(" Dupont ")
                .emailAddress("jean.dupont@axa.ma")
                .phoneNumber("\t0600 00 00 00\r\n")
                .subject(" Demande ")
                .message("Bonjour")
                .build();

        ContactRequest sanitized = service.sanitize(request);

        assertThat(sanitized.getEmailAddress()).isEqualTo("jean.dupont@axa.ma");
        assertThat(sanitized.getPhoneNumber()).isEqualTo("0600 00 00 00");
        assertThat(sanitized.getFirstName()).isEqualTo("Jean");
        assertThat(sanitized.getLastName()).isEqualTo("Dupont");
        assertThat(sanitized.getSubject()).isEqualTo("Demande");
    }

    @Test
    @DisplayName("sanitize should keep null strict fields safe")
    void sanitizeShouldKeepNullStrictFieldsSafe() {
        ContactRequest request = ContactRequest.builder()
                .firstName(null)
                .lastName(null)
                .subject(null)
                .message("Bonjour")
                .build();

        ContactRequest sanitized = service.sanitize(request);

        assertThat(sanitized.getFirstName()).isNull();
        assertThat(sanitized.getLastName()).isNull();
        assertThat(sanitized.getSubject()).isNull();
    }

    @Test
    @DisplayName("sanitize call me back should sanitize inline fields")
    void sanitizeCallMeBackShouldSanitizeFields() {
        CallMeBackContactRequest request = CallMeBackContactRequest.builder()
                .firstName("Jean")
                .lastName("Dupont")
                .phoneNumber("0600\r\n01")
                .emailAddress("jean@axa.ma")
                .subject("Question")
                .message("www.evil.test")
                .callHour(" 10h ")
                .callDate(" 2026-06-12 ")
                .build();

        CallMeBackContactRequest sanitized = service.sanitize(request);

        assertThat(sanitized.getMessage()).isEqualTo("[link removed]");
        assertThat(sanitized.getPhoneNumber()).isEqualTo("0600 01");
        assertThat(sanitized.getCallHour()).isEqualTo("10h");
        assertThat(sanitized.getCallDate()).isEqualTo("2026-06-12");
    }


    @Test
    @DisplayName("sanitize abandon should sanitize optional fields")
    void sanitizeAbandonShouldSanitizeFields() {
        AbandonRequest request = AbandonRequest.builder()
                .firstName("Jean")
                .lastName("Dupont")
                .phoneNumber("0600\t00")
                .emailAddress("jean@axa.ma")
                .build();

        AbandonRequest sanitized = service.sanitize(request);

        assertThat(sanitized.getPhoneNumber()).isEqualTo("0600 00");
        assertThat(sanitized.getEmailAddress()).isEqualTo("jean@axa.ma");
    }

    @Test
    @DisplayName("sanitize sehassur email payload should sanitize and preserve functional fields")
    void sanitizeSehassurPayloadShouldSanitizeAndPreserveFields() {
        SehassurPremiumSimulationRequest request = SehassurPremiumSimulationRequest.builder()
                .firstName("Jean")
                .lastName("Dupont")
                .mail("jean@axa.ma")
                .city("Casa")
                .cityLabel("Casablanca")
                .idLead("lead-1")
                .marketingConsent(Boolean.TRUE)
                .cguConsent(Boolean.FALSE)
                .build();

        SehassurPremiumSimulationRequest sanitized = service.sanitizeForEmail(request);

        assertThat(sanitized.getFirstName()).isEqualTo("Jean");
        assertThat(sanitized.getLastName()).isEqualTo("Dupont");
        assertThat(sanitized.getMail()).isEqualTo("jean@axa.ma");
        assertThat(sanitized.getIdLead()).isEqualTo("lead-1");
        assertThat(sanitized.getMarketingConsent()).isTrue();
        assertThat(sanitized.getCguConsent()).isFalse();
    }

    @Test
    @DisplayName("sanitize mrh payload should return null when request is null")
    void sanitizeMrhPayloadShouldReturnNullWhenRequestIsNull() {
        assertNull(service.sanitizeForEmail((MrhMinimalistSimulationRequest) null));
    }

    @Test
    @DisplayName("sanitize mrh payload should return same request when prospect is null")
    void sanitizeMrhPayloadShouldReturnSameRequestWhenProspectIsNull() {
        MrhMinimalistSimulationRequest request = MrhMinimalistSimulationRequest.builder().build();

        assertThat(service.sanitizeForEmail(request)).isSameAs(request);
    }

    @Test
    @DisplayName("sanitize mrh payload should sanitize nested prospect")
    void sanitizeMrhPayloadShouldSanitizeNestedProspect() {
        MrhMinimalistSimulationRequest request = MrhMinimalistSimulationRequest.builder()
                .mrhProspect(MRHV2ProspectDto.builder()
                        .firstName("Jean")
                        .lastName("Dupont")
                        .emailAddress("jean@axa.ma")
                        .phoneNumber("06\t00")
                        .title(" M ")
                        .city(" Casa ")
                        .build())
                .typeHabitation("3")
                .natureHabitation("P")
                .build();

        MrhMinimalistSimulationRequest sanitized = service.sanitizeForEmail(request);

        assertThat(sanitized.getMrhProspect().getPhoneNumber()).isEqualTo("06 00");
        assertThat(sanitized.getMrhProspect().getTitle()).isEqualTo("M");
        assertThat(sanitized.getMrhProspect().getCity()).isEqualTo("Casa");
    }


    @Test
    @DisplayName("toTemplateVariablesJson should escape json-sensitive characters")
    void toTemplateVariablesJsonShouldEscapeValues() {
        String json = service.toTemplateVariablesJson(Map.of("name", "Jean \"QA\""));

        assertThat(json).isEqualTo("{\"name\":\"Jean \\\"QA\\\"\"}");
    }

    @Test
    @DisplayName("toTemplateVariablesJson with key and value should serialize payload")
    void toTemplateVariablesJsonWithKeyAndValueShouldSerializePayload() {
        String json = service.toTemplateVariablesJson("name", "Jean");

        assertThat(json).isEqualTo("{\"name\":\"Jean\"}");
    }

    @Test
    @DisplayName("toTemplateVariablesJson should wrap serialization errors")
    void toTemplateVariablesJsonShouldWrapSerializationErrors() throws Exception {
        EmailContentProtectionService failingService = new EmailContentProtectionService(objectMapper);
        when(objectMapper.writeValueAsString(anyMap())).thenThrow(new JsonProcessingException("boom") { });

        GlobalException exception = assertThrows(GlobalException.class,
                () -> failingService.toTemplateVariablesJson(Map.of("name", "Jean")));

        assertThat(exception.getType()).isEqualTo("Error while serializing email variables");
    }
}
