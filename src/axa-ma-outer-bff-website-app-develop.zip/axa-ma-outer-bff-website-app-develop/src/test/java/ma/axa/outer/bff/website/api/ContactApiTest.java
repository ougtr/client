package ma.axa.outer.bff.website.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.CallMeBackContactRequest;
import ma.axa.outer.bff.website.dto.ContactRequest;
import ma.axa.outer.bff.website.dto.error.ApiErrorItem;
import ma.axa.outer.bff.website.exception.ControllerBusinessException;
import ma.axa.outer.bff.website.service.ContactService;
import ma.axa.outer.bff.website.service.EmailContentProtectionService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ContactApi.class)
@ExtendWith(SpringExtension.class)
public class ContactApiTest {
    private static final String CONTACT_US_URI = "/v1/contact-us";
    private static final String CALL_ME_BACK_URI = "/v1/call-me-back";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ContactService contactService;
    @MockBean
    private ICaptchaService captchaService;
    @MockBean
    private EmailContentProtectionService emailContentProtectionService;

    @Test
    void create_claim() throws Exception {
        ContactRequest claimRequest = new ContactRequest();
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(claimRequest);
        mockMvc.perform(
                MockMvcRequestBuilders.post(CONTACT_US_URI).param("g-recaptcha-response", "test")
                        .content(requestJson)
                        //.with(csrf())
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isCreated());

    }

    @Test
    void call_me_back() throws Exception {
        CallMeBackContactRequest request = new CallMeBackContactRequest();
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        mockMvc.perform(
                MockMvcRequestBuilders.post(CALL_ME_BACK_URI).param("g-recaptcha-response", "test")
                        .content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isCreated());
    }

    @Test
    void create_contact_returns_bad_request_when_sanitizer_rejects_input() throws Exception {
        ContactRequest claimRequest = new ContactRequest();
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(claimRequest);
        when(emailContentProtectionService.sanitize(any(ContactRequest.class)))
                .thenThrow(new ControllerBusinessException(List.of(
                        ApiErrorItem.builder().target("firstName").message("Suspicious content is not allowed in email fields").build()
                )));

        mockMvc.perform(
                        MockMvcRequestBuilders.post(CONTACT_US_URI).param("g-recaptcha-response", "test")
                                .content(requestJson)
                                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isBadRequest());
    }

}
