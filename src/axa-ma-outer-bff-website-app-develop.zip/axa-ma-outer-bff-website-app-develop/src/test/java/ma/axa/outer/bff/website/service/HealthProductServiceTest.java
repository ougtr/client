package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.client.InnerHealthProductProxy;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
public class HealthProductServiceTest {
    @Mock
    private InnerHealthProductProxy innerHealthProductProxy;
    @Mock
    private JsonRefService jsonRefService;
    @InjectMocks
    private HealthProductService healthProductService;

    @Test
    void test_health_product_get_packs_service() throws Exception {
        when(jsonRefService.getHealthProductOptions()).thenReturn(DataGenerator.getHealthProductOptionsData());
        when(innerHealthProductProxy.getAllProducts(any(), any())).thenReturn(DataGenerator.getAllHealthProductsData());
        when(innerHealthProductProxy.getOption(any())).thenReturn(DataGenerator.getHealthOptionData());
        when(innerHealthProductProxy.getOptionParams(any(), any())).thenReturn(DataGenerator.getHealthOptionsParamsData());
        assertThat(healthProductService.getAllPacksPsi().get(0)).hasFieldOrProperty("code");
    }

    @Test
    void test_health_product_get_sehassur_packs_service() throws Exception {
        when(jsonRefService.getSehassurOptionDetails()).thenReturn(DataGenerator.getHealthSehassurOptionsData());
        when(innerHealthProductProxy.getAllProducts(any(), any())).thenReturn(DataGenerator.getAllHealthProductsData());
        when(innerHealthProductProxy.getOption(any())).thenReturn(DataGenerator.getHealthOptionData());
        when(innerHealthProductProxy.getOptionParams(any(), any())).thenReturn(DataGenerator.getHealthOptionsParamsData());
        assertThat(healthProductService.getAllPacksSehassur().get(0)).hasFieldOrProperty("code");
    }
}
