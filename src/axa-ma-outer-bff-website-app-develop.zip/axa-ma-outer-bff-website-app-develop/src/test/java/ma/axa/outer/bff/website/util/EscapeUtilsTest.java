package ma.axa.outer.bff.website.util;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EscapeUtilsTest {

	@Test
	void test_escapeHtml_utility()
			throws IllegalAccessException, InstantiationException {
		String txt1 = EscapeUtils.escapeHtml("\"hello\"");
		String txtExpect = "&quot;hello&quot;";
		assertThat(txt1).isEqualTo(txtExpect);
	}
	
	@Test
	void test_escapeJson_utility() {
		String txt1 = EscapeUtils.escapeJson("\"hello\" from json");
		String txtExpect = "\\\"hello\\\" from json";
		assertThat(txt1).isEqualTo(txtExpect);
	}
	@Test
	void test_crlf_utility() {
		String txt1 = EscapeUtils.crlf("hello\r from new line");
		String txtExpect = "hello_ from new line";
		assertThat(txt1).isEqualTo(txtExpect);
	}
}
