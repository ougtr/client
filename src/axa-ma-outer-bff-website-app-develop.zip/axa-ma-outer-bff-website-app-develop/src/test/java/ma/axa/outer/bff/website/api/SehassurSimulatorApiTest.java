package ma.axa.outer.bff.website.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.request.SehassurPremiumSimulationRequest;
import ma.axa.outer.bff.website.service.EmailContentProtectionService;
import ma.axa.outer.bff.website.service.HealthProductService;
import ma.axa.outer.bff.website.service.HealthService;
import ma.axa.outer.bff.website.service.PrintingService;
import ma.axa.outer.bff.website.service.QuotationAccessTokenService;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(SehassurSimulatorApi.class)
@ExtendWith(SpringExtension.class)
public class SehassurSimulatorApiTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private HealthProductService healthProductService;
    @MockBean
    private HealthService healthService;
    @MockBean
    private ICaptchaService iCaptchaService;
    @MockBean
    private PrintingService printingService;
    @MockBean
    private QuotationAccessTokenService quotationAccessTokenService;
    @MockBean
    private EmailContentProtectionService emailContentProtectionService;
    private static final String PSI_SEHASSUR_URI = "/v1/sehassur";

    @Test
    void get_health_product_sehassur_packs() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get(PSI_SEHASSUR_URI + "/packs").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }

    @Test
    void test_sehassur_calculate_premium() throws Exception {
        SehassurPremiumSimulationRequest anObject = DataGenerator.constructSehassurPremiumSimulationRequestData();
        ObjectMapper mapper = new ObjectMapper();
        mapper.findAndRegisterModules();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(anObject);
        mockMvc.perform(
                MockMvcRequestBuilders.post("/v1/sehassur/premium").param("g-recaptcha-response", "test").content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void test_sehassur_generateDevis() throws Exception {
        SehassurPremiumSimulationRequest anObject = DataGenerator.constructSehassurPremiumSimulationRequestData();
        org.mockito.Mockito.when(quotationAccessTokenService.extractSehassurQuotationId(org.mockito.ArgumentMatchers.any())).thenReturn("12345");
        ObjectMapper mapper = new ObjectMapper();
        mapper.findAndRegisterModules();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(anObject);
        mockMvc.perform(
                MockMvcRequestBuilders.post("/v1/sehassur/signed-token/devis").content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void test_sehassur_sendDevis() throws Exception {
        SehassurPremiumSimulationRequest anObject = DataGenerator.constructSehassurPremiumSimulationRequestData();
        org.mockito.Mockito.when(quotationAccessTokenService.extractSehassurQuotationId(org.mockito.ArgumentMatchers.any())).thenReturn("12345");
        ObjectMapper mapper = new ObjectMapper();
        mapper.findAndRegisterModules();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(anObject);
        mockMvc.perform(
                MockMvcRequestBuilders.post("/v1/sehassur/signed-token/send-mail").content(requestJson)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}
