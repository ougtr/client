package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.dto.AbandonRequest;
import ma.axa.outer.bff.website.mapper.EmailMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class AbandonServiceTest {
    @Mock
    private InnerNotificationProxy innerNotificationProxy;

    @InjectMocks
    private AbandonService abandonService;

    @Mock
    private EmailMapper emailMapper;

    @Test
    @DisplayName("Test service save abandon")
    void save_claim() throws Exception{
        //when(innerNotificationProxy.sendMail(any())).thenReturn();
        assertNotNull(abandonService.createAbandon(new AbandonRequest()));
    }


}
