package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.client.InnerCarQuotationProxy;
import ma.axa.outer.bff.website.client.InnerQuotationProxy;
import ma.axa.outer.bff.website.client.InnerTiersProxy;
import ma.axa.outer.bff.website.dto.error.ApiError;
import ma.axa.outer.bff.website.exception.ControllerBusinessException;
import ma.axa.outer.bff.website.exception.InnerClientException;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class RenewalServiceTest {
    @Mock
    InnerQuotationProxy innerQuotationProxy;

    @Mock
    InnerCarQuotationProxy innerCarQuotationProxy;
    @Mock
    InnerTiersProxy innerTiersProxy;

    @InjectMocks
    private RenewalService renewalService;

    @Test
    @DisplayName("Test renewal data service")
    void ServiceGetRenewalData() throws Exception{
        when(innerTiersProxy.getIntermediary(any())).thenReturn(DataGenerator.intermediaryResponseEntity());
        when(innerCarQuotationProxy.getRenewalData(any())).thenReturn(DataGenerator.renewalDataResponseEntity());
        assertNotNull(renewalService.getRenewalData("12345"));
    }

    @Test
    @DisplayName("Test renewal data service ko")
    void test_service_get_renewal_data_ko() throws Exception{
        ApiError apiError = ApiError.builder().type("{errors:[]}").build() ;
        when(innerCarQuotationProxy.getRenewalData(any())).thenThrow(new InnerClientException(null, apiError));
        assertThrows(ControllerBusinessException.class, ()-> renewalService.getRenewalData("123456"));
    }

    @Test
    @DisplayName("Test renewal data service ko")
    void test_service_get_renewal_data_json_error() throws Exception{
        ApiError apiError = ApiError.builder().type("{errors:[]}").build() ;
        when(innerCarQuotationProxy.getRenewalData(any())).thenThrow(new InnerClientException(null, apiError));
        assertThrows(ControllerBusinessException.class, ()-> renewalService.getRenewalData("123456"));
    }

    @Test
    @DisplayName("Test service validate renewal contract")
    void test_service_validate_renewal_contract() throws Exception {
        when(innerCarQuotationProxy.validateContract(any())).thenReturn(DataGenerator.innerQuotationContractValidation());
        assertThat(renewalService.validateRenewalContract(DataGenerator.renewalContractValidationInputRequest())).isNotNull();
    }
}
