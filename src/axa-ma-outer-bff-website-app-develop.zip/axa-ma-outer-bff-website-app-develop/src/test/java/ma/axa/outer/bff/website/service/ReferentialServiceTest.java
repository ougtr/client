package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.client.InnerDataRefProxy;
import ma.axa.outer.bff.website.config.JsonProperties;
import ma.axa.outer.bff.website.util.DataGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ReferentialServiceTest {
    @Mock
    InnerDataRefProxy innerDataRefProxy;
    @Mock
    private JsonProperties jsonProperties;

    @InjectMocks
    private ReferentialService referentialService;

    @Test
    @DisplayName("Test service get cities by country code success ok ")
    void getCitiesSuccess() throws Exception {
        when(innerDataRefProxy.getCities(any())).thenReturn(DataGenerator.citiesResponseEntity());
        var cities = referentialService.getCities();
        assertNotNull(cities);
        assertThat(cities).hasSize(3);
    }

    @Test
    void getBrands_test() throws Exception {
        when(innerDataRefProxy.getBrands(any())).thenReturn(DataGenerator.brandsVehicle());
        assertEquals("a",referentialService.getBrands().get(0).getCode());
    }

    @Test
    void getFuel_test() throws Exception {
        when(jsonProperties.getFuel()).thenReturn(DataGenerator.fuelData());
        assertEquals("E",referentialService.getFuel().get(0).getCode());
    }
}
