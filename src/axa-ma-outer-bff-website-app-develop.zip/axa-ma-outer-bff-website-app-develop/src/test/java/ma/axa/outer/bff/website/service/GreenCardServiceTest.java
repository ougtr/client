package ma.axa.outer.bff.website.service;


import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.client.InnerPartnerProxy;
import ma.axa.outer.bff.website.client.InnerQuotationProxy;
import ma.axa.outer.bff.website.dto.payment.cmi.PaymentRequestDetailDto;
import ma.axa.outer.bff.website.dto.request.GreenCardAvenantRequest;
import ma.axa.outer.bff.website.dto.request.GreenCardDetailsRequest;
import ma.axa.outer.bff.website.dto.response.GreenCardAvenantDto;
import ma.axa.outer.bff.website.dto.response.GreenCardDetailsResponse;
import ma.axa.outer.bff.website.dto.response.GreenCardProductionResponse;
import ma.axa.outer.bff.website.enums.PaymentStatus;
import ma.axa.outer.bff.website.exception.GlobalException;
import ma.axa.outer.bff.website.util.constants.GlobalConstants;
import ma.axa.outer.bff.website.util.constants.PaymentConstants;
import org.apache.commons.codec.binary.Base64;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;


import java.time.LocalDateTime;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GreenCardServiceTest {

    @Mock private InnerPartnerProxy partnerClient;
    @Mock private InnerNotificationProxy notificationService;
    @Mock private InnerQuotationProxy innerQuotationProxy;
    @Mock private PaymentCmiService paymentCmiService;
    @Mock private EmailContentProtectionService emailContentProtectionService;
    @Mock private QuotationAccessTokenService quotationAccessTokenService;

    @InjectMocks private GreenCardService greenCardService;

    private PaymentRequestDetailDto buildPaidPayment(String orderId, String quotaitonId) {
        PaymentRequestDetailDto dto = new PaymentRequestDetailDto();
        dto.setStatus(PaymentStatus.PAID);
        dto.setQuotationId(quotaitonId);
        dto.setOrderId(orderId);
        dto.setOrderDate(LocalDateTime.of(2026, 7, 28, 10, 15));
        return dto;
    }

    @Test
    void greenCardDetails_shouldReturnSignedQuotationId() {
        String quotationId = "QU-001";
        String signedQuotationToken = "signed-green-card-token";
        GreenCardDetailsRequest request = new GreenCardDetailsRequest();
        GreenCardDetailsResponse response = new GreenCardDetailsResponse();
        response.setIdQuotation(quotationId);

        when(innerQuotationProxy.createNewGreenCardQuotation(request)).thenReturn(ResponseEntity.ok(response));
        when(quotationAccessTokenService.generateGreenCardQuotationToken(quotationId)).thenReturn(signedQuotationToken);

        ResponseEntity<GreenCardDetailsResponse> result = greenCardService.greenCardDetails(request);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(signedQuotationToken, result.getBody().getIdQuotation());
        verify(quotationAccessTokenService).generateGreenCardQuotationToken(quotationId);
    }

    @Test
    void launchGreenCardProduction_shouldReturnResource_whenValid() {
        String orderId = "ORD-001";
        String quotationId ="QU-001";
        String attestation = "494939393";

        GreenCardDetailsResponse greenCardDetails = new GreenCardDetailsResponse();
        greenCardDetails.setEmail("test@axa.ma");
        greenCardDetails.setIdQuotation(quotationId);
        greenCardDetails.setAttestation(Integer.valueOf(attestation));
        greenCardDetails.setPrenom("Sara");
        greenCardDetails.setMatricule("123-A-45");

        GreenCardProductionResponse productionResponse = new GreenCardProductionResponse();
        productionResponse.setPdfStream(Base64.encodeBase64String("pdf-content".getBytes()));

        Map<String, String> emailVariablesMap = Map.of(
                "firstName", "Sara",
                "transactionNumber", orderId,
                "purchaseDate", "28/07/2026",
                "vehicleRegistration", "123-A-45"
        );
        String emailVariables = "{\"firstName\":\"Sara\"}";

        when(paymentCmiService.fetchPaymentRequest(orderId)).thenReturn(buildPaidPayment(orderId, quotationId));
        when(innerQuotationProxy.getQuotationDetails(quotationId)).thenReturn(ResponseEntity.ok(greenCardDetails));
        when(partnerClient.produceGreenCard(any())).thenReturn(ResponseEntity.ok(productionResponse));
        when(emailContentProtectionService.toTemplateVariablesJson(eq(emailVariablesMap))).thenReturn(emailVariables);
        GreenCardAvenantRequest greenCardAvenantRequest = new GreenCardAvenantRequest();
        greenCardAvenantRequest.setAttestation(attestation);
        greenCardAvenantRequest.setQuotationId(quotationId);

        GreenCardAvenantDto greenCardAvenantDto = new GreenCardAvenantDto();
        greenCardAvenantDto.setAvenantNumber("11999999");
        greenCardAvenantDto.setPolicyNumber("1030000");

        doReturn(ResponseEntity.ok(greenCardAvenantDto)).when(innerQuotationProxy).validateGreenCardAvenant(greenCardAvenantRequest);
        ResponseEntity<Resource> result = greenCardService.launchGreenCardProduction(orderId);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        verify(notificationService).sendEmail(anyList(), isNull(), eq(GlobalConstants.GREEN_CARD_RECEPTION_MAIL_TEMPLATE),
                eq(GlobalConstants.GREEN_CARD_RECEPTION_EMAIL_SUBJECT), eq(emailVariables),
                eq(GlobalConstants.AXA_WEB_NO_REPLAY_EMAIL), any());
    }

    @Test
    void launchGreenCardProduction_shouldThrow_whenPaymentIsNotPaid() {
        String orderId = "ORD-001";
        PaymentRequestDetailDto dto = new PaymentRequestDetailDto();
        dto.setStatus(PaymentStatus.PENDING);
        dto.setQuotationId("QUOT-001");

        when(paymentCmiService.fetchPaymentRequest(orderId)).thenReturn(dto);

        GlobalException ex = assertThrows(GlobalException.class,
                () -> greenCardService.launchGreenCardProduction(orderId));
        assertEquals(PaymentConstants.PAYMENT_STATUS_IS_UNPAID, ex.getMessage());
    }

    @Test
    void launchGreenCardProduction_shouldThrow_whenQuotationIdIsBlank() {
        String orderId = "ORD-001";
        PaymentRequestDetailDto dto = new PaymentRequestDetailDto();
        dto.setStatus(PaymentStatus.PAID);
        dto.setQuotationId("");

        when(paymentCmiService.fetchPaymentRequest(orderId)).thenReturn(dto);

        GlobalException ex = assertThrows(GlobalException.class,
                () -> greenCardService.launchGreenCardProduction(orderId));
        assertEquals(PaymentConstants.PAYMENT_QUOTATION_NOT_FOUND, ex.getMessage());
    }

    @Test
    void launchGreenCardProduction_shouldThrow_whenQuotationDetailsNotFound() {
        String orderId = "ORD-001";
        String quotationId ="QU-001";

        when(paymentCmiService.fetchPaymentRequest(orderId)).thenReturn(buildPaidPayment(orderId, quotationId));
        when(innerQuotationProxy.getQuotationDetails(quotationId)).thenReturn(ResponseEntity.status(HttpStatus.NOT_FOUND).build());

        GlobalException ex = assertThrows(GlobalException.class,
                () -> greenCardService.launchGreenCardProduction(orderId));
        assertEquals(PaymentConstants.PAYMENT_QUOTATION_NOT_FOUND, ex.getMessage());
    }

    @Test
    void launchGreenCardProduction_shouldThrow_whenPartnerReturnsError() {
        String orderId = "ORD-001";
        String quotationId ="QU-001";

        GreenCardDetailsResponse greenCardDetails = new GreenCardDetailsResponse();
        greenCardDetails.setEmail("test@axa.ma");

        when(paymentCmiService.fetchPaymentRequest(orderId)).thenReturn(buildPaidPayment(orderId, quotationId));
        when(innerQuotationProxy.getQuotationDetails(quotationId)).thenReturn(ResponseEntity.ok(greenCardDetails));
        when(partnerClient.produceGreenCard(any())).thenReturn(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build());

        GlobalException ex = assertThrows(GlobalException.class,
                () -> greenCardService.launchGreenCardProduction(orderId));
        assertEquals(PaymentConstants.GREEN_CARD_PRODUCTION_ERROR_MESSAGE, ex.getMessage());
    }

    @Test
    void decodeBase64String_shouldDecodeCorrectly() {
        String original = "carte-verte-content";
        String encoded = Base64.encodeBase64String(original.getBytes());

        byte[] decoded = GreenCardService.decodeBase64String(encoded);

        assertArrayEquals(original.getBytes(), decoded);
    }

    @Test
    void should_throw_exception_when_validate_green_card_avenant_fails() {
        String quotationId = "1030400404";
        String attestationId= "103030333";
        assertThrows(GlobalException.class, () -> greenCardService.validateGreenCardAvenant(quotationId, attestationId));
    }

    @Test
    void should_throw_exception_when_email_sending_fails() {
        String orderId = "ORD-001";
        String quotationId ="QU-001";
        String attestation = "494939393";

        GreenCardDetailsResponse greenCardDetails = new GreenCardDetailsResponse();
        greenCardDetails.setEmail("test@axa.ma");
        greenCardDetails.setIdQuotation(quotationId);
        greenCardDetails.setAttestation(Integer.valueOf(attestation));

        GreenCardProductionResponse productionResponse = new GreenCardProductionResponse();
        productionResponse.setPdfStream(Base64.encodeBase64String("pdf-content".getBytes()));

        when(paymentCmiService.fetchPaymentRequest(orderId)).thenReturn(buildPaidPayment(orderId, quotationId));
        when(innerQuotationProxy.getQuotationDetails(quotationId)).thenReturn(ResponseEntity.ok(greenCardDetails));
        when(partnerClient.produceGreenCard(any())).thenReturn(ResponseEntity.ok(productionResponse));
        doThrow(new RuntimeException("Error while send green card email")).when(notificationService).sendEmail(any(), any(), any(), any(), any(), any(), any());

        GreenCardAvenantRequest greenCardAvenantRequest = new GreenCardAvenantRequest();
        greenCardAvenantRequest.setAttestation(attestation);
        greenCardAvenantRequest.setQuotationId(quotationId);

        GreenCardAvenantDto greenCardAvenantDto = new GreenCardAvenantDto();
        greenCardAvenantDto.setAvenantNumber("11999999");
        greenCardAvenantDto.setPolicyNumber("1030000");

        GlobalException ex = assertThrows(GlobalException.class,
                () -> greenCardService.launchGreenCardProduction(orderId));
        assertEquals(PaymentConstants.GREEN_CARD_EMAIL_ERROR_MESSAGE, ex.getMessage());
    }

    @Test
    void launchGreenCardProduction_shouldThrow_whenProductionIsNull() {
        String orderId = "ORD-001";
        PaymentRequestDetailDto dto = new PaymentRequestDetailDto();
        dto.setStatus(PaymentStatus.PENDING);
        dto.setQuotationId("QUOT-001");
        when(paymentCmiService.fetchPaymentRequest(orderId)).thenReturn(dto);

        GlobalException ex = assertThrows(GlobalException.class,
                () -> greenCardService.launchGreenCardProduction(orderId));
        assertEquals(PaymentConstants.PAYMENT_STATUS_IS_UNPAID, ex.getMessage());
    }
}
