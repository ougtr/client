package ma.axa.outer.bff.website.dto.error;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ApiError implements Serializable {
	private static final long serialVersionUID = -8110282627123433453L;

	private String type; 	// * A URI reference, ex: /problem/client-not-found
	private String title; 	// * A short, human-readable summary of the problem type
	private String detail; 	// A human-readable explanation 
	private String instance;// A URI reference that identifies the specific occurrence of the problem.
	private Integer status;	// The HTTP status code
	private String traceId;
	private List<ApiErrorItem> errors = new ArrayList<>();
}
