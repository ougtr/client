package ma.axa.outer.bff.website.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.dto.payment.cmi.PaymentObjectDto;
import ma.axa.outer.bff.website.dto.payment.cmi.PaymentRequestBffDto;
import ma.axa.outer.bff.website.dto.payment.cmi.PaymentRequestDetailDto;
import ma.axa.outer.bff.website.dto.payment.cmi.PaymentRequestDto;
import ma.axa.outer.bff.website.service.PaymentCmiService;
import ma.axa.outer.bff.website.util.Paths;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping(Paths.WEB_SITE_PAYMENT_CMI)
@RequiredArgsConstructor
@Validated
public class PaymentCmiApi {
    private final PaymentCmiService paymentCmiService ;
    @Operation(summary = "create payment request")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Create payment request",  content = {
                    @Content(mediaType = "application/json",  schema = @Schema(implementation = PaymentObjectDto.class))}) ,
            @ApiResponse(responseCode = "400", description = "Requet Invalid", content = @Content),
            @ApiResponse(responseCode = "404", description = "create payment request not found", content = @Content)})
    @PostMapping(path ="/payment-request" , produces = {"application/json"})
    public ResponseEntity<PaymentObjectDto> createPaymentRequest(
            @Valid @RequestBody PaymentRequestBffDto paymentRequest){
        return ResponseEntity.status(HttpStatus.CREATED).body(paymentCmiService.createPaymentRequest(paymentRequest));
    }
    @Operation(summary = "Get payment request details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Get payment request details",  content = {
                    @Content(mediaType = "application/json",  schema = @Schema(implementation = PaymentRequestDetailDto.class))}) ,
            @ApiResponse(responseCode = "400", description = "Requet Invalid", content = @Content),
            @ApiResponse(responseCode = "404", description = "Get payment request details not found", content = @Content)})
    @GetMapping(path="/payment-request/{orderId}",produces = {"application/json"})
    public ResponseEntity<PaymentRequestDetailDto> fetchPaymentRequest(@PathVariable String orderId){
        return ResponseEntity.ok().body(paymentCmiService.fetchPaymentRequest(orderId));
    }
    @Operation(summary = "Refresh payment request status")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Refresh payment request status",  content = {
                    @Content(mediaType = "application/json",  schema = @Schema(implementation = PaymentRequestDetailDto.class))}) ,
            @ApiResponse(responseCode = "400", description = "Requet Invalid", content = @Content),
            @ApiResponse(responseCode = "404", description = "Refresh payment request status not found", content = @Content)})
    @GetMapping(path="/payment-request/{orderId}/refresh-status",produces = {"application/json"})
    public ResponseEntity<PaymentRequestDetailDto> refreshStatus(@PathVariable String orderId){
        return ResponseEntity.ok().body(paymentCmiService.refreshStatus(orderId));
    }
}
