package ma.axa.outer.bff.website.service;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.client.InnerPrintingProxy;
import ma.axa.outer.bff.website.dto.sehassur.DevisSehassurPrinting;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PrintingService {
    private final InnerPrintingProxy innerPrintingProxy;
    public Resource getDevisFile(String quotationId) {
        return innerPrintingProxy.printDevis("DVR", "", "PSI", quotationId, "0337").getBody();
    }

    public Resource getSehassurDevisFile(DevisSehassurPrinting devisSehassurPrinting) {

        return innerPrintingProxy.printSehassurDevis(devisSehassurPrinting).getBody();
    }
}