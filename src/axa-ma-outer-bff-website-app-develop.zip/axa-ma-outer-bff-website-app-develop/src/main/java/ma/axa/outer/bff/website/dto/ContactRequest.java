package ma.axa.outer.bff.website.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ContactRequest {

    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String emailAddress;
    private String offer;
    private String city;
    private String subject;
    private String message;

}
