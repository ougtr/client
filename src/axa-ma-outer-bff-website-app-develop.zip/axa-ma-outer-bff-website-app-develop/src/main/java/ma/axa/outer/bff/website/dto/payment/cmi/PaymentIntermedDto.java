package ma.axa.outer.bff.website.dto.payment.cmi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.enums.IntermediaryStatus;
import ma.axa.outer.bff.website.enums.IntermediaryType;

import java.util.ArrayList;
import java.util.List;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentIntermedDto {
        private Long idIntermed ;
        private IntermediaryType intermediaryType ;
        private String storeCode ;
        private IntermediaryStatus status ;
        private String secretKey ;
        private List<PaymentPdvDto> paymentPdvs = new ArrayList<>(); ;

}
