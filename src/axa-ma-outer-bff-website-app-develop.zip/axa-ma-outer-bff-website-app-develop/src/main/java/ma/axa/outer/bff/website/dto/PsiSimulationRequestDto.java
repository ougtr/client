package ma.axa.outer.bff.website.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
public class PsiSimulationRequestDto {
    @NotNull(message = "le champs assuredInUsa est obligatoire")
    private Boolean assuredInUsa;
    @NotNull(message = "le champ birthdates est obligatoire")
    private List<String> birthdates;
}
