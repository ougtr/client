package ma.axa.outer.bff.website.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.Map;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SFClinicsDto {
    private String name;
    private String city;
    private String address;
    private String phone;
}
