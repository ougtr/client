package ma.axa.outer.bff.website.service;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.client.InnerSFDCProxy;
import ma.axa.outer.bff.website.dto.*;
import ma.axa.outer.bff.website.exception.GlobalException;
import ma.axa.outer.bff.website.mapper.LeadMapper;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PSISimulatorService {

    private final InnerSFDCProxy innerSFDCProxy;

    public ProspectResponseDto saveProspect(PSIProspectDto prospect) {
        LeadRequestDto request = LeadMapper.toPSILeadRequest(prospect);
        LeadResponseDto leadResponseDto = innerSFDCProxy.createLead(request).getBody();
        if(leadResponseDto != null)
            return new ProspectResponseDto(leadResponseDto.getId());
        return null;
    }

    public ProspectResponseDto savePsiProspect(LeadRequestDto request) {
        request.setLeadSource("Simulateur");
        LeadResponseDto leadResponseDto = innerSFDCProxy.createLead(request).getBody();
        if(leadResponseDto != null)
            return new ProspectResponseDto(leadResponseDto.getId());
        return null;
    }

    public ProspectResponseDto updateProspect(PSIProspectDto prospect) {
        if(prospect.getLeadId() == null)
            throw new GlobalException("Lead Id cannot be null");
        LeadRequestDto request = LeadMapper.toPSILeadRequest(prospect);

        request.setStatus("Sélectionné");
        request.setLeadSource("Simulateur");
        LeadResponseDto leadResponseDto = innerSFDCProxy.updateLead(request, prospect.getLeadId()).getBody();
        if(leadResponseDto != null)
            return new ProspectResponseDto(leadResponseDto.getId());
        return null;
    }

    public ProspectResponseDto updatePsiProspect(LeadRequestDto request, String id) {
        request.setStatus("Sélectionné");
        request.setLeadSource("Simulateur");
        LeadResponseDto leadResponseDto = innerSFDCProxy.updateLead(request, id).getBody();
        if(leadResponseDto != null)
            return new ProspectResponseDto(leadResponseDto.getId());
        return null;
    }
}