package ma.axa.outer.bff.website.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@ConfigurationProperties(prefix = "axa.cmi.redirect")
@Component
public class AxaCmiUrlsProps {
    private String okURL ;
    private String failUrl ;
    private String s2sFailUrl ;
}
