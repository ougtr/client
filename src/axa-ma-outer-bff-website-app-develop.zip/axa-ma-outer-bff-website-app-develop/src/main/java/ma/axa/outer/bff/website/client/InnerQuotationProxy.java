package ma.axa.outer.bff.website.client;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;

import ma.axa.outer.bff.website.dto.request.GreenCardAvenantRequest;
import ma.axa.outer.bff.website.dto.request.GreenCardDetailsRequest;
import ma.axa.outer.bff.website.dto.response.GreenCardAvenantDto;
import ma.axa.outer.bff.website.dto.response.GreenCardDetailsResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import io.swagger.v3.oas.annotations.Parameter;
import ma.axa.outer.bff.website.client.config.InnerClientConfig;
import ma.axa.outer.bff.website.dto.MRHSimulationRequestDto;
import ma.axa.outer.bff.website.dto.MRHSimulationResponseDto;
import ma.axa.outer.bff.website.dto.PublicCapitalDto;
import ma.axa.outer.bff.website.dto.quotation.QuotationMrhResponse;
import ma.axa.outer.bff.website.dto.quotation.QuotationResponseMrh;
import ma.axa.outer.bff.website.dto.quotation.request.QuotationMrhContrat;
import ma.axa.outer.bff.website.dto.quotation.request.QuotationMrhRequest;

@FeignClient(name = "innerQuotationProxy", url = "${axa.client.inner-quotation}", configuration = InnerClientConfig.class)
public interface InnerQuotationProxy {

    @PostMapping(path = "/v1/mrh/quotation", produces = {"application/json"})
    ResponseEntity<MRHSimulationResponseDto> getSimulation(
            @RequestBody @Valid MRHSimulationRequestDto mrhSimulationRequestDto
    );

    @GetMapping(path = "/v1/mrh/capitals", produces = {"application/json"})
    ResponseEntity<List<PublicCapitalDto>> getMRHCapitalList();

    @GetMapping(path = "/v1/mrh/quotations/garanties", produces = { "application/json" })
    public ResponseEntity<QuotationMrhContrat> getGaranties(
            @Parameter(description = "Capital assure") @RequestParam(name = "capital", required = true) BigDecimal capital,
            @Parameter(description = "Date effect") @RequestParam(name = "dateEffect", required = true) String dateEffect,
            @Parameter(description = "type Account") @RequestParam(name = "typeAccount", required = true) String typeAccount);

    @PostMapping(value = "/v1/mrh/quotations", consumes = "application/json")
    public ResponseEntity<QuotationResponseMrh> createQuotation(@RequestBody QuotationMrhRequest quotationRequest);
    
    
    @PutMapping(value = "/v1/mrh/quotations/{idQuotation}", consumes = "application/json")
    public ResponseEntity<QuotationResponseMrh> updateQuotationV2(QuotationMrhRequest input,  @PathVariable(name = "idQuotation", required = true) BigDecimal idQuotation);
    
	
    @PostMapping(path = "/v1/mrh/quotations/{idQuotation}/prices", produces = { "application/json" })
	public ResponseEntity<QuotationMrhResponse> calculePrimeMrh(  @PathVariable(name = "idQuotation", required = true) BigDecimal idQuotation, @Valid @RequestBody QuotationMrhRequest requestMrh);


    @PostMapping(value = "/v1/auto/green-card/quotations")
    ResponseEntity<GreenCardDetailsResponse> createNewGreenCardQuotation(@RequestBody GreenCardDetailsRequest greenCardDetailsRequest);

    @GetMapping(value = "/v1/auto/green-card/quotations/{quotationId}")
    ResponseEntity<GreenCardDetailsResponse> getQuotationDetails(@PathVariable("quotationId") String quotationId);

    @PostMapping(value = "/v1/auto/green-card/quotations/avenants")
    ResponseEntity<GreenCardAvenantDto> validateGreenCardAvenant(@RequestBody GreenCardAvenantRequest greenCardAvenantRequest);

}
