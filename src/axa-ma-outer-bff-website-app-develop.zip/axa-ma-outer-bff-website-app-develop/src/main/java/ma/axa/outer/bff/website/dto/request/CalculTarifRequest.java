package ma.axa.outer.bff.website.dto.request;

import lombok.*;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CalculTarifRequest {

	
    private String codeProduit;
    private String option;
    private BigDecimal dateEffet;
    private String baseRemb;
    private String tauxRemb;
    private String fraction;
    private BigDecimal age;
    private String capDeces;
    private String capRedoute;
    private String anteriorite;
    private String malRedoute;
    private BigDecimal tauxMal;
    private BigDecimal tauxDeces;
    private BigDecimal tauxMalRedoute;
    private String flagSouscription;
    private String franshise;
    private BigDecimal numOrder;

}
