package ma.axa.outer.bff.website.client;

import ma.axa.outer.bff.website.client.config.InnerClientConfig;
import ma.axa.outer.bff.website.dto.response.Option;
import ma.axa.outer.bff.website.dto.response.OptionParams;
import ma.axa.outer.bff.website.dto.response.Product;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@FeignClient(name = "innerHealthProductProxy", url = "${axa.client.inner-product-health}", configuration = InnerClientConfig.class)

public interface InnerHealthProductProxy {
    @GetMapping(value = "/v1/psi/products", produces = {"application/json"})
    public ResponseEntity<List<Product>> getAllProducts(
            @RequestParam(name="codePays", required = true) String codePays,
            @RequestParam (name="type", required = true) String type);

    @GetMapping(value="/v1/psi/products/{codeProduit}/options",produces = {"application/json"})
    public ResponseEntity<List<Option>> getOption(
            @NotEmpty(message = "{error.geo.ville.code.notblank}") @PathVariable(value = "codeProduit", required = true) String codeProduit);

    @GetMapping(value="/v1/psi/products/{codeProduit}/options/{codeOption}",produces = {"application/json"})
    public ResponseEntity<OptionParams> getOptionParams(
            @PathVariable(value = "codeProduit", required = true) String codeProduit,
            @PathVariable(value = "codeOption", required = true) String codeOption);

}
