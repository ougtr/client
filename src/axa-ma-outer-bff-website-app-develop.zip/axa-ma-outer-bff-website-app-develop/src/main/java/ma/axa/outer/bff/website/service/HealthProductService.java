package ma.axa.outer.bff.website.service;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.client.InnerHealthProductProxy;
import ma.axa.outer.bff.website.dto.request.OptionDetails;
import ma.axa.outer.bff.website.dto.request.OptionSehassurDetails;
import ma.axa.outer.bff.website.dto.response.*;
import ma.axa.outer.bff.website.mapper.HealthProductMapper;
import ma.axa.outer.bff.website.util.constants.GlobalConstants;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class HealthProductService {
    private final InnerHealthProductProxy innerHealthProductProxy;
    private final JsonRefService jsonRefService;

    public List<Product> getProduct(String productType) {
        return innerHealthProductProxy.getAllProducts(GlobalConstants.HEALTH_PRODUCT_CODE, productType).getBody();
    }

    public List<HealthPackResponse> getAllPacksPsi() {
        List<HealthPackResponse> healthPackResponses = new ArrayList<>();
        List<Product> products = getProduct(GlobalConstants.HEALTH_PRODUCT_TYPE);
        List<Option> options = null;
        if (!CollectionUtils.isEmpty(products)) {
            options = innerHealthProductProxy.getOption(products.get(0).getCode()).getBody();
        }
        List<OptionDetails> optionsDetails = jsonRefService.getHealthProductOptions();
        for (Option option : options) {
            Optional<OptionDetails> optionDetails = optionsDetails.stream().filter(e -> e.getCode().equals(option.getCode())).findFirst();
            if (!optionDetails.isEmpty() && !CollectionUtils.isEmpty(products)) {
                OptionParams optionParam = innerHealthProductProxy.getOptionParams(products.get(0).getCode(), option.getCode()).getBody();
                healthPackResponses.add(HealthProductMapper.toHealthPackResponse(option, optionParam, optionDetails.get()));
            }
        }

        return healthPackResponses;
    }

    public List<HealthSehassurPacksResponseDto> getAllPacksSehassur() {
        List<HealthSehassurPacksResponseDto> sehassurPacks = new ArrayList<>();
        List<Product> products = getProduct(GlobalConstants.HEALTH_SEHASSUR_TYPE);
        List<Option> options = null;
        if (!CollectionUtils.isEmpty(products)) {
            options = innerHealthProductProxy.getOption(products.get(0).getCode()).getBody();
            List<OptionSehassurDetails> optionsDetails = jsonRefService.getSehassurOptionDetails();
            for (Option option : options) {
                Optional<OptionSehassurDetails> optionDetails = optionsDetails.stream().filter(e -> e.getCode().equals(option.getCode())).findFirst();
                if (!optionDetails.isEmpty() && !CollectionUtils.isEmpty(products)) {
                    OptionParams optionParam = innerHealthProductProxy.getOptionParams(products.get(0).getCode(), option.getCode()).getBody();
                    sehassurPacks.add(HealthProductMapper.toHealthSehassurPacksResponseDto(option, optionParam, optionDetails.get(), products.get(0)));
                }
            }
        }
        return sehassurPacks;
    }
}
