package ma.axa.outer.bff.website.dto.sehassur;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class SehassurSpouse {

    private String birthDate;
    private String age;
}