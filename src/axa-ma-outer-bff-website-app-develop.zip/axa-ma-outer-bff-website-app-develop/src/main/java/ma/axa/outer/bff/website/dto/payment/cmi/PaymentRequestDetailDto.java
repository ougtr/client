package ma.axa.outer.bff.website.dto.payment.cmi;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.enums.PaymentProvider;
import ma.axa.outer.bff.website.enums.PaymentStatus;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentRequestDetailDto {
    private String quotationId ;
    private String orderId ;
    private PaymentStatus status ;
    private LocalDateTime orderDate ;
    private BigDecimal totalAmount ;
    private String paymentMode ;
    private String paymentMethod ;
    private List<PaymentItemDto> items ;
    private String paymentType ;
    private PaymentClientInfoDto clientInfo ;
    private String countryCode ;
    private LocalDateTime expiryDate ;
    private List<PaymentExtraDataDto>  extraData ;
    private String quittanceNumber ;
    private String policyNumber ;
    private String policyAvenant;
}
