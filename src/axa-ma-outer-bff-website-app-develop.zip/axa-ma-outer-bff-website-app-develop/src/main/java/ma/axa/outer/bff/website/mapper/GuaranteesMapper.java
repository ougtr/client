package ma.axa.outer.bff.website.mapper;

import ma.axa.outer.bff.website.dto.request.GarantieDto;
import ma.axa.outer.bff.website.dto.response.GuaranteesDetailsDto;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
@Component
public class GuaranteesMapper {

    public static List<GarantieDto> toQuotationGuaranteesDto(List<GuaranteesDetailsDto> guaranteesDetailsDto) {
        List<GarantieDto> garantieFinale = new ArrayList<>();
        for (GuaranteesDetailsDto guarantee:
             guaranteesDetailsDto) {
            Integer formule = guarantee.getFormules() != null ?  Integer.parseInt(guarantee.getFormules().get(0).getCode() ): 0;
            garantieFinale.add(GarantieDto.builder().typeVehcile(1).codeGarantie(Integer.parseInt(guarantee.getCode())).formule(formule).build());
        }

        return garantieFinale;

    }
}
