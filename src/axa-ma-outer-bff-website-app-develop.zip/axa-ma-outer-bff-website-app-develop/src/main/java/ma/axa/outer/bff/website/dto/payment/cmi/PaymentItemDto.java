package ma.axa.outer.bff.website.dto.payment.cmi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentItemDto {
    @Builder.Default
    private boolean due = true ;
    @Builder.Default
    private boolean selected = true ;
    private BigDecimal amount ;
    private String description ;
}
