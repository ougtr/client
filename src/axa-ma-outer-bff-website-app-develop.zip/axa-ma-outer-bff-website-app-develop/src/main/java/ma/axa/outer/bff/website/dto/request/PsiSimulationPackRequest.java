package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PsiSimulationPackRequest {
    private String packCode;
    private String packLabel;
    private String franchiseCode;
    private String franchiseLabel;
    private String fraction;
}