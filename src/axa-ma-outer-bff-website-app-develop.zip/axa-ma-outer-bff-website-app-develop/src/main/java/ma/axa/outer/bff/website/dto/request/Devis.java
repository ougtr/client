package ma.axa.outer.bff.website.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Devis {

    @JsonIgnore
    private BigDecimal idQuotation;

    private Assure assure;


    private Conducteur conducteur;


    private VehiculeDevis vehicule;

    @JsonIgnore
    private InfoCNT infoCNT;

}
