package ma.axa.outer.bff.website.dto.request;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class VehiculeDto {

    private String codeUsage;

    private String dateMisCirculation;

    private Character typeMatricule;

    private String matricule;

    private BigDecimal valeurNeuf;

    private BigDecimal valeurVenale;

    private BigDecimal valeurAmenagement;
}
