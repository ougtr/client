package ma.axa.outer.bff.website.dto.response;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;
@Data
@Builder
public class Product {
    private String code;
    private String libelle;
    private String type;
    private String idDocumentGed;
    private List<Capital> listCapitalMalRedoute;
    private BigDecimal assConAge;
    private BigDecimal pacAge;
}
