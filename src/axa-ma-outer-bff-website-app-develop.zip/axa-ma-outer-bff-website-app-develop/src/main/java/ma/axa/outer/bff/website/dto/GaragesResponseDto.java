package ma.axa.outer.bff.website.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.Map;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class GaragesResponseDto {
    private String RS;
    private String address;
    private String phoneNumber;
    private String  city;
}
