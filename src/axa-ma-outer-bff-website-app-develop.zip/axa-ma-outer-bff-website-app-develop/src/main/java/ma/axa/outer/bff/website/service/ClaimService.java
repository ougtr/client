package ma.axa.outer.bff.website.service;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.ClaimRequest;
import ma.axa.outer.bff.website.dto.EmailDto;
import ma.axa.outer.bff.website.exception.GlobalException;
import ma.axa.outer.bff.website.mapper.EmailMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ClaimService {

    @Value("${axa.mail.claim}")
    private String claimEmail;

    private final InnerNotificationProxy innerNotificationProxy;

    @Async
    public ApiMessageWrapper createClaim(ClaimRequest claimRequest) {

        EmailDto email = EmailMapper.toEmail(claimRequest);
        email.setTo(claimEmail);
        try {
            innerNotificationProxy.sendMail(email);
            return new ApiMessageWrapper("Email Sent");
        } catch (Exception e) {
            throw new GlobalException("Error while sending email");
        }
    }
}
