package ma.axa.outer.bff.website.dto.quotation.request;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.dto.MRHV2ProspectDto;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MrhMinimalistSimulationRequest {

	private BigDecimal idQuotation;
	
	/**'1,Appartement','2,Maison','3,Villa','4,Bungalow','5,Duplex','6,Riad'*/
	private String typeHabitation ;
	
	/** S or P secondaire ou principal **/
	private String natureHabitation;
	
	private List<String> optionnelGarantiesId ;
	
	/** "P : "Propriétaire" "L  : "Locataire"   O  , PN */ 
	private String typeOccupant;
	
	
	private String valeurBatiment;
	private String valeurContenu ;
	/**à calculer 20% valeurContenu **/
	private String valeurObject ;
	
	private BigDecimal prime;
	
	private MRHV2ProspectDto mrhProspect ;
}