package ma.axa.outer.bff.website.dto.payment.cmi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.enums.PaymentProvider;

import java.util.HashSet;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentMerchantDto {
        private String merchantCode ;
        private PaymentProvider paymentProvider ;
        private Set<PaymentPdvDto> pdvs = new HashSet<>();
        private Set<PaymentIntermedDto> intermeds = new HashSet<>();
}
