package ma.axa.outer.bff.website.mapper;

import ma.axa.outer.bff.website.dto.payment.cmi.*;
import ma.axa.outer.bff.website.mapper.utils.MapperUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface GreenCardMapper {
    public PaymentItemDto mapToPaymentItemDto(GreenCardPaymentItemDto paymentItemDto) ;
    public List<PaymentItemDto> mapToListPaymentItemDto(List<GreenCardPaymentItemDto> greenCardPaymentItemDtoList) ;
    @Mapping(target = "name", expression = "java(fullName(greenCardPaymentClientDto))")
    public PaymentClientInfoDto mapToPaymentClientInfoDto(GreenCardPaymentClientDto greenCardPaymentClientDto);

    public PaymentRequestDto mapToPaymentRequestBffDto(PaymentRequestBffDto paymentRequestBffDto);
    @Named("fullName")
    default String fullName(GreenCardPaymentClientDto source) {
        if (source == null) {
            return null;
        }
        return source.getFirstName() + " " + source.getLastName();
    }
}
