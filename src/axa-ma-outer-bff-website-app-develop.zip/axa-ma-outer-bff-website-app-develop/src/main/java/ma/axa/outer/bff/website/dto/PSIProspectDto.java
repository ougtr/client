package ma.axa.outer.bff.website.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PSIProspectDto {
    private String leadId;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String emailAddress;
    private String city;
    private String cityLabel;
    private String birthDate;
    private Boolean coveredInUSA;
    private Boolean liveInMorocco;
    private String option;
    private String franchise;
    private List<ProspectJointDto> joints;
    private List<ProspectChildDto> children;

}