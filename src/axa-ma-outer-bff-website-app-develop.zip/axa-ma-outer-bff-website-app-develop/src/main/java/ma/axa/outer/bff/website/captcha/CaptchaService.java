package ma.axa.outer.bff.website.captcha;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.client.CaptchaProxy;
import ma.axa.outer.bff.website.exception.ReCaptchaInvalidException;
import ma.axa.outer.bff.website.exception.ReCaptchaUnavailableException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;


@Service("captchaService")
@RequiredArgsConstructor
public class CaptchaService extends AbstractCaptchaService {

    private final static Logger LOGGER = LoggerFactory.getLogger(CaptchaService.class);
    private final CaptchaProxy captchaProxy;

    @Override
    public void processResponse(final String response) {
        securityCheck(response);

        try {
            final GoogleResponse googleResponse = captchaProxy.validateCaptcha(response, getReCaptchaSecret(), getClientIP()).getBody();
            ;
            LOGGER.debug("Google's response: {} ", googleResponse != null? googleResponse.toString() : null);

            if (googleResponse != null && !googleResponse.isSuccess()) {
                if (googleResponse.hasClientError()) {
                    reCaptchaAttemptService.reCaptchaFailed(getClientIP());
                }
                throw new ReCaptchaInvalidException("reCaptcha was not successfully validated");
            }
        } catch (RestClientException rce) {
            throw new ReCaptchaUnavailableException("Registration unavailable at this time.  Please try again later.", rce);
        }
        reCaptchaAttemptService.reCaptchaSucceeded(getClientIP());
    }
}
