package ma.axa.outer.bff.website.dto.response;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class GreenCardDetailsResponse {
    private String typeImmatriculation;
    private String codeCie;
    private String nature = "P";
    private String codeIntermediaire  = "0";
    private String intermediaire = "0";
    private Integer numeroCv = 0;
    private String police;
    private Integer attestation = 0;
    private String dateEffet;
    private String dateEcheance;
    private String matricule;
    private String categorie;
    private String marque;
    private String typeUsage;
    private String usage;
    private String assureNom;
    private String assureAdresse;
    private String matriculeOld;
    private String idQuotation;
    private BigDecimal totalAmount;
    private String email;
    private String phoneNumber;
    private String nom;
    private String prenom;
    private String avenantNumber;
    private String abreviation;
}
