package ma.axa.outer.bff.website.service;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.client.InnerTiersProxy;
import ma.axa.outer.bff.website.dto.GaragesListResponseDto;
import ma.axa.outer.bff.website.dto.IntermediariesDto;
import ma.axa.outer.bff.website.dto.IntermediariesListDto;
import ma.axa.outer.bff.website.dto.SFClinicsListDto;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TiersService {
    public static final String ACTIF = "Actif";
    public static final String EN_COURS = "En Cours";
    public static final String ASC = "ASC";
    private final InnerTiersProxy innerTiersProxy;

    public GaragesListResponseDto getGaragesList(String cityCode, String garageType) {
        GaragesListResponseDto garagesListResponseDto = innerTiersProxy.getGaragesList(cityCode, garageType, ACTIF).getBody();
        return garagesListResponseDto;
    }

    public IntermediariesListDto getIntermediariesList(String cityCode) {
        List<String> intermediaryTypes = Arrays.asList("Agent", "Direct AXA", "Bureau Direct");
        IntermediariesListDto intermediariesListDto = innerTiersProxy.getIntermediariesList(cityCode, null, EN_COURS, intermediaryTypes, ASC).getBody();
        return intermediariesListDto;
    }

    public IntermediariesDto getIntermediary(String intermediaryCode) {
        IntermediariesDto intermediariesDto = innerTiersProxy.getIntermediary(intermediaryCode).getBody();
        return intermediariesDto;
    }

    public SFClinicsListDto getClinicsList(String cityCode, String branch) {
        SFClinicsListDto clinicsList = innerTiersProxy.getSFClinicsList(cityCode, branch).getBody();
        return clinicsList;
    }
}
