package ma.axa.outer.bff.website.dto.quotation.request;

import java.math.BigDecimal;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.outer.bff.website.dto.CapitalAssure;
import ma.axa.outer.bff.website.dto.quotation.QuotationCouvertureMrhDto;

@Data
@SuperBuilder
@NoArgsConstructor
public class PackMrhRequest {
	private BigDecimal idQuotation;
	private CapitalAssure capitalAssure;
	private Boolean contratAutoValid;
	private BigDecimal numPolice;
	private QuotationCouvertureMrhDto quotationCouvert;
}
