package ma.axa.outer.bff.website.service;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.CallMeBackContactRequest;
import ma.axa.outer.bff.website.dto.ContactRequest;
import ma.axa.outer.bff.website.dto.EmailDto;
import ma.axa.outer.bff.website.exception.GlobalException;
import ma.axa.outer.bff.website.mapper.EmailMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ContactService {

    private final InnerNotificationProxy innerNotificationProxy;

    @Value("${axa.mail.contact}")
    private String contactEmail;

    @Async
    public ApiMessageWrapper contactUs(ContactRequest contactRequest) {

        EmailDto email = EmailMapper.toEmail(contactRequest);
        email.setTo(contactEmail);
        try {
            innerNotificationProxy.sendMail(email);
            return new ApiMessageWrapper("Email Sent");
        } catch (Exception e) {
            throw new GlobalException("Error while sending email");
        }
    }

    @Async
    public ApiMessageWrapper callMeBack(CallMeBackContactRequest callMeBackContactRequest) {
        EmailDto email = EmailMapper.toEmail(callMeBackContactRequest);
        email.setTo(contactEmail);
        try {
            innerNotificationProxy.sendMail(email);
            return new ApiMessageWrapper("Email Sent");
        } catch (Exception e) {
            throw new GlobalException("Error while sending email");
        }
    }
}
