package ma.axa.outer.bff.website.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;
import ma.axa.outer.bff.website.dto.error.ApiErrorItem;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper=true)
public class ControllerBusinessException extends RuntimeException {
	private static final long serialVersionUID = 4786368668233461454L;

	private final List<ApiErrorItem>  apiErrorItem ;

	public ControllerBusinessException(List<ApiErrorItem> apiErrorItem) {
		this.apiErrorItem = apiErrorItem;
	}
}
