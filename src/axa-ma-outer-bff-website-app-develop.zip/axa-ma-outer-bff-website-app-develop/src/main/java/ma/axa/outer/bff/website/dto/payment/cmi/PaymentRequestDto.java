package ma.axa.outer.bff.website.dto.payment.cmi;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.enums.PaymentProvider;
import ma.axa.outer.bff.website.enums.PaymentStatus;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentRequestDto {
    @NotNull(message = "L'id quotation est obligatoire.")
    private String quotationId ;
    private String orderId ;
    private PaymentStatus status ;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime orderDate ;
    private BigDecimal totalAmount ;
    @Builder.Default
    private String currency="504" ;
    private List<PaymentSplitDto> amountSplit ;
    @Builder.Default
    private String paymentMode ="PEL" ;
    private String paymentMethod ;
    private List<PaymentItemDto> items ;
    @Builder.Default
    private String paymentType ="TOTAL" ;
    private PaymentClientInfoDto clientInfo ;
    @Builder.Default
    private String countryCode="MA" ;
    @Builder.Default
    private boolean autoConfirmPayment=false ;
    @Builder.Default
    @JsonProperty("isCancellable")
    private boolean cancellable =true ;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime expiryDate ;
    private boolean generateQrCode ;
    @Builder.Default
    private String language="fr" ;
    private List<PaymentExtraDataDto>  extraData ;
    private String quittanceNumber ;
    private String policyNumber ;
    private String policyAvenant;

    private String registrationNumber ;
    private Long intermediaryCode ;
    @Builder.Default
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private PaymentProvider paymentProvider=PaymentProvider.CMI ;
    @Builder.Default
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OrderLinkDto orderLinks = new OrderLinkDto();
}
