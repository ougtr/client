package ma.axa.outer.bff.website.exception;


import lombok.Data;
import lombok.EqualsAndHashCode;
import ma.axa.outer.bff.website.dto.error.ApiError;
import ma.axa.outer.bff.website.util.constants.GlobalConstants;

@Data
@EqualsAndHashCode(callSuper = true)
public class NotFoundException extends GlobalException {

    private static final long serialVersionUID = 606130691394610424L;

    private final ApiError apiError;

    public NotFoundException(String message, ApiError apiError) {
        super(GlobalConstants.URI_RESOURCE_NOT_FOUND, message);
        this.apiError = apiError;
    }
}
