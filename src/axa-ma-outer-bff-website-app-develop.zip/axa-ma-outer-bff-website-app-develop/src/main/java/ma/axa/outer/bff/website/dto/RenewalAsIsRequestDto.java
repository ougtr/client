package ma.axa.outer.bff.website.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotNull;

@Data
@SuperBuilder
@NoArgsConstructor
public class RenewalAsIsRequestDto {

    @NotNull(message = "Le numero de police est obligatoire.")
    @Schema(description = "Numero de police", example = "211231211232")
    @JsonProperty(value = "NumeroPolice")
    private String policyNumber;
}
