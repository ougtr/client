package ma.axa.outer.bff.website.service;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.client.InnerCarQuotationProxy;
import ma.axa.outer.bff.website.client.InnerPaymentCmiProxy;
import ma.axa.outer.bff.website.config.AxaCmiUrlsProps;
import ma.axa.outer.bff.website.dto.payment.cmi.*;
import ma.axa.outer.bff.website.mapper.GreenCardMapper;
import ma.axa.outer.bff.website.util.constants.PaymentConstants;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PaymentCmiService {
    private final InnerPaymentCmiProxy innerApiPaymentCmiProxy;
    private final AxaCmiUrlsProps axaCmiUrlsProps ;
    private final InnerCarQuotationProxy innerCarQuotationProxy;
    private final GreenCardMapper greenCardMapper ;
    private final QuotationAccessTokenService quotationAccessTokenService;
    public PaymentObjectDto createPaymentRequest(PaymentRequestBffDto paymentRequestBffDto) {

        String quotationId = quotationAccessTokenService.extractGreenCardQuotationId(paymentRequestBffDto.getQuotationId());
        var rawPaymentRequest =  innerCarQuotationProxy.getPaymentDetails(quotationId) ;
        var paymentRequest = greenCardMapper.mapToPaymentRequestBffDto(paymentRequestBffDto) ;
        paymentRequest.setQuotationId(quotationId);
        paymentRequest.setClientInfo(greenCardMapper.mapToPaymentClientInfoDto(rawPaymentRequest.getClientInfo()));
        paymentRequest.getClientInfo().setInfoToShow(List.of(PaymentClientInfoItemDto.builder()
                                .key(PaymentConstants.INFO_TO_SHWO_FIELD_CLIENT_NAME).value(String.join(" ",rawPaymentRequest.getClientInfo().getFirstName(),
                                        rawPaymentRequest.getClientInfo().getLastName())).build()));
        paymentRequest.setTotalAmount(rawPaymentRequest.getTotalAmount());
        paymentRequest.setPolicyNumber(rawPaymentRequest.getPolicyNumber());
        paymentRequest.setPolicyAvenant(rawPaymentRequest.getAvenantNumber());
        paymentRequest.setRegistrationNumber(rawPaymentRequest.getRegistrationNumber());
        paymentRequest.setExtraData(List.of(PaymentExtraDataDto.builder().key(PaymentConstants.EXTRA_DATA_FIELD_POLICY_NAME).value(rawPaymentRequest.getPolicyNumber()).build()));
        paymentRequest.setItems(greenCardMapper.mapToListPaymentItemDto(rawPaymentRequest.getItems()));
        resolveOrderLinks(paymentRequest);
        paymentRequest.setOrderDate(LocalDateTime.now());
        paymentRequest.setExpiryDate(LocalDateTime.now().plusDays(PaymentConstants.PAYMENT_REQUEST_EXPIRATION_DAYS));
        return innerApiPaymentCmiProxy.createPaymentRequest(paymentRequest) ;
    }

    private void resolveOrderLinks(PaymentRequestDto paymentRequest) {
        paymentRequest.getOrderLinks().setOkURL(axaCmiUrlsProps.getOkURL());
        paymentRequest.getOrderLinks().setFailURL(axaCmiUrlsProps.getFailUrl());
        paymentRequest.getOrderLinks().setS2sFailURL(axaCmiUrlsProps.getS2sFailUrl());
    }

    public PaymentRequestDetailDto fetchPaymentRequest(String orderId){
        return innerApiPaymentCmiProxy.fetchPaymentRequest(orderId) ;
    }
    public PaymentRequestDetailDto refreshStatus(String orderId){
        return innerApiPaymentCmiProxy.refreshStatus(orderId) ;
    }
    public PaymentRequestDetailDto updatePaymentRequestWithContractDetails(String orderId,PaymentRequestContractDetailsRequest paymentRequestContractDetailsRequest){
        return innerApiPaymentCmiProxy.updatePaymentRequestWithContractDetails(orderId,paymentRequestContractDetailsRequest) ;
    }
}
