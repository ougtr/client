package ma.axa.outer.bff.website.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.captcha.CaptchaService;
import ma.axa.outer.bff.website.dto.request.GreenCardDetailsRequest;
import ma.axa.outer.bff.website.dto.response.GreenCardDetailsResponse;
import ma.axa.outer.bff.website.service.GreenCardService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/green-card")
@RequiredArgsConstructor
public class GreenCardApi {
    private final GreenCardService greenCardService;
    private final CaptchaService captchaService;
    @Value("${axa.web.green-card.success-url}")
    private String greenCardSuccessUrl ;
    @Value("${axa.web.green-card.fail-url}")
    private String greenCardFailUrl ;
    @Operation(summary = "Create new Green Card Quotation")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Green Card Quotation", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = GreenCardDetailsResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Request Invalid", content = @Content),
            @ApiResponse(responseCode = "404", description = "Green Card Quotation not found", content = @Content )})
    @PostMapping
    public ResponseEntity<GreenCardDetailsResponse> createNewGreenCardQuotation(@RequestBody GreenCardDetailsRequest greenCardDetailsRequest, @RequestParam("g-recaptcha-response") String captchaResponse) {
        this.captchaService.processResponse(captchaResponse);
        return this.greenCardService.greenCardDetails(greenCardDetailsRequest);
    }

    @Operation(summary = "Produce Green Card")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Production de la carte verte", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Resource.class))}),
            @ApiResponse(responseCode = "400", description = "Request invalide", content = @Content),
            @ApiResponse(responseCode = "404", description = "Resouce not found", content = @Content )})
    @PostMapping(value = "/produce/{orderId}", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<Resource> produceGreenCard(@PathVariable("orderId") String orderId) {
        return this.greenCardService.launchGreenCardProduction(orderId);
    }

    @Operation(summary = "Success payment Green Card")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Success payment Green Card", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = GreenCardDetailsResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Request Invalid", content = @Content),
            @ApiResponse(responseCode = "404", description = "Success payment Green Card not found", content = @Content )})
    @PostMapping("/payment/success")
    public ResponseEntity<Void> paymentSuccessReturn(@RequestParam String orderId) {
        return ResponseEntity.status(HttpStatus.FOUND).header(HttpHeaders.LOCATION, greenCardSuccessUrl+"?orderId="+orderId).build();
    }

    @Operation(summary = "Fail payment Green Card")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Fail payment Green Card", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = GreenCardDetailsResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Request Invalid", content = @Content),
            @ApiResponse(responseCode = "404", description = "Fail payment Green Card not found", content = @Content )})
    @PostMapping("/payment/fail")
    public ResponseEntity<Void> paymentFailReturn(@RequestParam String orderId) {
        return ResponseEntity.status(HttpStatus.FOUND).header(HttpHeaders.LOCATION, greenCardFailUrl+"?orderId="+orderId).build();
    }
}
