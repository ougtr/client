package ma.axa.outer.bff.website.dto.quotation;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.dto.quotation.request.ContratInfoComp;
import ma.axa.outer.bff.website.dto.quotation.request.DelegationBancaire;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ContratMrh {

	private String effectDate;
	private String expirationDate;
	private String anniversaryDate;
	private String natureHabitation;
	private String typeHabitation;
	private String typeOccupant;
	private String adresseRisque;
	private String localite;
	private String ville;
	private String pays;
	@Default
	private Boolean hasContratAuto = false;
	@Default
	private BigDecimal numPoliceAuto = BigDecimal.ZERO;
	private Boolean hasCompanieAssurance;
	private ContratInfoComp contratInfoComp;
	private Boolean hasDelegBancaire;
	private DelegationBancaire delegationBancaire;
	private Boolean contratSigne ;
}
