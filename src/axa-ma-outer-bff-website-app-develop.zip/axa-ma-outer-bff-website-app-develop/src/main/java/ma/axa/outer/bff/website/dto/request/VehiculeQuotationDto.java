package ma.axa.outer.bff.website.dto.request;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class VehiculeQuotationDto extends VehiculeDto {

    private Character energie;

    private Integer puissanceFiscale;

    private Float tauxCrm;

    private String ficheCrm;

    private String dateMutation;

    private String codeCarrosserie;

    private Integer codeMarque;

    private Integer nombrePlace;
    @Builder.Default
    private Integer  nbAttestation = 1 ;
}
