package ma.axa.outer.bff.website.dto.payment.cmi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GreenCardPaymentClientDto {
    private String firstName ;
    private String lastName ;
    private String email ;
    private String phoneNumber ;
    private String address ;
}
