package ma.axa.outer.bff.website.dto.response;

import lombok.Builder;
import lombok.Data;

import java.util.List;
@Data
@Builder
public class OptionParams {
    private String codeOption;
    private List<TauxRembAMC> listTauxRemb;
    private List<Franchise> listFranchise;
    private List<BaseRembAMC> listBaseRemb;
    private List<Capital> listCapitalDeces;
}
