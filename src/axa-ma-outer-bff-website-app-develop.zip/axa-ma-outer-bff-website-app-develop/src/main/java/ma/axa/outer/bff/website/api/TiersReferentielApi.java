package ma.axa.outer.bff.website.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.dto.GaragesListResponseDto;
import ma.axa.outer.bff.website.dto.IntermediariesDto;
import ma.axa.outer.bff.website.dto.IntermediariesListDto;
import ma.axa.outer.bff.website.dto.SFClinicsListDto;
import ma.axa.outer.bff.website.service.TiersService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/referentiel")
@RequiredArgsConstructor
@Validated
public class TiersReferentielApi {
    private final TiersService tiersService;

    @Operation(summary = "get garages liste")
    @GetMapping(value = "/garages", produces = {"application/json"})
    public ResponseEntity<GaragesListResponseDto> getGaragesList(
            @Parameter(description = "code ville") @RequestParam(name = "city-code", required = false) String cityCode,
            @Parameter(description = "type de garage") @RequestParam(name = "type-garages", required = false) String garagetype
    ) {
        return new ResponseEntity<>(tiersService.getGaragesList(cityCode, garagetype), HttpStatus.OK);
    }

    @Operation(summary = "get intermediaries liste by city")
    @GetMapping(value = "/intermediaires", produces = {"application/json"})
    public ResponseEntity<IntermediariesListDto> getIntermediariesList(
            @Parameter(description = "code ville") @RequestParam(name = "city-code", required = false) String cityCode
    ) {
        return new ResponseEntity<>(tiersService.getIntermediariesList(cityCode), HttpStatus.OK);
    }

    @Operation(summary = "get intermediaries liste by code")
    @GetMapping(value = "/intermediaires/{code}", produces = {"application/json"})
    public ResponseEntity<IntermediariesDto> getIntermediary(
            @Parameter(description = "code intermediaire") @PathVariable(name = "code") String intermediaryCode
    ) {
        return new ResponseEntity<>(tiersService.getIntermediary(intermediaryCode), HttpStatus.OK);
    }

    @Operation(summary = "get clinics list")
    @GetMapping(value = "/cliniques", produces = {"application/json"})
    public ResponseEntity<SFClinicsListDto> getClinicsList(
            @Parameter(description = "city code") @RequestParam(name = "city-code", required = false) String cityCode,
            @Parameter(description = "branch") @RequestParam(name = "branch", required = false) String branch
    ) {
        return new ResponseEntity<>(tiersService.getClinicsList(cityCode, branch), HttpStatus.OK);
    }

}
