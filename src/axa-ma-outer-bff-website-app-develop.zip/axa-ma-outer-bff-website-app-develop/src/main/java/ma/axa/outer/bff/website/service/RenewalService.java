package ma.axa.outer.bff.website.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.outer.bff.website.client.InnerCarQuotationProxy;
import ma.axa.outer.bff.website.client.InnerQuotationProxy;
import ma.axa.outer.bff.website.client.InnerTiersProxy;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.IntermediariesDto;
import ma.axa.outer.bff.website.dto.RenewalContractValidationInput;
import ma.axa.outer.bff.website.dto.RenewalDataResponseDto;
import ma.axa.outer.bff.website.dto.error.ViolationErrorResponse;
import ma.axa.outer.bff.website.exception.ControllerBusinessException;
import ma.axa.outer.bff.website.exception.InnerClientException;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
@Slf4j
public class RenewalService {
    private final InnerCarQuotationProxy innerQuotationProxy;
    private final InnerTiersProxy innerTiersProxy;

    public RenewalDataResponseDto getRenewalData(String request) {
        try {
            RenewalDataResponseDto renewalDataResponseDto = innerQuotationProxy.getRenewalData(request).getBody();
            IntermediariesDto intermediariesDto = null;
            if (renewalDataResponseDto != null && renewalDataResponseDto.getContractInfos() != null) {
                intermediariesDto = innerTiersProxy.getIntermediary(renewalDataResponseDto.getContractInfos().getIntermediaryCode()).getBody();
                renewalDataResponseDto.setIntermediaryInfos(intermediariesDto);
            }
            return renewalDataResponseDto;
        } catch (InnerClientException exception) {
            ViolationErrorResponse violationError = buildViolationError(exception.getApiError().getType());
            throw new ControllerBusinessException(violationError.getErrors());
        }
    }

    private ViolationErrorResponse buildViolationError(String type) {
        ViolationErrorResponse violationError = new ViolationErrorResponse();
        try {
            violationError = new ObjectMapper().readValue(type, ViolationErrorResponse.class);
        } catch (JsonProcessingException exception) {
            log.error(exception.getMessage());
        }
        return violationError;
    }

    public ApiMessageWrapper validateRenewalContract(RenewalContractValidationInput renewalContractValidationInput) {
        return innerQuotationProxy.validateContract(renewalContractValidationInput).getBody();
    }
}
