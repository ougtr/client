package ma.axa.outer.bff.website.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class OTPRequestDto {

    @NotEmpty
    @Pattern(regexp = "^(212)\\d{9}$", message = "Format Incorrect du Numéro du Téléphone")
    private String phoneNumber;

}
