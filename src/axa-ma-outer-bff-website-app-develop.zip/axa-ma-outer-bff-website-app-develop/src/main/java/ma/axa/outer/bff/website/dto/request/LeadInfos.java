package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LeadInfos {
    private String city;
    private String phoneNumber;
    private String licenceDate;
    private String brandName;
    private String intermediateName;
    private Boolean cguConsent;
    private Boolean marketingConsent;
}
