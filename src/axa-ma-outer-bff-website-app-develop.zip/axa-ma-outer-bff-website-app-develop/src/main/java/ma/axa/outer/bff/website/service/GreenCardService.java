package ma.axa.outer.bff.website.service;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.client.InnerPartnerProxy;
import ma.axa.outer.bff.website.client.InnerPaymentCmiProxy;
import ma.axa.outer.bff.website.client.InnerQuotationProxy;
import ma.axa.outer.bff.website.dto.payment.cmi.PaymentRequestContractDetailsRequest;
import ma.axa.outer.bff.website.dto.payment.cmi.PaymentRequestDetailDto;
import ma.axa.outer.bff.website.dto.request.GreenCardAvenantRequest;
import ma.axa.outer.bff.website.dto.request.GreenCardDetailsRequest;
import ma.axa.outer.bff.website.dto.response.GreenCardAvenantDto;
import ma.axa.outer.bff.website.dto.response.GreenCardDetailsResponse;
import ma.axa.outer.bff.website.dto.response.GreenCardProductionResponse;
import ma.axa.outer.bff.website.enums.PaymentStatus;
import ma.axa.outer.bff.website.exception.GlobalException;
import ma.axa.outer.bff.website.util.constants.GlobalConstants;
import ma.axa.outer.bff.website.util.constants.PaymentConstants;
import org.bouncycastle.util.encoders.Base64;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static ma.axa.outer.bff.website.util.constants.GlobalConstants.URI_INTER_SERVICE_COMMUNICATION;
import static ma.axa.outer.bff.website.util.constants.GlobalConstants.URI_VALIDATION_CONSTRAINT_VIOLATION;

@Service
@Slf4j
@AllArgsConstructor
public class GreenCardService {
    public static final String CODE_INTERMEDIAIRE_0 = "0";
    private static final DateTimeFormatter GREEN_CARD_EMAIL_DATE_FORMATTER = DateTimeFormatter.ofPattern(GlobalConstants.DEVIS_DATE_FORMAT);
    private final InnerPartnerProxy partnerClient;
    private final InnerNotificationProxy notificationService;
    private final InnerQuotationProxy quotationClient;
    private final EmailContentProtectionService emailContentProtectionService;
    private final QuotationAccessTokenService quotationAccessTokenService;
    public final  PaymentCmiService paymentCmiService;

    public ResponseEntity<Resource> launchGreenCardProduction(String orderId) {
        GreenCardProductionContext greenCardProductionContext = validateGreenCardProductionRequest(orderId);
        GreenCardDetailsResponse greenCardDetailsResponse = greenCardProductionContext.greenCardDetailsResponse;
        // Force code to zero for production to avoid the consumptions of intermidiare tokens in green card production
        greenCardDetailsResponse.setCodeIntermediaire(CODE_INTERMEDIAIRE_0);
        ResponseEntity<GreenCardProductionResponse> response = partnerClient.produceGreenCard(greenCardDetailsResponse);
        var  greenCardResponsePartner  = response.getBody();
        if(isResponseInvalid(response) || greenCardResponsePartner == null) {
            throw new GlobalException(URI_VALIDATION_CONSTRAINT_VIOLATION, PaymentConstants.GREEN_CARD_PRODUCTION_ERROR_MESSAGE);
        }
        // update paymentRequest by green card details
        var paymentRequestContractDetailsRequest =  PaymentRequestContractDetailsRequest.builder()
                .quittanceNumber(greenCardResponsePartner.getNumero()).build() ;
        this.paymentCmiService.updatePaymentRequestWithContractDetails(orderId,paymentRequestContractDetailsRequest) ;
        Resource producedGreenCard = new ByteArrayResource(decodeBase64String(Objects.requireNonNull(greenCardResponsePartner).getPdfStream()));
        this.sendGreenCardEmail(producedGreenCard, greenCardDetailsResponse.getEmail(), greenCardDetailsResponse,
                greenCardProductionContext.paymentRequestDetailDto, orderId);
        this.validateGreenCardAvenant(greenCardDetailsResponse.getIdQuotation(), String.valueOf(greenCardDetailsResponse.getAttestation()));
        return ResponseEntity.ok().body(producedGreenCard);
    }

    public void validateGreenCardAvenant(String quotationId, String greenCardAttestation) {
        GreenCardAvenantRequest greenCardDetailsRequest = new GreenCardAvenantRequest(quotationId, greenCardAttestation);
        ResponseEntity<GreenCardAvenantDto> response =  this.quotationClient.validateGreenCardAvenant(greenCardDetailsRequest);
        if(isResponseInvalid(response) || response.getBody() == null) {
            throw new GlobalException(URI_VALIDATION_CONSTRAINT_VIOLATION, PaymentConstants.GREEN_CARD_AVENANT_VALIDATION_ERROR);
        }
    }

    private void sendGreenCardEmail(Resource resource, String email, GreenCardDetailsResponse greenCardDetailsResponse, PaymentRequestDetailDto paymentRequestDetailDto, String orderId) {
        try {
            MultipartFile attachment = this.getGreenCardAsMultipartFile(resource.getInputStream().readAllBytes());
            String variables = buildGreenCardEmailVariables(greenCardDetailsResponse, paymentRequestDetailDto, orderId);
            notificationService.sendEmail(List.of(email), null, GlobalConstants.GREEN_CARD_RECEPTION_MAIL_TEMPLATE,
                    GlobalConstants.GREEN_CARD_RECEPTION_EMAIL_SUBJECT, variables,
                    GlobalConstants.AXA_WEB_NO_REPLAY_EMAIL, new MultipartFile[]{attachment});
        } catch (Exception e) {
            log.error("Error while sending email of green card");
            throw new GlobalException(URI_INTER_SERVICE_COMMUNICATION, PaymentConstants.GREEN_CARD_EMAIL_ERROR_MESSAGE);
        }
    }

    private String buildGreenCardEmailVariables(GreenCardDetailsResponse greenCardDetailsResponse, PaymentRequestDetailDto paymentRequestDetailDto, String fallbackOrderId) {
        Map<String, String> variables = new HashMap<>();
        variables.put("firstName", valueOrEmpty(greenCardDetailsResponse.getPrenom()));
        variables.put("transactionNumber", getTransactionNumber(paymentRequestDetailDto, fallbackOrderId));
        variables.put("purchaseDate", formatPurchaseDate(paymentRequestDetailDto.getOrderDate()));
        variables.put("vehicleRegistration", valueOrEmpty(greenCardDetailsResponse.getMatricule()));
        return emailContentProtectionService.toTemplateVariablesJson(variables);
    }

    private String getTransactionNumber(PaymentRequestDetailDto paymentRequestDetailDto, String fallbackOrderId) {
        if (StringUtils.hasText(paymentRequestDetailDto.getOrderId())) {
            return paymentRequestDetailDto.getOrderId();
        }
        return valueOrEmpty(fallbackOrderId);
    }

    private String formatPurchaseDate(LocalDateTime orderDate) {
        if (orderDate == null) {
            return "";
        }
        return orderDate.format(GREEN_CARD_EMAIL_DATE_FORMATTER);
    }

    private String valueOrEmpty(String value) {
        return value == null ? "" : value;
    }

    private MultipartFile getGreenCardAsMultipartFile(byte[] file) {
        return new MockMultipartFile(GlobalConstants.GREEN_CARD_FILE_NAME, GlobalConstants.GREEN_CARD_FILE_NAME,
                MediaType.APPLICATION_PDF_VALUE,
                file);
    }

    public ResponseEntity<GreenCardDetailsResponse> greenCardDetails(GreenCardDetailsRequest greenCardDetailsRequest) {
        ResponseEntity<GreenCardDetailsResponse> response = this.quotationClient.createNewGreenCardQuotation(greenCardDetailsRequest);
        if (response == null || response.getBody() == null || !response.getStatusCode().is2xxSuccessful()) {
            return response;
        }
        GreenCardDetailsResponse greenCardDetailsResponse = response.getBody();
        if (StringUtils.hasText(greenCardDetailsResponse.getIdQuotation())) {
            greenCardDetailsResponse.setIdQuotation(
                    quotationAccessTokenService.generateGreenCardQuotationToken(greenCardDetailsResponse.getIdQuotation()));
        }
        return response;
    }

    /** Decode base64 string */
    public static byte[] decodeBase64String(String base64String) {
        return Base64.decode(base64String);
    }

    private boolean isResponseInvalid(ResponseEntity<?> response) {
        return response == null || response.getStatusCode() != HttpStatus.OK;
    }

    private GreenCardProductionContext validateGreenCardProductionRequest(String orderId) {
        PaymentRequestDetailDto paymentRequestDto = paymentCmiService.fetchPaymentRequest(orderId);
        if(paymentRequestDto == null)  throw new GlobalException(URI_VALIDATION_CONSTRAINT_VIOLATION, PaymentConstants.PAYMENT_REQUEST_NOT_FOUND);
        if(paymentRequestDto.getStatus() != PaymentStatus.PAID ) {
            throw new GlobalException(URI_VALIDATION_CONSTRAINT_VIOLATION, PaymentConstants.PAYMENT_STATUS_IS_UNPAID);
        }
        if(!StringUtils.hasText(paymentRequestDto.getQuotationId())) {
            throw new GlobalException(URI_VALIDATION_CONSTRAINT_VIOLATION, PaymentConstants.PAYMENT_QUOTATION_NOT_FOUND);
        }
        if(StringUtils.hasText(paymentRequestDto.getQuittanceNumber())) {
            throw new GlobalException(URI_VALIDATION_CONSTRAINT_VIOLATION, PaymentConstants.GREEN_CARD_ALREADY_GENERATED);
        }
        ResponseEntity<GreenCardDetailsResponse> quotationDetailsResponse = this.quotationClient.getQuotationDetails(paymentRequestDto.getQuotationId());
        if(isResponseInvalid(quotationDetailsResponse) || quotationDetailsResponse.getBody() == null) {
            throw new GlobalException(URI_VALIDATION_CONSTRAINT_VIOLATION, PaymentConstants.PAYMENT_QUOTATION_NOT_FOUND);
        }
        return new GreenCardProductionContext(paymentRequestDto, quotationDetailsResponse.getBody());
    }

    private static final class GreenCardProductionContext {
        private final PaymentRequestDetailDto paymentRequestDetailDto;
        private final GreenCardDetailsResponse greenCardDetailsResponse;

        private GreenCardProductionContext(PaymentRequestDetailDto paymentRequestDetailDto, GreenCardDetailsResponse greenCardDetailsResponse) {
            this.paymentRequestDetailDto = paymentRequestDetailDto;
            this.greenCardDetailsResponse = greenCardDetailsResponse;
        }
    }
}
