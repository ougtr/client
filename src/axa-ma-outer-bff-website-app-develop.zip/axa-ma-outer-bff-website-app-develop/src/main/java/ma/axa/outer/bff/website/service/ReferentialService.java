package ma.axa.outer.bff.website.service;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.client.InnerDataRefProxy;
import ma.axa.outer.bff.website.config.JsonProperties;
import ma.axa.outer.bff.website.dto.RefDataResponse;
import ma.axa.outer.bff.website.dto.response.FuelDto;
import ma.axa.outer.bff.website.util.constants.GlobalConstants;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@RequiredArgsConstructor
public class ReferentialService {
	private final InnerDataRefProxy innerDataRefProxy;
	private final JsonProperties jsonProperties;

	public List<RefDataResponse> getCities() {
		return innerDataRefProxy.getCities(GlobalConstants.MOROCCO_COUNTRY_CODE).getBody();
	}

	public List<RefDataResponse> getBrands() {return innerDataRefProxy.getBrands(GlobalConstants.PRODUCT_TOURISM_CODE).getBody();}

	public List<FuelDto> getFuel() {
		return jsonProperties.getFuel();
	}

}
