package ma.axa.outer.bff.website.api;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.dto.request.BeneficiaryRequestDto;
import ma.axa.outer.bff.website.dto.response.BeneficiaryResponseDto;
import ma.axa.outer.bff.website.service.HealthContractService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/v1/dabadoc")
@RequiredArgsConstructor
public class HealthContractApi {
    private final HealthContractService healthContractService;

    @GetMapping(value = "/beneficiaries")
    public ResponseEntity<List<BeneficiaryResponseDto>> getBeneficiaries(BeneficiaryRequestDto beneficiaryRequestDto) {
        return new ResponseEntity<>(healthContractService.getBeneficiariesDetails(beneficiaryRequestDto), HttpStatus.OK);
    }
}