package ma.axa.outer.bff.website.config;

import feign.FeignException;
import ma.axa.outer.bff.website.dto.error.ApiError;
import ma.axa.outer.bff.website.dto.error.ApiErrorItem;
import ma.axa.outer.bff.website.dto.error.InnerClientErrorResponse;
import ma.axa.outer.bff.website.dto.error.ViolationErrorResponse;
import ma.axa.outer.bff.website.exception.*;
import ma.axa.outer.bff.website.util.constants.GlobalConstants;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.validation.ConstraintViolationException;
import java.util.stream.Collectors;

@RestControllerAdvice
public class ErrorHandlingAdvice {

	@ExceptionHandler(MissingServletRequestParameterException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	ApiError onMissingServletRequestParameterException(
			MissingServletRequestParameterException e) {
		return ApiError.builder()
				.type(GlobalConstants.URI_MISSING_REQUEST_PARAMETER)
				.title("Missing Request Parameter").detail(e.getMessage())
				.status(HttpStatus.BAD_REQUEST.value()).build();
	}

	@ExceptionHandler(FeignException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	ApiError onFeignException(FeignException e) {

		return ApiError.builder()
				.type(GlobalConstants.URI_INTER_SERVICE_COMMUNICATION)
				.title("Inter Service Communication").detail(e.getMessage())
				.status(HttpStatus.INTERNAL_SERVER_ERROR.value()).build();
	}

	@ExceptionHandler(InnerClientException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	InnerClientErrorResponse onInnerClientException(InnerClientException e) {

		return InnerClientErrorResponse.builder()
				.type(GlobalConstants.URI_INTER_SERVICE_COMMUNICATION)
				.title("Inter Service Communication").detail(e.getMessage())
				.status(HttpStatus.INTERNAL_SERVER_ERROR.value())
				.clientError(e.getApiError()).build();
	}

	@ExceptionHandler(ConstraintViolationException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	ViolationErrorResponse onConstraintValidationException(
			ConstraintViolationException e) {
		return ViolationErrorResponse.builder()
				.type(GlobalConstants.URI_VALIDATION_CONSTRAINT_VIOLATION)
				.title("Field validation").detail(e.getMessage())
				.status(HttpStatus.BAD_REQUEST.value())
				.errors(e.getConstraintViolations().stream()
						.map(violation -> ApiErrorItem.builder()
								.target(violation.getPropertyPath().toString())
								.message(violation.getMessage()).build())
						.collect(Collectors.toList()))
				.build();
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	ViolationErrorResponse onMethodArgumentNotValidException(
			MethodArgumentNotValidException e) {

		return ViolationErrorResponse.builder()
				.type(GlobalConstants.URI_METHOD_ARGUMENT_NOT_VALID)
				.title("Method Argument Not Valid").detail(e.getMessage())
				.status(HttpStatus.BAD_REQUEST.value())
				.errors(e.getBindingResult().getFieldErrors().stream()
						.map(fieldError -> ApiErrorItem.builder()
								.target(fieldError.getField())
								.message(fieldError.getDefaultMessage())
								.build())
						.collect(Collectors.toList()))
				.build();
	}

	@ExceptionHandler(NotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	InnerClientErrorResponse onInnerClientNotFoundException(NotFoundException e) {

		return InnerClientErrorResponse.builder()
				.type(GlobalConstants.URI_RESOURCE_NOT_FOUND)
				.title("Resource Not Found").detail(e.getMessage())
				.status(HttpStatus.NOT_FOUND.value())
				.clientError(e.getApiError()).build();
	}

	@ExceptionHandler(InvalidSignedTokenException.class)
	@ResponseStatus(HttpStatus.FORBIDDEN)
	ApiError onInvalidSignedTokenException(InvalidSignedTokenException e) {
		return ApiError.builder()
				.type(GlobalConstants.URI_INVALID_SIGNED_TOKEN)
				.title("Invalid Signed Token")
				.detail(e.getMessage())
				.status(HttpStatus.FORBIDDEN.value())
				.build();
	}

	@ExceptionHandler(GlobalException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	InnerClientErrorResponse onGlobalException(GlobalException e) {

		return InnerClientErrorResponse.builder()
				.type(GlobalConstants.URI_INTER_SERVICE_COMMUNICATION)
				.title(e.getType()).detail(e.getMessage())
				.status(HttpStatus.INTERNAL_SERVER_ERROR.value()).build();
	}

	@ExceptionHandler(ControllerBusinessException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	ViolationErrorResponse onMethodControllerBusinessException(ControllerBusinessException e) {
		return ViolationErrorResponse.builder()
				.type(GlobalConstants.URI_METHOD_ARGUMENT_NOT_VALID)
				.title("Error Request Parameter")
				.detail(e.getMessage())
				.errors(e.getApiErrorItem())
				.status(HttpStatus.BAD_REQUEST.value()).build() ;
	}

	@ExceptionHandler(GenericInnerClientException.class)
//	@ResponseStatus(HttpStatus.BAD_REQUEST)
	InnerClientErrorResponse onMethodGenericInnerClientException(GenericInnerClientException e) {
		return InnerClientErrorResponse.builder()
				.type(GlobalConstants.URI_INTER_SERVICE_COMMUNICATION)
				.title("Inter Service Communication").detail(e.getMessage())
				.status(e.getApiError().getStatus())
				.clientError(e.getApiError()).build();
	}

}
