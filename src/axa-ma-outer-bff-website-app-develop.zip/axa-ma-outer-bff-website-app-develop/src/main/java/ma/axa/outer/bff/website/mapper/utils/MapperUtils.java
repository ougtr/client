package ma.axa.outer.bff.website.mapper.utils;

import lombok.experimental.UtilityClass;
import org.mapstruct.Named;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
@UtilityClass
public class MapperUtils {

    public static String FormatDateForSF(String date) {
        String sfDate = date != null ? date.substring(6, 10) + "-" + date.substring(3, 5) + "-" + date.substring(0, 2) : "";
        return sfDate;
    }

    public static String localDateToString(LocalDate date, String format) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        return date.format(formatter);
    }

    public static BigDecimal stringToBigDecimal(String value) {
        return new BigDecimal(value);
    }

    public static BigDecimal localDateToBigDecimal(LocalDate date, String format){
        return stringToBigDecimal(localDateToString(date, format));
    }

    @Named("setNumAffilie")
    public static BigDecimal setNumAffilie(BigDecimal value) {
        return new BigDecimal(1);
    }

    @Named("setPrestation")
    public static BigDecimal setPrestation(BigDecimal value) {
        return new BigDecimal(999);
    }

    @Named("splitPolicyNumberFirstPart")
    public static String splitFirstPart(String policyNumber) {
        return policyNumber.substring(0, 3);
    }

    @Named("splitPolicyNumberSecondPart")
    public static String splitSecondPart(String policyNumber) {
        return policyNumber.substring(3);
    }
}
