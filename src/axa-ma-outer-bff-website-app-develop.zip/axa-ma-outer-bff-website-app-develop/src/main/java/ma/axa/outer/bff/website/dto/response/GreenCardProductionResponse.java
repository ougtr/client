package ma.axa.outer.bff.website.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class GreenCardProductionResponse {
    private Integer solde ;
    private String  numero;
    private String pdfStream  ;
    private String  qrCode;
    private String methode ;
}
