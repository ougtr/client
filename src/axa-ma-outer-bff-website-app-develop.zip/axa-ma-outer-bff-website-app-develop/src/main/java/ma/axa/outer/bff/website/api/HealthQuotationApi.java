package ma.axa.outer.bff.website.api;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.PsiSimulationRequestDto;
import ma.axa.outer.bff.website.dto.PsiSimulationResponseDto;
import ma.axa.outer.bff.website.dto.request.PsiPremiumSimulationRequest;
import ma.axa.outer.bff.website.dto.response.TarifResponseDto;
import ma.axa.outer.bff.website.service.EmailContentProtectionService;
import ma.axa.outer.bff.website.service.HealthService;
import ma.axa.outer.bff.website.service.PrintingService;
import ma.axa.outer.bff.website.service.QuotationAccessTokenService;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/v1/health")
@RequiredArgsConstructor
@Validated
public class HealthQuotationApi {
    private final HealthService healthService;
    private final ICaptchaService captchaService;
    private final PrintingService printingService;
    private final QuotationAccessTokenService quotationAccessTokenService;
    private final EmailContentProtectionService emailContentProtectionService;

    @PostMapping(value = "/simulation", produces = {"application/json"})
    @Deprecated(since = "1.0.9")
    public ResponseEntity<PsiSimulationResponseDto> getPsiSimulation(
            @RequestBody @Valid PsiSimulationRequestDto psiSimulationRequestDto
    ) {
        return new ResponseEntity<>(healthService.getPsiSimulation(psiSimulationRequestDto), HttpStatus.OK);
    }

    @PostMapping(value = "/calculate-premium", produces = {"application/json"})
    public ResponseEntity<TarifResponseDto> calculatePremium(@RequestBody PsiPremiumSimulationRequest psiPremiumSimulationRequest, @RequestParam("g-recaptcha-response") String captchaResponse
    ) {
        captchaService.processResponse(captchaResponse);
        return new ResponseEntity<>(healthService.calculatePsiPremium(psiPremiumSimulationRequest), HttpStatus.OK);

    }

    @GetMapping(value = "/devis")
    public ResponseEntity<Resource> printDevis(@RequestParam String quotationId) {
        String resolvedQuotationId = quotationAccessTokenService.extractHealthQuotationId(quotationId);
        return new ResponseEntity<>(printingService.getDevisFile(resolvedQuotationId), HttpStatus.OK);
    }

    @GetMapping(value = "/send-mail")
    public ResponseEntity<ApiMessageWrapper> sendDevis(@RequestParam String quotationId, @RequestParam String mailAddress, @RequestParam String name) {
        String resolvedQuotationId = quotationAccessTokenService.extractHealthQuotationId(quotationId);
        String sanitizedName = emailContentProtectionService.sanitizeDisplayName("name", name);
        return new ResponseEntity<>(healthService.sendMail(resolvedQuotationId, mailAddress, sanitizedName), HttpStatus.OK);
    }
}
