package ma.axa.outer.bff.website.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class RenewalPersonInfos {
    private String lastName;
    private String firstName;
    private String address;
    private String city;
    private String phoneNumber;
}
