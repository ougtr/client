package ma.axa.outer.bff.website.dto.payment.cmi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentClientInfoItemDto {
    private String key ;
    private String value ;
}
