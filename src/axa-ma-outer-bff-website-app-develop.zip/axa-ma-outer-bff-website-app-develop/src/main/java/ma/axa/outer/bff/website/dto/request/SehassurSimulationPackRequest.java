package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SehassurSimulationPackRequest {
    private String packCode;
    private String fraction;
    private String rembRate;
    private String rembBase;
    private String deathCapital;
    private String disease;
}
