package ma.axa.outer.bff.website.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class FormuleMrhDto extends RefDataMRHResponse {
	private Boolean checked;
	private Boolean disabled;
}
