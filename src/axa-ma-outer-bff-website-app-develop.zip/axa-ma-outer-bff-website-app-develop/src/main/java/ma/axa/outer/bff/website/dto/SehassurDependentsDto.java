package ma.axa.outer.bff.website.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;

@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SehassurDependentsDto {
    private LocalDate birthDate;
    private  String type;
    private String deathCapital;
}
