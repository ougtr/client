package ma.axa.outer.bff.website.util;

import java.io.IOException;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;



public class BigdecimalConverter extends JsonDeserializer<String> {

    @Override
    public String deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JacksonException {
        String dateFormatedAs400 = p.readValueAs(String.class);
        if(dateFormatedAs400 == null || dateFormatedAs400.equals("0")) return dateFormatedAs400 ;
        if(dateFormatedAs400.length() == 8){
            dateFormatedAs400 =  dateFormatedAs400.join("/", dateFormatedAs400.substring(dateFormatedAs400.length()-2),dateFormatedAs400.substring(4,6),dateFormatedAs400.substring(0,4))  ;
        }
        return dateFormatedAs400;
    }
}