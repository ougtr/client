package ma.axa.outer.bff.website.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.ClaimRequest;
import ma.axa.outer.bff.website.service.ClaimService;
import ma.axa.outer.bff.website.service.EmailContentProtectionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/claims")
@RequiredArgsConstructor
@Validated
public class ClaimApi {

    private final ClaimService claimService;
    private final ICaptchaService captchaService;
    private final EmailContentProtectionService emailContentProtectionService;

    @Operation(summary = "Create Claim")
    @ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Claim created", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = ApiMessageWrapper.class)) }),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content) })
    @PostMapping(produces = { "application/json" }, consumes = { "application/json" })
    public ResponseEntity<ApiMessageWrapper> createClaim(@RequestBody ClaimRequest claimRequest,
                                                         @RequestParam("g-recaptcha-response") String captchaResponse) {
        captchaService.processResponse(captchaResponse);
        return new ResponseEntity<>(claimService.createClaim(emailContentProtectionService.sanitize(claimRequest)), HttpStatus.CREATED);
    }
}
