package ma.axa.outer.bff.website.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Tarif {

	private BigDecimal mntTotal;
	private BigDecimal mntDeces;
	private BigDecimal mntMal;
	private String flagSiege;
	private String codeRetour;
	private String libelleAnomalie;
	private BigDecimal mntDecesRedoute;
	private BigDecimal mntMalRedoute;
	private BigDecimal mntMalRedouteBrut;
	private BigDecimal mntMalBrut;
	private BigDecimal nbrJour;
}
