package ma.axa.outer.bff.website.client;

import ma.axa.outer.bff.website.client.config.InnerClientConfig;
import ma.axa.outer.bff.website.dto.request.BeneficiaireRequest;
import ma.axa.outer.bff.website.dto.response.Beneficiaire;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "innerHealthContractProxy", url = "${axa.client.inner-contract-health}", configuration = InnerClientConfig.class)
public interface HealthContractProxy {

    @GetMapping(path = "/v1/sehassur/contrats/beneficiaries" ,consumes = {"application/json"})
    ResponseEntity<List<Beneficiaire>> getBeneficiaires(@SpringQueryMap BeneficiaireRequest beneficiaireRequest);

}