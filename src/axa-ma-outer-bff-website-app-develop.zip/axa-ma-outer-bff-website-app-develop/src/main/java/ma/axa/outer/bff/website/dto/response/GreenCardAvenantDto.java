package ma.axa.outer.bff.website.dto.response;

import lombok.Data;

@Data
public class GreenCardAvenantDto {
    private String policyNumber;
    private String avenantNumber;
}
