package ma.axa.outer.bff.website.api;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.dto.response.AssitanceRefDto;
import ma.axa.outer.bff.website.dto.response.GuaranteesDto;
import ma.axa.outer.bff.website.dto.response.PacksDto;
import ma.axa.outer.bff.website.service.JsonRefService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/auto")
@RequiredArgsConstructor
@Validated
public class RefAutoApi {
    private final JsonRefService jsonRefService;

    @GetMapping(value = "/assistance/packs" ,produces = {"application/json"})
    public ResponseEntity<List<AssitanceRefDto>> getAssistanceHeaders() {
        return new ResponseEntity<>(jsonRefService.getAssistanceHeaders(), HttpStatus.OK);
    }

    @GetMapping(value = "/assistance/details", produces = {"application/json"})
    public ResponseEntity<List<PacksDto>> getAssistanceDetails() {
        return new ResponseEntity<>(jsonRefService.getAssistancePack(), HttpStatus.OK);
    }

    @GetMapping(value = "/guarantees/packs", produces = {"application/json"})
    public ResponseEntity<List<GuaranteesDto>> getGuaranteesPacks() {
        return new ResponseEntity<>(jsonRefService.getGuaranteesPacks(), HttpStatus.OK);
    }
}
