package ma.axa.outer.bff.website.dto.quotation.request;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.dto.CapitalAssure;
import ma.axa.outer.bff.website.dto.quotation.AvenantData;
import ma.axa.outer.bff.website.dto.quotation.ContratMrh;
import ma.axa.outer.bff.website.dto.quotation.QuotationCouvertureMrhDto;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QuotationMrhContrat{
	
	 @Default
    private String agentCode="205";
    @Default
    private String userName="qualif205";
    @Default
    private String typeGestion = "";
	@JsonProperty("IdQuotation")
	private BigDecimal idQuotation;
	private CapitalAssure capitalAssure;
	private AvenantData avenant;
	private ContratMrh contrat;
	private QuotationCouvertureMrhDto quotationCouvert;
	
	
}
