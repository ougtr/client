package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Personne {

    private Character typePersonne;

    private Character sexe;

    private String civilite;

    private String nom;

    private String prenom;

    private String adresse;

    private BigDecimal codeVille;

    private BigDecimal codePays;

    private String identifiant;

    private String raisonSociale;
}
