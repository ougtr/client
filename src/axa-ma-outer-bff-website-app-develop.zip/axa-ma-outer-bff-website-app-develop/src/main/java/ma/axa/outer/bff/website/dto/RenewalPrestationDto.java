package ma.axa.outer.bff.website.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class RenewalPrestationDto {
    private String label;
    private String comment;
}
