package ma.axa.outer.bff.website.dto.request;

import lombok.Data;

@Data
public class GreenCardRequest {
    private String email;
    private CarteVerte carteVerte;
}
