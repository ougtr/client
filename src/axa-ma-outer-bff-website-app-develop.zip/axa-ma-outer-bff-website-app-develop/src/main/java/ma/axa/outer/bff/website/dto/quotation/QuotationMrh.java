package ma.axa.outer.bff.website.dto.quotation;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.outer.bff.website.dto.CapitalAssure;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class QuotationMrh {
	@JsonProperty("IdQuotation")
	@Schema(description = "Id quotation")
	private BigDecimal idQuotation;
	@Schema(description = "les capitaux assurés")
	private CapitalAssure capitalAssure;
	@Schema(description = "l'avenant à saisir")
	private AvenantData avenant;
	@Schema(description = "les informations du contrat")
	private ContratMrh contrat;
	@Schema(description = "les information de couverture")
	private QuotationCouvertureMrhDto quotationCouvert;
}
