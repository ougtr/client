package ma.axa.outer.bff.website.dto.response;

import lombok.Data;

@Data
public class GreenCardResponse {
    private String message;
}