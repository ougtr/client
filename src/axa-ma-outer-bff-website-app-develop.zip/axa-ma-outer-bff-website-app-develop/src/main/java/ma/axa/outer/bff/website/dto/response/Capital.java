package ma.axa.outer.bff.website.dto.response;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
@Data
@Builder
public class Capital {
    private String code;
    private String libelle;
    private Double mntCapital;
    private BigDecimal dateDebut;
    private Double tauxCapital;
}
