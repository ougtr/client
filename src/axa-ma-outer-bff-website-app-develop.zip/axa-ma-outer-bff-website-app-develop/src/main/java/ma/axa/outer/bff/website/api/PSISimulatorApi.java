package ma.axa.outer.bff.website.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.PSIProspectDto;
import ma.axa.outer.bff.website.dto.ProspectResponseDto;
import ma.axa.outer.bff.website.dto.response.HealthPackResponse;
import ma.axa.outer.bff.website.dto.response.HealthSehassurPacksResponseDto;
import ma.axa.outer.bff.website.service.HealthProductService;
import ma.axa.outer.bff.website.service.PSISimulatorService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/psi")
@RequiredArgsConstructor
@Validated
public class PSISimulatorApi {

    private final PSISimulatorService psiSimulatorService;
    private final ICaptchaService captchaService;
    private final HealthProductService healthProductService;

    @Operation(summary = "Save prospect")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Prospect created", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = ProspectResponseDto.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
    @PostMapping(value = "/prospect", produces = {"application/json"}, consumes = {"application/json"})
    public ResponseEntity<ProspectResponseDto> saveProspect(@RequestBody PSIProspectDto prospect,
                                                            @RequestParam("g-recaptcha-response") String captchaResponse) {
        captchaService.processResponse(captchaResponse);
        return new ResponseEntity<>(psiSimulatorService.saveProspect(prospect), HttpStatus.CREATED);
    }

    @Operation(summary = "Update Prospect")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Prospect updated", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = ProspectResponseDto.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
    @PutMapping(value = "/prospect/{prospectId}", produces = {"application/json"}, consumes = {"application/json"})
    public ResponseEntity<ProspectResponseDto> updateProspect(@RequestBody PSIProspectDto prospect, @PathVariable String prospectId,
                                                              @RequestParam("g-recaptcha-response") String captchaResponse) {
        captchaService.processResponse(captchaResponse);
        prospect.setLeadId(prospectId);
        return new ResponseEntity<>(psiSimulatorService.updateProspect(prospect), HttpStatus.OK);
    }
    @GetMapping(value = "/packs", produces = {"application/json"})
    public ResponseEntity<List<HealthPackResponse>> getPacks() {
        return new ResponseEntity<>(healthProductService.getAllPacksPsi(), HttpStatus.OK);
    }




}
