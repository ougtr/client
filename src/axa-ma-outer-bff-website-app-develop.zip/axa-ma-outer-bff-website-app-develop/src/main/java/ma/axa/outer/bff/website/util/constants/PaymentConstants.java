package ma.axa.outer.bff.website.util.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class PaymentConstants {
    public static final String INFO_TO_SHWO_FIELD_CLIENT_NAME="Nom Client" ;
    public static final String EXTRA_DATA_FIELD_POLICY_NAME="Numéro Contrat" ;
    public static final Integer PAYMENT_REQUEST_EXPIRATION_DAYS=3 ;
    public static final String PAYMENT_STATUS_IS_UNPAID = "Ce paiement n'a pas encore été effectué";
    public static final String PAYMENT_QUOTATION_NOT_FOUND = "Ce paiement n'est associé à aucune cotation";
    public static final String GREEN_CARD_PRODUCTION_ERROR_MESSAGE = "Une erreur est survenue lors de la production de la carte verte";
    public static final String GREEN_CARD_EMAIL_ERROR_MESSAGE = "Une erreur s’est produite lors de l’envoi de la carte verte par email";
    public static final String PAYMENT_REQUEST_NOT_FOUND = "Aucune demande de paiement trouvée pour cet identifiant de commande.";
    public static final String GREEN_CARD_AVENANT_VALIDATION_ERROR = "Une erreur est survenue lors de la validation de l'avenant de la carte verte";
    public static final String GREEN_CARD_ALREADY_GENERATED = "Une carte verte a déjà été générée pour cette demande.";
}
