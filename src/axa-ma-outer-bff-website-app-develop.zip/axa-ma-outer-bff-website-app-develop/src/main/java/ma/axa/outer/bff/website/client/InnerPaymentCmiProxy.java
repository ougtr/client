package ma.axa.outer.bff.website.client;

import ma.axa.outer.bff.website.client.config.InnerClientConfig;
import ma.axa.outer.bff.website.dto.payment.cmi.PaymentObjectDto;
import ma.axa.outer.bff.website.dto.payment.cmi.PaymentRequestContractDetailsRequest;
import ma.axa.outer.bff.website.dto.payment.cmi.PaymentRequestDetailDto;
import ma.axa.outer.bff.website.dto.payment.cmi.PaymentRequestDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@FeignClient(name = "innerPaymentCmiProxy", url = "${axa.client.inner-payment-cmi}", configuration = InnerClientConfig.class)
public interface InnerPaymentCmiProxy {

    @PostMapping(path = "/v1/cmi/payment-requests", produces = {"application/json"})
    PaymentObjectDto createPaymentRequest(
            @RequestBody PaymentRequestDto paymentRequestDto
    );
    @PutMapping("/v1/cmi/payment-requests/{orderId}")
    PaymentRequestDto updatePaymentRequest(
            @RequestBody PaymentRequestDto updatePaymentRequest,
            @PathVariable String orderId) ;
    @GetMapping("/v1/cmi/payment-requests/{orderId}")
    PaymentRequestDetailDto fetchPaymentRequest(@PathVariable String orderId) ;


    @PutMapping("/v1/cmi/payment-requests/{orderId}/sync-status")
    PaymentRequestDetailDto refreshStatus(@PathVariable String orderId) ;

    @PatchMapping("/v1/cmi/payment-requests/{orderId}/contract")
    PaymentRequestDetailDto updatePaymentRequestWithContractDetails(@PathVariable String orderId,
                                 @RequestBody  PaymentRequestContractDetailsRequest paymentRequestContractDetailsRequest) ;

}
