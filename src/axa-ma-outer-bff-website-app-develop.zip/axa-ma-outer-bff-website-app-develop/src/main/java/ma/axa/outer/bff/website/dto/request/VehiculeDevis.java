package ma.axa.outer.bff.website.dto.request;


import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VehiculeDevis {
	
	private String      model ;
	
	private String  codeChassis  ;
	
	private Character   baremeConventionnel  ;
	
	private BigDecimal      typeStationnement ;

	private BigDecimal	codeVilleStationnement;
	
	private BigDecimal	codePostal;

	private CreditDevis credit ;

	private Remorque remorque;

	private Radio radio ;

	private BigDecimal	numuroPolice ;
}
