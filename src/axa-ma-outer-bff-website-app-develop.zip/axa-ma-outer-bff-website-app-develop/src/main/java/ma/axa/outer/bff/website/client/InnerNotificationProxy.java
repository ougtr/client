package ma.axa.outer.bff.website.client;

import ma.axa.outer.bff.website.client.config.InnerClientNoRetryConfig;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.EmailDto;
import ma.axa.outer.bff.website.dto.InnerOTPRequestDto;
import ma.axa.outer.bff.website.dto.ValidationOTPDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@FeignClient(name = "innerNotificationProxy", url = "${axa.client.inner-notification}", configuration = InnerClientNoRetryConfig.class)

public interface InnerNotificationProxy {

    @PostMapping(path = "/v1/otp", produces = {"application/json"})
    ResponseEntity<ApiMessageWrapper> createOTP(@RequestBody InnerOTPRequestDto otpRequestDto);


    @PutMapping(path = "/v1/otp", produces = {"application/json"})
    ResponseEntity<ApiMessageWrapper> validateOTP(@RequestBody ValidationOTPDto validationOTPDto);

    @PostMapping(path = "/v1/emails/mail", produces = {"application/json"})
    ResponseEntity<Void> sendMail(@RequestBody EmailDto emailDto);

    @PostMapping(value = "/v1/emails/send-mail", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public void sendEmail(@RequestParam List<String> to, @RequestParam(required = false) String[] cc, @RequestParam(required = false) String template, @RequestParam(required = true) String subject, @RequestParam(required = false) String variables,
                          @RequestParam(required = true) String from, @RequestPart(value = "attachments", required = false) MultipartFile[] attachments);

}
