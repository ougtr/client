package ma.axa.outer.bff.website.config.security;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.web.util.UrlPathHelper;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import ma.axa.outer.bff.website.dto.error.ApiError;
import ma.axa.outer.bff.website.util.constants.GlobalConstants;

@Slf4j
public class SecurityAuthEntryPoint implements AuthenticationEntryPoint {

	private final UrlPathHelper urlPathHelper = new UrlPathHelper();

	@Override
	public void commence(HttpServletRequest request,
			HttpServletResponse response, AuthenticationException authException)
			throws IOException {
        PrintWriter out = SecurityAccessDeniedHandler.getPrintWriter(request, response, authException.getCause(), authException.getMessage(), log);
        ApiError apiError = ApiError.builder().type(GlobalConstants.URI_DEFAULT)
				.title(HttpStatus.FORBIDDEN.getReasonPhrase())
				.status(HttpStatus.FORBIDDEN.value())
				.detail("Access to this resource is denied")
				.instance(urlPathHelper.getPathWithinApplication(request))
				.build();
		var jsonRes = new ObjectMapper().writeValueAsString(apiError);
		out.print(jsonRes);
		out.flush();
	}

}
