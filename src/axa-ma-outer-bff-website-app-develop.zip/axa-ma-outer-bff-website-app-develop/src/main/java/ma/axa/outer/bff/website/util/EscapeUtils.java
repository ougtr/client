package ma.axa.outer.bff.website.util;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class EscapeUtils {

	private static final String[] TO_REPLACE = new String[]{"\n", "\r"};
	private static final String[] REPLACE_WITH = new String[]{"_", "_"};

	public static String escapeHtml(String s) {
		return (s == null) ? null : StringEscapeUtils.escapeHtml4(crlf(s));
	}

	public static String escapeJson(String s) {
		return (s == null) ? null : StringEscapeUtils.escapeJson(crlf(s));
	}

	public static String crlf(String s) {
		return (s == null) ? null : StringUtils.replaceEach(s, TO_REPLACE, REPLACE_WITH);
	}
}
