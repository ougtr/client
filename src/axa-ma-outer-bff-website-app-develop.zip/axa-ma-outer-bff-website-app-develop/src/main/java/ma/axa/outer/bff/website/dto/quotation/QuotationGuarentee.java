package ma.axa.outer.bff.website.dto.quotation;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.outer.bff.website.dto.RefDataMRHResponse;

@Data
@EqualsAndHashCode(callSuper = true)
@JsonInclude(value = Include.NON_NULL)
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class QuotationGuarentee extends RefDataMRHResponse {
	private boolean checked ;
	private boolean disabled ;
	List<QuotationGarantiesElementsMrhDto> technicalElements ;
	private Primes primeGarantie;
	private ConfigGarantiePrime customPricingGarantyParams;
	private Boolean  eligiblePackGuarantee ;
	private Boolean  calculateWithRate ;
	private boolean  pricingWithBuilding ;
	private boolean  pricingWithContentBuilding ;
}
