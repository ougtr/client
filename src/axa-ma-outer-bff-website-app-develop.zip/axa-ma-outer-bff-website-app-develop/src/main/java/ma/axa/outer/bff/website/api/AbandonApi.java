package ma.axa.outer.bff.website.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.dto.AbandonRequest;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.service.AbandonService;
import ma.axa.outer.bff.website.service.EmailContentProtectionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/abandon")
@RequiredArgsConstructor
@Validated
public class AbandonApi {

    private final AbandonService abandonService;
    private final EmailContentProtectionService emailContentProtectionService;

    @Operation(summary = "Create Abandon")
    @ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Abandon created", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = ApiMessageWrapper.class)) }),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content) })
    @PostMapping(produces = { "application/json" }, consumes = { "application/json" })
    public ResponseEntity<ApiMessageWrapper> createAbandon(@RequestBody AbandonRequest abandonRequest) {
        return new ResponseEntity<>(abandonService.createAbandon(emailContentProtectionService.sanitize(abandonRequest)), HttpStatus.CREATED);
    }
}
