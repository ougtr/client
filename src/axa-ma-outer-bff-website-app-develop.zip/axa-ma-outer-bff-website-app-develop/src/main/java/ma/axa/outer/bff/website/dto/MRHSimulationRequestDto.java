package ma.axa.outer.bff.website.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Data
@SuperBuilder
@NoArgsConstructor
public class MRHSimulationRequestDto {

    private BigDecimal valeurCapital;

    private String modeAssurance;
    private BigDecimal valeurCapitalBatiment;
    private BigDecimal valeurContenuMobilier;
    private BigDecimal valeurDontObjet;
    private BigDecimal valeurPrimeTtc;
    private String leadId;
}