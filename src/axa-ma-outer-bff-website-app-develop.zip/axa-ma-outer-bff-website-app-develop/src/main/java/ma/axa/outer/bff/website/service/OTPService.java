package ma.axa.outer.bff.website.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.InnerOTPRequestDto;
import ma.axa.outer.bff.website.dto.OTPRequestDto;
import ma.axa.outer.bff.website.dto.ValidationOTPDto;
import ma.axa.outer.bff.website.dto.error.ApiErrorItem;
import ma.axa.outer.bff.website.dto.error.ApiErrorObject;
import ma.axa.outer.bff.website.exception.ControllerBusinessException;
import ma.axa.outer.bff.website.exception.InnerClientException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class OTPService {

    @Value("${axa.otp.expiration-time:60}")
    private int expirationTime;

    private final InnerNotificationProxy innerNotificationProxy;

    public ApiMessageWrapper generateOTP(OTPRequestDto otpRequestDto) {
        try {
            InnerOTPRequestDto innerOTPRequest = new InnerOTPRequestDto(otpRequestDto.getPhoneNumber(), expirationTime);
            return innerNotificationProxy.createOTP(innerOTPRequest).getBody();
        } catch (InnerClientException e) {
            log.error(e.getApiError().getType());
            List<ApiErrorItem> apiErrorItems = buildViolationError(e.getApiError().getType());
            throw new ControllerBusinessException(apiErrorItems);
        }

    }

    private List<ApiErrorItem> buildViolationError(String type) {
        List<ApiErrorItem> apiErrorItems = new ArrayList<>();
        try {
            ApiErrorObject error = new ObjectMapper().readValue(type, ApiErrorObject.class);
            apiErrorItems.add(new ApiErrorItem(error.getTitle(), error.getType()));
        } catch (JsonProcessingException exception) {
            log.error(exception.getMessage());
        }
        return apiErrorItems;

    }

    public ApiMessageWrapper validateOTP(ValidationOTPDto validationOTPDto) {
        return innerNotificationProxy.validateOTP(validationOTPDto).getBody();
    }
}
