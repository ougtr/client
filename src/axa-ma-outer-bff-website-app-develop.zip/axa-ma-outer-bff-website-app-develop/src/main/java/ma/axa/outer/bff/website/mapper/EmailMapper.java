package ma.axa.outer.bff.website.mapper;

import ma.axa.outer.bff.website.dto.*;

import java.util.HashMap;
import java.util.Map;

public interface EmailMapper {

    String CONTACT_SUBJECT = "Contactez-nous";
    String CONTACT_EMAIL = "contact@axa.ma";
    String CONTACT_TEMPLATE = "contact-template";
    String CALL_ME_BACK_SUBJECT = "Contactez-moi";
    String CALL_ME_BACK_EMAIL = "contact@axa.ma";
    String CALL_ME_BACK_TEMPLATE = "contact-template";
    String CLAIM_SUBJECT = "Réclamation";
    String CLAIM_EMAIL = "servicereclamations@axa.ma";
    String CLAIM_TEMPLATE = "website-claim-template";
    String ABANDON_SUBJECT = "Abandon de renouvellement";
    String ABANDON_EMAIL = "abandon.renouvellement@axa.ma";
    String ABANDON_TEMPLATE = "abandon-template";

    static EmailDto toEmail(ContactRequest contactRequest) {
        EmailDto email = new EmailDto();
        email.setFrom(CONTACT_EMAIL);
        email.setTo(CONTACT_EMAIL);
        email.setSubject(CONTACT_SUBJECT);
        email.setTemplate(CONTACT_TEMPLATE);
        Map<String, Object> variables = new HashMap<>();
        variables.put("firstName", contactRequest.getFirstName());
        variables.put("lastName", contactRequest.getLastName());
        variables.put("phoneNumber", contactRequest.getPhoneNumber());
        variables.put("emailAddress", contactRequest.getEmailAddress());
        variables.put("subject", contactRequest.getSubject());
        variables.put("message", contactRequest.getMessage());
        email.setVariables(variables);
        return email;
    }

    static EmailDto toEmail(CallMeBackContactRequest callMeBackContactRequest) {
        EmailDto email = new EmailDto();
        email.setFrom(CALL_ME_BACK_EMAIL);
        email.setTo(CALL_ME_BACK_EMAIL);
        email.setSubject(CALL_ME_BACK_SUBJECT);
        email.setTemplate(CALL_ME_BACK_TEMPLATE);
        Map<String, Object> variables = new HashMap<>();
        variables.put("firstName", callMeBackContactRequest.getFirstName());
        variables.put("lastName", callMeBackContactRequest.getLastName());
        variables.put("phoneNumber", callMeBackContactRequest.getPhoneNumber());
        variables.put("emailAddress", callMeBackContactRequest.getEmailAddress());
        variables.put("subject", callMeBackContactRequest.getSubject());
        variables.put("message", callMeBackContactRequest.getMessage());
        email.setVariables(variables);
        return email;
    }

    static EmailDto toEmail(ClaimRequest claimRequest) {
        EmailDto email = new EmailDto();
        email.setFrom(CLAIM_EMAIL);
        email.setTo(CLAIM_EMAIL);
        email.setSubject(CLAIM_SUBJECT);
        email.setTemplate(CLAIM_TEMPLATE);
        Map<String, Object> variables = new HashMap<>();
        variables.put("firstName", claimRequest.getFirstName());
        variables.put("lastName", claimRequest.getLastName());
        variables.put("phoneNumber", claimRequest.getPhoneNumber());
        variables.put("emailAddress", claimRequest.getEmailAddress());
        variables.put("city", claimRequest.getCity());
        variables.put("subject", claimRequest.getSubject());
        variables.put("message", claimRequest.getMessage());
        email.setVariables(variables);
        return email;
    }

    static EmailDto toEmail(AbandonRequest abandonRequest) {
        EmailDto email = new EmailDto();
        email.setFrom(ABANDON_EMAIL);
        email.setTo(ABANDON_EMAIL);
        email.setSubject(ABANDON_SUBJECT);
        email.setTemplate(ABANDON_TEMPLATE);
        Map<String, Object> variables = new HashMap<>();
        variables.put("firstName", abandonRequest.getFirstName());
        variables.put("lastName", abandonRequest.getLastName());
        variables.put("phoneNumber", abandonRequest.getPhoneNumber());
        variables.put("emailAddress", abandonRequest.getEmailAddress());
        email.setVariables(variables);
        return email;
    }

}