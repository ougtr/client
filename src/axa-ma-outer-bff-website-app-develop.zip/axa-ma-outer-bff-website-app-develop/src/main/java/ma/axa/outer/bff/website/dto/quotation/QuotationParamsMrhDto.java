package ma.axa.outer.bff.website.dto.quotation;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QuotationParamsMrhDto {
	
		private String minEffectDate;
		private String maxEffectDate;
		private BigDecimal valeurBatimentMax;
		private BigDecimal valeurBatimentMin;
}
