package ma.axa.outer.bff.website.dto.request;

import lombok.Data;

@Data
public class GreenCardDetailsRequest {
    private String email;
    private String phoneNumber;
    private String policyNumber;
    private String vehicleImmatNumber;
    private String typeIdentite;
    private String numPieceIdentite;
}
