package ma.axa.outer.bff.website.dto.payment.cmi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GreenCardPaymentDto {
    private BigDecimal totalAmount ;
    private String policyNumber ;

    private String registrationNumber ;
    @Builder.Default
    private String avenantNumber ="0" ;
    private List<GreenCardPaymentItemDto> items ;
    private GreenCardPaymentClientDto clientInfo ;
}
