package ma.axa.outer.bff.website.dto.quotation;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class ErrorDto {
	    @JsonProperty("codeError")
	    private String code;
	    @JsonProperty("typeError")
	    private String type;
	    @JsonProperty("libelleError")
	    private String label;
}
