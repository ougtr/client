package ma.axa.outer.bff.website.client;

import ma.axa.outer.bff.website.client.config.InnerClientConfig;
import ma.axa.outer.bff.website.dto.GaragesListResponseDto;
import ma.axa.outer.bff.website.dto.IntermediariesDto;
import ma.axa.outer.bff.website.dto.IntermediariesListDto;
import ma.axa.outer.bff.website.dto.SFClinicsListDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "innerTiersProxy", url = "${axa.client.inner-tiers}", configuration = InnerClientConfig.class)

public interface InnerTiersProxy {
    @GetMapping(path = "/v1/tiers/sfdc/garages", produces = { "application/json" })
    public ResponseEntity<GaragesListResponseDto> getGaragesList(
            @RequestParam(name="city-code", required=false) String cityCode,
            @RequestParam(name="garage-type", required=false) String garageType,
            @RequestParam(name="status", required=false) String status
    );

    @GetMapping(path = "/v1/tiers/sfdc/intermediaires", produces = { "application/json" })
    public ResponseEntity<IntermediariesListDto> getIntermediariesList(
            @RequestParam(name="city-code", required=false) String cityCode,
            @RequestParam(name="intermediary-code", required=false) String intermediaryCode,
            @RequestParam(name="situation", required=false) String situation,
            @RequestParam(name="intermediary-types", required=false) List<String> intermediaryTypes,
            @RequestParam(name="order-by-name", required=false) String orderByName
    );

    @GetMapping(path = "/v1/tiers/sfdc/intermediaires/{code}", produces = { "application/json" })
    public ResponseEntity<IntermediariesDto> getIntermediary(
            @PathVariable(name="code") String intermediaryCode
    );

    @GetMapping(path = "/v1/tiers/sfdc/cliniques", produces = { "application/json" })
    public ResponseEntity<SFClinicsListDto> getSFClinicsList(
            @RequestParam(name="city-code", required = false) String cityCode,
            @RequestParam(name = "branch", required = false) String branch
    );
}
