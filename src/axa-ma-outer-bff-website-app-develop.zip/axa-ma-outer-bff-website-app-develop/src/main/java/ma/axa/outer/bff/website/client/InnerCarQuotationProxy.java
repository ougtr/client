package ma.axa.outer.bff.website.client;

import io.swagger.v3.oas.annotations.Parameter;
import ma.axa.outer.bff.website.client.config.InnerClientConfig;
import ma.axa.outer.bff.website.dto.*;
import ma.axa.outer.bff.website.dto.payment.cmi.GreenCardPaymentDto;
import ma.axa.outer.bff.website.dto.quotation.QuotationCouvertureMrhDto;
import ma.axa.outer.bff.website.dto.quotation.QuotationMrhResponse;
import ma.axa.outer.bff.website.dto.quotation.QuotationResponseMrh;
import ma.axa.outer.bff.website.dto.quotation.request.QuotationMrhRequest;
import ma.axa.outer.bff.website.dto.request.Devis;
import ma.axa.outer.bff.website.dto.request.QuotationDto;
import ma.axa.outer.bff.website.dto.response.DevisResponse;
import ma.axa.outer.bff.website.dto.response.PrimeDto;
import ma.axa.outer.bff.website.util.Paths;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

@FeignClient(name = "innerCarQuotationProxy", url = "${axa.client.inner-quotation}", configuration = InnerClientConfig.class)
public interface InnerCarQuotationProxy {
    @GetMapping(path = Paths.QUOTATION_VERSION_PROXY+"/renewal-as-is", produces = {"application/json"})
    ResponseEntity<RenewalDataResponseDto> getRenewalData(
            @RequestParam("policyNumber") String request
    );

    @PostMapping(path =Paths.QUOTATION_VERSION_PROXY+"/renewal-as-is/validate", produces = {"application/json"})
    ResponseEntity<ApiMessageWrapper> validateContract(
            @RequestBody @Valid RenewalContractValidationInput renewalContractValidationInput
    );
    @PostMapping(path = Paths.QUOTATION_VERSION_PROXY+"/quotations", produces = {"application/json"})
    public ResponseEntity<PrimeDto> createQuotationAuto(@RequestBody QuotationDto input);
    @PutMapping(path = Paths.QUOTATION_VERSION_PROXY+"/quotations/{idQuotation}", produces = {"application/json"})

    public ResponseEntity<PrimeDto> updateQuotation(@Valid @RequestBody QuotationDto input,
                                                    @PathVariable(name = "idQuotation", required = true) BigDecimal idQuotation);


    @PostMapping(path=Paths.QUOTATION_VERSION_PROXY+"/quotations/{idQuotation}/valider" ,produces = {"application/json"})
    public ResponseEntity<DevisResponse> validerQuotation(@Valid @RequestBody(required = true) Devis devis,
                                                          @NotNull(message = "{error.v1.quotation.idQuotation}")
                                                          @Parameter(description = "Id quotation")
                                                          @PathVariable(name = "idQuotation",required = true) BigDecimal idQuotation);

    @GetMapping(path = Paths.QUOTATION_VERSION_PROXY+"/quotations/{idQuotation}/payment-details", produces = {"application/json"})
    GreenCardPaymentDto getPaymentDetails(@PathVariable("idQuotation") String idQuotation);

}
