package ma.axa.outer.bff.website.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BeneficiaryRequestDto {
    private String birthDate;

    private BigDecimal numAffilie;

    @Length(min = 3,max = 3,message = "la longueur doit être 3 caracteres ")
    private String policyNumber;


    @Length(min = 5,message = "la longueur doit être au min 5 caracteres ")
    private String cin;

    private String cnss;

    private BigDecimal prestation;
}
