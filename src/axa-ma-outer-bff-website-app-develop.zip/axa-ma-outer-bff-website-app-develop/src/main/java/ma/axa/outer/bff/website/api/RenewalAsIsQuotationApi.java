package ma.axa.outer.bff.website.api;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.RenewalAsIsRequestDto;
import ma.axa.outer.bff.website.dto.RenewalContractValidationInput;
import ma.axa.outer.bff.website.dto.RenewalDataResponseDto;
import ma.axa.outer.bff.website.service.RenewalService;
import ma.axa.outer.bff.website.util.Paths;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping(Paths.QUOTATION_RENEW)
@RequiredArgsConstructor
@Validated
public class RenewalAsIsQuotationApi {
    private final ICaptchaService captchaService;
    private final RenewalService renewalService;

    @Operation(summary = "get renewal data")
    @GetMapping(path = "/data", produces = { "application/json" })
    public ResponseEntity<RenewalDataResponseDto> getRenewalData(
            RenewalAsIsRequestDto renewalAsIsRequestDto,
            @RequestParam("g-recaptcha-response") String captchaResponse
            ) {
        captchaService.processResponse(captchaResponse);
        return new ResponseEntity<>(renewalService.getRenewalData(renewalAsIsRequestDto.getPolicyNumber()), HttpStatus.OK);
    }

    @PostMapping(path = "/validate", produces = { "application/json" })
    public ResponseEntity<ApiMessageWrapper> validateRenewalData(@RequestBody @Valid RenewalContractValidationInput renewalContractValidationInput) {
        return new ResponseEntity(renewalService.validateRenewalContract(renewalContractValidationInput), HttpStatus.OK);
    }
}
