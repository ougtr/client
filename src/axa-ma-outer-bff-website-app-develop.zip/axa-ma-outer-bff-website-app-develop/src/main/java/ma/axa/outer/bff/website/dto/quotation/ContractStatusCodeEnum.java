package ma.axa.outer.bff.website.dto.quotation;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum ContractStatusCodeEnum {
	IN_PROGRESS(1), TERMINATED(2), SUSPENDED(3);
	
	public final Integer code;
	
	
}
