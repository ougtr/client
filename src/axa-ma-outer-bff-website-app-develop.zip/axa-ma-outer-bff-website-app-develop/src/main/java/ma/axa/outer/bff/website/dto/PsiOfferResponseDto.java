package ma.axa.outer.bff.website.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class PsiOfferResponseDto {
    private String prime;
    private String description;
    private String threshold;
}
