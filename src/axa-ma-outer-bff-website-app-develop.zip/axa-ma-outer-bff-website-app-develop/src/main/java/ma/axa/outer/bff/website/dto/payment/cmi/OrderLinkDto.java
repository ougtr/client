package ma.axa.outer.bff.website.dto.payment.cmi;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderLinkDto {
    @NotBlank
    @Pattern(
            regexp = "^https://.*",
            message = "callbackURL must use HTTPS"
    )
    private String okURL ;
    @NotBlank
    @Pattern(
            regexp = "^https://.*",
            message = "callbackURL must use HTTPS"
    )
    private String failURL ;
    @NotBlank
    @Pattern(
            regexp = "^https://.*",
            message = "callbackURL must use HTTPS"
    )
    private String s2sFailURL ;
}
