package ma.axa.outer.bff.website.dto.quotation;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Primes {
	private BigDecimal annualPrice;
	private BigDecimal priceNetHorsEC;
	private BigDecimal annuelNetEC;
	private BigDecimal annualAccessory;
	private BigDecimal annualTaxes;
	private BigDecimal annualNetPrice;
	private BigDecimal comptantPrice;
	private BigDecimal comptantNetEC;
	private BigDecimal comptantNetHorsEC;
	private BigDecimal comptantTaxes;
	private BigDecimal comptantAccessory;
	private BigDecimal comptantNetPrice;
	
	
	
}
