package ma.axa.outer.bff.website.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.CallMeBackContactRequest;
import ma.axa.outer.bff.website.dto.ContactRequest;
import ma.axa.outer.bff.website.service.ContactService;
import ma.axa.outer.bff.website.service.EmailContentProtectionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1")
@RequiredArgsConstructor
@Validated
public class ContactApi {
    private final ContactService contactService;
    private final ICaptchaService captchaService;
    private final EmailContentProtectionService emailContentProtectionService;

    @Operation(summary = "Contact Us")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Contact message created", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = ApiMessageWrapper.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
    @PostMapping(value = "/contact-us", produces = {"application/json"}, consumes = {"application/json"})
    public ResponseEntity<ApiMessageWrapper> contactUs(@RequestBody ContactRequest contactRequest,
                                                       @RequestParam("g-recaptcha-response") String captchaResponse
    ) {
        captchaService.processResponse(captchaResponse);
        return new ResponseEntity<>(contactService.contactUs(emailContentProtectionService.sanitize(contactRequest)), HttpStatus.CREATED);
    }

    @Operation(summary = "Call Me Back")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Call Me Back message created", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = ApiMessageWrapper.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
    @PostMapping(value = "/call-me-back", produces = {"application/json"}, consumes = {"application/json"})
    public ResponseEntity<ApiMessageWrapper> callMeBack(@RequestBody CallMeBackContactRequest callMeBackContactRequest,
                                                        @RequestParam("g-recaptcha-response") String captchaResponse) {
        captchaService.processResponse(captchaResponse);
        return new ResponseEntity<>(contactService.callMeBack(emailContentProtectionService.sanitize(callMeBackContactRequest)), HttpStatus.CREATED);
    }
}
