package ma.axa.outer.bff.website.api;


import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.OTPRequestDto;
import ma.axa.outer.bff.website.dto.ValidationOTPDto;
import ma.axa.outer.bff.website.service.OTPService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/v1/otp")
@RequiredArgsConstructor
public class OTPApi {

    private final OTPService otpService;

    @PostMapping
    public ResponseEntity<ApiMessageWrapper> createOTP(@Valid @RequestBody OTPRequestDto otpRequestDto) {
        return new ResponseEntity<>(otpService.generateOTP(otpRequestDto), HttpStatus.CREATED);
    }

    @PostMapping("/validate")
    public ResponseEntity<ApiMessageWrapper> validateOTP(@Valid @RequestBody ValidationOTPDto validationOTPDto) {
        return new ResponseEntity<>(otpService.validateOTP(validationOTPDto), HttpStatus.OK);
    }
}
