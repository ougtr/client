package ma.axa.outer.bff.website.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Data
@SuperBuilder
@NoArgsConstructor
public class PublicCapitalDto {

    private BigDecimal buildingCapital;

    private BigDecimal contentCapital;
}
