package ma.axa.outer.bff.website.dto.quotation;

import io.swagger.v3.oas.annotations.media.Schema;

import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AvenantData {
	@Schema(description = "Le code produit")
	@Default
	private String productCode ="22660";
	@NotNull
	@Default
	@Schema(description = "Le type avenant")
	private String type = "1";

	@Schema(description = "Le sous type avenant")
	@Default
	@NotNull
	private String subType = "1";

	@Default
	@Schema(description = "Le numéro de la police")
	@NotNull
	private String policyNumber="0";

	@Default
	@Schema(description = "Le numéro de la pol")
	private String devisNumber="0";

	@Default
	private Integer step=1;

	private String intermediaryCode;

	private String utilisateur;
	@Builder.Default
	private String typeGestion = "";
	
	@Default
	private String motifCode="";
	@Default
	private String motif="";
	@Default
	private String isAgent=""   ;
	@Default
	private String typeAccount=""  ;
	@Default
	private String agencyCode="0";
}
