package ma.axa.outer.bff.website.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.outer.bff.website.client.InnerCarQuotationProxy;
import ma.axa.outer.bff.website.dto.LeadResponseDto;
import ma.axa.outer.bff.website.dto.request.AllQuotationsDto;
import ma.axa.outer.bff.website.dto.request.Devis;
import ma.axa.outer.bff.website.dto.request.QuotationDto;
import ma.axa.outer.bff.website.dto.response.*;
import ma.axa.outer.bff.website.mapper.GuaranteesMapper;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class QuotationService {
    private final InnerCarQuotationProxy innerCarQuotationProxy;
    private final LeadService leadService;
    private final JsonRefService jsonRefService;
    private final GuaranteesMapper guaranteesMapper;
    private final ObjectMapper mapper;

    public List<PrimeDto> createQuotation(AllQuotationsDto allQuotationDto) {
        List<GuaranteesDto> guaranteesRef = mapper.convertValue(jsonRefService.getGuaranteesPacks(), mapper.getTypeFactory().constructCollectionType(List.class, GuaranteesDto.class));
        List<PrimeDto> guaranteesPrime = new ArrayList<>();
        List<GuaranteesDetailsDto> basic = guaranteesRef.get(0).getGuarantees();
        List<GuaranteesDetailsDto> basicPlus = guaranteesRef.get(1).getGuarantees();
        List<GuaranteesDetailsDto> optimal = guaranteesRef.get(2).getGuarantees();
        List<GuaranteesDetailsDto> premium = guaranteesRef.get(3).getGuarantees();
        QuotationDto quotationDto = QuotationDto.builder().contrat(allQuotationDto.getContrat()).vehicule(allQuotationDto.getVehicule()).garanties(guaranteesMapper.toQuotationGuaranteesDto(basic)).idPack(2).build();
        quotationDto.getContrat().setIntermediaireName(allQuotationDto.getLeadInfos().getIntermediateName());
        try {

            LeadResponseDto leadResponseDto = leadService.saveAutoProspect(allQuotationDto);
            PrimeDto prime = innerCarQuotationProxy.createQuotationAuto(quotationDto).getBody();
            if(leadResponseDto != null && prime != null) {
                prime.setIdLead(leadResponseDto.getId());
            }
            guaranteesPrime.add(prime);
            quotationDto.setGaranties(guaranteesMapper.toQuotationGuaranteesDto(basicPlus));
            quotationDto.setIdPack(3);
            prime = innerCarQuotationProxy.updateQuotation(quotationDto, guaranteesPrime.get(0).getIdQuotation()).getBody();
            if(leadResponseDto != null && prime != null)
                prime.setIdLead(leadResponseDto.getId());
            guaranteesPrime.add(prime);
            quotationDto.setGaranties(guaranteesMapper.toQuotationGuaranteesDto(optimal));
            quotationDto.setIdPack(4);
            prime = innerCarQuotationProxy.updateQuotation(quotationDto , guaranteesPrime.get(0).getIdQuotation()).getBody();
            if(leadResponseDto != null && prime != null)
                prime.setIdLead(leadResponseDto.getId());
            guaranteesPrime.add(prime);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            if(LocalDate.parse(quotationDto.getVehicule().getDateMisCirculation(), formatter).isAfter(LocalDate.now().minusYears(5)))
            {
                quotationDto.setGaranties(guaranteesMapper.toQuotationGuaranteesDto(premium));
                quotationDto.setIdPack(5);
                prime = innerCarQuotationProxy.updateQuotation(quotationDto, guaranteesPrime.get(0).getIdQuotation()).getBody();
                if(prime != null && leadResponseDto != null)
                    prime.setIdLead(leadResponseDto.getId());
                guaranteesPrime.add(prime);
            }

        } catch (Exception e) {
            throw e;
        }
        return  guaranteesPrime;
    }

    public PrimeDto updateQuotation(QuotationDto quotationDto, BigDecimal idQuotation) {
        quotationDto.getContrat().setIntermediaireName(quotationDto.getLeadInfos().getIntermediateName());
        PrimeDto primeDto = innerCarQuotationProxy.updateQuotation(quotationDto, idQuotation).getBody();
        if(primeDto != null)
            leadService.updateAutoProspect(quotationDto, primeDto.getPrimeTotaleComptant().toString());
        if(primeDto != null)
            primeDto.setIdLead(quotationDto.getIdLead());
        return  primeDto;
    }

    public DevisResponse validerQuotation(Devis devis,  BigDecimal idQuotation) {
        return innerCarQuotationProxy.validerQuotation(devis, idQuotation).getBody();
    }
}
