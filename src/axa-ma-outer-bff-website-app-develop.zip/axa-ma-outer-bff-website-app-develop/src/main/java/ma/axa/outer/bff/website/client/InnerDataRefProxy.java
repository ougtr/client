package ma.axa.outer.bff.website.client;

import ma.axa.outer.bff.website.client.config.InnerClientConfig;
import ma.axa.outer.bff.website.dto.RefDataResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "innerDataRefProxy", url = "${axa.client.inner-api-dataref}", configuration = InnerClientConfig.class)
public interface InnerDataRefProxy {
    @RequestMapping(method = RequestMethod.GET, path = "/v1/geo/villes", produces = { "application/json" })
    public ResponseEntity<List<RefDataResponse>> getCities(@RequestParam(value = "code_pays") String countyCode);

    @GetMapping(path="/v1/auto/marques",produces = {"application/json"})
    public ResponseEntity<List<RefDataResponse>> getBrands(@RequestParam(value = "code_produit") Integer productCode);

}
