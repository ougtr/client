package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Permis {

    private String code;

    private Character type;

    @Builder.Default
    private String dateObtention = "0";

    private BigDecimal codeVille;

    private BigDecimal codePays;
}