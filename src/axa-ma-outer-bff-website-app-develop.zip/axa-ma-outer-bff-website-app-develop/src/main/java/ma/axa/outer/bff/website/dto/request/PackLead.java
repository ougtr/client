package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PackLead {
    private String rembRateValue;
    private String rembBaseValue;
    private String deathCapitalValue;
    private String diseaseValue;
    private String diseaseReimbursementCeiling;
    private String formulaValue;
}