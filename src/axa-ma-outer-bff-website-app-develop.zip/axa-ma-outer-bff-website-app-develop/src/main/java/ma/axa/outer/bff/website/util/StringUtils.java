package ma.axa.outer.bff.website.util;

import com.google.common.hash.Hashing;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.util.Base64;
import java.util.Locale;
@Slf4j
@UtilityClass
public class StringUtils {

	public static String computeHash512(String text) {
		return Hashing.sha512().hashString(text, StandardCharsets.UTF_8).toString();
	}

	public static String encodeBase64(String text) {
		return Base64.getEncoder().encodeToString(text.getBytes(StandardCharsets.UTF_8));
	}
	
	public static String bigDecimalFormatting (BigDecimal number) {
        try {
			NumberFormat formatter = NumberFormat.getInstance(Locale.FRENCH); 
			formatter.setMaximumFractionDigits(2);
			formatter.setMinimumFractionDigits(2);
			formatter.setGroupingUsed(true);
			return  formatter.format(number);
		} catch (Exception e) {
			log.error("error conversion ",e);
		}
        
        return "";
        
    }
	
	
	public static String bigDecimalFormatting (String number) {
        try {
			NumberFormat formatter = NumberFormat.getInstance(Locale.FRENCH); 
			formatter.setMaximumFractionDigits(2);
			formatter.setMinimumFractionDigits(2);
			formatter.setGroupingUsed(true);
			return  formatter.format(new BigDecimal(number));
		} catch (Exception e) {
			log.error("error conversion ",e);
		}
        return "";
    }
}