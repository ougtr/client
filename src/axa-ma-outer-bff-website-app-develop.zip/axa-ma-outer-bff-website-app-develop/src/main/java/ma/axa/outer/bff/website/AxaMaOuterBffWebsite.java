package ma.axa.outer.bff.website;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableAsync;


@SpringBootApplication
@EnableAsync
@EnableConfigurationProperties
public class AxaMaOuterBffWebsite {

    public static void main(String[] args) {
        SpringApplication.run(AxaMaOuterBffWebsite.class, args);
    }

}
