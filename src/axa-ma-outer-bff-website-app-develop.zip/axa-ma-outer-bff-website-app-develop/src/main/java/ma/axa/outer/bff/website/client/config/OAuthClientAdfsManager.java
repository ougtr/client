package ma.axa.outer.bff.website.client.config;

import java.util.Objects;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.oauth2.client.OAuth2AuthorizeRequest;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.registration.ClientRegistration;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OAuthClientAdfsManager {
	private final OAuth2AuthorizedClientManager manager;
	private final ClientRegistration clientRegistration;

	public OAuthClientAdfsManager(OAuth2AuthorizedClientManager manager, ClientRegistration clientRegistration) {
		this.manager = manager;
		this.clientRegistration = clientRegistration;
	}

	public String getAccessToken() {
		try {
			Authentication principal = new AnonymousAuthenticationToken("key", "anonymous", AuthorityUtils.createAuthorityList("ROLE_ANONYMOUS"));
			var authorizeRequest = OAuth2AuthorizeRequest
					.withClientRegistrationId(clientRegistration.getRegistrationId())
					.principal(principal)
					.build();
			var client = manager.authorize(authorizeRequest);

			if (Objects.isNull(client)) {
				throw new IllegalStateException("client credentials " + clientRegistration.getRegistrationId() + " client, is null");
			}
			if (Objects.isNull(client.getAccessToken())) {
				throw new IllegalStateException("Access token for client " + clientRegistration.getRegistrationId() + " is null");
			}
			log.info(client.getAccessToken().getTokenValue());
			return client.getAccessToken().getTokenValue();
		} catch (Exception e) {
			log.error("Error client credentials, err: {} ", e.getMessage());
		}
		return null;
	}

}