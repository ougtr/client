package ma.axa.outer.bff.website.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.outer.bff.website.dto.RefDataResponse;

import java.util.List;
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class GuaranteesDetailsDto extends RefDataResponse {
    private List<RefDataResponse> formules;
}
