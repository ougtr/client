package ma.axa.outer.bff.website.dto;

import lombok.*;

import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmailDto {
    private String from;
    private String to;
    private String template;
    private String subject;
    private Map<String, Object> variables;
}
