package ma.axa.outer.bff.website.dto.quotation;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.outer.bff.website.dto.FormuleMrhDto;
import ma.axa.outer.bff.website.dto.RefDataMRHResponse;

@Data
@EqualsAndHashCode(callSuper = true)
@JsonInclude(value = Include.NON_NULL)
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class QuotationGarantiesElementsMrhDto extends RefDataMRHResponse {
	private List<FormuleMrhDto> formules ;
	private List<Primes> primes ;
}
