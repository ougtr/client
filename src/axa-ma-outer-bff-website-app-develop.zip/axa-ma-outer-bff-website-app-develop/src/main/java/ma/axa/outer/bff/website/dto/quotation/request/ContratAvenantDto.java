package ma.axa.outer.bff.website.dto.quotation.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ContratAvenantDto {
    @Schema(description = "Delegation bancaire")
    private Boolean hasDelegBancaire;
    @Schema(description = "Date effet de la Delegation bancaire")
    private String effectDate ;
    @Schema(description = "information de délégation bancaire ")
    private DelegationBancaire  delegationBancaire;
}
