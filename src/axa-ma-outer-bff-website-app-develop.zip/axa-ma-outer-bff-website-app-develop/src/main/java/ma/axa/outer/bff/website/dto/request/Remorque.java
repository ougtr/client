package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class Remorque {

    private BigDecimal valeurNeuf;

    private BigDecimal valeurVenale;

    private BigDecimal valeurGlace;

    private String matricule;

    private Integer codeMarque;
}
