package ma.axa.outer.bff.website.dto.request;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class Assure extends Personne {


    private String dateNaissance = "0";
    private String situationFamiliale;
    private BigDecimal codeProfession;

    private Character clientVip;

    private String numeroTelephone;

    private String numeroFaxe;


    private String email;

    private Character mainDominante;

    private String beneficiaire;

    private BigDecimal nationnalite;

    private String codePassport;


}