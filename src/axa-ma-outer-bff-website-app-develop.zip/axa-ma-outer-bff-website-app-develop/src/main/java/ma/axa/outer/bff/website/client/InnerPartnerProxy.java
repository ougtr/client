package ma.axa.outer.bff.website.client;

import ma.axa.outer.bff.website.client.config.InnerClientNoRetryConfig;
import ma.axa.outer.bff.website.dto.response.GreenCardDetailsResponse;
import ma.axa.outer.bff.website.dto.response.GreenCardProductionResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@FeignClient(name = "innerPartnerProxy", url = "${axa.client.inner-partner}", configuration = InnerClientNoRetryConfig.class)
public interface InnerPartnerProxy {
    @PostMapping(value = "/v1/bcma/cartes-verte", produces = {"application/json"})
    ResponseEntity<GreenCardProductionResponse> produceGreenCard(@RequestBody GreenCardDetailsResponse carteVerte);
}
