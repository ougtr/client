package ma.axa.outer.bff.website.dto.request;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class Conducteur extends Personne {

    private String situationFamiliale;

    private BigDecimal codeProfession;

    private Permis permis;

}