package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AllQuotationsDto {
    private ContratDto contrat;
    private VehiculeQuotationDto vehicule;
    private List<ClauseDto> clauses ;
    private LeadInfos leadInfos;
    private String idLead;
}
