package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CapDesDtoRequest {
    private BigDecimal idcota;
    private BigDecimal rang;
    private String flactrl;
    private String capdes;
    private String belnom;
    private String belpre;
}
