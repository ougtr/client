package ma.axa.outer.bff.website.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.*;

@Getter
@Setter
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IntermediariesDto {
    private String name;
    private String intermediaryCode;
    private String city;
    private String phoneNumber;
    private String mail;
    private String address;
    private String latitude;
    private String longitude;

}
