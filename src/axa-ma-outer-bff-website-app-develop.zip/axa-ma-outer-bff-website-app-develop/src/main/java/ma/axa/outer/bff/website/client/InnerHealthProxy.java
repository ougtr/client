package ma.axa.outer.bff.website.client;

import ma.axa.outer.bff.website.client.config.InnerClientConfig;
import ma.axa.outer.bff.website.dto.PsiSimulationRequestDto;
import ma.axa.outer.bff.website.dto.PsiSimulationResponseDto;
import ma.axa.outer.bff.website.dto.request.*;
import ma.axa.outer.bff.website.dto.response.PsiQuotationResponse;
import ma.axa.outer.bff.website.dto.response.Tarif;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.util.Map;

@FeignClient(name = "innerHealthProxy", url = "${axa.client.inner-health}", configuration = InnerClientConfig.class)
public interface InnerHealthProxy {
    @PostMapping(path = "/v1/health/simulation", produces = {"application/json"})
    public ResponseEntity<PsiSimulationResponseDto> getSimulation(
            @RequestBody @Valid PsiSimulationRequestDto psiSimulationRequestDto
    );

    @PostMapping(path = "/v1/health/simulation/quotation", produces = {"application/json"})
    public ResponseEntity<PsiQuotationResponse> createQuotation(@RequestBody PsiQuotationRequest PsiQuotationRequest);

    @PostMapping(value = "/v1/psi/quotations/{quotationId}/personnes-a-charge")
    public ResponseEntity<SharedResponse> createPac(
            @PathVariable(value = "quotationId", required = true) BigDecimal quotationId,
            @RequestBody() PacCreationRequest pac);

    @PostMapping(value = "/v1/psi/quotations/{quotationId}/calculate-tarif", produces = {"application/json"})
    public ResponseEntity<Tarif> calculTarif(@PathVariable(value = "quotationId") BigDecimal quotationId, @RequestBody CalculTarifRequest tarif);


    @PutMapping(path = "/v1/psi/quotations/{quotationId}/{rang}/updateCapital",consumes ={"application/json"} )
    public ResponseEntity<SharedResponse> updateCapital(
            @PathVariable(value = "quotationId", required = true) BigDecimal quotationId,
            @PathVariable(value = "rang", required = true) BigDecimal rang,
            @RequestBody PacModifCapitalRequest pac);

    @PostMapping(path = "/v1/health/simulation/sehassur/capital-decease")
    public ResponseEntity addCapDes(@RequestBody CapDesDtoRequest capDesDtoRequest);

    @PostMapping(value = "/v1/psi/quotations/{quotationId}/calculate-tarif/all", produces = {"application/json"})
    ResponseEntity<Map<String, Tarif>> calculAllFractionTarif(@PathVariable(value = "quotationId") BigDecimal quotationId, @RequestBody CalculTarifRequest tarif);
}