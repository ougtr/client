package ma.axa.outer.bff.website.mapper;

import ma.axa.outer.bff.website.dto.request.BeneficiaireRequest;
import ma.axa.outer.bff.website.dto.request.BeneficiaryRequestDto;
import ma.axa.outer.bff.website.dto.response.Beneficiaire;
import ma.axa.outer.bff.website.dto.response.BeneficiaryResponseDto;
import ma.axa.outer.bff.website.mapper.utils.MapperUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE,uses = MapperUtils.class)
public interface HealthContractMapper {
    @Mapping(source = "nom", target = "lastName")
    @Mapping(source = "prenom", target = "firstName")
    @Mapping(source = "resteTC", target = "remaining")
    @Mapping(source = "numAffilie", target = "affiliateNumber")
    BeneficiaryResponseDto toBeneficiaryDto(Beneficiaire beneficiaire);

    List<BeneficiaryResponseDto> toBeneficiaryDtos(List<Beneficiaire> beneficiaire);

    @Mapping(source = "birthDate", target = "dateNaissance")
    @Mapping(source = "policyNumber", target = "police1", qualifiedByName = "splitPolicyNumberFirstPart")
    @Mapping(source = "policyNumber", target = "police2", qualifiedByName = "splitPolicyNumberSecondPart")
    @Mapping(source = "numAffilie", target = "numAffilie", qualifiedByName = "setNumAffilie")
    @Mapping(source = "prestation", target = "prestation", qualifiedByName = "setPrestation")
    BeneficiaireRequest toBeneficiaireRequest(BeneficiaryRequestDto beneficiaryRequestDto);
}