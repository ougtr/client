package ma.axa.outer.bff.website.mapper;

import ma.axa.outer.bff.website.dto.LeadRequestDto;
import ma.axa.outer.bff.website.dto.request.*;
import ma.axa.outer.bff.website.dto.response.Product;
import ma.axa.outer.bff.website.dto.response.Tarif;
import ma.axa.outer.bff.website.dto.response.TarifResponseDto;
import ma.axa.outer.bff.website.mapper.utils.MapperUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static ma.axa.outer.bff.website.util.constants.GlobalConstants.*;

@Component
public class PsiPremiumMapper {
    public PsiQuotationRequest toPsiQuotationRequest(PsiPremiumSimulationRequest psiPremiumSimulationRequest, Product product) {
        return PsiQuotationRequest.builder().productCode(product.getCode()).intermediaryCode("").lastName(psiPremiumSimulationRequest.getLastName()).firstName(psiPremiumSimulationRequest.getFirstName()).birthDate(MapperUtils.localDateToBigDecimal(psiPremiumSimulationRequest.getBirthDate(), AS400_DATE_FORMAT)).
                effectDate(MapperUtils.localDateToBigDecimal(LocalDate.now(), AS400_DATE_FORMAT)).address("").secondAddress("").country("Maroc").city(psiPremiumSimulationRequest.getCity()).phoneNumber(psiPremiumSimulationRequest.getPhoneNumber()).optionCode(psiPremiumSimulationRequest.getPack().getPackCode()).franchiseCode(psiPremiumSimulationRequest.getPack().getFranchiseCode()).repaymentRate("T01").fraction(psiPremiumSimulationRequest.getPack().getFraction()).reimbBase("").disease("").crtFlg("N").anteriority("N").userCreation("").build();

    }

    public PsiQuotationRequest toSehassurQuotationRequest(SehassurPremiumSimulationRequest sehassurPremiumSimulationRequest, Product product) {
        return PsiQuotationRequest.builder().productCode(product.getCode()).intermediaryCode("").lastName(sehassurPremiumSimulationRequest.getLastName()).firstName(sehassurPremiumSimulationRequest.getFirstName()).birthDate(MapperUtils.localDateToBigDecimal(sehassurPremiumSimulationRequest.getBirthDate(), AS400_DATE_FORMAT)).
                effectDate(MapperUtils.localDateToBigDecimal(LocalDate.now(), AS400_DATE_FORMAT)).address("").secondAddress("")
                .country("Maroc").city(sehassurPremiumSimulationRequest.getCity()).phoneNumber(sehassurPremiumSimulationRequest.getPhoneNumber())
                .optionCode(sehassurPremiumSimulationRequest.getPack().getPackCode()).repaymentRate("T01").fraction(sehassurPremiumSimulationRequest.getPack().getFraction()).franchiseCode("").reimbBase(sehassurPremiumSimulationRequest.getPack().getRembBase()).disease(sehassurPremiumSimulationRequest.getPack().getDisease()).crtFlg("O").anteriority("O").userCreation("").build();

    }

    public CapDesDtoRequest toCapDesDtoRequest(SehassurDependentsRequestDto sehassurDependentsRequestDto, BigDecimal idQuotation, Integer rang) {
        return CapDesDtoRequest.builder().capdes(sehassurDependentsRequestDto.getDeathCapital()).belnom("").belpre("").flactrl("O").idcota(idQuotation).rang(new BigDecimal(1)).build();
    }

    public PacModifCapitalRequest toPacModifCapitalRequest(SehassurDependentsRequestDto sehassurDependentsRequestDto) {
        return PacModifCapitalRequest.builder().capitalDeces(sehassurDependentsRequestDto.getDeathCapital()).nom("").prenom("").flagControl("O").build();
    }

    public PacCreationRequest toPacCreationRequest(DependentsPeopleRequestDto dependent) {
        return PacCreationRequest.builder().dateNaissance(MapperUtils.localDateToBigDecimal(dependent.getBirthDate(), AS400_DATE_FORMAT)).
                lienParente(dependent.getType()).dateAffiliation(MapperUtils.localDateToBigDecimal(LocalDate.now(), AS400_DATE_FORMAT)).
                codeClient("").nom("").prenom("").sexe("M").handicape("N").pieceIdentite("").numPieceIdentite("").tel("").
                adresse("").user("").etat("").numOrdre(new BigDecimal(1)).build();
    }

    public CalculTarifRequest toCalculTarifRequest(PsiQuotationRequest psiQuotationRequest, PsiPremiumSimulationRequest psiPremiumSimulationRequest) {
        return CalculTarifRequest.builder().codeProduit(psiQuotationRequest.getProductCode()).option(psiQuotationRequest.
                getOptionCode()).dateEffet(MapperUtils.localDateToBigDecimal(LocalDate.now(), AS400_DATE_FORMAT)).baseRemb("").tauxRemb("T01").
                fraction(psiQuotationRequest.getFraction()).age(new BigDecimal(Period.between(psiPremiumSimulationRequest.
                getBirthDate(), LocalDate.now()).getYears())).capDeces("").capRedoute("").anteriorite("").malRedoute("").
                tauxMal(new BigDecimal(0)).tauxDeces(new BigDecimal(0)).tauxMalRedoute(new BigDecimal(0)).
                flagSouscription("C").franshise(psiQuotationRequest.getFranchiseCode()).numOrder(new BigDecimal(0)).build();
    }

    public CalculTarifRequest toSehassurCalculTarifRequest(PsiQuotationRequest psiQuotationRequest, SehassurPremiumSimulationRequest psiPremiumSimulationRequest) {
        return CalculTarifRequest.builder().codeProduit(psiQuotationRequest.getProductCode()).option(psiQuotationRequest.
                getOptionCode()).dateEffet(MapperUtils.localDateToBigDecimal(LocalDate.now(), AS400_DATE_FORMAT)).baseRemb(psiPremiumSimulationRequest.getPack().getRembBase()).tauxRemb(psiPremiumSimulationRequest.getPack().getRembRate()).
                fraction(psiQuotationRequest.getFraction()).age(new BigDecimal(Period.between(psiPremiumSimulationRequest.
                getBirthDate(), LocalDate.now()).getYears())).capDeces(psiPremiumSimulationRequest.getPack().getDeathCapital()).capRedoute(psiPremiumSimulationRequest.getPack().getDisease()).anteriorite(AS400_YES_VALUE)
                .malRedoute(!StringUtils.isEmpty(psiPremiumSimulationRequest.getPack().getDisease()) ? AS400_YES_VALUE : "").
                        tauxMal(new BigDecimal(0)).tauxDeces(new BigDecimal(0)).tauxMalRedoute(new BigDecimal(0)).
                        flagSouscription("C").franshise(psiQuotationRequest.getFranchiseCode()).numOrder(new BigDecimal(0)).build();
    }

    public LeadRequestDto toLeadRequestDto(PsiPremiumSimulationRequest psiPremiumSimulationRequest) {
        LeadRequestDto leadRequestDto = new LeadRequestDto();
        leadRequestDto.setLastName(psiPremiumSimulationRequest.getLastName());
        leadRequestDto.setFirstName(psiPremiumSimulationRequest.getFirstName());
        leadRequestDto.setPhone(psiPremiumSimulationRequest.getPhoneNumber());
        leadRequestDto.setEmail(psiPremiumSimulationRequest.getMail());
        leadRequestDto.setVille(psiPremiumSimulationRequest.getCityLabel());
        leadRequestDto.setProductCode("SEHASSUR Plus Internationale");
        leadRequestDto.setIsSimulator(true);
        leadRequestDto.setStatus("Prospect");
        leadRequestDto.setBirthDate(MapperUtils.localDateToString(psiPremiumSimulationRequest.getBirthDate(), SFDC_DATE_FORMAT));
        leadRequestDto.setLiveInMorocco(true);
        leadRequestDto.setFranchise(psiPremiumSimulationRequest.getPack().getFranchiseLabel());
        leadRequestDto.setFormula(psiPremiumSimulationRequest.getPack().getPackLabel());
        leadRequestDto.setHasPAC(psiPremiumSimulationRequest.getDependents().size() > 0);
        leadRequestDto.setPeriodicity(periodToSF(psiPremiumSimulationRequest.getPack().getFraction()));
        List<DependentsPeopleRequestDto> jointList = psiPremiumSimulationRequest.getDependents() != null ? psiPremiumSimulationRequest.getDependents().stream().
                filter(d -> d.getType().equals("C")).collect(Collectors.toList()) : null;
        List<DependentsPeopleRequestDto> childrenList = psiPremiumSimulationRequest.getDependents() != null ? psiPremiumSimulationRequest.getDependents().stream().
                filter(d -> d.getType().equals("E")).collect(Collectors.toList()) : null;
        String jointsAsString = (jointList == null ? "" : jointList.stream().map(j -> MapperUtils.localDateToString(j.getBirthDate(), SFDC_DATE_FORMAT)).collect(Collectors.joining(";")));
        String childrenAsString = (childrenList == null ? "" : childrenList.stream().map(c -> MapperUtils.localDateToString(c.getBirthDate(), SFDC_DATE_FORMAT)).collect(Collectors.joining(";")));
        String description = String.format("Conjoints: %s | Enfants: %s ",
                jointsAsString, childrenAsString);
        leadRequestDto.setHasPAC(psiPremiumSimulationRequest.getDependents().size() > 0);
        leadRequestDto.setPac(description);
        leadRequestDto.setLeadSource("Simulateur");
        leadRequestDto.setCguConsent(psiPremiumSimulationRequest.getCguConsent());
        leadRequestDto.setMarketingConsent(psiPremiumSimulationRequest.getMarketingConsent());
        return leadRequestDto;
    }

    private String periodToSF(String value) {
        String sfValue = "Annuelle";
        switch (value) {
            case "A":
                sfValue = "Annuelle";
                break;
            case "S":
                sfValue = "Semestrielle";
                break;
            case "M":
                sfValue = "Mensuelle";
                break;
            case "T":
                sfValue = "Trimestrielle";
                break;

        }
        return sfValue;
    }

    public LeadRequestDto toSehassurLeadRequestDto(SehassurPremiumSimulationRequest psiPremiumSimulationRequest) {
        LeadRequestDto leadRequestDto = new LeadRequestDto();
        leadRequestDto.setLeadSource("Simulateur");
        leadRequestDto.setLastName(psiPremiumSimulationRequest.getLastName());
        leadRequestDto.setFirstName(psiPremiumSimulationRequest.getFirstName());
        leadRequestDto.setPhone(psiPremiumSimulationRequest.getPhoneNumber());
        leadRequestDto.setEmail(psiPremiumSimulationRequest.getMail());
        leadRequestDto.setVille(psiPremiumSimulationRequest.getCityLabel());
        leadRequestDto.setProductCode("SEHASSUR");
        leadRequestDto.setIsSimulator(true);
        leadRequestDto.setStatus("Prospect");
        leadRequestDto.setBirthDate(MapperUtils.localDateToString(psiPremiumSimulationRequest.getBirthDate(), SFDC_DATE_FORMAT));
        leadRequestDto.setLiveInMorocco(true);
        if (Objects.nonNull(psiPremiumSimulationRequest.getPackLead())) {
            leadRequestDto.setFormula(psiPremiumSimulationRequest.getPackLead().getFormulaValue());
            leadRequestDto.setReimbursementRate(parseDouble(psiPremiumSimulationRequest.getPackLead().getRembRateValue().replace("%", ""), 0.0));
            leadRequestDto.setReimbursementBase(psiPremiumSimulationRequest.getPackLead().getRembBaseValue());
            /*if(Objects.nonNull(psiPremiumSimulationRequest.getPack()) && !psiPremiumSimulationRequest.getPack().getDisease().isEmpty())
                leadRequestDto.setDiseaseGuaranty(psiPremiumSimulationRequest.getPackLead().getDiseaseValue().replaceAll(" ", ""));*/
            leadRequestDto.setDeceaseGuaranty(
            	    Optional.ofNullable(psiPremiumSimulationRequest.getPackLead().getDeathCapitalValue())
            	        .map(v -> v.replaceAll("\\s+", ""))
            	        .filter(v -> !v.isEmpty())
            	        .map(Double::parseDouble)
            	        .orElse(0.0)
            	);
        }
        if (Objects.nonNull(psiPremiumSimulationRequest.getPack())) {
            leadRequestDto.setPrelevement(!psiPremiumSimulationRequest.getPack().getFraction().equals("A"));
            leadRequestDto.setPeriodicity(periodToSF(psiPremiumSimulationRequest.getPack().getFraction()));
        }

        List<SehassurDependentsRequestDto> spouseList = psiPremiumSimulationRequest.getDependents() != null ? psiPremiumSimulationRequest.getDependents().stream().
                filter(d -> d.getType().equals("C")).collect(Collectors.toList()) : null;
        String deceaseGuarantySpouse = "";
        for (SehassurDependentsRequestDto spouse:spouseList) {
            if(Objects.nonNull(spouse.getDeathCapital()) && spouse.getDeathCapital().isEmpty()) deceaseGuarantySpouse += "Garantie décès conjoint : Non; Montant : 0DH | ";
            else deceaseGuarantySpouse += "Garantie décès conjoint : Oui; Montant : "+spouse.getDeathCapitalAmount()+" | ";
        }
        leadRequestDto.setDeceaseSpouseGuaranty(deceaseGuarantySpouse);

        List<DependentsPeopleRequestDto> jointList = psiPremiumSimulationRequest.getDependents() != null ? psiPremiumSimulationRequest.getDependents().stream().
                filter(d -> d.getType().equals("C")).collect(Collectors.toList()) : null;
        List<DependentsPeopleRequestDto> childrenList = psiPremiumSimulationRequest.getDependents() != null ? psiPremiumSimulationRequest.getDependents().stream().
                filter(d -> d.getType().equals("E")).collect(Collectors.toList()) : null;
        String jointsAsString = (jointList == null ? "" : jointList.stream().map(j -> MapperUtils.localDateToString(j.getBirthDate(), SFDC_DATE_FORMAT)).collect(Collectors.joining(";")));
        String childrenAsString = (childrenList == null ? "" : childrenList.stream().map(c -> MapperUtils.localDateToString(c.getBirthDate(), SFDC_DATE_FORMAT)).collect(Collectors.joining(";")));
        String description = String.format("Conjoints: %s | Enfants: %s ",
                jointsAsString, childrenAsString);
        leadRequestDto.setHasPAC(psiPremiumSimulationRequest.getDependents().size() > 0);
        leadRequestDto.setPac(description);
        leadRequestDto.setCguConsent(psiPremiumSimulationRequest.getCguConsent());
        leadRequestDto.setMarketingConsent(psiPremiumSimulationRequest.getMarketingConsent());
        return leadRequestDto;
    }

    public TarifResponseDto toTarifResponseDto(Tarif tarif, String idLead, String quotationId) {
        return TarifResponseDto.builder().premium(tarif.getMntTotal().toString()).idLead(idLead).quotationId(quotationId).build();
    }

    private Double parseDouble(String number, Double defaultValue) {
        try {
            return Double.valueOf(number);
        } catch (Exception e) {
            return defaultValue;
        }
    }
}