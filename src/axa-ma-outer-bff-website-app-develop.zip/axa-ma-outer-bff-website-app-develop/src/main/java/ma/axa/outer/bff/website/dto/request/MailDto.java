package ma.axa.outer.bff.website.dto.request;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MailDto {
    private String[] to;
    private String[] cc;
    private String template;
    private String subject;
    private String variables;
    private String from;
}