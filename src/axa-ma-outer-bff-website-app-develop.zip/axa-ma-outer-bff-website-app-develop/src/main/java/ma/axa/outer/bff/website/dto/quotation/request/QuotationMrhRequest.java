package ma.axa.outer.bff.website.dto.quotation.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.outer.bff.website.dto.quotation.Primes;
import ma.axa.outer.bff.website.dto.quotation.QuotationMrh;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class QuotationMrhRequest extends QuotationMrh {
	@Schema(description = "La prime totale du pack")
	private Primes primesTotals;
}