package ma.axa.outer.bff.website.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InfoCNT {
	@Schema(description = "Le matricule de l'agent" ,example ="")
	private BigDecimal	    matriculeAgent;
	@Schema(description = "L'imputation budgetaire(refrentiel bufget)" ,example ="45666")
	private BigDecimal	       imputationBudgetaire;
	@Schema(description = "Le nombre de mensualites" ,example ="12")
	private BigDecimal	   nombreMensualites;
}
