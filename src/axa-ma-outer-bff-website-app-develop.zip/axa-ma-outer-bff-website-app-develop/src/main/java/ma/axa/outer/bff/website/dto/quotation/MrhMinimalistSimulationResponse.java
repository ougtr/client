package ma.axa.outer.bff.website.dto.quotation;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.dto.quotation.request.MrhMinimalistSimulationRequest;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class MrhMinimalistSimulationResponse extends MrhMinimalistSimulationRequest{
	
	private BigDecimal annualPrice;
	
	 public static MrhMinimalistSimulationResponse fromRequest(MrhMinimalistSimulationRequest request) {
	        MrhMinimalistSimulationResponse response = new MrhMinimalistSimulationResponse();
	        response.setIdQuotation(request.getIdQuotation());
	        response.setTypeHabitation(request.getTypeHabitation());
	        response.setNatureHabitation(request.getNatureHabitation());
	        response.setOptionnelGarantiesId(request.getOptionnelGarantiesId());
	        response.setTypeOccupant(request.getTypeOccupant());
	        response.setValeurBatiment(request.getValeurBatiment());
	        response.setValeurContenu(request.getValeurContenu());
	        response.setValeurObject(request.getValeurObject());
	        response.setMrhProspect(request.getMrhProspect());
	        return response;
	    }

}
