package ma.axa.outer.bff.website.dto.sehassur;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class SehassurDependent {
    private List<SehassurSpouse> spouseList;
    private List<SehassurChild> childList;
}