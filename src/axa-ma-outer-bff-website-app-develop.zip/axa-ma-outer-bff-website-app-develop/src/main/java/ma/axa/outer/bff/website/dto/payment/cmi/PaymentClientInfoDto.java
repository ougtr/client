package ma.axa.outer.bff.website.dto.payment.cmi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentClientInfoDto {
    private String name ;
    private String email ;
    private String phoneNumber ;
    private String address ;
    private String loyaltyNumber ;
    private List<PaymentClientInfoItemDto> infoToShow  ;
}
