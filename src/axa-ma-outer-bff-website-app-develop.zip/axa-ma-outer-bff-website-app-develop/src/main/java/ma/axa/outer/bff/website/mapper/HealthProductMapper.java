package ma.axa.outer.bff.website.mapper;

import ma.axa.outer.bff.website.dto.RefDataResponse;
import ma.axa.outer.bff.website.dto.request.OptionDetails;
import ma.axa.outer.bff.website.dto.request.OptionSehassurDetails;
import ma.axa.outer.bff.website.dto.response.*;

import java.util.List;
import java.util.stream.Collectors;

public interface HealthProductMapper {
    static HealthPackResponse toHealthPackResponse(Option option, OptionParams optionParam, OptionDetails optionDetails) {
        return HealthPackResponse.builder().code(optionParam.getCodeOption()).packName(option.getLibelle().trim())
                .annualLimit(option.getPlafondIndividuel().toEngineeringString())
                .coverageArea(option.getLibelleZoneGeo().trim().replaceAll("/", ", ")).
                        franchise(toRefDataResponse(optionParam.getListFranchise())).description(optionDetails.getDescription()).
                        carence(optionDetails.getCarence()).insuredPartnerLimit(option.getAgeAssureConjoint().toString()).childrenLimit(option.getAgeEnfant().toString()).build();
    }

    static List<RefDataResponse> toRefDataResponse(List<Franchise> franchiseList) {
        return franchiseList.stream().map(e ->
                RefDataResponse.builder().label(e.getMontant().toEngineeringString()).code(e.getCode()).build()
        ).collect(Collectors.toList());
    }

    static List<RefDataResponse> toRembRateDataRef(List<TauxRembAMC> listTauxRemb) {
        return listTauxRemb.stream().map(e -> RefDataResponse.builder().label(e.getLibelle().trim()).code(e.getCode()).build()).collect(Collectors.toList());
    }

    static List<RefDataResponse> toRembBaseDataRef(List<BaseRembAMC> listBaseRemb) {
        return listBaseRemb.stream().map(e -> RefDataResponse.builder().label(e.getLibelle().trim()).code(e.getCode()).build()).collect(Collectors.toList());
    }

    static List<RefDataResponse> toDeathCapitalDataRef(List<Capital> listCapitalDeces) {
        return listCapitalDeces.stream().map(e -> RefDataResponse.builder().label(e.getLibelle().trim()).code(e.getCode()).build()).collect(Collectors.toList());
    }

    static List<RefDataResponse> toCriticalIllnessCapitalDataRef(List<Capital> listCapitalMalRedoute) {
        return listCapitalMalRedoute.stream().map(e -> RefDataResponse.builder().label(e.getLibelle().trim()).code(e.getCode()).build()).collect(Collectors.toList());
    }

    static HealthSehassurPacksResponseDto toHealthSehassurPacksResponseDto(Option option, OptionParams optionParam, OptionSehassurDetails optionDetails, Product product) {
        return HealthSehassurPacksResponseDto.builder().code(optionParam.getCodeOption()).packName(option.getLibelle().trim())
                .annualLimit(option.getPlafondIndividuel().toEngineeringString())
                .rembRate(toRembRateDataRef(optionParam.getListTauxRemb())).deathCapital(toDeathCapitalDataRef(optionParam.getListCapitalDeces()))
                .rembBase(toRembBaseDataRef(optionParam.getListBaseRemb())).description(optionDetails.getDescription())
                .criticalIllnessCapital(toCriticalIllnessCapitalDataRef(product.getListCapitalMalRedoute())).build();
    }
}
