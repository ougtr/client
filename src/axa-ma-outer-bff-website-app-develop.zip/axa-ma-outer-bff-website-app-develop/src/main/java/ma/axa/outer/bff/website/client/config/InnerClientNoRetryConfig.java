package ma.axa.outer.bff.website.client.config;

import feign.Retryer;
import lombok.RequiredArgsConstructor;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

@EnableFeignClients(basePackages = "ma.axa.outer.bff.website.client")
@RequiredArgsConstructor
public class InnerClientNoRetryConfig {

	@Bean
	public Retryer noRetryer() {
		return Retryer.NEVER_RETRY;
	}

}
