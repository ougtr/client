package ma.axa.outer.bff.website.api;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.request.SehassurPremiumSimulationRequest;
import ma.axa.outer.bff.website.dto.response.HealthSehassurPacksResponseDto;
import ma.axa.outer.bff.website.dto.response.TarifResponseDto;
import ma.axa.outer.bff.website.service.EmailContentProtectionService;
import ma.axa.outer.bff.website.service.HealthProductService;
import ma.axa.outer.bff.website.service.HealthService;
import ma.axa.outer.bff.website.service.PrintingService;
import ma.axa.outer.bff.website.service.QuotationAccessTokenService;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/v1/sehassur")
@RequiredArgsConstructor
@Validated
public class SehassurSimulatorApi {
    private final HealthProductService healthProductService;
    private final HealthService healthService;
    private final ICaptchaService captchaService;
    private final PrintingService printingService;
    private final QuotationAccessTokenService quotationAccessTokenService;
    private final EmailContentProtectionService emailContentProtectionService;

    @GetMapping(value = "/packs", produces = {"application/json"})
    public ResponseEntity<List<HealthSehassurPacksResponseDto>> getSehassurPacks() {
        return new ResponseEntity<>(healthProductService.getAllPacksSehassur(), HttpStatus.OK);
    }

    @PostMapping(value = "/premium", produces = {"application/json"})
    public ResponseEntity<TarifResponseDto> calculateSehassurPremium(@RequestBody SehassurPremiumSimulationRequest sehassurSimulationRequestDto
            , @RequestParam("g-recaptcha-response") String captchaResponse
    ) {
        captchaService.processResponse(captchaResponse);
        return new ResponseEntity<>(healthService.calculateSehassurPremium(sehassurSimulationRequestDto), HttpStatus.OK);
    }

    @PostMapping(value = "/{quotationId}/devis")
    public ResponseEntity<Resource> generateDevis(@PathVariable String quotationId, @RequestBody SehassurPremiumSimulationRequest sehassurPremiumSimulationRequest
    ) {
        String resolvedQuotationId = quotationAccessTokenService.extractSehassurQuotationId(quotationId);
        return new ResponseEntity<>(healthService.getSehassurDevis(resolvedQuotationId, sehassurPremiumSimulationRequest), HttpStatus.OK);
    }

    @PostMapping(value = "/{quotationId}/send-mail")
    public ResponseEntity<ApiMessageWrapper> sendDevis(@PathVariable String quotationId, @RequestBody SehassurPremiumSimulationRequest sehassurPremiumSimulationRequest) {
        String resolvedQuotationId = quotationAccessTokenService.extractSehassurQuotationId(quotationId);
        SehassurPremiumSimulationRequest sanitizedRequest = emailContentProtectionService.sanitizeForEmail(sehassurPremiumSimulationRequest);
        return new ResponseEntity<>(healthService.sendSehassurMail(resolvedQuotationId, sanitizedRequest), HttpStatus.OK);
    }
}
