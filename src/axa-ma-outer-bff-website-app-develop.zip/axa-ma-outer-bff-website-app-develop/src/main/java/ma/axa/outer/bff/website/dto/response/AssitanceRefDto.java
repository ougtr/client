package ma.axa.outer.bff.website.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AssitanceRefDto {
    private String code;
    private String packName;
    private String currency;
    private String value;
}
