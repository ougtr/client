package ma.axa.outer.bff.website.dto.payment.cmi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentRequestContractDetailsRequest {
    private String quittanceNumber  ;
    private String policyNumber ;
    private String policyAvenant ;
}
