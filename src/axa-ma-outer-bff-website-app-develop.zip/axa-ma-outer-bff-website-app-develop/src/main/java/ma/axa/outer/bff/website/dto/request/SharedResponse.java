package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SharedResponse {

	private BigDecimal cotationId;
	private BigDecimal PacRang;
	private BigDecimal benefId;
	private BigDecimal numQst;
}
