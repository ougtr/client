package ma.axa.outer.bff.website.dto.quotation;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
@SuperBuilder
@EqualsAndHashCode(callSuper = true)
public class QuotationMrhResponse  extends QuotationMrh {
	@Schema(description = "La prime totale du pack")
	private Primes primesTotals;
}
