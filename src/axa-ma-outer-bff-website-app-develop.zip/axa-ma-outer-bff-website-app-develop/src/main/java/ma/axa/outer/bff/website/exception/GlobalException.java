package ma.axa.outer.bff.website.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@AllArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class GlobalException extends RuntimeException {
	private static final long serialVersionUID = 4786368668233461454L;

	private final String type;

	public GlobalException(String type, String detail) {
		super(detail);
		this.type = type;
	}
}
