package ma.axa.outer.bff.website.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.outer.bff.website.client.InnerSFDCProxy;
import ma.axa.outer.bff.website.dto.LeadRequestDto;
import ma.axa.outer.bff.website.dto.LeadResponseDto;
import ma.axa.outer.bff.website.dto.request.AllQuotationsDto;
import ma.axa.outer.bff.website.dto.request.QuotationDto;
import ma.axa.outer.bff.website.dto.response.GuaranteesDto;
import ma.axa.outer.bff.website.mapper.LeadMapper;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class LeadService {
    private final InnerSFDCProxy innerSFDCProxy;
    private final JsonRefService jsonRefService;
    private final ObjectMapper mapper;

    public LeadResponseDto saveProspect(LeadRequestDto leadRequestDto) {
            return innerSFDCProxy.createLead(leadRequestDto).getBody();
    }

    public LeadResponseDto updateLead(LeadRequestDto leadRequestDto, String idLead) {
            return innerSFDCProxy.updateLead(leadRequestDto, idLead).getBody();
    }

    public LeadResponseDto saveAutoProspect(AllQuotationsDto allQuotationDto){
        LeadRequestDto request = LeadMapper.autoToLeadDto(allQuotationDto);
       return saveProspect(request);
    }

    public LeadResponseDto updateAutoProspect(QuotationDto quotationDto, String prime) {
        List<GuaranteesDto> guaranteesRef = mapper.convertValue(jsonRefService.getGuaranteesPacks(), mapper.getTypeFactory().constructCollectionType(List.class, GuaranteesDto.class));
        LeadRequestDto leadRequestDto = LeadMapper.autoUpdateToLeadDto(quotationDto, guaranteesRef.get(quotationDto.getIdPack() - 2), prime);
        leadRequestDto.setPrime(new BigDecimal(prime));
        return updateLead(leadRequestDto, quotationDto.getIdLead());
    }
}
