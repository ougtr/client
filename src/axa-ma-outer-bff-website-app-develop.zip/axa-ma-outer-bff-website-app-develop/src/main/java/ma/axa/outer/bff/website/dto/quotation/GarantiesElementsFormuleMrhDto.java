package ma.axa.outer.bff.website.dto.quotation;

import ma.axa.outer.bff.website.dto.RefDataMRHResponse;

public class GarantiesElementsFormuleMrhDto extends RefDataMRHResponse {
}
