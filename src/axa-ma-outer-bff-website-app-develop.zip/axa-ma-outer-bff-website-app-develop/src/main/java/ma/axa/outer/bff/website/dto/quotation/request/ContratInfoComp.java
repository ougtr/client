package ma.axa.outer.bff.website.dto.quotation.request;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.util.BigdecimalConverter;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class 	ContratInfoComp {
	@JsonDeserialize(using = BigdecimalConverter.class, as=String.class)
	private String dateEffet;
	private String denomAssureur;
	private String etage;
	private Integer surface;
	private Integer nombrePiece;
	@JsonDeserialize(using = BigdecimalConverter.class, as=String.class)
	private String anneConstruction;
	private Boolean sysAlarme;
	private Boolean sysVideoSurveillance;
	private Boolean sysDetecFume;
}
