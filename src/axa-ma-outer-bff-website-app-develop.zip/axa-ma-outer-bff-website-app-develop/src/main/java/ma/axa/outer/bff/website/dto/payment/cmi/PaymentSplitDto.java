package ma.axa.outer.bff.website.dto.payment.cmi;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.enums.DistributionChannel;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentSplitDto {
    private DistributionChannel channel ;
    private BigDecimal amount ;
    private Long intermediaryCode ;
}
