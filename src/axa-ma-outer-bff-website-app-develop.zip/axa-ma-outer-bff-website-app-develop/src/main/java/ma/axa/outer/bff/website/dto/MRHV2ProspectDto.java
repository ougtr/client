package ma.axa.outer.bff.website.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MRHV2ProspectDto {

    private String leadId;
    private String title;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String emailAddress;
    private String owner;// type d'occuppant
    private String propertyNature;// type d'habitation : habitation principal ...
    private String propertyType;//  type du bien  : villa ...
    private String insuredValue; //valeur du batiment
    private String insuredContentValue; //valeur du contenu assuré
    private String city;
    private BigDecimal prime;
    private Boolean marketingConsent;
    private Boolean cguConsent;
}
