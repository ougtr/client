package ma.axa.outer.bff.website.client.config;

import java.nio.charset.Charset;

import ma.axa.outer.bff.website.exception.InnerClientException;
import ma.axa.outer.bff.website.exception.NotFoundException;
import org.apache.commons.io.IOUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;
import ma.axa.outer.bff.website.dto.error.ApiError;
import ma.axa.outer.bff.website.util.EscapeUtils;
import org.springframework.http.HttpStatus;

@Slf4j
public class InnerErrorDecoder implements ErrorDecoder {


	@Override
	public Exception decode(String methodKey, Response response) {
		String message = null;
		try (var isBody = response.body().asInputStream();){
			ApiError apiError = null;
			if (response.body() == null) {
				message = response.reason() ;
			} else {
				message = IOUtils.toString(isBody, String.valueOf(Charset.defaultCharset()));
				apiError = new ObjectMapper().readValue(message, ApiError.class);
			}
			var details = String.format(
					"%s - receive INNER error message with http status %s: %s",
					methodKey, response.status(),
					EscapeUtils.escapeHtml(response.reason()));
			log.error(details);
			apiError.setStatus(response.status());
			log.error("error : {}",apiError);
			if(response.status() == HttpStatus.NOT_FOUND.value())
				return new NotFoundException(details, apiError);
			return new InnerClientException(details, apiError);
		} catch (Exception e) {
			var details = String.format(
					"%s - receive unexpected INNER error message with http status %s: %s",
					methodKey, response.status(), e.getMessage());
			log.error(details);

			var apiError = ApiError.builder().type(message)
					.title("unexpected").detail(details).build();

			if(response.status() == HttpStatus.NOT_FOUND.value())
				return new NotFoundException(details, apiError);
			return new InnerClientException(e.getMessage(), apiError);
		}
	}
}
