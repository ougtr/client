package ma.axa.outer.bff.website.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.*;

import java.util.List;


@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GaragesListResponseDto {
    private int totalSize;
    List<GaragesResponseDto> garagesList;
}
