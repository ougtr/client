package ma.axa.outer.bff.website.service;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.outer.bff.website.client.InnerQuotationProxy;
import ma.axa.outer.bff.website.config.JsonProperties;
import ma.axa.outer.bff.website.dto.request.OptionDetails;
import ma.axa.outer.bff.website.dto.request.OptionSehassurDetails;
import ma.axa.outer.bff.website.dto.request.QuotationDto;
import ma.axa.outer.bff.website.dto.response.AssitanceRefDto;
import ma.axa.outer.bff.website.dto.response.GuaranteesDto;
import ma.axa.outer.bff.website.dto.response.PacksDto;
import ma.axa.outer.bff.website.dto.response.PrimeDto;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class JsonRefService {
    private final JsonProperties jsonProperties;
    private final ObjectMapper objectMapper;


    public List<AssitanceRefDto> getAssistanceHeaders() { return jsonProperties.getAssistanceHeaders();
    }

    public List<PacksDto> getAssistancePack() { return jsonProperties.getAssistance();
    }

    public List<GuaranteesDto> getGuaranteesPacks() {
        return  jsonProperties.getGuaranteesPacks();
    }
    public List<OptionDetails> getHealthProductOptions() {

        return objectMapper.convertValue(jsonProperties.getHealthProductOptions(), new TypeReference<List<OptionDetails>>() {});
    }

    public List<OptionSehassurDetails> getSehassurOptionDetails() {
        return objectMapper.convertValue(jsonProperties.getSehassurProductOptionsDetails(), new TypeReference<List<OptionSehassurDetails>>() {});

    }
}
