package ma.axa.outer.bff.website.util.constants;

public final class GlobalConstants  {

	private GlobalConstants() throws InstantiationException {
	   throw new InstantiationException("Instances of this type are forbidden");
	}

	/** SCOPE **/
    public static final String SCOPE_GEO_READ = "SCOPE_geo:read";


	/** REQUEST HEADERS**/
    public static final String HEADER_BEARER = "Bearer ";

	/** API ERROR CODES **/
	private static final String BASE_URI							= "/problem";
	public static final String URI_DEFAULT 							= BASE_URI + "/error-with-detail";
	public static final String URI_MISSING_REQUEST_PARAMETER 		= BASE_URI + "/missing-request-params";
	public static final String URI_INTER_SERVICE_COMMUNICATION		= BASE_URI + "/inter-service-communication";
	public static final String URI_VALIDATION_CONSTRAINT_VIOLATION 	= BASE_URI + "/validation-constraint-violation";
	public static final String URI_METHOD_ARGUMENT_NOT_VALID 		= BASE_URI + "/method-argument-not-valid";
	public static final String URI_RESOURCE_NOT_FOUND 		        = BASE_URI + "/resource-not-found";
	public static final String URI_INVALID_SIGNED_TOKEN             = BASE_URI + "/invalid-signed-token";

	/** COUNTRY CODE **/
	public final static String MOROCCO_COUNTRY_CODE = "212";

	/** TOURISM PRODUCT CODE **/
	public final static Integer PRODUCT_TOURISM_CODE = 115;

	/** QUOTATION VARIABLES **/
	public static final Character PERSONNE_MORALE = 'M';
	public static final Character PERSONNE_PHYSIQUE = 'P';
	public static final String TYPE_PERSONNE_FORMAT_INVALID = "La valeur de type de personne est invalide";
	public static final String TYPE_PERSONNE_NAME = "typePersonne"  ;
	public static final String IDENTIFIANT_NAME = "identifiant"  ;
	public static final String REGEX_CIN = "^[A-Za-z]{1,2}[0-9]{1,6}[a-zA-Z]{0,1}";
	public static final String IDENTIFIANT_FORMAT_INVALID = "Le format de l'indentifiant est invalid"  ;
	public static final String NOM_NAME = "nom"  ;
	public static final String PRENOM_NAME = "prenom"  ;
	public static final String NOM_REQUIRED = "Le nom  est obligatoire"  ;
	public static final String PRENOM_REQUIRED = "Le prénom est obligatoire"  ;
	public static final String REGEX_NUMERIQUE = "\\b\\d+\\b" ;
	public static final Integer MAX_LENGTH_RC = 9 ;
	public static final String IDENTIFIANT_LENGTH_INVALID = "La taille de l'indentifiant est invalid"  ;
	public static final String RAISON_SOCIALE_REQUIRED = "La raison sociale est obligatoire"  ;
	public static final String RAISON_SOCIALE_NAME = "raisonSociale"  ;

	/** HEALTH PRODUCT CODES **/
	public static final String HEALTH_PRODUCT_CODE = "1";
	public static final String HEALTH_PRODUCT_TYPE = "P";
	public static final String HEALTH_SEHASSUR_TYPE = "A";

	/** HEALTH MAIL **/
	public static final String PSI_MAIL_TEMPLATE = "psi-simulation-template";
	public static final String PSI_MAIL_TEMPLATE_MRH = "psi-simulation-template-mrh";
	/** DATE FORMAT **/
	public static final String AS400_DATE_FORMAT = "yyyyMMdd";
	public static final String SFDC_DATE_FORMAT = "yyyy-MM-dd";
	public static final String DEVIS_DATE_FORMAT = "dd/MM/yyyy";

	/** AS400 CODES **/
	public static final String AS400_YES_VALUE = "O";
	
	
	/** MRH PRODUCT CODES **/
	public static final String MRH_PRODUCT_CODE = "22660";
	public static final String _780 = "780";
	public static final String _212 = "212";
	/** Green Card CONSTANTS */
	public static final String GREEN_CARD_RECEPTION_MAIL_TEMPLATE = "green-card-reception-template.html";
	// change the green card number to Carte-verte-%s.pdf to include the policy number or the order number
	public static final String GREEN_CARD_FILE_NAME = "Carte-verte.pdf";
	public static final String GREEN_CARD_RECEPTION_EMAIL_SUBJECT = "Confirmation d’achat – Votre Carte Verte en pièce jointe.";
	public  static  final String AXA_WEB_NO_REPLAY_EMAIL  = "contact@axa.ma";
	public static final String GREEN_CARD_CHECK_EMAIL_MESSAGE = "Veuillez vérifier votre boîte mail pour recevoir votre carte verte.";
	public static final String GREEN_CARD_FAILED_MESSAGE = "Une erreur s'est produite lors de traitement de votre demande";
}
