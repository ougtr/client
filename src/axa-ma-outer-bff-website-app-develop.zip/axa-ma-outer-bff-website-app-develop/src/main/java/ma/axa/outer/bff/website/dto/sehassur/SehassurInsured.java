package ma.axa.outer.bff.website.dto.sehassur;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class SehassurInsured {

    private String gender;
    private String firstName;
    private String lastName;
    private String birthDate;
    private SehassurDependent dependents;
    private String optionLabel;
    private String diseaseCeiling;
    private String deceaseBenefit;
    private String criticalIllnessCapital;
    private String numberOfPAC;
    private SehassurOptionPremium optionPremiums;
}