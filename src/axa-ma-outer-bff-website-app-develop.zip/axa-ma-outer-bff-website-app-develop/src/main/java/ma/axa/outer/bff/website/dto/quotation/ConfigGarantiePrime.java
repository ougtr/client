package ma.axa.outer.bff.website.dto.quotation;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class ConfigGarantiePrime {
	private String typeFranchise;
	private Double valeurFranchise;
	private String assiteFranchise; 
	private Double valeurMinFranchise;
	//pour la tarification
	private String modeTarification; 
	private Double valeurMajorationOuReduction;
	private Double valeurBatiment;
	private Double valeurContenu;
	private Double primeForfaitaire;
	private String exclusionCommment;
}
