package ma.axa.outer.bff.website.dto.payment.cmi;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.enums.PaymentProvider;
import ma.axa.outer.bff.website.enums.PaymentStatus;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentRequestBffDto {
    @NotNull(message = "L'id quotation est obligatoire.")
    private String quotationId ;
    @Builder.Default
    private String paymentMode ="PEL" ;
    @Builder.Default
    private String paymentType ="TOTAL" ;
    private String paymentMethod ;
    private boolean generateQrCode ;
    private String quittanceNumber ;
    private String policyNumber ;
    private String policyAvenant;
    private Long intermediaryCode ;
}
