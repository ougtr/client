package ma.axa.outer.bff.website.dto.quotation.request;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class PersonneDto {
	private Character typePersonne   ;
	
	//@NotNull(message = "Le sexe  est obligatoire")
	@Schema(description = "sexe : M(Masculin), F(Féminin)" ,example ="M")
	private Character sexe ;
	private String civilite ;
	private String nom ;
	private String prenom ;
	private String adresse ;
	private BigDecimal codeVille ;
	private BigDecimal codePays ;
	private String identifiant ;
	private String raisonSociale ;
}
