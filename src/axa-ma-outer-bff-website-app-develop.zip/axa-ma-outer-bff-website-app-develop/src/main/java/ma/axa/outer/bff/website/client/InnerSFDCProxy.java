package ma.axa.outer.bff.website.client;

import ma.axa.outer.bff.website.client.config.InnerClientConfig;
import ma.axa.outer.bff.website.dto.LeadRequestDto;
import ma.axa.outer.bff.website.dto.LeadResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "innerSFDCProxy", url = "${axa.client.inner-sfdc}", configuration = InnerClientConfig.class)

public interface InnerSFDCProxy {
    @PostMapping(path = "/v1/leads", produces = { "application/json" })
    ResponseEntity<LeadResponseDto> createLead(
            @RequestBody LeadRequestDto leadRequest
    );

    @PutMapping(path = "/v1/leads/{leadId}", produces = { "application/json" })
    ResponseEntity<LeadResponseDto> updateLead(
            @RequestBody LeadRequestDto leadRequest, @PathVariable String leadId
    );

}
