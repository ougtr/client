package ma.axa.outer.bff.website.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SFClinicsListDto
{
    private int totalSize;
    private List<SFClinicsDto> clinicsList;
}
