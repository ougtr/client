package ma.axa.outer.bff.website.mapper;

import ma.axa.outer.bff.website.dto.*;
import ma.axa.outer.bff.website.dto.request.AllQuotationsDto;
import ma.axa.outer.bff.website.dto.request.QuotationDto;
import ma.axa.outer.bff.website.dto.response.GuaranteesDto;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import static ma.axa.outer.bff.website.mapper.utils.MapperUtils.FormatDateForSF;

public interface LeadMapper {

    static LeadRequestDto toLeadRequest(ClaimRequest claimRequest) {
        LeadRequestDto leadRequestDto = new LeadRequestDto();
        leadRequestDto.setFirstName(claimRequest.getFirstName());
        leadRequestDto.setLastName(claimRequest.getLastName());
        leadRequestDto.setPhone(claimRequest.getPhoneNumber());
        leadRequestDto.setEmail(claimRequest.getEmailAddress());
        leadRequestDto.setCity(claimRequest.getCity());
        String description = String.format("Subject: %s | Message: %s",
                claimRequest.getSubject(), claimRequest.getMessage());
        leadRequestDto.setDescription(description);
        return leadRequestDto;
    }

    static LeadRequestDto toLeadRequest(ContactRequest contactRequest) {
        LeadRequestDto leadRequestDto = new LeadRequestDto();
        leadRequestDto.setFirstName(contactRequest.getFirstName());
        leadRequestDto.setLastName(contactRequest.getLastName());
        leadRequestDto.setPhone(contactRequest.getPhoneNumber());
        leadRequestDto.setEmail(contactRequest.getEmailAddress());
        leadRequestDto.setCity(contactRequest.getCity());
        String description = String.format("Subject: %s | Message: %s",
                contactRequest.getSubject(), contactRequest.getMessage());
        leadRequestDto.setDescription(description);
        return leadRequestDto;
    }

    static LeadRequestDto toLeadRequest(CallMeBackContactRequest callMeBackContactRequest) {
        LeadRequestDto leadRequestDto = new LeadRequestDto();
        leadRequestDto.setFirstName(callMeBackContactRequest.getFirstName());
        leadRequestDto.setLastName(callMeBackContactRequest.getLastName());
        leadRequestDto.setPhone(callMeBackContactRequest.getPhoneNumber());
        leadRequestDto.setEmail(callMeBackContactRequest.getEmailAddress());
        leadRequestDto.setEmail(callMeBackContactRequest.getEmailAddress());
        String description = String.format("Subject: %s | Message: %s",
                callMeBackContactRequest.getSubject(), callMeBackContactRequest.getMessage());
        leadRequestDto.setDescription(description);
        leadRequestDto.setCallMeBack(true);
        return leadRequestDto;
    }

    static LeadRequestDto toPSILeadRequest(PSIProspectDto prospect) {
        LeadRequestDto leadRequestDto = new LeadRequestDto();
        leadRequestDto.setProductCode("PSI");

        leadRequestDto.setLastName(prospect.getLastName());
        leadRequestDto.setFirstName(prospect.getFirstName());
        leadRequestDto.setPhone(prospect.getPhoneNumber());
        leadRequestDto.setEmail(prospect.getEmailAddress());
        leadRequestDto.setVille(prospect.getCityLabel());
        leadRequestDto.setIsSimulator(true);
        leadRequestDto.setStatus("Prospect");
        leadRequestDto.setBirthDate(prospect.getBirthDate());
        leadRequestDto.setCoveredInUSA(prospect.getCoveredInUSA());
        leadRequestDto.setLiveInMorocco(prospect.getLiveInMorocco());
        String jointsAsString = (prospect.getJoints() == null ? "" : prospect.getJoints().stream().map(j -> j.getBirthDate()).collect(Collectors.joining(";")));
        String childrenAsString = (prospect.getChildren() == null ? "" : prospect.getChildren().stream().map(c -> c.getBirthDate()).collect(Collectors.joining(";")));
        String description = String.format("Joints: %s | Children: %s | Franchise: %s | Option: %s",
                jointsAsString, childrenAsString, prospect.getFranchise(), prospect.getOption());
        leadRequestDto.setDescription(description);
        leadRequestDto.setLeadSource("Simulateur");
        return leadRequestDto;
    }
    static LeadRequestDto toMRHLeadRequest(MRHProspectDto prospect) {
        LeadRequestDto leadRequestDto = new LeadRequestDto();
        leadRequestDto.setLastName(prospect.getLastName());
        leadRequestDto.setFirstName(prospect.getFirstName());
        leadRequestDto.setPhone(prospect.getPhoneNumber());
        leadRequestDto.setEmail(prospect.getEmailAddress());
        leadRequestDto.setProductCode("Multirisque Habitation");
        leadRequestDto.setIsSimulator(true);
        leadRequestDto.setStatus("Prospect");
        leadRequestDto.setLeadSource("Simulateur");

        if(Objects.nonNull(prospect.getOwner())) leadRequestDto.setJeSuis(getSFOwnerValue(prospect.getOwner()));
        leadRequestDto.setSalutation(prospect.getTitle());
        if(Objects.nonNull(prospect.getPropertyNature())) leadRequestDto.setNatureDuBien(getSFNatureBienValue(prospect.getPropertyNature()));
        if(Objects.nonNull(prospect.getPropertyType())) leadRequestDto.setTypeDuBien(getSFTypeBienValue(prospect.getPropertyType()));
        return leadRequestDto;
    }

    static LeadRequestDto toMRHLeadRequest(MRHSimulationRequestDto mrhSimulationRequestDto, MRHSimulationResponseDto mrhSimulationResponseDto) {
        LeadRequestDto leadRequestDto = new LeadRequestDto();
        leadRequestDto.setLeadSource("Simulateur");
        if(Objects.nonNull(mrhSimulationRequestDto.getModeAssurance())) leadRequestDto.setValeurAssuree(getSFValeurAssureeValue(mrhSimulationRequestDto.getModeAssurance()));
        leadRequestDto.setValeurDuBien(mrhSimulationResponseDto.getBuildingCapital());
        leadRequestDto.setValeurDuMobilier(mrhSimulationResponseDto.getContentCapital());
        leadRequestDto.setObjetDeValeur(mrhSimulationResponseDto.getObjectsOfValue());
        leadRequestDto.setAnnualPremium(mrhSimulationResponseDto.getTotalPrime().doubleValue());
        return leadRequestDto;
    }

    private static String getSFValeurAssureeValue(String valeurAssuree) {
        String sfValue = "Contenu Mobilier"; //Default Value
        switch (valeurAssuree){
            case "C":
                sfValue = "Contenu Mobilier";
                break;
            case "B":
                sfValue = "Bâtiment";
                break;
            default:
                break;
        }
        return sfValue;
    }

    private static String getSFOwnerValue(String owner) {
        String sfValue = "Propriétaire"; //Default Value
        switch (owner){
            case "owner":
                sfValue = "Propriétaire";
                break;
            case "tenant":
                sfValue = "Locataire";
                break;
            case "co-owner":
                sfValue = "Copropriétaire";
                break;
            default:
                break;
        }
        return sfValue;
    }

    private static String getSFNatureBienValue(String propertyNature) {
        String sfValue = "Principale"; //Default Value
        switch (propertyNature){
            case "principal":
                sfValue = "Principale";
                break;
            case "secondary":
                sfValue = "Secondaire";
                break;
            default:
                break;
        }
        return sfValue;
    }

    private static String getSFTypeBienValue(String propertyType) {
        String sfValue = "Maison"; //Default Value
        switch (propertyType){
            case "house":
                sfValue = "Maison";
                break;
            case "appartement":
                sfValue = "Appartement";
                break;
            case "bungalow":
                sfValue = "Bungalow";
                break;
            case "villa":
                sfValue = "Villa";
                break;
            case "duplex":
                sfValue = "Duplex";
                break;
            default:
                break;
        }
        return sfValue;
    }

    static LeadRequestDto autoToLeadDto(AllQuotationsDto quotationsDto) {
        return  LeadRequestDto.builder().leadSource("Simulateur").productCode("Solutions Auto").firstName(quotationsDto.getContrat().getPrenom()).lastName(quotationsDto.getContrat().getNom())
                .ville(quotationsDto.getLeadInfos().getCity()).cin("")
                .phone(quotationsDto.getLeadInfos().getPhoneNumber()).birthDate(FormatDateForSF(quotationsDto.getContrat().getDateNaissanceAssure()))
                .dateObtentionPermis(FormatDateForSF(quotationsDto.getLeadInfos().getLicenceDate()))
                .marqueVehicule(quotationsDto.getLeadInfos().getBrandName())
                .typeCarburant(getSFFuelValue(quotationsDto.getVehicule().getEnergie().toString())).puissanceFiscale(quotationsDto.getVehicule().getPuissanceFiscale().toString())
                .dateMiseEnCirculation(FormatDateForSF(quotationsDto.getVehicule().getDateMisCirculation())).nombrePlace(quotationsDto.getVehicule().getNombrePlace())
                .valeurNeuf( quotationsDto.getVehicule().getValeurNeuf().doubleValue()).valeurVenale(quotationsDto.getVehicule().getValeurVenale().doubleValue())
                .immatriculation(quotationsDto.getVehicule().getMatricule()).intermediaryCode(quotationsDto.getLeadInfos().getIntermediateName())
                .marketingConsent(quotationsDto.getLeadInfos().getMarketingConsent())
                .cguConsent(quotationsDto.getLeadInfos().getCguConsent())
                .build();
    }

    private static String getSFAssistancevalue(Integer idAssistance) {
        String sfValue = "Access";
        switch (idAssistance) {
            case 2:
                sfValue = "Access";
                break;
            case 5:
                sfValue = "Essentielle";
                break;
            case 8:
                sfValue = "Optimum";
                break;
            case 11:
                sfValue = "Premium";
                break;
        }
        return sfValue;
    }

    public static String getSFFuelValue(String fuel) {
        String sfValue = "Essence";
        switch (fuel) {
            case "G":
                sfValue = "Diesel";
                break;
            case "E":
                sfValue = "Essence";
                break;
            case "W":
                sfValue = "Electrique";
                break;
        }
        return sfValue;
    }

    static LeadRequestDto autoUpdateToLeadDto(QuotationDto quotationsDto, GuaranteesDto pack, String prime) {
        String guarantees = pack.getGuarantees().stream().map(j -> j.getLabel()).collect(Collectors.joining("|"));
        Integer assistanceId = quotationsDto.getGaranties().get(quotationsDto.getGaranties().size() - 1).getFormule();

        return LeadRequestDto.builder().firstName(quotationsDto.getContrat().getPrenom()).lastName(quotationsDto.getContrat().getNom())
                .cin("").leadSource("Simulateur")
                .birthDate(FormatDateForSF(quotationsDto.getContrat().getDateNaissanceAssure()))
                .typeCarburant(getSFFuelValue(quotationsDto.getVehicule().getEnergie().toString())).puissanceFiscale(quotationsDto.getVehicule().getPuissanceFiscale().toString())
                .dateMiseEnCirculation(FormatDateForSF(quotationsDto.getVehicule().getDateMisCirculation())).nombrePlace(quotationsDto.getVehicule().getNombrePlace())
                .valeurNeuf( quotationsDto.getVehicule().getValeurNeuf().doubleValue()).valeurVenale(quotationsDto.getVehicule().getValeurVenale().doubleValue())
                .immatriculation(quotationsDto.getVehicule().getMatricule())
                .formula(pack.getPackName() + " à partir de " + prime + " MAD").garantie(guarantees).pack(getSFAssistancevalue(assistanceId)).build();
    }
    
    
    
    static LeadRequestDto toMRHV2LeadRequest(MRHV2ProspectDto prospect) {
        LeadRequestDto leadRequestDto = new LeadRequestDto();
        leadRequestDto.setLastName(prospect.getLastName());
        leadRequestDto.setFirstName(prospect.getFirstName());
        leadRequestDto.setPhone(prospect.getPhoneNumber());
        leadRequestDto.setEmail(prospect.getEmailAddress());
        leadRequestDto.setProductCode("Multirisque Habitation");
        leadRequestDto.setIsSimulator(true);
        leadRequestDto.setStatus("Prospect");
        leadRequestDto.setLeadSource("Simulateur");
        leadRequestDto.setCity(prospect.getCity());
        leadRequestDto.setMarketingConsent(prospect.getMarketingConsent());
        leadRequestDto.setCguConsent(prospect.getCguConsent());
        ;
        if(Objects.nonNull(prospect.getOwner())) leadRequestDto.setJeSuis(getSFOwnerValue(prospect.getOwner()));
        leadRequestDto.setSalutation(prospect.getTitle());
        if(Objects.nonNull(prospect.getPropertyNature())) leadRequestDto.setNatureDuBien(prospect.getPropertyNature());//getSFNatureBienValue()
        if(Objects.nonNull(prospect.getPropertyType())) leadRequestDto.setTypeDuBien(prospect.getPropertyType());//getSFTypeBienValue()
        if(StringUtils.isNoneBlank(prospect.getInsuredContentValue())) leadRequestDto.setValeurDuMobilier(new BigDecimal(prospect.getInsuredContentValue()));
        if(StringUtils.isNoneBlank(prospect.getInsuredValue())) leadRequestDto.setValeurDuBien(new BigDecimal(prospect.getInsuredValue()));
        if(Objects.nonNull(prospect.getPrime())) leadRequestDto.setAnnualPremium( prospect.getPrime().doubleValue());
        return leadRequestDto;
    }
}