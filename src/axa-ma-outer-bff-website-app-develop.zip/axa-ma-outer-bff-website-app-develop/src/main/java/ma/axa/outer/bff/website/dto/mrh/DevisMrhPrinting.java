package ma.axa.outer.bff.website.dto.mrh;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.dto.MRHV2ProspectDto;
import ma.axa.outer.bff.website.dto.quotation.QuotationGuarentee;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class DevisMrhPrinting {

    private String validityDate;
    private String quotationNumber;
    private String issueDate;
    private String prime;
    private MRHV2ProspectDto mrhProspect;
    private List<QuotationGuarentee> garantiesBases ;
    private List<QuotationGuarentee> garantiesOptionnels ;

}