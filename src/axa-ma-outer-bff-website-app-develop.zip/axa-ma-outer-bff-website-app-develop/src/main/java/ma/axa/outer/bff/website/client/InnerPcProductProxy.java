package ma.axa.outer.bff.website.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import ma.axa.outer.bff.website.client.config.InnerClientConfig;
import ma.axa.outer.bff.website.dto.RefDataResponse;


@FeignClient(name = "innerPcProductProxy", url = "${axa.client.inner-api-pc-product}", configuration = InnerClientConfig.class)
public interface InnerPcProductProxy {

	@GetMapping(path = "/v1/products/{productCode}/building-types", produces = { "application/json" })
    public ResponseEntity<List<RefDataResponse>> getTypeHabitations(@PathVariable(name = "productCode", required = true) String productCode);
    
	
	@GetMapping(path = "/v1/products/{productCode}/occupant-types", produces = { "application/json" })
    public ResponseEntity<List<RefDataResponse>> getTypeOccupants(@PathVariable(name = "productCode", required = true) String productCode);
    
    
}
