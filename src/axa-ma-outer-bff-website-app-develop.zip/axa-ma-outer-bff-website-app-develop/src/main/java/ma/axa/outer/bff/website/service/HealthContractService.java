package ma.axa.outer.bff.website.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.outer.bff.website.client.HealthContractProxy;
import ma.axa.outer.bff.website.dto.request.BeneficiaryRequestDto;
import ma.axa.outer.bff.website.dto.response.Beneficiaire;
import ma.axa.outer.bff.website.dto.response.BeneficiaryResponseDto;
import ma.axa.outer.bff.website.mapper.HealthContractMapper;
import ma.axa.outer.bff.website.util.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class HealthContractService {
    private final HealthContractMapper healthContractMapper;
    private final HealthContractProxy healthContractProxy;
    @Value("${axa.dabadoc.sharedSecretKey:secret}")
    private String sharedSecretKey;

    public List<BeneficiaryResponseDto> getBeneficiariesDetails(BeneficiaryRequestDto beneficiaryRequestDto) {
        List<Beneficiaire> beneficiaries =  healthContractProxy.getBeneficiaires(healthContractMapper.toBeneficiaireRequest(beneficiaryRequestDto)).getBody();
        List<BeneficiaryResponseDto> beneficiaryList = healthContractMapper.toBeneficiaryDtos(beneficiaries);
        applyChecksum(beneficiaryList, beneficiaryRequestDto.getPolicyNumber());
        return beneficiaryList;
    }

    private void applyChecksum(List<BeneficiaryResponseDto> beneficiaryList, String policyNumber) {
        for (BeneficiaryResponseDto beneficiary:beneficiaryList) {
            try {
                beneficiary.setId(UUID.randomUUID().toString());
                String textToEncode = beneficiary.getId().concat(policyNumber)
                        .concat(beneficiary.getLastName()).concat(beneficiary.getFirstName())
                        .concat(beneficiary.getAffiliateNumber().toString())
                        .concat(beneficiary.getRang().toString()).concat(sharedSecretKey);
                String hash512 = StringUtils.computeHash512(textToEncode);
                beneficiary.setChecksum(StringUtils.encodeBase64(hash512));
            } catch (Exception e) {
                log.error("Error while generating checksum for dabadooc redirection url");
                log.error(e.getMessage());
            }

        }
    }
}