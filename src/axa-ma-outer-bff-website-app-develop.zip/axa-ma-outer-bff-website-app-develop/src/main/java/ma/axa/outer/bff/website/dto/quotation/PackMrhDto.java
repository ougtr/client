package ma.axa.outer.bff.website.dto.quotation;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.dto.RefDataMRHResponse;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class PackMrhDto extends RefDataMRHResponse {
    private List<QuotationGuarentee> garanties ;
}
