package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.outer.bff.website.dto.SehassurDependentsDto;
import ma.axa.outer.bff.website.dto.SehassurPackDto;

import java.time.LocalDate;
import java.util.List;

@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SehassurSimulationRequestDto {
    private String firstName;
    private String lastName;
    private LocalDate birthDate;
    private String phoneNumber;
    private String mail;
    private String city;
    private List<SehassurDependentsDto> dependents;
    private SehassurPackDto pack;
    private String idLead;
}
