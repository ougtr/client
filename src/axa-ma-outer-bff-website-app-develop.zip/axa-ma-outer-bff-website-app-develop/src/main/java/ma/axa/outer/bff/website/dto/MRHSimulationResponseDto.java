package ma.axa.outer.bff.website.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Data
@SuperBuilder
@NoArgsConstructor
public class MRHSimulationResponseDto {


    private String optionCode;

    private BigDecimal objectsOfValue;

    private BigDecimal price;

    private BigDecimal buildingCapital;

    private BigDecimal contentCapital;

    private BigDecimal totalPrime;

}
