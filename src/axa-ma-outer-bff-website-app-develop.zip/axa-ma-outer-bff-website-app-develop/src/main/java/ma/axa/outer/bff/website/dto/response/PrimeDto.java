package ma.axa.outer.bff.website.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Data
@SuperBuilder
@NoArgsConstructor
public class PrimeDto {
	
	@Schema(description = "L'id quotation" ,example ="854796")
	private BigDecimal idQuotation ;
	@Schema(description = "La date d'expiration",format ="dd-MM-yyyy" ,example ="04-01-2023")
	private String     dateExpiration ;
	@Schema(description = "La prime net comptant" ,example ="2344.33")
	private BigDecimal primeNetComptant ;
	@Schema(description = "Les taxes comptant" ,example ="385.22")
	private BigDecimal taxesComptant ;
	@Schema(description = "CNPAC comptant" ,example ="17.00")
	private BigDecimal cnpacComptant ;
	@Schema(description = "La frais des accessoires comptant" ,example ="35.00")
	private BigDecimal accessoireComptant ;
	
	@Schema(description = "La prime totale comptant" ,example ="2781.55")
	private BigDecimal primeTotaleComptant ;
	
	@Schema(description = "La prime net annuel" ,example ="2344.33")
	private BigDecimal primeNetAnnuel ;
	@Schema(description = "Les frais des taxes annuel" ,example ="385.22")
	private BigDecimal taxesAnnuel ;
	@Schema(description = "CNPAC annuel" ,example ="17.00")
	private BigDecimal cnpacAnnuel ;
	@Schema(description = "La frais des accessoires annuel" ,example ="35.00")
	private BigDecimal accessoireAnnuel ;
	
	@Schema(description = "La prime totale annuel" ,example ="2781.55")
	private BigDecimal primeTotaleAnnuel ;

	private String idLead;
	
}
