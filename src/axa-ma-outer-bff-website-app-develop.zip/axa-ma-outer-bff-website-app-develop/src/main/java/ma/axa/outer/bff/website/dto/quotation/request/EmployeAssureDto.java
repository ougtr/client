package ma.axa.outer.bff.website.dto.quotation.request;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmployeAssureDto {

    @NotNull(message = "Le code profession est obligatoire")
    @Schema(description = "Le code de la profession(Référentiel : professions)" ,example ="502")
    private BigDecimal codeProfession;

    @Schema(description = "Le nombre de personnes assures " ,example ="3")
    private String nbPersonnesAssurees;
}