package ma.axa.outer.bff.website.exception;

public class InvalidSignedTokenException extends RuntimeException {
    private static final long serialVersionUID = -2269443493526210197L;

    public InvalidSignedTokenException(String message) {
        super(message);
    }
}
