package ma.axa.outer.bff.website.client;

import ma.axa.outer.bff.website.client.config.InnerClientNoRetryConfig;
import ma.axa.outer.bff.website.dto.mrh.DevisMrhPrinting;
import ma.axa.outer.bff.website.dto.sehassur.DevisSehassurPrinting;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "innerPrintingProxy", url = "${axa.client.inner-printing}", configuration = InnerClientNoRetryConfig.class)

public interface InnerPrintingProxy {
    @GetMapping(value = "/v1/health/printing/editique", produces =  {"application/json"})
    public ResponseEntity<Resource> printDevis(@RequestParam String DocType, @RequestParam String user,
                                               @RequestParam String perimetre, @RequestParam String cotationId, @RequestParam String codeProduit);

    @PostMapping(value = "/v1/sehassur/printing/devis", produces =  {"application/json"})
    ResponseEntity<Resource> printSehassurDevis(@RequestBody DevisSehassurPrinting devisSehassurPrinting);
    
    @PostMapping(value = "/v1/mrh/printing/devis", produces =  {"application/json"})
    ResponseEntity<Resource> printMrhDevis(@RequestBody DevisMrhPrinting input);
    
}