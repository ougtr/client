package ma.axa.outer.bff.website.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
public class RenewalAssistance {
    private String formula;
    private String label;
    private String prime;
    private List<RenewalPrestationDto> prestations;
}
