package ma.axa.outer.bff.website.enums;

public enum PaymentStatus {
    CREATED,PENDING,PAID,SUCCESS,FAILED,CANCELED,EXPIRED,REJECTED,NOT_FOUND
}
