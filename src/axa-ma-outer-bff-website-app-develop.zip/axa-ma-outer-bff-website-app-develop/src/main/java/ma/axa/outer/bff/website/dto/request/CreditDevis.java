package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreditDevis {

    private BigDecimal type;


    private BigDecimal montant;

    @Builder.Default
    private String dateFin = "0";

    private BigDecimal idOrganisme;

    private BigDecimal optionRCI;

    private String beneficiaire;

    private BigDecimal numeroDossier;
}
