package ma.axa.outer.bff.website.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Beneficiaire {
	
	private String client;
	private BigDecimal rang;
	private String nom;
	private String prenom;
	private String lienParente;
	private String sexe;
	private BigDecimal numAffilie;
	private String cin;
	private BigDecimal nombreTC;
	private BigDecimal consomeTC;
	private BigDecimal resteTC;
	private String codeRetour;
	 
}
