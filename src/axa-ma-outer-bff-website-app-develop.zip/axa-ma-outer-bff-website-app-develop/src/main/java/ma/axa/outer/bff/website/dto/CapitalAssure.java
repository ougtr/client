package ma.axa.outer.bff.website.dto;

import java.math.BigDecimal;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class CapitalAssure {
	private BigDecimal valeurBatiment;
	private BigDecimal valeurContenu;
	private BigDecimal valeurObject;
}
