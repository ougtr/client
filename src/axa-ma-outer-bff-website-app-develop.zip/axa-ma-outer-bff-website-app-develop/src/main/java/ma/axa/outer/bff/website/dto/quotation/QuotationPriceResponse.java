package ma.axa.outer.bff.website.dto.quotation;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class QuotationPriceResponse {

	@Schema(description = "L'id quotation", example = "854796")
	private BigDecimal idQuotation;
	
	private BigDecimal comptantPrice;
	private BigDecimal comptantAccessory;
	private BigDecimal comptantTaxes;
	private BigDecimal comptantNetPrice;
	
	private BigDecimal annualPrice;
	private BigDecimal annualAccessory;
	private BigDecimal annualTaxes;
	private BigDecimal annualNetPrice;

}
