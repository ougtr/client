package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CarteVerte {
    private String typeImmatriculation;
    private String codeCie;
    private String nature;
    private String codeIntermediaire ;
    private String intermediaire;
    private Integer numeroCv =0;
    private String police;
    private Integer attestation = 0;
    private String dateEffet;
    private String dateEcheance;
    private String matricule;
    private String categorie;
    private String marque;
    private String typeUsage;
    private String usage;
    private String assureNom;
    private String assureAdresse ;
    private String matriculeOld;
}
