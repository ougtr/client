package ma.axa.outer.bff.website.dto.sehassur;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class SehassurOptionPremium {

    private String annualPremiumTTC_80;
    private String semesterPremiumTTC_80;
    private String quarterlyPremiumTTC_80;
    private String monthlyPremiumTTC_80;
    private String annualPremiumTTC_90;
    private String semesterPremiumTTC_90;
    private String quarterlyPremiumTTC_90;
    private String monthlyPremiumTTC_90;
    private String annualPremiumTTC_95;
    private String semesterPremiumTTC_95;
    private String quarterlyPremiumTTC_95;
    private String monthlyPremiumTTC_95;
}