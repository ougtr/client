package ma.axa.outer.bff.website.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class RenewalVehicle {
    private String immat;
    private String brand;
    private String model;
    private String fuel;
    private String fiscalPower;
}
