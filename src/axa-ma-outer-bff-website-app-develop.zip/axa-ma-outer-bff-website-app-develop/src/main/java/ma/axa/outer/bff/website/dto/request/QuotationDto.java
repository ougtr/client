package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QuotationDto {
	
	private ContratDto contrat;
	
	private VehiculeQuotationDto vehicule;
	
	private Integer idPack ;

	private String idLead;

	private List<ClauseDto> clauses ;
	
	private List<GarantieDto> garanties ;

	private LeadInfos leadInfos;

	
}
