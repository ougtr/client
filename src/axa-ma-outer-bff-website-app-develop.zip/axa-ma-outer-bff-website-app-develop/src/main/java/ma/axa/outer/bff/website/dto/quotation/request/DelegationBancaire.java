package ma.axa.outer.bff.website.dto.quotation.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DelegationBancaire {
	private String typeCredit;
	private Double montantCredit;
	private String organismeCredit;
	private String agenceCredit;
	private String adresse;
	private String ville;
}
