package ma.axa.outer.bff.website.config.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.util.List;

@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Value("${axa.security.enabled:true}")
    private boolean securityEnabled;

    @Value("${axa.security.allowed-origin-patterns}")
    private List<String> allowedOriginPatterns;

    @Value("${axa.security.auth0.audience}")
    private String audience;

    @Value("${spring.security.oauth2.resourceserver.jwt.jwk-set-uri}")
    private String jwtSetUri;

    @Bean
    JwtDecoder jwtDecoder() {
        NimbusJwtDecoder jwtDecoder = NimbusJwtDecoder.withJwkSetUri(jwtSetUri).build();

        OAuth2TokenValidator<Jwt> audienceValidator = new AudienceValidator(audience);

        OAuth2TokenValidator<Jwt> withAudience = new DelegatingOAuth2TokenValidator<>(audienceValidator);

        jwtDecoder.setJwtValidator(withAudience);

        return jwtDecoder;
    }

    @Override
    public void configure(HttpSecurity http) throws Exception {
        // @formatter:off
        if (!securityEnabled) {
            http.authorizeRequests().anyRequest().permitAll();
        } else {
            http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and().authorizeRequests(authRequests -> {
                //  Permissions on your endpoints
                authRequests.mvcMatchers(HttpMethod.OPTIONS).permitAll();
                authRequests.mvcMatchers("/v1/geo/**").hasAuthority("SCOPE_geo:read");
                //	.mvcMatchers("/v1/resource2/**").hasRole("ADMIN")
                //  .mvcMatchers("/v1/resource2/**").hasAnyRole("ROLE1", "ROLE2")
                //  ...

                // Management endpoints
                authRequests.mvcMatchers("/management/**", "/docs/**", "/webjars/**", "/v1/referentiel/**", "/v1/renewal/**").permitAll();
                // else
                authRequests.anyRequest().authenticated();
            });

            http.oauth2ResourceServer().jwt();
        }
        http.cors().and().csrf().disable() //NOSONAR
                .exceptionHandling().accessDeniedHandler(securityAccessDeniedHandler()).authenticationEntryPoint(securityAuthEntryPoint());
        // @formatter:on
    }

    @Bean
    public CorsFilter corsFilter() {
        var source = new UrlBasedCorsConfigurationSource();
        var config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");
        source.registerCorsConfiguration("/**", config);
        config.setAllowedOriginPatterns(allowedOriginPatterns);
        return new CorsFilter(source);
    }

    @Bean
    public AccessDeniedHandler securityAccessDeniedHandler() {
        return new SecurityAccessDeniedHandler();
    }

    @Bean
    public AuthenticationEntryPoint securityAuthEntryPoint() {
        return new SecurityAuthEntryPoint();
    }
}
