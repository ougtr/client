package ma.axa.outer.bff.website.dto.request;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Data
@SuperBuilder
@NoArgsConstructor
@ToString
public class PacCreationRequest {

    private String codeClient;
    private String nom;
    private String prenom;    
    private BigDecimal dateNaissance;    
    private BigDecimal dateAffiliation;
    private String sexe;
    private String lienParente;
    private String handicape;
    private String pieceIdentite;
    private String numPieceIdentite;
    private String tel;
    private String adresse;
    private String user;
    private BigDecimal numOrdre;
    private String etat;
}
