package ma.axa.outer.bff.website.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.outer.bff.website.client.InnerHealthProductProxy;
import ma.axa.outer.bff.website.client.InnerHealthProxy;
import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.dto.*;
import ma.axa.outer.bff.website.dto.request.*;
import ma.axa.outer.bff.website.dto.response.*;
import ma.axa.outer.bff.website.dto.sehassur.*;
import ma.axa.outer.bff.website.exception.GlobalException;
import ma.axa.outer.bff.website.mapper.PsiPremiumMapper;
import ma.axa.outer.bff.website.mapper.utils.MapperUtils;
import ma.axa.outer.bff.website.util.constants.GlobalConstants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Period;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static ma.axa.outer.bff.website.util.constants.GlobalConstants.DEVIS_DATE_FORMAT;

@Service
@Slf4j
@RequiredArgsConstructor
public class HealthService {
    private final InnerHealthProxy innerHealthProxy;
    private final InnerHealthProductProxy innerHealthProductProxy;
    private final PsiPremiumMapper psiMapper;
    private final PSISimulatorService psiSimulatorService;
    private final PrintingService printingService;
    private final HealthProductService healthProductService;
    private final InnerNotificationProxy innerNotificationProxy;
    private final QuotationAccessTokenService quotationAccessTokenService;
    private final EmailContentProtectionService emailContentProtectionService;

    @Value("${axa.mail.psi}")
    private String psiEmail;

    public PsiSimulationResponseDto getPsiSimulation(PsiSimulationRequestDto psiSimulationRequestDto) {
        return innerHealthProxy.getSimulation(psiSimulationRequestDto).getBody();
    }

    public TarifResponseDto calculatePsiPremium(PsiPremiumSimulationRequest psiPremiumSimulationRequest) {
        try {
        	 ProspectResponseDto prospect = null;
             if (psiPremiumSimulationRequest.getIdLead() == null) {
                 prospect = psiSimulatorService.savePsiProspect(psiMapper.toLeadRequestDto(psiPremiumSimulationRequest));
             } else {
                 prospect = psiSimulatorService.updatePsiProspect(psiMapper.toLeadRequestDto(psiPremiumSimulationRequest), psiPremiumSimulationRequest.getIdLead());
             }
        	
            List<Product> products = innerHealthProductProxy.getAllProducts(GlobalConstants.HEALTH_PRODUCT_CODE, GlobalConstants.HEALTH_PRODUCT_TYPE).getBody();
            PsiQuotationRequest psiQuotationRequest = null;
            if (!CollectionUtils.isEmpty(products)) {
                psiQuotationRequest = psiMapper.toPsiQuotationRequest(psiPremiumSimulationRequest, products.get(0));
            }
            PsiQuotationResponse psiQuotationResponse = innerHealthProxy.createQuotation(psiQuotationRequest).getBody();
            if (!CollectionUtils.isEmpty(psiPremiumSimulationRequest.getDependents()) && psiQuotationResponse != null) {
                for (DependentsPeopleRequestDto dependent :
                        psiPremiumSimulationRequest.getDependents()) {
                    SharedResponse personInCharge = innerHealthProxy.createPac(new BigDecimal(psiQuotationResponse.getIdQuotation()), psiMapper.toPacCreationRequest(dependent)).getBody();
                }
            }
           
            if (psiQuotationResponse != null) {
                Tarif tarif = innerHealthProxy.calculTarif(new BigDecimal(psiQuotationResponse.getIdQuotation()), psiMapper.toCalculTarifRequest(psiQuotationRequest, psiPremiumSimulationRequest)).getBody();
                if (tarif != null && tarif.getMntTotal() != null) {
                    BigDecimal annualPremium = calculatePremiumByFraction(tarif.getMntTotal(), psiPremiumSimulationRequest.getPack().getFraction());
                    psiSimulatorService.updatePsiProspect(LeadRequestDto.builder().primeSimulation(tarif.getMntTotal()).annualPremium(annualPremium.doubleValue()).build(), prospect.getLeadId());
                }
                TarifResponseDto tarifResponseDto = psiMapper.toTarifResponseDto(tarif, prospect.getLeadId(), psiQuotationResponse.getIdQuotation());
                tarifResponseDto.setQuotationId(
                        quotationAccessTokenService.generateHealthQuotationToken(psiQuotationResponse.getIdQuotation()));
                return tarifResponseDto;
            }
            return null;
        } catch (Exception e) {
            throw e;
        }
    }

    private BigDecimal calculatePremiumByFraction(BigDecimal mntTotal, String fraction) {
        BigDecimal annualPremium = BigDecimal.valueOf(0);
        switch (fraction) {
            case "A":
                annualPremium = mntTotal;
                break;
            case "M":
                annualPremium = mntTotal.multiply(BigDecimal.valueOf(12));
                break;
            case "S":
                annualPremium = mntTotal.multiply(BigDecimal.valueOf(2));
                break;
            case "T":
                annualPremium = mntTotal.multiply(BigDecimal.valueOf(4));
                break;
            default:
                break;
        }
        return annualPremium;
    }

    public ApiMessageWrapper sendMail(String quotationId, String mailAddress, String name) {
        Resource file = printingService.getDevisFile(quotationId);

        try {
            MultipartFile[] content = {new MockMultipartFile("devis.pdf", file.getFilename(), "application/pdf", file.getInputStream().readAllBytes())};
            innerNotificationProxy.sendEmail(
                    Arrays.asList(mailAddress),
                    null,
                    GlobalConstants.PSI_MAIL_TEMPLATE,
                    "simulation PSI",
                    emailContentProtectionService.toTemplateVariablesJson("name", name),
                    psiEmail,
                    content);
        } catch (IOException e) {
            log.error("Failed to send mail");
        }
        return ApiMessageWrapper.builder().message("OK").build();
    }

    public TarifResponseDto calculateSehassurPremium(SehassurPremiumSimulationRequest sehassurPremiumSimulationRequest) {
        try {
        	
        	ProspectResponseDto prospect = null;
            LeadRequestDto lead = psiMapper.toSehassurLeadRequestDto(sehassurPremiumSimulationRequest);
            if (sehassurPremiumSimulationRequest.getIdLead() == null) {
                prospect = psiSimulatorService.savePsiProspect(lead);
            } else {
                prospect = psiSimulatorService.updatePsiProspect(lead, sehassurPremiumSimulationRequest.getIdLead());
            }
        	
            List<Product> products = innerHealthProductProxy.getAllProducts(GlobalConstants.HEALTH_PRODUCT_CODE, GlobalConstants.HEALTH_SEHASSUR_TYPE).getBody();
            PsiQuotationRequest psiQuotationRequest = null;
            if (!CollectionUtils.isEmpty(products)) {
                psiQuotationRequest = psiMapper.toSehassurQuotationRequest(sehassurPremiumSimulationRequest, products.get(0));

            }
            PsiQuotationResponse psiQuotationResponse = innerHealthProxy.createQuotation(psiQuotationRequest).getBody();
            if (!CollectionUtils.isEmpty(sehassurPremiumSimulationRequest.getDependents()) && psiQuotationResponse != null) {
                Integer index = 1;
                for (SehassurDependentsRequestDto dependent :
                        sehassurPremiumSimulationRequest.getDependents()) {
                    innerHealthProxy.createPac(new BigDecimal(psiQuotationResponse.getIdQuotation()), psiMapper.toPacCreationRequest(dependent)).getBody();
                    if (!dependent.getDeathCapital().isEmpty())
                        updateCapital(new BigDecimal(psiQuotationResponse.getIdQuotation()), new BigDecimal(index), psiMapper.toPacModifCapitalRequest(dependent));
                    index++;
                }

            }
            
            if (psiQuotationResponse != null) {
                Tarif tarif = innerHealthProxy.calculTarif(new BigDecimal(psiQuotationResponse.getIdQuotation()), psiMapper.toSehassurCalculTarifRequest(psiQuotationRequest, sehassurPremiumSimulationRequest)).getBody();
                if (tarif != null && tarif.getMntTotal() != null) {
                    lead.setPremiumTTC(tarif.getMntTotal().doubleValue());
                    psiSimulatorService.updatePsiProspect(lead, prospect.getLeadId());
                }
                TarifResponseDto tarifResponseDto = psiMapper.toTarifResponseDto(tarif, prospect.getLeadId(), psiQuotationResponse.getIdQuotation());
                tarifResponseDto.setQuotationId(
                        quotationAccessTokenService.generateSehassurQuotationToken(psiQuotationResponse.getIdQuotation()));
                return tarifResponseDto;
            }
            return null;
        } catch (Exception e) {
            throw e;
        }
    }

    public void addDeathCapital(CapDesDtoRequest capDesDtoRequest) {
        innerHealthProxy.addCapDes(capDesDtoRequest);
    }

    public SharedResponse updateCapital(BigDecimal quotationId, BigDecimal rang, PacModifCapitalRequest pac) {
        return innerHealthProxy.updateCapital(quotationId, rang, pac).getBody();
    }

    public Resource getSehassurDevis(String quotationId, SehassurPremiumSimulationRequest sehassurPremiumSimulationRequest) {
        if (Objects.isNull(sehassurPremiumSimulationRequest.getPack()))
            throw new GlobalException("Pack is mandatory");

        List<Product> products = innerHealthProductProxy.getAllProducts(GlobalConstants.HEALTH_PRODUCT_CODE, GlobalConstants.HEALTH_SEHASSUR_TYPE).getBody();
        PsiQuotationRequest psiQuotationRequest = null;
        if (!CollectionUtils.isEmpty(products)) {
            psiQuotationRequest = psiMapper.toSehassurQuotationRequest(sehassurPremiumSimulationRequest, products.get(0));
        }
        List<HealthSehassurPacksResponseDto> options = healthProductService.getAllPacksSehassur();
        HealthSehassurPacksResponseDto selectedOption = options.stream().filter(o -> o.getCode().equals(sehassurPremiumSimulationRequest.getPack().getPackCode())).findFirst().orElseThrow();
        CalculTarifRequest calculTarifRequest_80 = null;
        CalculTarifRequest calculTarifRequest_90 = null;
        CalculTarifRequest calculTarifRequest_95 = null;
        sehassurPremiumSimulationRequest.getPackLead().setDiseaseReimbursementCeiling(selectedOption.getAnnualLimit());
        for (RefDataResponse rembRate : selectedOption.getRembRate()) {
            sehassurPremiumSimulationRequest.getPack().setRembRate(rembRate.getCode());
            switch (rembRate.getLabel()) {
                case "80%":
                    calculTarifRequest_80 = psiMapper.toSehassurCalculTarifRequest(psiQuotationRequest, sehassurPremiumSimulationRequest);
                    break;
                case "90%":
                    calculTarifRequest_90 = psiMapper.toSehassurCalculTarifRequest(psiQuotationRequest, sehassurPremiumSimulationRequest);
                    break;
                case "95%":
                    calculTarifRequest_95 = psiMapper.toSehassurCalculTarifRequest(psiQuotationRequest, sehassurPremiumSimulationRequest);
                    break;
                default:
                    break;
            }
        }
        DevisSehassurPrinting devisSehassurPrinting = prepareSehassurDevis(quotationId, sehassurPremiumSimulationRequest, calculTarifRequest_80, calculTarifRequest_90, calculTarifRequest_95);
        return printingService.getSehassurDevisFile(devisSehassurPrinting);
    }

    private DevisSehassurPrinting prepareSehassurDevis(String quotationId, SehassurPremiumSimulationRequest sehassurPremiumSimulationRequest,
                                                       CalculTarifRequest calculTarifRequest_80,
                                                       CalculTarifRequest calculTarifRequest_90, CalculTarifRequest calculTarifRequest_95) {
        Map<String, Tarif> t_80 = innerHealthProxy.calculAllFractionTarif(new BigDecimal(quotationId), calculTarifRequest_80).getBody();
        Map<String, Tarif>  t_90 = innerHealthProxy.calculAllFractionTarif(new BigDecimal(quotationId), calculTarifRequest_90).getBody();
        Map<String, Tarif>  t_95 = innerHealthProxy.calculAllFractionTarif(new BigDecimal(quotationId), calculTarifRequest_95).getBody();

        SehassurOptionPremium sehassurOptionPremium = SehassurOptionPremium.builder()
                .annualPremiumTTC_80(Objects.nonNull( t_80.get("A")) ? t_80.get("A").getMntTotal() + " DHS" : "-")
                .monthlyPremiumTTC_80(Objects.nonNull( t_80.get("M")) ? t_80.get("M").getMntTotal() + " DHS" : "-")
                .quarterlyPremiumTTC_80(Objects.nonNull( t_80.get("T")) ? t_80.get("T").getMntTotal() + " DHS" : "-")
                .semesterPremiumTTC_80(Objects.nonNull( t_80.get("S")) ? t_80.get("S").getMntTotal() + " DHS" : "-")
                .annualPremiumTTC_90(Objects.nonNull( t_90.get("A")) ? t_90.get("A").getMntTotal() + " DHS" : "-")
                .monthlyPremiumTTC_90(Objects.nonNull( t_90.get("M")) ? t_90.get("M").getMntTotal() + " DHS" : "-")
                .quarterlyPremiumTTC_90(Objects.nonNull( t_90.get("T")) ? t_90.get("T").getMntTotal() + " DHS" : "-")
                .semesterPremiumTTC_90(Objects.nonNull( t_90.get("S")) ? t_90.get("S").getMntTotal() + " DHS" : "-")
                .annualPremiumTTC_95(Objects.nonNull( t_95.get("A")) ? t_95.get("A").getMntTotal() + " DHS" : "-")
                .monthlyPremiumTTC_95(Objects.nonNull( t_95.get("M")) ? t_95.get("M").getMntTotal() + " DHS" : "-")
                .quarterlyPremiumTTC_95(Objects.nonNull( t_95.get("T")) ? t_95.get("T").getMntTotal() + " DHS" : "-")
                .semesterPremiumTTC_95(Objects.nonNull( t_95.get("S")) ? t_95.get("S").getMntTotal() + " DHS" : "-").build();

        List<SehassurSpouse> jointList = sehassurPremiumSimulationRequest.getDependents() != null ? sehassurPremiumSimulationRequest.getDependents().stream().
                filter(d -> d.getType().equals("C")).map(d -> new SehassurSpouse(d.getBirthDate().toString(), getCurrentAge(d.getBirthDate()))).collect(Collectors.toList()) : null;
        List<SehassurChild> childrenList = sehassurPremiumSimulationRequest.getDependents() != null ? sehassurPremiumSimulationRequest.getDependents().stream().
                filter(d -> d.getType().equals("E")).map(d -> new SehassurChild(d.getBirthDate().toString(), getCurrentAge(d.getBirthDate()))).collect(Collectors.toList()) : null;


        SehassurDependent sehassurDependent = SehassurDependent.builder().spouseList(jointList).childList(childrenList).build();
        SehassurInsured sehassurInsured = SehassurInsured.builder().gender("Madame, Monsieur "+sehassurPremiumSimulationRequest.getFirstName() + " " + sehassurPremiumSimulationRequest.getLastName())
                .firstName(sehassurPremiumSimulationRequest.getFirstName())
                .lastName(sehassurPremiumSimulationRequest.getLastName())
                .birthDate(MapperUtils.localDateToString(sehassurPremiumSimulationRequest.getBirthDate(), DEVIS_DATE_FORMAT))
                .optionLabel(sehassurPremiumSimulationRequest.getPackLead().getFormulaValue())
                .diseaseCeiling((Objects.nonNull(sehassurPremiumSimulationRequest.getPackLead()) && Objects.nonNull(sehassurPremiumSimulationRequest.getPackLead().getDiseaseReimbursementCeiling()))
                       ? sehassurPremiumSimulationRequest.getPackLead().getDiseaseReimbursementCeiling() + " DHS" : "-")
                .deceaseBenefit((Objects.nonNull(sehassurPremiumSimulationRequest.getPackLead()) && Objects.nonNull(sehassurPremiumSimulationRequest.getPackLead().getDeathCapitalValue()))
                        ? sehassurPremiumSimulationRequest.getPackLead().getDeathCapitalValue() + " DHS" : "-")
                .criticalIllnessCapital((Objects.nonNull(sehassurPremiumSimulationRequest.getPackLead()) && Objects.nonNull(sehassurPremiumSimulationRequest.getPackLead().getDiseaseValue()))
                        ? sehassurPremiumSimulationRequest.getPackLead().getDiseaseValue() + " DHS" : "-")
                .numberOfPAC(sehassurPremiumSimulationRequest.getDependents().size()+"")
                .optionPremiums(sehassurOptionPremium)
                .dependents(sehassurDependent)
                .build();

        DevisSehassurPrinting devisSehassurPrinting = DevisSehassurPrinting.builder().validityDate(MapperUtils.localDateToString(LocalDate.now().plusDays(30), DEVIS_DATE_FORMAT))
        .quotationNumber(quotationId).issueDate(MapperUtils.localDateToString(LocalDate.now(), DEVIS_DATE_FORMAT)).sehassurInsured(sehassurInsured)
                .build();
        return devisSehassurPrinting;
    }

    private String getCurrentAge(LocalDate birthDate) {
        if(birthDate != null)
            return Period.between(birthDate, LocalDate.now()).getYears()+" ans";
        return 0 + "an";
    }

    public ApiMessageWrapper sendSehassurMail(String quotationId, SehassurPremiumSimulationRequest sehassurPremiumSimulationRequest) {
        Resource file = getSehassurDevis(quotationId, sehassurPremiumSimulationRequest);

        try {
            MultipartFile[] content = {new MockMultipartFile("devis.pdf", file.getFilename(), "application/pdf", file.getInputStream().readAllBytes())};
            innerNotificationProxy.sendEmail(
                    Arrays.asList(sehassurPremiumSimulationRequest.getMail()),
                    null,
                    GlobalConstants.PSI_MAIL_TEMPLATE,
                    "simulation PSI",
                    emailContentProtectionService.toTemplateVariablesJson(
                            "name", sehassurPremiumSimulationRequest.getFirstName() + " " + sehassurPremiumSimulationRequest.getLastName()),
                    psiEmail,
                    content);
        } catch (IOException e) {
            log.error("Failed to send mail");
        }
        return ApiMessageWrapper.builder().message("OK").build();
    }
}
