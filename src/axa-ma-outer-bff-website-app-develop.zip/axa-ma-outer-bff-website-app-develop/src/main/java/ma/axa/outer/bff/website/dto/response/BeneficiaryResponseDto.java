package ma.axa.outer.bff.website.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class BeneficiaryResponseDto {
    private String id;
    private String lastName;
    private String firstName;
    private String remaining;
    private BigDecimal rang;
    private BigDecimal affiliateNumber;
    private String checksum;
    
}