package ma.axa.outer.bff.website.service;

import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.dto.AbandonRequest;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.EmailDto;
import ma.axa.outer.bff.website.exception.GlobalException;
import ma.axa.outer.bff.website.mapper.EmailMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AbandonService {


    @Value("${axa.mail.abandon}")
    private String abandonEmail;

    private final InnerNotificationProxy innerNotificationProxy;

    public ApiMessageWrapper createAbandon(AbandonRequest abandonRequest) {

        EmailDto email = EmailMapper.toEmail(abandonRequest);
        email.setTo(abandonEmail);
        try {
            innerNotificationProxy.sendMail(email);
            return new ApiMessageWrapper("Email Sent");
        } catch (Exception e) {
            throw new GlobalException("Error while sending email");
        }
    }
}
