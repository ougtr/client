package ma.axa.outer.bff.website.dto.quotation;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize.Inclusion;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties
@EqualsAndHashCode(callSuper = true)
@JsonSerialize(include = Inclusion.NON_NULL)	
public class QuotationResponseMrh extends AbstractJsonResponseDto{
	 @JsonProperty("IdQuotation")
	 private BigDecimal idQuotation; 
	 private QuotationParamsMrhDto parmAvenant;
}
