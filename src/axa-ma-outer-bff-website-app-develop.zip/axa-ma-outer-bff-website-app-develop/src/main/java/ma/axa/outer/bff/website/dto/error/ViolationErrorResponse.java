package ma.axa.outer.bff.website.dto.error;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class ViolationErrorResponse extends ApiError {
	private static final long serialVersionUID = 2910692346451622362L;

	private List<ApiErrorItem> errors;
}
