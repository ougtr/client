package ma.axa.outer.bff.website.dto.quotation;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties
public class AbstractJsonResponseDto {
	    @JsonProperty("codeRetour")
	    private String retCode;
	    @JsonProperty("errors")
	    private List<ErrorDto> errors;
}
