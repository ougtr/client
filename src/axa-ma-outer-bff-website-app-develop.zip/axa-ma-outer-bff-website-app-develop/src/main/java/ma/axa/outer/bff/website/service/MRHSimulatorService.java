package ma.axa.outer.bff.website.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.outer.bff.website.client.InnerNotificationProxy;
import ma.axa.outer.bff.website.client.InnerPcProductProxy;
import ma.axa.outer.bff.website.client.InnerPrintingProxy;
import ma.axa.outer.bff.website.client.InnerQuotationProxy;
import ma.axa.outer.bff.website.client.InnerSFDCProxy;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.CapitalAssure;
import ma.axa.outer.bff.website.dto.FormuleMrhDto;
import ma.axa.outer.bff.website.dto.LeadRequestDto;
import ma.axa.outer.bff.website.dto.LeadResponseDto;
import ma.axa.outer.bff.website.dto.MRHProspectDto;
import ma.axa.outer.bff.website.dto.MRHSimulationRequestDto;
import ma.axa.outer.bff.website.dto.MRHSimulationResponseDto;
import ma.axa.outer.bff.website.dto.MRHV2ProspectDto;
import ma.axa.outer.bff.website.dto.ProspectResponseDto;
import ma.axa.outer.bff.website.dto.PublicCapitalDto;
import ma.axa.outer.bff.website.dto.RefDataResponse;
import ma.axa.outer.bff.website.dto.mrh.DevisMrhPrinting;
import ma.axa.outer.bff.website.dto.quotation.AvenantData;
import ma.axa.outer.bff.website.dto.quotation.ContratMrh;
import ma.axa.outer.bff.website.dto.quotation.MrhMinimalistSimulationResponse;
import ma.axa.outer.bff.website.dto.quotation.QuotationCouvertureMrhDto;
import ma.axa.outer.bff.website.dto.quotation.QuotationGarantiesElementsMrhDto;
import ma.axa.outer.bff.website.dto.quotation.QuotationGuarentee;
import ma.axa.outer.bff.website.dto.quotation.QuotationMrhResponse;
import ma.axa.outer.bff.website.dto.quotation.QuotationResponseMrh;
import ma.axa.outer.bff.website.dto.quotation.request.MrhMinimalistSimulationRequest;
import ma.axa.outer.bff.website.dto.quotation.request.QuotationMrhContrat;
import ma.axa.outer.bff.website.dto.quotation.request.QuotationMrhRequest;
import ma.axa.outer.bff.website.exception.GlobalException;
import ma.axa.outer.bff.website.mapper.LeadMapper;
import ma.axa.outer.bff.website.util.constants.GlobalConstants;

@Slf4j
@Service
@RequiredArgsConstructor
public class MRHSimulatorService {


    private static final Gson gson = new Gson();
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	private final InnerSFDCProxy innerSFDCProxy;
    private final InnerQuotationProxy innerQuotationProxy;
    private final InnerPcProductProxy innerPcProductProxy;
    private final InnerNotificationProxy innerNotificationProxy;
    private final InnerPrintingProxy innerPrintingProxy;
    private final EmailContentProtectionService emailContentProtectionService;
    

    @Value("${axa.mail.mrh}")
    private String mrhEmail;


    public ProspectResponseDto saveProspect(MRHProspectDto prospect) {
        LeadRequestDto request = LeadMapper.toMRHLeadRequest(prospect);
        LeadResponseDto leadResponseDto = innerSFDCProxy.createLead(request).getBody();
        if(leadResponseDto != null)
            return new ProspectResponseDto(leadResponseDto.getId());
        return null;
    }

    public ProspectResponseDto updateProspect(MRHProspectDto prospect) {
        if(prospect.getLeadId() == null)
            throw new GlobalException("Lead Id cannot be null");
        LeadRequestDto request = LeadMapper.toMRHLeadRequest(prospect);
        request.setStatus("Sélectionné");
        request.setLeadSource("Simulateur");
        LeadResponseDto leadResponseDto = innerSFDCProxy.updateLead(request, prospect.getLeadId()).getBody();
        if(leadResponseDto != null)
            return new ProspectResponseDto(leadResponseDto.getId());
        return null;
    }

    public MRHSimulationResponseDto getMRHSimulation(MRHSimulationRequestDto mrhSimulationRequestDto) {
        MRHSimulationResponseDto mrhSimulationResponseDto = innerQuotationProxy.getSimulation(mrhSimulationRequestDto).getBody();
        LeadRequestDto request = LeadMapper.toMRHLeadRequest(mrhSimulationRequestDto, mrhSimulationResponseDto);
        LeadResponseDto leadResponseDto = innerSFDCProxy.updateLead(request, mrhSimulationRequestDto.getLeadId()).getBody();
        return mrhSimulationResponseDto;
    }

    public List<PublicCapitalDto> getMRHCapitalList() {
        return innerQuotationProxy.getMRHCapitalList().getBody();
    }
    
    public ProspectResponseDto saveProspectV2(MRHV2ProspectDto prospect) {
        LeadRequestDto request = LeadMapper.toMRHV2LeadRequest(prospect);
        LeadResponseDto leadResponseDto = innerSFDCProxy.createLead(request).getBody();
        if(leadResponseDto != null)
            return new ProspectResponseDto(leadResponseDto.getId());
        return null;
    }
    
    public ProspectResponseDto updateProspectV2(MRHV2ProspectDto prospect) {
        if(prospect == null )
            throw new GlobalException("Lead Id cannot be null");
        if(StringUtils.isBlank(prospect.getLeadId()))
        	return saveProspectV2(prospect);
        LeadRequestDto request = LeadMapper.toMRHV2LeadRequest(prospect);
        request.setStatus("Sélectionné");
        request.setLeadSource("Simulateur");
        LeadResponseDto leadResponseDto = innerSFDCProxy.updateLead(request, prospect.getLeadId()).getBody();
        if(leadResponseDto != null)
            return new ProspectResponseDto(leadResponseDto.getId());
        return null;
    }
    
    
    public List<RefDataResponse> getTypeHabitations() {
        return innerPcProductProxy.getTypeHabitations(GlobalConstants.MRH_PRODUCT_CODE).getBody();
    }
    
    public List<RefDataResponse> getTypeOccupants() {
        return innerPcProductProxy.getTypeOccupants(GlobalConstants.MRH_PRODUCT_CODE).getBody();
    }
    
    public QuotationCouvertureMrhDto getGaranties(BigDecimal capital) {
    	 return Optional.ofNullable(innerQuotationProxy.getGaranties(capital, 
    		        LocalDate.now().format(DATE_FORMAT), ""))
    		        .map(response -> response.getBody())
    		        .map(QuotationMrhContrat::getQuotationCouvert)
    		        .orElse(null);  

    }
    
    public QuotationResponseMrh createMrhQuotation( QuotationMrhRequest quotationRequest) {
        return  innerQuotationProxy.createQuotation(quotationRequest).getBody();
    }
    

    public MrhMinimalistSimulationResponse tarification(MrhMinimalistSimulationRequest request) {
    	MrhMinimalistSimulationResponse response = null;
        if (request == null) {
            throw new IllegalArgumentException("Request cannot be null");
        }

        try {
            ContratMrh contratMrh = buildContratMrh(request);
            AvenantData avenant = AvenantData.builder().intermediaryCode("708").utilisateur("").isAgent("N").step(0).build();

            QuotationMrhRequest quotationRequest = QuotationMrhRequest.builder()
                    .contrat(contratMrh)
                    .avenant(avenant)
                    .build();

            logDebug(gson.toJson(quotationRequest));

            QuotationResponseMrh quotationCreated = createQuotationRequest(request, quotationRequest);
            if (quotationCreated!=null && "OK".equals(quotationCreated.getRetCode())) {
                QuotationMrhResponse  primeCalculated  = calculateFinalQuotation(quotationCreated, request, contratMrh);
                try {
         			response = MrhMinimalistSimulationResponse.fromRequest(request);
         			response.setIdQuotation(quotationCreated.getIdQuotation());
         			BigDecimal annualPrice = (primeCalculated!=null && primeCalculated.getPrimesTotals()!=null) ?  primeCalculated.getPrimesTotals().getAnnualPrice() : new BigDecimal(0);
					response.setAnnualPrice(annualPrice);
					request.getMrhProspect().setPrime(annualPrice);
					populateMrhProspectFromSimulation(request);
         			updateProspectV2(request.getMrhProspect());
         		} catch (Exception e1) {
         			 logError("An error occurred during creating Lead", e1);
         		}
                return response;
            }
        } catch (Exception e) {
            logError("An error occurred during tarification", e);
            throw e;
        }
        return null;
    }
    private void populateMrhProspectFromSimulation(MrhMinimalistSimulationRequest request) {
    	
    	request.getMrhProspect().setPropertyNature("P".equalsIgnoreCase(request.getNatureHabitation() )? "Principale" : "Secondaire");
    	request.getMrhProspect().setInsuredValue(request.getValeurBatiment());
    	request.getMrhProspect().setInsuredContentValue(request.getValeurContenu());
    	
    	
    	List<RefDataResponse> typesOccuppants = getTypeOccupants();
    	
    	try {
			Optional<RefDataResponse> targetObject = typesOccuppants.stream()
				    .filter(occupant -> occupant.getCode().trim().equals(request.getTypeOccupant().trim()))
				    .findFirst(); 
			if (targetObject.isPresent()) {
			   request.getMrhProspect().setOwner(targetObject.get().getLabel());
			}
			
		} catch (Exception e) {
			 logError("An error occurred during get Type Occupant", e);
		}
    	
    	
    	List<RefDataResponse> typesHabs = getTypeHabitations();
    	
    	try {
			Optional<RefDataResponse> targetTypesHab = typesHabs.stream()
				    .filter(typesHab -> typesHab.getCode().trim().equals(request.getTypeHabitation().trim()))
				    .findFirst(); 
			if (targetTypesHab.isPresent()) {
				request.getMrhProspect().setPropertyType(targetTypesHab.get().getLabel());
			}
		} catch (Exception e) {
			 logError("An error occurred during get Type Habitation", e);
		}
    	
        //"propertyType": "villa", /**'1,Appartement','2,Maison','3,Villa','4,Bungalow','5,Duplex','6,Riad'*/
    }
    

    private ContratMrh buildContratMrh(MrhMinimalistSimulationRequest request) {
        return ContratMrh.builder()
                .effectDate(LocalDate.now().format(DATE_FORMAT))
                .expirationDate(LocalDate.now().plusYears(1).format(DATE_FORMAT))
                .anniversaryDate(LocalDate.now().plusYears(1).format(DATE_FORMAT))
                .natureHabitation(request.getNatureHabitation())
                .typeHabitation(request.getTypeHabitation())
                .typeOccupant(request.getTypeOccupant())
                .adresseRisque("")
                .localite("")
                .ville(GlobalConstants._780)
                .pays(GlobalConstants._212)
                .hasContratAuto(false)
                .numPoliceAuto(BigDecimal.ZERO)
                .build();
    }

    private QuotationResponseMrh createQuotationRequest(MrhMinimalistSimulationRequest request, QuotationMrhRequest quotationRequest) {
        if (request.getIdQuotation()==null) {
            return innerQuotationProxy.createQuotation(quotationRequest).getBody();
        } else {
            return QuotationResponseMrh.builder()
                    .idQuotation(request.getIdQuotation())
                    .retCode("OK")
                    .build();
        }
    }

    private QuotationMrhResponse calculateFinalQuotation(QuotationResponseMrh response, MrhMinimalistSimulationRequest request, ContratMrh contratMrh) {
        BigDecimal valeurBatiment = new BigDecimal(request.getValeurBatiment());
        BigDecimal valeurContenu = new BigDecimal(request.getValeurContenu());
        BigDecimal valeurObject = valeurContenu.divide(new BigDecimal(5));



        QuotationCouvertureMrhDto quotationCouvertureMrhDto = Optional.ofNullable(innerQuotationProxy.getGaranties(valeurBatiment, contratMrh.getEffectDate(), ""))
                .map(responseEntity -> responseEntity.getBody())
                .map(QuotationMrhContrat::getQuotationCouvert)
                .orElse(null);  // Or return a default value
        
        
        quotationCouvertureMrhDto = updateSelectedOptionnelGuarantees(quotationCouvertureMrhDto, request.getOptionnelGarantiesId());

        QuotationMrhRequest requestMrh = QuotationMrhRequest.builder()
                .capitalAssure(CapitalAssure.builder().valeurBatiment(valeurBatiment)
                        .valeurContenu(valeurContenu)
                        .valeurObject(valeurObject)
                        .build())
                .contrat(contratMrh)
                .avenant(AvenantData.builder().intermediaryCode("0").build())
                .quotationCouvert(QuotationCouvertureMrhDto.builder().pack(quotationCouvertureMrhDto.getPack()).build())
                .build();

        requestMrh.setIdQuotation(response.getIdQuotation());

        logDebug(gson.toJson(requestMrh));
        return innerQuotationProxy.calculePrimeMrh(response.getIdQuotation(), requestMrh).getBody();
    }

    private void logDebug(String message) {
        log.debug(message);
    }

    private void logError(String message, Throwable e) {
        log.error(message,e);
    }
    
    
    public QuotationCouvertureMrhDto updateSelectedOptionnelGuarantees(QuotationCouvertureMrhDto  quotationCouvertureMrhDto , List<String> codes) {
    	List<QuotationGuarentee> guarantees = quotationCouvertureMrhDto.getPack().getGaranties();
        for (QuotationGuarentee guarantee : guarantees) {
            if (codes.contains(guarantee.getCode())) {
                guarantee.setChecked(true);  

                if (CollectionUtils.isNotEmpty(guarantee.getTechnicalElements())) {
                    QuotationGarantiesElementsMrhDto firstElement = guarantee.getTechnicalElements().get(0);
                    if ( CollectionUtils.isNotEmpty(firstElement.getFormules())  ) {
                        FormuleMrhDto firstFormule = firstElement.getFormules().get(0);
                        if (Boolean.FALSE.equals(firstFormule.getDisabled())) {  
                            firstFormule.setChecked(true);
                        }
                    }
                }
            }
        }
        return quotationCouvertureMrhDto;
    }
    
    
    public ApiMessageWrapper sendMrhDevisMail( MrhMinimalistSimulationRequest request) {
        Resource file = getMRHDevis(request);
        try {
			String fileName = "Devis-MRH-"+request.getIdQuotation() +".pdf";
			MultipartFile[] content = {new MockMultipartFile(fileName, fileName, "application/pdf", file.getInputStream().readAllBytes())};
            innerNotificationProxy.sendEmail(Arrays.asList(request.getMrhProspect().getEmailAddress()), null,
                    GlobalConstants.PSI_MAIL_TEMPLATE_MRH, "Votre devis d'assurance multirisque habitation « Habit’Assur »", emailContentProtectionService.toTemplateVariablesJson("name", request.getMrhProspect().getFirstName() + " " + request.getMrhProspect().getLastName()), mrhEmail, content);
        } catch (IOException e) {
            log.error("Failed to send mail");
        }
        return ApiMessageWrapper.builder().message("OK").build();
    }
    
    public Resource getMRHDevis(MrhMinimalistSimulationRequest request) {
    	
    	if (Objects.isNull(request.getMrhProspect()) || Objects.isNull(request.getValeurBatiment())  || Objects.isNull(request.getIdQuotation()))
            throw new GlobalException("check mandatory fields");
    	
    	populateMrhProspectFromSimulation(request);
    	
    	BigDecimal valeurBatiment = new BigDecimal(request.getValeurBatiment());
    	QuotationCouvertureMrhDto quotationCouvertureMrhDto = getGaranties(valeurBatiment);
    	
    	List<QuotationGuarentee> garantiesBases =  getGarantiesBases (quotationCouvertureMrhDto);
    	List<QuotationGuarentee> garantiesOptionnels  = getSelectedGarantiesOptionnels(quotationCouvertureMrhDto, request.getOptionnelGarantiesId());
    	
        
        DevisMrhPrinting input = DevisMrhPrinting.builder()
        		.prime(ma.axa.outer.bff.website.util.StringUtils.bigDecimalFormatting(request.getPrime()))
        		.mrhProspect(request.getMrhProspect())
        		.garantiesBases(garantiesBases)
        		.garantiesOptionnels(garantiesOptionnels)
        		.issueDate(LocalDate.now().format(DATE_FORMAT))
        		.quotationNumber(request.getIdQuotation().toPlainString())
        		.build() ;
        input.getMrhProspect().setInsuredValue(ma.axa.outer.bff.website.util.StringUtils.bigDecimalFormatting(input.getMrhProspect().getInsuredValue() ));
        input.getMrhProspect().setInsuredContentValue(ma.axa.outer.bff.website.util.StringUtils.bigDecimalFormatting(input.getMrhProspect().getInsuredContentValue() ));
        return innerPrintingProxy.printMrhDevis(input).getBody();
    }
    
    
    public List<QuotationGuarentee> getGarantiesBases( QuotationCouvertureMrhDto quotationCouvertureMrhDto ) {
    	try {
			List<QuotationGuarentee> garanties = quotationCouvertureMrhDto.getPack().getGaranties();
			return garanties.stream()
			                .filter(guarantee -> guarantee.isDisabled())
			                .collect(Collectors.toList());
		} catch (Exception e) {
			 log.error("aucune garantie de base  trouvée",e);
		}
		return null;
    }
    
    
    public List<QuotationGuarentee> getSelectedGarantiesOptionnels(QuotationCouvertureMrhDto quotationCouvertureMrhDto, List<String> codes) {
    	
    	try {
			List<QuotationGuarentee> garanties = quotationCouvertureMrhDto.getPack().getGaranties();
			return garanties.stream()
			                .filter(guarantee -> codes.contains(guarantee.getCode()))
			                .collect(Collectors.toList());
		} catch (Exception e) {
			 log.error("aucune garantie oprtionnelle trouvée",e);
		}
		return null;
    }
    
    
   
}
