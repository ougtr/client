package ma.axa.outer.bff.website.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LeadRequestDto {

    private String firstName;
    private String lastName;
    private String phone;
    private String company;
    private String leadSource;
    private Boolean callMeBack;
    private String email;
    private String description;
    private String city;
    private String productCode;
    private Boolean isSimulator;
    private String status;
    private Boolean coveredInUSA;
    private Boolean liveInMorocco;
    private String birthDate;

    private String salutation;
    private String title;
    private String street;
    private String state;
    private String postalCode;
    private String country;
    private String latitude;
    private String longitude;
    private String geocodeAccuracy;
    private String website;
    private String industry;

    private String formula;
    private String periodicity;
    private Boolean hasPAC;
    private String pac;
    /*** PSI ***/
    private String franchise;
    private double quarterlyPremium;
    private double annualPremium;
    /*** PSI ***/
    /*** SEHASSUR ***/
    private double reimbursementRate;
    private String reimbursementBase;
    private double deceaseGuaranty;
    private String diseaseGuaranty;
    private Boolean prelevement;
    private double premiumTTC;
    private String deceaseSpouseGuaranty;
    private String includeDeceaseSpouseGuaranty;
    /*** SEHASSUR ***/
    /*** MRH ***/
    private String jeSuis;
    private String natureDuBien;
    private String typeDuBien;
    private String valeurAssuree;
    private BigDecimal valeurDuBien;
    private BigDecimal valeurDuMobilier;
    private BigDecimal objetDeValeur;
    private BigDecimal primeSimulation;
    /*** MRH ***/
    /*** AUTO ***/
    private String ville;
    private String cin;
    private String dateObtentionPermis;
    private String marqueVehicule;
    private String typeCarburant;
    private String puissanceFiscale;
    private String dateMiseEnCirculation;
    private int nombrePlace;
    private double valeurNeuf;
    private double valeurVenale;
    private String immatriculation;
    private String intermediaryCode;
    private String pack;
    private String garantie;
     private BigDecimal prime;
    /*** AUTO ***/
    private Boolean marketingConsent;
    private Boolean cguConsent;
    
}