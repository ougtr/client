package ma.axa.outer.bff.website.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class InnerOTPRequestDto {

    private String phoneNumber;
    private int expirationTimeInSeconds;
}
