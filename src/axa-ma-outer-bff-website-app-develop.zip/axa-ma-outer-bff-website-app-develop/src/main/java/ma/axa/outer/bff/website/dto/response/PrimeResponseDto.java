package ma.axa.outer.bff.website.dto.response;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class PrimeResponseDto extends PrimeDto{
    private String GuaranteeLabel;
}
