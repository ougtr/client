package ma.axa.outer.bff.website.service;

import ma.axa.outer.bff.website.exception.InvalidSignedTokenException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@Service
public class QuotationAccessTokenService {
    private static final String HMAC_SHA_256 = "HmacSHA256";
    private static final String PSI_QUOTATION_SCOPE = "psi:quotation:access";
    private static final String SEHASSUR_QUOTATION_SCOPE = "sehassur:quotation:access";
    private static final String GREEN_CARD_QUOTATION_SCOPE = "green-card:quotation:payment";
    private static final String SCOPE = "scope";
    private static final String QUOTATION_ID = "quotationId";
    private static final String EXPIRES_AT = "expiresAt";

    @Value("${axa.signature.secret-key:change-me}")
    private String secretKey;

    @Value("${axa.signature.expiration-duration:300}")
    private long expirationDurationInSeconds;

    public String generateHealthQuotationToken(String quotationId) {
        return generateToken(quotationId, PSI_QUOTATION_SCOPE);
    }

    public String generateSehassurQuotationToken(String quotationId) {
        return generateToken(quotationId, SEHASSUR_QUOTATION_SCOPE);
    }

    public String generateGreenCardQuotationToken(String quotationId) {
        return generateToken(quotationId, GREEN_CARD_QUOTATION_SCOPE);
    }

    public String extractHealthQuotationId(String token) {
        SignedPayload payload = decodeAndValidate(token, PSI_QUOTATION_SCOPE);
        return payload.quotationId;
    }

    public String extractSehassurQuotationId(String token) {
        SignedPayload payload = decodeAndValidate(token, SEHASSUR_QUOTATION_SCOPE);
        return payload.quotationId;
    }

    public String extractGreenCardQuotationId(String token) {
        SignedPayload payload = decodeAndValidate(token, GREEN_CARD_QUOTATION_SCOPE);
        return payload.quotationId;
    }

    private String generateToken(String quotationId, String scope) {
        long expiresAt = System.currentTimeMillis() + expirationDurationInSeconds * 1000;
        String payload = String.join("\n",
                SCOPE + "=" + scope,
                QUOTATION_ID + "=" + quotationId,
                EXPIRES_AT + "=" + expiresAt);
        String encodedPayload = Base64.getUrlEncoder().withoutPadding()
                .encodeToString(payload.getBytes(StandardCharsets.UTF_8));
        return encodedPayload + "." + sign(encodedPayload);
    }

    private SignedPayload decodeAndValidate(String token, String expectedScope) {
        if (StringUtils.isBlank(token) || StringUtils.countMatches(token, '.') != 1) {
            throw new InvalidSignedTokenException("Invalid signed token");
        }

        String[] tokenParts = token.split("\\.", 2);
        String encodedPayload = tokenParts[0];
        String providedSignature = tokenParts[1];
        String expectedSignature = sign(encodedPayload);

        if (!MessageDigest.isEqual(
                expectedSignature.getBytes(StandardCharsets.UTF_8),
                providedSignature.getBytes(StandardCharsets.UTF_8))) {
            throw new InvalidSignedTokenException("Invalid signed token");
        }

        Map<String, String> tokenContent = parseTokenContent(encodedPayload);
        String scope = tokenContent.get(SCOPE);
        String quotationId = tokenContent.get(QUOTATION_ID);
        String expiresAt = tokenContent.get(EXPIRES_AT);

        if (!StringUtils.equals(expectedScope, scope)
                || StringUtils.isBlank(quotationId)
                || StringUtils.isBlank(expiresAt)) {
            throw new InvalidSignedTokenException("Invalid signed token");
        }

        long expirationDate;
        try {
            expirationDate = Long.parseLong(expiresAt);
        } catch (NumberFormatException exception) {
            throw new InvalidSignedTokenException("Invalid signed token");
        }

        if (expirationDate < System.currentTimeMillis()) {
            throw new InvalidSignedTokenException("Expired signed token");
        }

        return new SignedPayload(quotationId, expirationDate);
    }

    private Map<String, String> parseTokenContent(String encodedPayload) {
        try {
            String decodedPayload = new String(
                    Base64.getUrlDecoder().decode(encodedPayload),
                    StandardCharsets.UTF_8);
            Map<String, String> tokenContent = new HashMap<>();
            for (String line : decodedPayload.split("\n")) {
                String[] keyValue = line.split("=", 2);
                if (keyValue.length == 2) {
                    tokenContent.put(keyValue[0], keyValue[1]);
                }
            }
            return tokenContent;
        } catch (IllegalArgumentException exception) {
            throw new InvalidSignedTokenException("Invalid signed token");
        }
    }

    private String sign(String encodedPayload) {
        try {
            Mac mac = Mac.getInstance(HMAC_SHA_256);
            mac.init(new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), HMAC_SHA_256));
            byte[] signature = mac.doFinal(encodedPayload.getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(signature);
        } catch (NoSuchAlgorithmException | InvalidKeyException exception) {
            throw new InvalidSignedTokenException("Unable to sign token");
        }
    }

    private static final class SignedPayload {
        private final String quotationId;
        private final long expiresAt;

        private SignedPayload(String quotationId, long expiresAt) {
            this.quotationId = quotationId;
            this.expiresAt = expiresAt;
        }
    }
}
