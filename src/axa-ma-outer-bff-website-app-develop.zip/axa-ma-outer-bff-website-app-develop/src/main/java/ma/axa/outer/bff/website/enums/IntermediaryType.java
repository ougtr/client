package ma.axa.outer.bff.website.enums;

public enum IntermediaryType {
    A,
    B,
    C
}
