package ma.axa.outer.bff.website.api;

import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.dto.request.AllQuotationsDto;
import ma.axa.outer.bff.website.dto.request.Devis;
import ma.axa.outer.bff.website.dto.request.QuotationDto;
import ma.axa.outer.bff.website.dto.response.DevisResponse;
import ma.axa.outer.bff.website.dto.response.PrimeDto;
import ma.axa.outer.bff.website.service.QuotationService;
import ma.axa.outer.bff.website.util.Paths;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping(Paths.QUOTATION_WEB_SITE)
@RequiredArgsConstructor
@Validated
public class QuotationApi {
    private final QuotationService quotationService;

    @PostMapping(produces = {"application/json"})
    public ResponseEntity<List<PrimeDto>> createQuotation(@RequestBody AllQuotationsDto quotationDto) {
        return new ResponseEntity<>(quotationService.createQuotation(quotationDto), HttpStatus.OK);
    }
    @PutMapping(path = "/{idQuotation}", produces = {"application/json"})
    public ResponseEntity<PrimeDto> updateQuotation(@Valid @RequestBody QuotationDto input,
                                                    @PathVariable(name = "idQuotation", required = true) BigDecimal idQuotation) {
        return new ResponseEntity<>(quotationService.updateQuotation(input, idQuotation), HttpStatus.OK);
    }

    @PostMapping(path="/{idQuotation}/validate" ,produces = {"application/json"})
    public ResponseEntity<DevisResponse> validerQuotation(@Valid @RequestBody(required = true) Devis devis,
                                                          @NotNull(message = "{error.v1.quotation.idQuotation}")
                                                          @Parameter(description = "Id quotation")
                                                          @PathVariable(name = "idQuotation",required = true) BigDecimal idQuotation)  {
        return new ResponseEntity<>(quotationService.validerQuotation(devis,idQuotation),HttpStatus.OK);
    }
}
