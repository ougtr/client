package ma.axa.outer.bff.website.validator;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Payload;

@Target({ TYPE, FIELD, ANNOTATION_TYPE })
@Retention(RUNTIME)
@Documented
public @interface CustomConverter {
	  String message() default "Format invalid";
	  Class <?> [] groups() default {};
	  Class <? extends Payload> [] payload() default {};
	  String nameConverter() ;
	  String pattern() default "dd-MM-yyyy";
}
