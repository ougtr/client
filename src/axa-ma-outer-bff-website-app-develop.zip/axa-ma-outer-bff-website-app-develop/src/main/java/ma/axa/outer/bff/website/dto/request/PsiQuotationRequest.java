package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PsiQuotationRequest {
    private String productCode;
    private String intermediaryCode;
    private String firstName;
    private String lastName;
    private BigDecimal birthDate;
    private BigDecimal effectDate;
    private String address;
    private String secondAddress;
    private String country;
    private String city;
    private String phoneNumber;
    private String optionCode;
    private String franchiseCode;
    private String repaymentRate;
    private String fraction;
    private String reimbBase;
    private String disease;
    private String crtFlg;
    private String anteriority;
    private String userCreation;
}
