package ma.axa.outer.bff.website.config;

import lombok.*;
import ma.axa.outer.bff.website.dto.RefDataResponse;
import ma.axa.outer.bff.website.dto.request.OptionDetails;
import ma.axa.outer.bff.website.dto.request.OptionSehassurDetails;
import ma.axa.outer.bff.website.dto.response.AssitanceRefDto;
import ma.axa.outer.bff.website.dto.response.FuelDto;
import ma.axa.outer.bff.website.dto.response.GuaranteesDto;
import ma.axa.outer.bff.website.dto.response.PacksDto;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@PropertySource(value = "classpath:data.json",
        factory = JsonPropertySourceFactory.class)
@ConfigurationProperties
@AllArgsConstructor
@NoArgsConstructor
@Data
public class JsonProperties {
    private List<PacksDto> assistance;
    private List<AssitanceRefDto> assistanceHeaders;
    private List<FuelDto> fuel;
    private List<GuaranteesDto> guaranteesPacks;
    private List<OptionDetails>  healthProductOptions;
    private List<OptionSehassurDetails> sehassurProductOptionsDetails;

}
