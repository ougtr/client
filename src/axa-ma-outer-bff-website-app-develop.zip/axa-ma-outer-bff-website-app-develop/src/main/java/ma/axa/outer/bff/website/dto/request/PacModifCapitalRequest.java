package ma.axa.outer.bff.website.dto.request;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.beans.factory.annotation.Value;

@Data
@SuperBuilder
@NoArgsConstructor
public class PacModifCapitalRequest {
    private String nom;
    private String prenom;
    private String flagControl;
    private String capitalDeces;
}

