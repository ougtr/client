package ma.axa.outer.bff.website.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotNull;
@Data
@SuperBuilder
@NoArgsConstructor
public class RenewalContractValidationInput {
    @NotNull(message = "idQuotation est obligatoire")
    private String idQuotation;
    @JsonIgnore
    //@NotNull(message = "paymentMode est obligatoire")
    private String paymentMode;
    @JsonIgnore
    //@NotNull(message = "shippingMode est obligatoire")
    private String shippingMode;
    @JsonIgnore
    //@NotNull(message = "shippingAddress est obligatoire")
    private String shippingAddress;
    @JsonIgnore
    //@NotNull(message = "shippingCity est obligatoire")
    private String shippingCity;
    @JsonIgnore
    //@NotNull(message = "phoneNumber est obligatoire")
    private String phoneNumber;
}
