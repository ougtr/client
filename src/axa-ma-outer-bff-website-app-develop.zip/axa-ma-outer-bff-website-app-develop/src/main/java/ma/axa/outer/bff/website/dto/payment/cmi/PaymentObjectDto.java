package ma.axa.outer.bff.website.dto.payment.cmi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.outer.bff.website.enums.PaymentStatus;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentObjectDto {
    private String orderId ;
    private String tokenRef ;
    private PaymentStatus status ;
    private String  qrcode ;
    private String paymentLink ;
    private List<PaymentExtraDataDto>  extraData ;
    private PaymentFees fees  ;
}
