package ma.axa.outer.bff.website.client.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.security.oauth2.client.AuthorizedClientServiceOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProviderBuilder;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.endpoint.DefaultClientCredentialsTokenResponseClient;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;

import feign.RequestInterceptor;
import feign.Retryer;
import feign.codec.ErrorDecoder;
import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.util.constants.GlobalConstants;

import java.time.Duration;

@Configuration
@EnableFeignClients(basePackages = "ma.axa.outer.bff.website.client")
@RequiredArgsConstructor
public class InnerClientConfig {
	
	private final OAuth2AuthorizedClientService oAuth2AuthorizedClientService;
	private final ClientRegistrationRepository clientRegistrationRepository;
	@Value("${axa.client.security.clock.skew.duration:300}")
	private int clockSkewDuration;

	@Bean
	RequestInterceptor jwtRequestInterceptor() {
		var clientRegistration = clientRegistrationRepository.findByRegistrationId("adfs");
		var oAuthClientAdfsManager = new OAuthClientAdfsManager(authorizedClientManager(), clientRegistration);
		return template -> template.header(HttpHeaders.AUTHORIZATION, GlobalConstants.HEADER_BEARER + oAuthClientAdfsManager.getAccessToken());
	}

	@Bean
	public Retryer retryer() {
		return new InnerAPIRetryer();
	}

	@Bean
	public ErrorDecoder errorDecoder() {
		return new InnerErrorDecoder();
	}

	@Bean
	@ConditionalOnMissingBean
	OAuth2AuthorizedClientManager authorizedClientManager() {
		var tokenResponseClient = new DefaultClientCredentialsTokenResponseClient();
		var authorizedClientProvider = OAuth2AuthorizedClientProviderBuilder.builder()
				.clientCredentials(c -> c.accessTokenResponseClient(tokenResponseClient).clockSkew(Duration.ofSeconds(clockSkewDuration)))
				.build();
		var authorizedClientManager = new AuthorizedClientServiceOAuth2AuthorizedClientManager(clientRegistrationRepository, oAuth2AuthorizedClientService);
		authorizedClientManager.setAuthorizedClientProvider(authorizedClientProvider);
		return authorizedClientManager;
	}
}
