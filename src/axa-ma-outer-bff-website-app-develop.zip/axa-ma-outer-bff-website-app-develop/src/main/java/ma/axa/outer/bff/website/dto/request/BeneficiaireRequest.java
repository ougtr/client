package ma.axa.outer.bff.website.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Builder;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
public class BeneficiaireRequest {

	private String dateNaissance;
	
	private BigDecimal numAffilie;
	
	@Length(min = 3,max = 3,message = "la longueur doit être 3 caracteres ")
	private String police1;
	
	@Length(min = 6,max = 6,message = "la longueur doit être 6 caracteres ")
	private String police2;
	
	@Length(min = 5,message = "la longueur doit être au min 5 caracteres ")
	private String cin;
	
	private String cnss;
 
	private BigDecimal prestation;

 
}
