package ma.axa.outer.bff.website.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class RenewalGuarantee {
    private String order;
    private String code;
    private String label;
    private String franchiseRate;
    private String minFranchise;
    private String capital;
}
