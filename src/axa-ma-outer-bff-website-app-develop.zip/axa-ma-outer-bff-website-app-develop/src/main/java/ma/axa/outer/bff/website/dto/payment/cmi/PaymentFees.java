package ma.axa.outer.bff.website.dto.payment.cmi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentFees {
    private BigDecimal stampFeesAmount ;
    private BigDecimal clientFeesAmount ;
}
