package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;
import java.util.List;
@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PsiPremiumSimulationRequest {
    private String firstName;
    private String lastName;
    private LocalDate birthDate;
    private String phoneNumber;
    private String mail;
    private String city;
    private String cityLabel;
    private List<DependentsPeopleRequestDto> dependents;
    private PsiSimulationPackRequest pack;
    private String idLead;
    private Boolean marketingConsent;
    private Boolean cguConsent;

}