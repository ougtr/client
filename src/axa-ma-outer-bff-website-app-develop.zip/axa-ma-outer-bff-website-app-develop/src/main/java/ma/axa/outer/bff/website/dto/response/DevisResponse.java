package ma.axa.outer.bff.website.dto.response;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Data
@SuperBuilder
@NoArgsConstructor
public class DevisResponse {
    private BigDecimal numeroDevis;
}
