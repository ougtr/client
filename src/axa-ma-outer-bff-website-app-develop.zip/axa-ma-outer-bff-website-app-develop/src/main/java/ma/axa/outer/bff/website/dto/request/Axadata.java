package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Axadata {


    private BigDecimal idQuotation;

    private BigDecimal codeIntermediaire;

    private Integer codeProduit;

    private BigDecimal numeroPolice = BigDecimal.ZERO;

    private Integer typeAvenant;

    private Integer sousAvenant;

    private String dateEffet;

    private String typeContrat;

    private String modePaiement;

    private String dateEcheance;

    private String dateExpiration;

    private Character typePersonne;

    private Character assureEstConducteur;

    private String identifiant;

    private String dateNaissanceConducteur;

    private Character isFonctionnaire;

    private Integer codeConvention;
    private String channel ="ASA" ;
    private String intermediaireName ;
}
