package ma.axa.outer.bff.website.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;

@Configuration
public class OpenApiConfig {

	@Bean
	public OpenAPI springShopOpenAPI(@Value("${axa.docs.version}") String version) {
		return new OpenAPI().info(apiInfo(version));
	}

	private static Info apiInfo(String version) {
		return new Info().title("AXA Partners APIs")
				.description("Outer api as BFF for axa website")
				.version(version)
				.termsOfService("https://www.axa.ma/mentions-legales");
	}
}
