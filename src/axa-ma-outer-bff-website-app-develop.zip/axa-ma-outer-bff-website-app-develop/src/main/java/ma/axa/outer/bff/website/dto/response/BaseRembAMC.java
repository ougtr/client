package ma.axa.outer.bff.website.dto.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BaseRembAMC {
    private String code;
    private String libelle;
    private Double base;
}
