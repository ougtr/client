package ma.axa.outer.bff.website.enums;

public enum PaymentProvider {
    CMI
}
