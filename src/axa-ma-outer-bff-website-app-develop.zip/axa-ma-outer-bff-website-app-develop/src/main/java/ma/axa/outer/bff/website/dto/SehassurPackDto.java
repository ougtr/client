package ma.axa.outer.bff.website.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SehassurPackDto {
    private String packCode;
    private String rembRate;
    private String rembBase;
    private String deathCapital;
    private String fraction;
}
