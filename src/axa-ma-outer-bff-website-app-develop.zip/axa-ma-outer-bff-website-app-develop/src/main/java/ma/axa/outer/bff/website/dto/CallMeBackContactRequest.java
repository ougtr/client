package ma.axa.outer.bff.website.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CallMeBackContactRequest {

    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String emailAddress;
    private String subject;
    private String message;
    private String callHour;
    private String callDate;

}
