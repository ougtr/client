package ma.axa.outer.bff.website.config.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import ma.axa.outer.bff.website.dto.error.ApiError;
import ma.axa.outer.bff.website.util.constants.GlobalConstants;
import org.slf4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.web.util.UrlPathHelper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@Slf4j
public class SecurityAccessDeniedHandler implements AccessDeniedHandler {

    private final UrlPathHelper urlPathHelper = new UrlPathHelper();

    static PrintWriter getPrintWriter(HttpServletRequest request, HttpServletResponse response, Throwable cause, String message2, Logger log) throws IOException {
        String message;
        if (cause != null) {
            message = cause.getMessage();
        } else {
            message = message2;
        }
        log.warn(message + ": " + request.getMethod() + " "
                + request.getRequestURI());
        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        return response.getWriter();
    }

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response,
                       AccessDeniedException accessDeniedException)
            throws IOException {
        PrintWriter out = getPrintWriter(request, response, accessDeniedException.getCause(), accessDeniedException.getMessage(), log);
        var apiError = ApiError.builder().type(GlobalConstants.URI_DEFAULT)
                .title(HttpStatus.FORBIDDEN.getReasonPhrase())
                .status(HttpStatus.FORBIDDEN.value())
                .detail("Access to this resource is denied")
                .instance(urlPathHelper.getPathWithinApplication(request))
                .build();
        var jsonRes = new ObjectMapper().writeValueAsString(apiError);
        out.print(jsonRes);
        out.flush();
    }

}
