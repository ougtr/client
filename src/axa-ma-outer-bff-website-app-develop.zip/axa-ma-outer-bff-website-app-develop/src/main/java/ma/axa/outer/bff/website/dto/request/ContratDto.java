package ma.axa.outer.bff.website.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;


@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class ContratDto extends Axadata {
    @JsonIgnore
    @Builder.Default
    private Integer nombreFraction = BigDecimal.ONE.precision();
    private String typeFractionnement;
    private Character newClient;
    private String nom;
    private String prenom;
    private String raisonSociale;
    private String dateNaissanceAssure;
    private Character joker;
    private Integer tauxReduction;
    @JsonProperty
    public Integer getNombreFraction() {
        return nombreFraction;
    }
    @JsonIgnore
    public void setNombreFraction(Integer nombreFraction) {
        this.nombreFraction = nombreFraction;
    }
}
