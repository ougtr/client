package ma.axa.outer.bff.website.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
public class RenewalDataResponseDto {
    private String idQuotation;
    private RenewalContract contractInfos;
    private RenewalVehicle vehicleInfos;
    private RenewalPersonInfos subscriberInfos;
    private List<RenewalGuarantee> guaranteesList;
    private RenewalAssistance assistancePack;
    private IntermediariesDto intermediaryInfos;
    private String autoPrime;
}
