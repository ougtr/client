package ma.axa.outer.bff.website.api;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.captcha.ICaptchaService;
import ma.axa.outer.bff.website.dto.ApiMessageWrapper;
import ma.axa.outer.bff.website.dto.MRHProspectDto;
import ma.axa.outer.bff.website.dto.MRHSimulationRequestDto;
import ma.axa.outer.bff.website.dto.MRHSimulationResponseDto;
import ma.axa.outer.bff.website.dto.MRHV2ProspectDto;
import ma.axa.outer.bff.website.dto.ProspectResponseDto;
import ma.axa.outer.bff.website.dto.PublicCapitalDto;
import ma.axa.outer.bff.website.dto.RefDataResponse;
import ma.axa.outer.bff.website.dto.quotation.MrhMinimalistSimulationResponse;
import ma.axa.outer.bff.website.dto.quotation.QuotationCouvertureMrhDto;
import ma.axa.outer.bff.website.dto.quotation.request.MrhMinimalistSimulationRequest;
import ma.axa.outer.bff.website.service.EmailContentProtectionService;
import ma.axa.outer.bff.website.service.MRHSimulatorService;

@RestController
@RequestMapping("/v1/mrh")
@RequiredArgsConstructor
@Validated
public class MRHSimulatorApi {

    private final MRHSimulatorService mrhSimulatorService;
    private final ICaptchaService captchaService;
    private final EmailContentProtectionService emailContentProtectionService;

    @Operation(summary = "Save prospect")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Prospect created", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = ProspectResponseDto.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
    @PostMapping(value = "/prospect", produces = {"application/json"}, consumes = {"application/json"})
    public ResponseEntity<ProspectResponseDto> saveProspect(@RequestBody MRHProspectDto prospect,
                                                            @RequestParam("g-recaptcha-response") String captchaResponse) {
        captchaService.processResponse(captchaResponse);
        return new ResponseEntity<>(mrhSimulatorService.saveProspect(prospect), HttpStatus.CREATED);
    }

    @Operation(summary = "Update Prospect")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Prospect updated", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = ProspectResponseDto.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
    @PutMapping(value = "/prospect/{prospectId}", produces = {"application/json"}, consumes = {"application/json"})
    public ResponseEntity<ProspectResponseDto> updateProspect(@RequestBody MRHProspectDto prospect, @PathVariable String prospectId,
                                                              @RequestParam("g-recaptcha-response") String captchaResponse) {
        captchaService.processResponse(captchaResponse);
        prospect.setLeadId(prospectId);
        return new ResponseEntity<>(mrhSimulatorService.updateProspect(prospect), HttpStatus.OK);
    }

    @PostMapping(value = "/simulation", produces = {"application/json"})
    public ResponseEntity<MRHSimulationResponseDto> getMRHSimulation(
            @RequestBody @Valid MRHSimulationRequestDto mrhSimulationRequestDto
    ) {
        return new ResponseEntity<>(mrhSimulatorService.getMRHSimulation(mrhSimulationRequestDto), HttpStatus.OK);
    }

    @GetMapping(value = "/capitals", produces = {"application/json"})
    public ResponseEntity<List<PublicCapitalDto>> getMRHCapitalList() {
        return new ResponseEntity<>(mrhSimulatorService.getMRHCapitalList(), HttpStatus.OK);
    }
    
    /********************************************************************************************************/
    /********************************** NEW ENDPOINTS FOR MRH V2 SIMULATOR **********************************/
    /********************************************************************************************************/
    
    @Operation(summary = "Récupérer la liste des Habitations Villa, Maison..")
    @GetMapping(value = "/building-types", produces = { "application/json" })
    public ResponseEntity<List<RefDataResponse>> getTypeHabitations() {
        return new ResponseEntity<>(mrhSimulatorService.getTypeHabitations(), HttpStatus.OK);
    }
    
    
	@Operation(summary = "Récupérer la liste des types d'occupants  Propriétaire/Locataire")
    @GetMapping(value = "/occupant-types", produces = { "application/json" })
    public ResponseEntity<List<RefDataResponse>> getTypeOccupants() {
        return new ResponseEntity<>(mrhSimulatorService.getTypeOccupants(), HttpStatus.OK);
    }
    
	@Operation(summary = "get garanties")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "get garanties", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = String.class)) }),
			@ApiResponse(responseCode = "400", description = "Requet Invalid", content = @Content),
			@ApiResponse(responseCode = "404", description = "get garanties non trouvée", content = @Content) })
	@GetMapping(path = "/garanties", produces = { "application/json" })
	public ResponseEntity<QuotationCouvertureMrhDto> getGaranties(
			@Parameter(description = "Capital assure") @RequestParam(name = "capital", required = true) BigDecimal capital) {
		return new ResponseEntity<>(mrhSimulatorService.getGaranties(capital), HttpStatus.OK);
	}
	
	
    @Operation(summary = "Create or update prospect/Lead V2")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Prospect created", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = ProspectResponseDto.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
    @PostMapping(value = "/prospectV2", produces = {"application/json"}, consumes = {"application/json"})
    public ResponseEntity<ProspectResponseDto> createProspectV2(@RequestBody MRHV2ProspectDto prospect,
                                                            @RequestParam("g-recaptcha-response") String captchaResponse) {
        captchaService.processResponse(captchaResponse);
        return new ResponseEntity<>(mrhSimulatorService.updateProspectV2(prospect), HttpStatus.CREATED);
    }
    
    
    @Operation(summary = "Update Prospect")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Prospect updated", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = ProspectResponseDto.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
    @PutMapping(value = "/prospectV2/{prospectId}", produces = {"application/json"}, consumes = {"application/json"})
    public ResponseEntity<ProspectResponseDto> updateProspect(@RequestBody MRHV2ProspectDto prospect, @PathVariable String prospectId,
                                                              @RequestParam("g-recaptcha-response") String captchaResponse) {
        captchaService.processResponse(captchaResponse);
        prospect.setLeadId(prospectId);
        return new ResponseEntity<>(mrhSimulatorService.updateProspectV2(prospect), HttpStatus.OK);
    }
	
    
	@Operation(summary = "Calcule prime mrh quotation")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Calcule prime quotation", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = String.class)) }),
			@ApiResponse(responseCode = "400", description = "Requet Invalid", content = @Content),
			@ApiResponse(responseCode = "404", description = "calcule Prime quotation non trouvée", content = @Content) })
	@PostMapping(path = "/tarification", produces = { "application/json" })
	public ResponseEntity<MrhMinimalistSimulationResponse> calculePrimeMrh( @Valid @RequestBody MrhMinimalistSimulationRequest mrhMinimalistSimulationRequest ,
            @RequestParam("g-recaptcha-response") String captchaResponse) {
		captchaService.processResponse(captchaResponse);
		return new ResponseEntity<>(mrhSimulatorService.tarification(mrhMinimalistSimulationRequest), HttpStatus.OK);
	}
	
	@Operation(summary = "Envoie Devis PDF MRH")
    	@PostMapping(value = "/send-devis-mail")
    	public ResponseEntity<ApiMessageWrapper> sendDevis(@Valid @RequestBody MrhMinimalistSimulationRequest mrhMinimalistSimulationRequest ,
                @RequestParam("g-recaptcha-response") String captchaResponse) {
			captchaService.processResponse(captchaResponse);
        	return new ResponseEntity<>(mrhSimulatorService.sendMrhDevisMail(emailContentProtectionService.sanitizeForEmail(mrhMinimalistSimulationRequest)), HttpStatus.OK);
    	}
	
	@Operation(summary = "Géneration Devis PDF MRH")
	@PostMapping(value = "/generate-devis-mrh")
    	public ResponseEntity<Resource> generateDevis(@Valid @RequestBody MrhMinimalistSimulationRequest mrhMinimalistSimulationRequest ) {
        	return new ResponseEntity<>(mrhSimulatorService.getMRHDevis(mrhMinimalistSimulationRequest), HttpStatus.OK);
    	}
}
