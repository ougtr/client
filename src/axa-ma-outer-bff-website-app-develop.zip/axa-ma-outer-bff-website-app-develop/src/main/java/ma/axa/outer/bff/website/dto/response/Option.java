package ma.axa.outer.bff.website.dto.response;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
@Data
@Builder
public class Option {
    private String code;
    private String libelle;
    private String typePlafond;
    private BigDecimal plafondFamille;
    private BigDecimal plafondIndividuel;
    private BigDecimal tauxSup;
    private String flagMalRedoute;
    private String codeZoneGeo;
    private String libelleZoneGeo;
    private BigDecimal ageAssureConjoint;
    private BigDecimal ageEnfant;
}
