package ma.axa.outer.bff.website.enums;

public enum IntermediaryStatus {
    ACTIVE,SUSPENDED,TERMINATED
}
