package ma.axa.outer.bff.website.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class PsiSimulationResponseDto {
    private PsiOfferResponseDto standard;
    private PsiOfferResponseDto comprehensive;
    private PsiOfferResponseDto prestige;
    private PsiOfferResponseDto prestigePlus;
}
