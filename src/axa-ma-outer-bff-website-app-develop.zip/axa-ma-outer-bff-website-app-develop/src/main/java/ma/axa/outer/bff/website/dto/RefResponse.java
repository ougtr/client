package ma.axa.outer.bff.website.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RefResponse {
	
	private String code;
	private String label;
	private String discription;
	private Boolean active;
}
