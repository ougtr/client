package ma.axa.outer.bff.website.dto.response;

import lombok.Data;
import lombok.experimental.SuperBuilder;
import ma.axa.outer.bff.website.dto.RefDataResponse;
import ma.axa.outer.bff.website.dto.request.CarencePeriod;

import java.util.List;

@Data
@SuperBuilder
public class HealthPackResponse {
    private String code;
    private String packName;
    List<RefDataResponse> franchise;
    private String annualLimit;
    private String coverageArea;
    private String description;
    private CarencePeriod carence;
    private String insuredPartnerLimit;
    private String childrenLimit;
}
