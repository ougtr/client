package ma.axa.outer.bff.website.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.outer.bff.website.dto.RefDataResponse;
import ma.axa.outer.bff.website.dto.request.CarencePeriod;

import java.util.List;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class HealthSehassurPacksResponseDto {
    private String code;
    private String packName;
    List<RefDataResponse> rembRate;
    List<RefDataResponse> rembBase;
    List<RefDataResponse> deathCapital;
    List<RefDataResponse> criticalIllnessCapital;
    private String annualLimit;
    private String description;
}
