package ma.axa.outer.bff.website.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.dto.AbandonRequest;
import ma.axa.outer.bff.website.dto.CallMeBackContactRequest;
import ma.axa.outer.bff.website.dto.ClaimRequest;
import ma.axa.outer.bff.website.dto.ContactRequest;
import ma.axa.outer.bff.website.dto.MRHV2ProspectDto;
import ma.axa.outer.bff.website.dto.request.SehassurPremiumSimulationRequest;
import ma.axa.outer.bff.website.dto.quotation.request.MrhMinimalistSimulationRequest;
import ma.axa.outer.bff.website.exception.GlobalException;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class EmailContentProtectionService {
    private static final String HTTP_SCHEME = "http://";
    private static final String HTTPS_SCHEME = "https://";
    private static final String WWW_PREFIX = "www.";
    private static final String JAVASCRIPT_SCHEME = "javascript:";
    private static final String VBSCRIPT_SCHEME = "vbscript:";
    private static final String HTML_DATA_SCHEME = "data:text/html";
    private static final String SCRIPT_TAG = "<script";
    private static final String SCRIPT_END_TAG = "</script";
    private static final String LINK_REMOVED = "[link removed]";

    private final ObjectMapper objectMapper;

    public ContactRequest sanitize(ContactRequest request) {
        return ContactRequest.builder()
                .firstName(sanitizeStrictText(request.getFirstName()))
                .lastName(sanitizeStrictText(request.getLastName()))
                .phoneNumber(sanitizeInlineText(request.getPhoneNumber()))
                .emailAddress(sanitizeInlineText(request.getEmailAddress()))
                .offer(sanitizeInlineText(request.getOffer()))
                .city(sanitizeInlineText(request.getCity()))
                .subject(sanitizeStrictText(request.getSubject()))
                .message(sanitizeFreeText(request.getMessage()))
                .build();
    }

    public CallMeBackContactRequest sanitize(CallMeBackContactRequest request) {
        return CallMeBackContactRequest.builder()
                .firstName(sanitizeStrictText(request.getFirstName()))
                .lastName(sanitizeStrictText(request.getLastName()))
                .phoneNumber(sanitizeInlineText(request.getPhoneNumber()))
                .emailAddress(sanitizeInlineText(request.getEmailAddress()))
                .subject(sanitizeStrictText(request.getSubject()))
                .message(sanitizeFreeText(request.getMessage()))
                .callHour(sanitizeInlineText(request.getCallHour()))
                .callDate(sanitizeInlineText(request.getCallDate()))
                .build();
    }

    public ClaimRequest sanitize(ClaimRequest request) {
        return ClaimRequest.builder()
                .firstName(sanitizeStrictText(request.getFirstName()))
                .lastName(sanitizeStrictText(request.getLastName()))
                .phoneNumber(sanitizeInlineText(request.getPhoneNumber()))
                .emailAddress(sanitizeInlineText(request.getEmailAddress()))
                .city(sanitizeStrictText(request.getCity()))
                .isClient(request.getIsClient())
                .subject(sanitizeStrictText(request.getSubject()))
                .message(sanitizeFreeText(request.getMessage()))
                .build();
    }

    public AbandonRequest sanitize(AbandonRequest request) {
        return AbandonRequest.builder()
                .firstName(sanitizeStrictText(request.getFirstName()))
                .lastName(sanitizeStrictText(request.getLastName()))
                .phoneNumber(sanitizeInlineText(request.getPhoneNumber()))
                .emailAddress(sanitizeInlineText(request.getEmailAddress()))
                .build();
    }

    public SehassurPremiumSimulationRequest sanitizeForEmail(SehassurPremiumSimulationRequest request) {
        return SehassurPremiumSimulationRequest.builder()
                .firstName(sanitizeStrictText(request.getFirstName()))
                .lastName(sanitizeStrictText(request.getLastName()))
                .birthDate(request.getBirthDate())
                .phoneNumber(sanitizeInlineText(request.getPhoneNumber()))
                .mail(sanitizeInlineText(request.getMail()))
                .city(sanitizeInlineText(request.getCity()))
                .cityLabel(sanitizeInlineText(request.getCityLabel()))
                .dependents(request.getDependents())
                .pack(request.getPack())
                .idLead(request.getIdLead())
                .packLead(request.getPackLead())
                .marketingConsent(request.getMarketingConsent())
                .cguConsent(request.getCguConsent())
                .build();
    }

    public MrhMinimalistSimulationRequest sanitizeForEmail(MrhMinimalistSimulationRequest request) {
        if (request == null || request.getMrhProspect() == null) {
            return request;
        }

        MRHV2ProspectDto sanitizedProspect = MRHV2ProspectDto.builder()
                .leadId(request.getMrhProspect().getLeadId())
                .title(sanitizeInlineText(request.getMrhProspect().getTitle()))
                .firstName(sanitizeStrictText(request.getMrhProspect().getFirstName()))
                .lastName(sanitizeStrictText(request.getMrhProspect().getLastName()))
                .phoneNumber(sanitizeInlineText(request.getMrhProspect().getPhoneNumber()))
                .emailAddress(sanitizeInlineText(request.getMrhProspect().getEmailAddress()))
                .owner(sanitizeInlineText(request.getMrhProspect().getOwner()))
                .propertyNature(sanitizeInlineText(request.getMrhProspect().getPropertyNature()))
                .propertyType(sanitizeInlineText(request.getMrhProspect().getPropertyType()))
                .insuredValue(request.getMrhProspect().getInsuredValue())
                .insuredContentValue(request.getMrhProspect().getInsuredContentValue())
                .city(sanitizeInlineText(request.getMrhProspect().getCity()))
                .prime(request.getMrhProspect().getPrime())
                .marketingConsent(request.getMrhProspect().getMarketingConsent())
                .cguConsent(request.getMrhProspect().getCguConsent())
                .build();

        return MrhMinimalistSimulationRequest.builder()
                .idQuotation(request.getIdQuotation())
                .typeHabitation(request.getTypeHabitation())
                .natureHabitation(request.getNatureHabitation())
                .optionnelGarantiesId(request.getOptionnelGarantiesId())
                .typeOccupant(request.getTypeOccupant())
                .valeurBatiment(request.getValeurBatiment())
                .valeurContenu(request.getValeurContenu())
                .valeurObject(request.getValeurObject())
                .prime(request.getPrime())
                .mrhProspect(sanitizedProspect)
                .build();
    }

    public String sanitizeDisplayName(String fieldName, String value) {
        return sanitizeStrictText(value);
    }

    public String toTemplateVariablesJson(Map<String, String> variables) {
        try {
            return objectMapper.writeValueAsString(variables);
        } catch (JsonProcessingException exception) {
            throw new GlobalException("Error while serializing email variables");
        }
    }

    public String toTemplateVariablesJson(String key, String value) {
        Map<String, String> variables = new HashMap<>();
        variables.put(key, value);
        return toTemplateVariablesJson(variables);
    }

    private String sanitizeStrictText(String value) {
        return normalizeInlineWhitespace(stripHtmlTags(sanitizeInlineText(value)));
    }

    private String sanitizeInlineText(String value) {
        if (value == null) {
            return null;
        }

        return normalizeInlineWhitespace(filterControlCharacters(value, false));
    }

    private String sanitizeFreeText(String value) {
        if (value == null) {
            return null;
        }

        String sanitized = filterControlCharacters(value, true);
        if (sanitized == null) {
            return null;
        }
        sanitized = stripHtmlTags(sanitized);
        if (sanitized == null) {
            return null;
        }
        sanitized = replaceSuspiciousTokens(sanitized, LINK_REMOVED);
        sanitized = collapseBlankLines(removeInlineSpacesAfterNewLines(sanitized));
        return sanitized.trim();
    }

    private String normalizeInlineWhitespace(String value) {
        if (value == null) {
            return null;
        }

        StringBuilder normalized = new StringBuilder(value.length());
        boolean previousWhitespace = false;
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            if (character == ' ' || character == '\t') {
                if (!previousWhitespace) {
                    normalized.append(' ');
                    previousWhitespace = true;
                }
            } else {
                normalized.append(character);
                previousWhitespace = false;
            }
        }
        return normalized.toString().trim();
    }

    private String filterControlCharacters(String value, boolean preserveNewLines) {
        StringBuilder sanitized = new StringBuilder(value.length());
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            if (character == '\r') {
                boolean hasFollowingLineFeed = index + 1 < value.length() && value.charAt(index + 1) == '\n';
                if (preserveNewLines) {
                    sanitized.append('\n');
                } else {
                    sanitized.append(' ');
                }
                if (hasFollowingLineFeed) {
                    index++;
                }
                continue;
            }
            if (character == '\n') {
                sanitized.append(preserveNewLines ? '\n' : ' ');
                continue;
            }
            if (character == '\t') {
                sanitized.append(' ');
                continue;
            }
            if (Character.isISOControl(character)) {
                sanitized.append(' ');
                continue;
            }
            sanitized.append(character);
        }
        return sanitized.toString();
    }

    private String stripHtmlTags(String value) {
        if (value == null) {
            return null;
        }

        StringBuilder sanitized = new StringBuilder(value.length());
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            if (character == '<') {
                int closingTagIndex = value.indexOf('>', index + 1);
                if (closingTagIndex > index + 1) {
                    sanitized.append(' ');
                    index = closingTagIndex;
                    continue;
                }
            }
            sanitized.append(character);
        }
        return sanitized.toString();
    }

    private String replaceSuspiciousTokens(String value, String replacement) {
        StringBuilder sanitized = new StringBuilder(value.length());
        StringBuilder token = new StringBuilder();
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            if (Character.isWhitespace(character)) {
                appendSanitizedToken(sanitized, token, replacement);
                sanitized.append(character);
            } else {
                token.append(character);
            }
        }
        appendSanitizedToken(sanitized, token, replacement);
        return sanitized.toString();
    }

    private void appendSanitizedToken(StringBuilder sanitized, StringBuilder token, String replacement) {
        if (token.length() == 0) {
            return;
        }

        String tokenValue = token.toString();
        String normalizedToken = trimTokenDelimiters(tokenValue).toLowerCase(Locale.ROOT);
        if (isSuspiciousToken(normalizedToken)) {
            sanitized.append(replacement);
        } else {
            sanitized.append(tokenValue);
        }
        token.setLength(0);
    }

    private boolean isSuspiciousToken(String normalizedToken) {
        return normalizedToken.startsWith(HTTP_SCHEME)
                || normalizedToken.startsWith(HTTPS_SCHEME)
                || normalizedToken.startsWith(WWW_PREFIX)
                || normalizedToken.startsWith(JAVASCRIPT_SCHEME)
                || normalizedToken.startsWith(VBSCRIPT_SCHEME)
                || normalizedToken.startsWith(HTML_DATA_SCHEME)
                || looksLikeDomainToken(normalizedToken);
    }

    private String trimTokenDelimiters(String tokenValue) {
        int start = 0;
        int end = tokenValue.length();
        while (start < end && isTokenDelimiter(tokenValue.charAt(start))) {
            start++;
        }
        while (end > start && isTokenDelimiter(tokenValue.charAt(end - 1))) {
            end--;
        }
        return tokenValue.substring(start, end);
    }

    private boolean isTokenDelimiter(char character) {
        return character == '"' || character == '\'' || character == '(' || character == ')' || character == '['
                || character == ']' || character == '{' || character == '}' || character == ','
                || character == ';' || character == ':' || character == '!' || character == '?';
    }

    private boolean looksLikeDomainToken(String tokenValue) {
        if (tokenValue == null || tokenValue.isBlank() || tokenValue.contains("@")) {
            return false;
        }

        String trimmedToken = trimTokenDelimiters(tokenValue);
        int firstDotIndex = trimmedToken.indexOf('.');
        if (firstDotIndex <= 0 || firstDotIndex == trimmedToken.length() - 1) {
            return false;
        }

        String[] labels = trimmedToken.split("\\.");
        if (labels.length < 2) {
            return false;
        }

        String topLevelDomain = labels[labels.length - 1];
        if (topLevelDomain.length() < 2 || topLevelDomain.length() > 24) {
            return false;
        }

        for (int index = 0; index < topLevelDomain.length(); index++) {
            if (!Character.isLetter(topLevelDomain.charAt(index))) {
                return false;
            }
        }

        for (String label : labels) {
            if (label.isBlank()) {
                return false;
            }
            for (int index = 0; index < label.length(); index++) {
                char character = label.charAt(index);
                if (!Character.isLetterOrDigit(character) && character != '-') {
                    return false;
                }
            }
        }
        return true;
    }

    private String removeInlineSpacesAfterNewLines(String value) {
        StringBuilder sanitized = new StringBuilder(value.length());
        boolean trimLeadingSpaces = false;
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            if (character == '\n') {
                sanitized.append(character);
                trimLeadingSpaces = true;
                continue;
            }
            if (trimLeadingSpaces && character == ' ') {
                continue;
            }
            sanitized.append(character);
            trimLeadingSpaces = false;
        }
        return sanitized.toString();
    }

    private String collapseBlankLines(String value) {
        StringBuilder sanitized = new StringBuilder(value.length());
        int consecutiveNewLines = 0;
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            if (character == '\n') {
                consecutiveNewLines++;
                if (consecutiveNewLines <= 2) {
                    sanitized.append(character);
                }
            } else {
                consecutiveNewLines = 0;
                sanitized.append(character);
            }
        }
        return sanitized.toString();
    }
}
