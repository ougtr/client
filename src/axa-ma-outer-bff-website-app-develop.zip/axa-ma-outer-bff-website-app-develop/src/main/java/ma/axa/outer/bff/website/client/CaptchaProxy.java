package ma.axa.outer.bff.website.client;

import ma.axa.outer.bff.website.captcha.GoogleResponse;
import ma.axa.outer.bff.website.client.config.InnerClientConfig;
import ma.axa.outer.bff.website.dto.GaragesListResponseDto;
import ma.axa.outer.bff.website.dto.IntermediariesDto;
import ma.axa.outer.bff.website.dto.IntermediariesListDto;
import ma.axa.outer.bff.website.dto.SFClinicsListDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "captchaProxy", url = "https://www.google.com/recaptcha/api", configuration = InnerClientConfig.class)

public interface CaptchaProxy {
    @GetMapping(path = "/siteverify", produces = {"application/json"})
    public ResponseEntity<GoogleResponse> validateCaptcha(
            @RequestParam(name = "response", required = false) String response,
            @RequestParam(name = "secret", required = false) String secret,
            @RequestParam(name = "remoteip", required = false) String remoteip
    );
}
