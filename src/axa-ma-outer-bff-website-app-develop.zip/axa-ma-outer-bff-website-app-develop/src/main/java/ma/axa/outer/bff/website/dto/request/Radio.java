package ma.axa.outer.bff.website.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class Radio {

    private BigDecimal valeurNeuf;

    private BigDecimal valeurVenale;

    private String indiceVol;


    private Integer codeMarque;
}
