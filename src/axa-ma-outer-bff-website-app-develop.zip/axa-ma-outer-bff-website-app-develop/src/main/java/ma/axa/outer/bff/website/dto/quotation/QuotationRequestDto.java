package ma.axa.outer.bff.website.dto.quotation;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QuotationRequestDto {
    
    private String intermediaryCode;
    
    @Schema(description = "Policy number")
    @Builder.Default
    private String policyNumber="0";

    @Schema(description = "Avenant type")
    private String avenantType;
    
    @Schema(description = "Avenant subtype")
    private String avenantSubType;
    
    @Builder.Default
    private String utilisateur = "";
    
    @Builder.Default
    private String typeGestion = "";
}
