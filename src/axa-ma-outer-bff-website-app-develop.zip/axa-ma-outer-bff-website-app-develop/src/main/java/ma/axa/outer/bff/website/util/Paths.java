package ma.axa.outer.bff.website.util;

public class Paths {
	public static final String QUOTATION_VERSION_PROXY = "/v2/auto";
	public static final String QUOTATION_RENEW = "/v1/renewal";
	public static final String QUOTATION_WEB_SITE= "/v1/quotation";
	public static final String WEB_SITE_PAYMENT_CMI= "/v1/payment/cmi";
	private Paths() throws InstantiationException {
		throw new InstantiationException("Instances of this type are forbidden");
	}
}
