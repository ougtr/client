package ma.axa.outer.bff.website.api;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import ma.axa.outer.bff.website.dto.RefDataResponse;
import ma.axa.outer.bff.website.dto.response.FuelDto;
import ma.axa.outer.bff.website.service.ReferentialService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/v1/referentiel")
@RequiredArgsConstructor
@Validated
public class DataRefReferentielApi {
    private final ReferentialService referentialService;

    @Operation(summary = "Récupérer la liste des villes")
    @GetMapping(value = "/cities", produces = { "application/json" })
    public ResponseEntity<List<RefDataResponse>> getCities() {
        return new ResponseEntity<>(referentialService.getCities(), HttpStatus.OK);
    }

    @GetMapping(value = "/brands", produces = {"application/json"})
    public ResponseEntity<List<RefDataResponse>> getBrands() {
        return new ResponseEntity<>(referentialService.getBrands(), HttpStatus.OK);
    }

    @GetMapping(value= "/fuel", produces = {"application/json"})
    public ResponseEntity<List<FuelDto>> getFuel() {
        return new ResponseEntity<>(referentialService.getFuel(), HttpStatus.OK);
    }
}
