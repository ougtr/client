package ma.axa.outer.bff.website.enums;

public enum DistributionChannel {
    INSURER,
    INTERMEDIARY
}
