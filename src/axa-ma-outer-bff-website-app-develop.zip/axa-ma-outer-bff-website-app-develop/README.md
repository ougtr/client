# AXA Outer API BFF for AXA website

A spring boot app as an outer api BFF for AXA website.

## Requirements
> Please follow [Developer Workplace](#) wiki to get/install your devTools.
* [Open JDK-11+](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Developer-Workplace#java)
* [Maven 3](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Developer-Workplace#maven)
* [Spring Tool Suite IDE](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Developer-Workplace#spring-tool-suite)
       - Mandatory Plugins: Lombok
> Make sure you'r using OpenJDK-11, check your java version with : `java -version`.

## How create new project from this Template

Please follow this wiki [Creating a Repository from a Template](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Create-First-Java-Project)

## Project Structure:

### Main folders

The project follows a standard spring project structure,is decomposed into multiple folders:

- **api**: contains different server Rest Controller, defining the various endpoints.
- **client**: contains all client API.
- **config**: contains project configuration like: openApi, security and web config.
- **domain**: contains the app's business objects.
- **dto**: contains objects representing requests and responses for various external systems (Client services, Axa Outer Services).
- **enums**: contains Enumerations.
- **exception**: contains objects used in exceptions management.
- **mapper**: contains the app's mapper classes.
- **service**: contains the service layer.
- **utils**: contains utility classes.
- **utils/constants**: contains constants classes.

### Test folders

All Test classes, must be under `/src/main/test`:

- **api**: contains unit testing for API layer.
- **service**: contains Unit testing for service layer.
- **utils**: contains Test utility classes.

## Run & Build application

### Locally

1. To build the project locally, run the following command:   

```
 mvn clean install
```

2. To run the application locally, run the following command:

```
 mvn spring-boot:run
```

### With Jenkins
1. Update file `cicd/jenkins.properties`: replace apps parameters with your application name, ...   
2. Update / Add env variables in : `cicd/resources/cm-env.yaml` or `cicd/resources/secrets.yaml`.  
3. Create your project on [Jenkins OpenPaaS](https://confluence.axa.com/confluence/pages/viewpage.action?pageId=290631844)
4. Build project with jenkins pipeline, follow the instructions [WIKI](https://confluence.axa.com/confluence/pages/viewpage.action?pageId=290631844#CI/CDOuterAPIs-BuildPipeline).   
. Deploy the application use Jenkins, follow the instructions [WIKI](https://confluence.axa.com/confluence/4pages/viewpage.action?pageId=290631844#CI/CDOuterAPIs-DeployPipeline).
5. To expose this API, You SHOULD add Nginx config on one of the following space:  
          - [Gateway External](https://github.axa.com/axa-ma/axa-ma-gateway/tree/master/outer/external).  
          - [External Internal](https://github.axa.com/axa-ma/axa-ma-gateway/tree/master/outer/internal).  


## Test your Rest APIs with Postman

1. Open your Postman. (If not installed yet, follow [Install Postman](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Developer-Workplace#postman))
2. Read the wiki [How to test your APIs](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Postman#how-to-test-your-apis-with-postman).

## Security Management

1. To enable/disable spring security, You must update the property `axa.security.enabled` (by default is `true`) in the application.yml file :

     ```
      axa:
        security:
          enabled: false
     ```
2. In case the spring security enabled, You should generate a Token and add it to your `http Authorization header`, Follow the wiki [How to Generate & add token with Postman](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Postman#how-to-generate--add-token-with-postman).

## links

| Tools       | Discription                             |
| ----------- | --------------------------------------- |
| [JIRA](https://jira.axa.com/)        | A proprietary issue tracking product.   |
| [Jenkins](https://jenkins-cicd-dev-axa-ma.axa-ma-dev-int.merlot.eu-central-1.aws.openpaas.axa-cloud.com)     | An open source automation server.       |
| [AXA MA Confluence](https://confluence.axa.com/confluence/display/AXAMA/AXA+Morocco+Home) | A web-based corporate wiki.                   |

