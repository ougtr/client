package ma.axa.inner.ged.claim.common.service;

import ma.axa.inner.ged.claim.health.dto.DocClaimHealthReq;
import ma.axa.inner.ged.config.GedHealthProperties;
import ma.axa.inner.ged.domain.ESResponse;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.dto.CimaRequestDocument;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.helper.ElasticSearchHelper;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.Property;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.mock.web.MockMultipartFile;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UploadHelperTest {

    private final static String ID_ALFRESCO = "a162223f-9a5c-466e-a678-b6cc0a37bbc7";
    private final static String CONTRACT_NUMBER = "/v1/cima/claims";
    private final static String COUNTRY_CODE = "SE";
    private final static String INDEX = "cimaindex";
    private final static String TYPE = "cimatype";

    @Mock
    ClaimDocumentRepository claimDocumentRepository;
    @Mock
    GedHealthProperties gedHealthProperties;
    @Mock
    Document document;
    @Mock
    Folder folder;
    @Mock
    ElasticSearchHelper elasticSearchHelper;


    @InjectMocks
    UploadHelper uploadHelper;


    @Test
    void indexDossier() {
    }

    @Test
    void pathFromDateDoc() {
    }

    private Document getMockedDocument(String id) {
        return createMockedCmisObject(new Object[][]{
                {PropertyIds.NAME, "Name", "test" + id + ".txt"},
                {PropertyIds.CONTENT_STREAM_LENGTH, "Content stream length", "210"},
                {PropertyIds.BASE_TYPE_ID, "Base type id", "cmis:document"},
                {PropertyIds.OBJECT_TYPE_ID, "Object type id", "cmis:document"},
                {PropertyIds.LAST_MODIFICATION_DATE, "Last modification date", new Date()},
                {PropertyIds.CONTENT_STREAM_MIME_TYPE, "Content stream mime type", "text/plain"},
                {PropertyIds.OBJECT_ID, "Object type id", id}}, Document.class);
    }

    private <T extends CmisObject> T createMockedCmisObject(Object[][] properties, Class<T> tClass) {
        T object = mock(tClass);
        List<Property<?>> documentProperties = new ArrayList<Property<?>>();
        for (Object[] mockProp : properties) {
            Property<?> prop = createMockedProperty(mockProp[0], mockProp[1], mockProp[2]);
            documentProperties.add(prop);
        }

        return object;
    }

    private Property<?> createMockedProperty(Object id, Object displayName, Object value) {
        Property<String> property = mock(Property.class);
        return property;
    }

    @Test
    void uploadFile() {
        document = getMockedDocument("test");
        assertThat(claimDocumentRepository).isNotNull();

        MockMultipartFile multiPartFile = new MockMultipartFile("data", "test.pdf", "application/pdf",
                "content".getBytes());

        DocClaimHealthReq claimHealthReq = new DocClaimHealthReq();
        claimHealthReq.setNomDoc("CIN");
        claimHealthReq.setTypeDoc("LETM");
        claimHealthReq.setTypeGestion("CVA");
        claimHealthReq.setIdAlfresco("5905d039-d9ec-4fed-8bdc-6240606e6042");

        var alfrescoID = "5905d039-d9ec-4fed-8bdc-6240606e6042";

        GedDocument gedDocument = new GedDocument();
        gedDocument.setFileByte("content".getBytes());
        gedDocument.setFileName("test.pdf");
        gedDocument.setMimeType("application/pdf");


        lenient().when(gedHealthProperties.getOutbox())
                .thenReturn("/Sites/groupe-indexation/documentLibrary/health");
        lenient().when(document.getVersionSeriesId()).thenReturn(alfrescoID);
        lenient().when(claimDocumentRepository.createArboFoldersByPath(any(String.class), any(String.class)))
                .thenReturn(folder);
        lenient().when(claimDocumentRepository.createDocument(any(Folder.class), any(GedDocument.class)))
                .thenReturn(document);


        var id = uploadHelper.uploadFile(multiPartFile, "/Sites/groupe-indexation/documentLibrary/health").get("idAlfresco");
        assertThat(id).isNotNull().isEqualTo(alfrescoID);
    }

    @Test
    void uploadFile_throw_InternalErrorException() {
        document = getMockedDocument("test");
        assertThat(claimDocumentRepository).isNotNull();

        MockMultipartFile multiPartFile = new MockMultipartFile("data", "test.pdf", "application/pdf",
                "content".getBytes());

        DocClaimHealthReq claimHealthReq = new DocClaimHealthReq();
        claimHealthReq.setNomDoc("CIN");
        claimHealthReq.setTypeDoc("LETM");
        claimHealthReq.setTypeGestion("CVA");
        claimHealthReq.setIdAlfresco("5905d039-d9ec-4fed-8bdc-6240606e6042");

        var alfrescoID = "5905d039-d9ec-4fed-8bdc-6240606e6042";

        GedDocument gedDocument = new GedDocument();
        gedDocument.setFileByte("content".getBytes());
        gedDocument.setFileName("test.pdf");
        gedDocument.setMimeType("application/pdf");


        lenient().when(gedHealthProperties.getOutbox())
                .thenReturn("/Sites/groupe-indexation/documentLibrary/health");
        lenient().when(document.getVersionSeriesId()).thenReturn(alfrescoID);
        lenient().when(claimDocumentRepository.createArboFoldersByPath(any(String.class), any(String.class)))
                .thenReturn(folder);
        lenient().when(claimDocumentRepository.createDocument(any(Folder.class), any(GedDocument.class)))
                .thenReturn(null);

        assertThrows(InternalErrorException.class, () -> uploadHelper.uploadFile(multiPartFile, "/Sites/groupe-indexation/documentLibrary/health"));
    }

    @Test
    void createDocumentInEs() {
        var cimaRequestDocument = new CimaRequestDocument();
        var esResponse = new ESResponse();
        cimaRequestDocument.setIdAlfresco(ID_ALFRESCO);
        cimaRequestDocument.setContractNumber(CONTRACT_NUMBER);
        cimaRequestDocument.setCountryCode(COUNTRY_CODE);
        esResponse.setCreated(true);
        esResponse.setIndex(INDEX);
        esResponse.setType(TYPE);
        esResponse.setId(ID_ALFRESCO);

        when(elasticSearchHelper.addCimaDocument(any(CimaRequestDocument.class), anyString())).thenReturn(esResponse);

        var response = uploadHelper.createDocumentInEs(cimaRequestDocument, ID_ALFRESCO);
        assertThat(response).isEqualTo(esResponse);
    }
}
