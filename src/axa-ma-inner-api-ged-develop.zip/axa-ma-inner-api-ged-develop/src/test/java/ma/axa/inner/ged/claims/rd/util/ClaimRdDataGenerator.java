package ma.axa.inner.ged.claims.rd.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import lombok.experimental.UtilityClass;
import ma.axa.inner.ged.claim.rd.domain.DocumentClaimRdEs;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdAddReq;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdResponse;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdUpdateReq;
import ma.axa.inner.ged.domain.alfresco.DocumentAlfresco;
import ma.axa.inner.ged.enums.Branche;
import ma.axa.inner.ged.enums.GedClaimStatus;
import ma.axa.inner.ged.util.DateUtils;

@UtilityClass
public class ClaimRdDataGenerator {

	public static final String DOCUMENT_ID = "64a7fb0a-c4d3-4487-8e97-8d453c458adb";
	public static final String DOCUMENT_ID_NOT = "64a7fb0a-c4d3-4487-8e97";
	public static final String APP_CODE = "GED_CLAIM";
	public static final String CREATED_BY = "a205mohamed";
	public static final String LASTUPDATED_BY	= "hakim";
	public static final String REFERENCE = "ref-20230202-01";
	public static final String SINISTRE_NUMBER = "ref-20230202-01";
	public static final LocalDateTime CREATE_DATE_TIME = LocalDateTime.now();

	/** ======== Request ======== **/
	public static final MultiValueMap<String, String> getAddRequest() {
		return getAddRequest(APP_CODE, CREATED_BY, REFERENCE, SINISTRE_NUMBER, GedClaimStatus.EN_INSTANCE.name());
	}

	public static final MultiValueMap<String, String> getAddRequest(String reference) {
		return getAddRequest(APP_CODE, CREATED_BY, reference, SINISTRE_NUMBER, GedClaimStatus.EN_INSTANCE.name());
	}

	public static final MultiValueMap<String, String> getAddRequestForFaildValidation() {
		return getAddRequest(APP_CODE, CREATED_BY, REFERENCE, null, GedClaimStatus.IDENTIFIE.name());
	}

	public static final MultiValueMap<String, String> getAddRequest(String appCode, String createdBy,
			String reference, String sinistreNumber, String status) {
		MultiValueMap<String, String> meta = new LinkedMultiValueMap<>();
		// required
		meta.set("applicationCode", appCode);
		meta.set("createdBy", createdBy);
		meta.set("reference", reference);

		meta.set("assureNom", "achref");
		meta.set("assurePrenom", "hakimi");
		meta.set("comment", null);
		meta.set("dateNumerisation", LocalDate.now().format(DateUtils.dateFormatter));
		meta.set("dateReception", LocalDate.now().minusDays(1).format(DateUtils.dateFormatter));
		meta.set("dateSurvenance", LocalDate.now().minusDays(4).format(DateUtils.dateFormatter));
		meta.set("draft", "false");
		meta.set("entityCode", "1");
		meta.set("entityLabel", "");
		meta.set("filename", "new_filename.pdf");
		meta.set("intermediaireCode", "205");
		meta.set("intermediaireNom", "Marrache et Dor");
		meta.set("original", "false");
		meta.set("produitCode", "4");
		meta.set("produitLabel", "Product name");
		meta.set("sinistreNumber", sinistreNumber);
		meta.set("sinistreUserCreator", "mohamed");
		meta.set("status", status);
		meta.set("typeDocumentCode", "3");
		meta.set("typeDocumentLabel", "cin");
		return meta;
	}
	
	public static final DocClaimRdAddReq getAddRequestDto() {
		return DocClaimRdAddReq.builder()
				.createdBy(CREATED_BY)
				.applicationCode(APP_CODE)
				.reference(REFERENCE)
				.sinistreNumber(SINISTRE_NUMBER)
				.intermediaireCode(205)
				.build();
	}

	public static final DocClaimRdUpdateReq getUpdateRequestDto() {
		return DocClaimRdUpdateReq.builder()
				.lastUpdatedBy(LASTUPDATED_BY)
				.reference(REFERENCE)
				.sinistreNumber(SINISTRE_NUMBER)
				.intermediaireCode(205)
				.build();
	}
	
	public static final MultiValueMap<String, String> getSearchParams(int pageNumber, int pageSize) {
		MultiValueMap<String, String> meta = new LinkedMultiValueMap<>();
		meta.set("pageNumber", String.valueOf(pageNumber));
		meta.set("pageSize", String.valueOf(pageSize));
		meta.set("createdBy", CREATED_BY);
		meta.set("status", GedClaimStatus.IDENTIFIE.name());
		meta.set("sinistreNumber", SINISTRE_NUMBER);
		meta.set("reference", REFERENCE);
		return meta;
	}
	
	public static final Map<String, Object> getFolderProperties() {
		Map<String, Object> meta = new HashMap<String, Object>();
		meta.put("axa:dossier:codeIntermediaire", 1);
		return meta;
	}
	
	public static final DocumentAlfresco getDocumentAlfresco() {
		return DocumentAlfresco.builder()
				.id(DOCUMENT_ID)
				.mimeType("application/pdf")
				.path("/site/folder/to/upload")
				.build();
	}

	/** ======== Response DTOs ======== **/

	public static DocumentClaimRdEs getDocumentEs() {
		return DocumentClaimRdEs.builder()
				.id(DOCUMENT_ID)
				.applicationCode(APP_CODE)
				.assureNom("achref")
				.assurePrenom("hakimi")
				.brancheCode(Branche.RD.getCode())
				.brancheLabel(Branche.RD.getLabel())
				.comment(null)
				.createdAt(CREATE_DATE_TIME)
				.createdBy(CREATED_BY)
				.dateNumerisation(LocalDate.now())
				.dateReception(LocalDate.now().minusDays(1))
				.dateSurvenance(LocalDate.now().minusDays(4))
				.draft(false)
				.entityCode(1)
				.entityLabel("")
				.filename("filename.pdf")
				.intermediaireCode(205)
				.intermediaireNom("Marrache et Dor")
				.lastUpdatedAt(null)
				.lastUpdatedBy(null)
				.original(false)
				.path("/site/folder/to/upload")
				.produitCode(4)
				.produitLabel("Product name")
				.reference(REFERENCE)
				.sinistreNumber(SINISTRE_NUMBER)
				.sinistreUserCreator("mohamed")
				.status("Identifié")
				.typeDocumentCode(3)
				.typeDocumentLabel("cin")
				.build();
	}

	public static DocClaimRdResponse getOnResponseDoc() {
		return DocClaimRdResponse.builder()
				.id(DOCUMENT_ID)
				.applicationCode(APP_CODE)
				.assureNom("achref")
				.assurePrenom("hakimi")
				.brancheCode(Branche.RD.getCode())
				.brancheLabel(Branche.RD.getLabel())
				.comment(null)
				.createdAt(CREATE_DATE_TIME)
				.createdBy(CREATED_BY)
				.dateNumerisation(LocalDate.now())
				.dateReception(LocalDate.now().minusDays(1))
				.dateSurvenance(LocalDate.now().minusDays(4))
				.draft(false)
				.entityCode("1")
				.entityLabel("")
				.filename("filename.pdf")
				.intermediaireCode(205)
				.intermediaireNom("Marrache et Dor")
				.lastUpdatedAt(null)
				.lastUpdatedBy(null)
				.original(false)
				.path("/site/folder/to/upload")
				.produitCode(4)
				.produitLabel("Product name")
				.reference(REFERENCE)
				.sinistreNumber(SINISTRE_NUMBER)
				.sinistreUserCreator("mohamed")
				
				.typeDocumentCode("3")
				.typeDocumentLabel("cin")
				.build();
	}
	
	
	public static DocClaimRdResponse getOnResponseAfterUpdateDoc() {
		return DocClaimRdResponse.builder()
				.id(DOCUMENT_ID)
				.applicationCode(APP_CODE)
				.assureNom("achref")
				.assurePrenom("hakimi")
				.brancheCode(Branche.RD.getCode())
				.brancheLabel(Branche.RD.getLabel())
				.comment(null)
				.createdAt(CREATE_DATE_TIME)
				.createdBy(CREATED_BY)
				.dateNumerisation(LocalDate.now())
				.dateReception(LocalDate.now().minusDays(1))
				.dateSurvenance(LocalDate.now().minusDays(4))
				.draft(false)
				.entityCode("1")
				.entityLabel("")
				.filename("filename.pdf")
				.intermediaireCode(205)
				.intermediaireNom("Marrache et Dor")
				.lastUpdatedAt(LocalDateTime.now())
				.lastUpdatedBy(LASTUPDATED_BY)
				.original(false)
				.path("/site/folder/to/upload")
				.produitCode(4)
				.produitLabel("Product name")
				.reference(REFERENCE)
				.sinistreNumber(SINISTRE_NUMBER)
				.sinistreUserCreator("mohamed")
				
				.typeDocumentCode("3")
				.typeDocumentLabel("cin")
				.build();
	}
}
