package ma.axa.inner.ged.claims.common.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import ma.axa.inner.ged.domain.parametrage.BrancheParametrage;
import ma.axa.inner.ged.domain.parametrage.EntityParametrage;
import ma.axa.inner.ged.domain.parametrage.RepertoireParametrage;
import ma.axa.inner.ged.domain.parametrage.TypeDocumentParametrage;
import ma.axa.inner.ged.repository.parametrage.ParametrageRepository;

@ExtendWith(MockitoExtension.class)
class ParametrageGedRepositoryTest {

	@Mock
	JdbcTemplate jdbcTemplate;

	@InjectMocks
	ParametrageRepository parametrageRepository;

	@Test
	void Should_Get_All_Branches() {
		List<BrancheParametrage> list = new ArrayList<BrancheParametrage>(
				List.of(BrancheParametrage.builder().code(new BigDecimal(1)).libelle("Transport").build(),
						BrancheParametrage.builder().code(new BigDecimal(2)).libelle("RD").build()));
		
		when(jdbcTemplate.query(anyString(), ArgumentMatchers.<RowMapper<BrancheParametrage>>any())).thenReturn(list);
		assertThat(parametrageRepository.getAll()).isNotNull();

	}

	@Test
	void Should_Get_All_Entities() {
		List<EntityParametrage> list = new ArrayList<EntityParametrage>(List.of(
				EntityParametrage.builder().code(new BigDecimal(1)).libelle("Risque simple").codbran(new BigDecimal(1))
						.build(),
				EntityParametrage.builder().code(new BigDecimal(2)).libelle("Risque technique")
						.codbran(new BigDecimal(2)).build()));
		when(jdbcTemplate.query(anyString(), ArgumentMatchers.<RowMapper<EntityParametrage>>any(),
				ArgumentMatchers.any())).thenReturn(list);
		assertThat(parametrageRepository.getListEntityByIdBranche(1)).isNotNull();

	}

	@Test
	void Should_Get_All_Type_Documents() {
		List<TypeDocumentParametrage> list = new ArrayList<TypeDocumentParametrage>(List.of(
				TypeDocumentParametrage.builder().code(new BigDecimal(1)).libelle("Déclaration sinistre").build(),
				TypeDocumentParametrage.builder().code(new BigDecimal(3)).libelle("Facture de réparation").build()));
		when(jdbcTemplate.query(anyString(), ArgumentMatchers.<RowMapper<TypeDocumentParametrage>>any(),
				ArgumentMatchers.any())).thenReturn(list);
		assertThat(parametrageRepository.getListRepertoireByIdDocument(1,1)).isNotNull();

	}

	@Test
	void Should_Get_All_Directories_by_id_document() {
		List<RepertoireParametrage> list = new ArrayList<RepertoireParametrage>(List.of(
				RepertoireParametrage.builder().code(new BigDecimal(1)).libelle("DECLARATION").build(),
				RepertoireParametrage.builder().code(new BigDecimal(2)).libelle("RAPPORT D EXPERTISE").build()));
		when(jdbcTemplate.query(anyString(), ArgumentMatchers.<RowMapper<RepertoireParametrage>>any(),
				ArgumentMatchers.any())).thenReturn(list);
		assertThat(parametrageRepository.getListRepertoireByIdDocument(1,1)).isNotNull();
	}

	@Test
	void Should_Get_All_Directories() {
		List<RepertoireParametrage> list = new ArrayList<>(List.of(
                RepertoireParametrage.builder().code(new BigDecimal(1)).libelle("DECLARATION").build(),
                RepertoireParametrage.builder().code(new BigDecimal(2)).libelle("RAPPORT D EXPERTISE").build()));
		when(jdbcTemplate.query(anyString(), ArgumentMatchers.<RowMapper<RepertoireParametrage>>any())).thenReturn(list);
		assertThat(parametrageRepository.getListRepertoire()).isNotNull();
	}

}
