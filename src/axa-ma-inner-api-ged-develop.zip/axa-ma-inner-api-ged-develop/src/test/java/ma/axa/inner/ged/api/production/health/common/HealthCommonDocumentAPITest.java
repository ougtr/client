package ma.axa.inner.ged.api.production.health.common;


import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.dto.production.health.common.DocHealthCommonResp;
import ma.axa.inner.ged.dto.production.health.common.DocHealthSearchParams;
import ma.axa.inner.ged.service.production.health.common.HealthDocumentService;
import ma.axa.inner.ged.util.DataGenerator;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(HealthDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
public class HealthCommonDocumentAPITest {

    private static final String SERVICE_PATH = "/v1/health/documents";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    HealthDocumentService healthDocumentService;

    @Autowired
    WebApplicationContext webApplicationContext;

    @MockBean
	private DataSourceContextHolder dataSourceContextHolder;

   private final MockMultipartFile multiPartFile = new MockMultipartFile("test","test.pdf","application/pdf","content".getBytes());

    @Test
    @DisplayName("production health  upload document")
    @WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
    void uploadDocument_ok() throws Exception {
        when(healthDocumentService.uploadHealthDocument(any(), any())).thenReturn(DataGenerator.getOnResponseCommonHealthDoc());
        var meta = DataGenerator.getAddDocumentRequest();
        var request = multipart(SERVICE_PATH)
                .file("files", multiPartFile.getBytes())
                .contentType(MediaType.MULTIPART_FORM_DATA_VALUE)
                .params(meta);
        mockMvc.perform(request)
                .andExpect(status().isCreated());
    }

    @Test
    @DisplayName("delete common document")
    @WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
    void deleteDocument_ok() throws Exception {
        when(healthDocumentService.deleteDocument(anyString())).thenReturn("deleted");

        var fullPath = String.format("%s/%s", SERVICE_PATH, "64a7fb0a-c4d3-4487-8e97-8d453c458adb");
        var requestBuilder = MockMvcRequestBuilders
                .delete(fullPath);
        mockMvc.perform(requestBuilder)
                .andExpect(status().isOk());
    }


    @Test
    @DisplayName("download document")
    @WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
    void download_file_success() throws Exception {
        String id = "alfresco";
        ByteArrayResource output = new ByteArrayResource("content".getBytes());
        when(healthDocumentService.downloadFile(id)).thenReturn(ResponseEntity.ok(output));
        mockMvc.perform(MockMvcRequestBuilders.get(SERVICE_PATH + "/"+ id +"/content")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }


    @Test
    @DisplayName("search  documents")
    @WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
    void searchDocuments_shouldReturn200WhenDocumentsAreFound() throws Exception {
        var searchParams = new DocHealthSearchParams();
        when(healthDocumentService.search(searchParams)).thenReturn(new PageImpl<>(Collections.singletonList(new DocHealthCommonResp())));
        var requestBuilder = MockMvcRequestBuilders
                .get(SERVICE_PATH)
                .queryParams(DataGenerator.getSearchParams(1, 10));
        mockMvc.perform(requestBuilder)
                .andExpect(status().isOk());
    }

}
