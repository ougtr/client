package ma.axa.inner.ged.claims.health.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import ma.axa.inner.ged.util.FormatterUtils;

@ExtendWith(MockitoExtension.class)
class FormatterUtilsTest {
	
 
	FormatterUtils formatterUtils;
	
	

	@Test
	void formatterUtils_shouldReturnZero() {
		formatterUtils = new FormatterUtils();
		assertEquals(formatterUtils.toBigDecimal(null), BigDecimal.ZERO);
	}
	
	
	@Test
	void formatterUtils_shouldReturnExactDateCoverted() throws ParseException {
		formatterUtils = new FormatterUtils();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date date = df.parse("2023-12-12");
		assertEquals(formatterUtils.toBigDecimal(date), new BigDecimal(20231212));
	}
}
