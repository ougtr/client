package ma.axa.inner.ged.mobile.scan.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.google.zxing.WriterException;

import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.mobile.scan.dto.OcrDoc;
import ma.axa.inner.ged.mobile.scan.dto.OcrDocDto;
import ma.axa.inner.ged.mobile.scan.dto.ScanResponse;
import ma.axa.inner.ged.mobile.scan.repository.OcrDocRepository;
import ma.axa.inner.ged.mobile.scan.repository.QrCodeRepository;


@ExtendWith(MockitoExtension.class)
class QrCodeServiceImplTest {
	@InjectMocks
	QrCodeServiceImpl qrCodeServiceImpl = new QrCodeServiceImpl();
	@Mock
	OcrDocRepository ocrDocRepository;
	@Mock
	QrCodeRepository qrCodeRepository;

	@BeforeEach
	void setUp() throws Exception {

	}

	@Test
	void testGetTypeDocumentByToken() throws WriterException, IOException {
		OcrDoc ocrDocument = new OcrDoc();
		assertNotNull(ocrDocument);
		QrCodeServiceImpl spy = Mockito.spy(QrCodeServiceImpl.class);
		Mockito.lenient().doReturn(new ScanResponse()).when(spy).getTypeDocumentByToken(any(String.class));
	}

	@Test
	void testGetOcrDocumentByToken() throws WriterException, IOException {
		OcrDoc ocrDocument = new OcrDoc();
		assertNotNull(ocrDocument);
		QrCodeServiceImpl spy = Mockito.spy(QrCodeServiceImpl.class);
		Mockito.lenient().doReturn(new OcrDocDto()).when(spy).getocrDocumentByToken(any(String.class));
	}

	@Test
	void testGenerateQRCode() throws WriterException, IOException {

		String token = "your_token";
		when(ocrDocRepository.findByToken(token)).thenReturn(null);
		qrCodeServiceImpl.getTypeDocumentByToken(token);
		Mockito.lenient().when(qrCodeServiceImpl.generateQRCode("cin", 200, 200)).thenReturn(new ScanResponse());

	}

	@Test
	void GenerateQRCode_exception() {
		assertThrows(GlobalException.class,
				() -> qrCodeServiceImpl.generateQRCode("carte_sejour", 200, 200));

	}
}
