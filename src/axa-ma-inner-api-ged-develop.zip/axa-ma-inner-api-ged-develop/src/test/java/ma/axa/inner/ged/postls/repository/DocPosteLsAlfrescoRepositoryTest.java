package ma.axa.inner.ged.postls.repository;

import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.exception.DocumentNotFoundException;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.IOFileException;
import ma.axa.inner.ged.postels.repository.DocPosteLsAlfrescoRepository;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;
import org.apache.chemistry.opencmis.client.api.*;
import org.apache.chemistry.opencmis.client.runtime.OperationContextImpl;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.apache.chemistry.opencmis.commons.data.AllowableActions;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.chemistry.opencmis.commons.data.RepositoryCapabilities;
import org.apache.chemistry.opencmis.commons.data.RepositoryInfo;
import org.apache.chemistry.opencmis.commons.enums.Action;
import org.apache.chemistry.opencmis.commons.enums.CapabilityContentStreamUpdates;
import org.apache.chemistry.opencmis.commons.enums.IncludeRelationships;
import org.apache.chemistry.opencmis.commons.enums.VersioningState;
import org.apache.chemistry.opencmis.commons.exceptions.CmisContentAlreadyExistsException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisObjectNotFoundException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisPermissionDeniedException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisServiceUnavailableException;
import org.apache.chemistry.opencmis.commons.impl.dataobjects.ContentStreamImpl;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DocPosteLsAlfrescoRepositoryTest {

    @Mock
    private Session session;

    @InjectMocks
    private DocPosteLsAlfrescoRepository repository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        repository = new DocPosteLsAlfrescoRepository(session);
    }

    @Test
    void testCreateOrUpdateFolder_FolderExists() {
        String parentFolderPath = "/parent";
        Map<String, Object> properties = new HashMap<>();
        properties.put(PropertyIds.NAME, "child");
        Folder folder = mock(Folder.class);

        when(session.getObjectByPath(parentFolderPath + "/child")).thenReturn(folder);

        Folder result = repository.createOrUpdateFolder(parentFolderPath, properties);

        assertEquals(folder, result);
        verify(session).getObjectByPath(parentFolderPath + "/child");
    }

    @Test
    void testCreateOrUpdateFolder_FolderDoesNotExist() {
        String parentFolderPath = "/parent";
        Map<String, Object> properties = new HashMap<>();
        properties.put(PropertyIds.NAME, "child");
        Folder parentFolder = mock(Folder.class);
        Folder createdFolder = mock(Folder.class);

        when(session.getObjectByPath(parentFolderPath + "/child")).thenThrow(new CmisObjectNotFoundException(""));
        when(session.getObjectByPath(parentFolderPath)).thenReturn(parentFolder);
        when(parentFolder.createFolder(properties)).thenReturn(createdFolder);

        Folder result = repository.createOrUpdateFolder(parentFolderPath, properties);

        assertEquals(createdFolder, result);
        verify(parentFolder).createFolder(properties);
    }

    @Test
    void testCreateArboFoldersByPath() {
        String parentFolderPath = "/parent";
        String path = "a/b";
        Folder folderA = mock(Folder.class);
        Folder folderB = mock(Folder.class);

        when(session.getObjectByPath("/parent")).thenReturn(folderA);
        when(folderA.createFolder(any())).thenReturn(folderA);

        when(session.getObjectByPath("/parent/a/b")).thenThrow(new CmisObjectNotFoundException(""));
        when(session.getObjectByPath("/parent/a")).thenReturn(folderA);
        when(folderA.getPath()).thenReturn("/parent/a");
        when(folderA.createFolder(any())).thenReturn(folderB);

        when(folderB.getPath()).thenReturn("/parent/a/b");

        Folder result = repository.createArboFoldersByPath(parentFolderPath, path);

        assertEquals(folderB, result);
    }

    @Test
    void testGetFileObject_Success() {
        String id = "docId";
        Document doc = mock(Document.class);

        when(session.getObject(id)).thenReturn(doc);

        Document result = repository.getFileObject(id);

        assertEquals(doc, result);
    }

    @Test
    void testGetFileObject_NotFound() {
        String id = "docId";
        when(session.getObject(id)).thenThrow(new CmisObjectNotFoundException(""));

        assertThrows(DocumentNotFoundException.class, () -> repository.getFileObject(id));
    }

    @Test
    void testGetFileObject_BlankId() {
        Document result = repository.getFileObject("");
        assertNull(result);
    }

    @Test
    void testCreateDocument() {
        Folder folder = mock(Folder.class);
        GedDocument data = new GedDocument();
        data.setFileName("file.txt");
        data.setMimeType("text/plain");
        data.setFileByte("abc".getBytes());

        Document doc = mock(Document.class);
        Document latestDoc = mock(Document.class);

        when(folder.createDocument(any(), any(), eq(VersioningState.MAJOR))).thenReturn(doc);
        when(doc.getObjectOfLatestVersion(false)).thenReturn(latestDoc);

        Document result = repository.createDocument(folder, data);

        assertEquals(latestDoc, result);
        verify(folder).createDocument(any(), any(), eq(VersioningState.MAJOR));
    }

    @Test
    void testGetFileDocument() throws IOException {
        String alfrescoId = "id";
        Document doc = mock(Document.class);
        ContentStream contentStream = mock(ContentStream.class);
        ByteArrayInputStream bais = new ByteArrayInputStream("abc".getBytes());

        when(session.getObject(alfrescoId)).thenReturn(doc);
        when(doc.getContentStream()).thenReturn(contentStream);
        when(contentStream.getStream()).thenReturn(bais);
        when(doc.getName()).thenReturn("file.txt");

        GedDocument result = repository.getFileDocument(alfrescoId);

        assertNotNull(result);
        assertEquals("file.txt", result.getFileName());
        assertEquals("text/plain", result.getMimeType());
        assertArrayEquals("abc".getBytes(), result.getFileByte());
    }

    @Test
    void testGetFolder_Success() {
        String folderPath = "/folder";
        Folder folder = mock(Folder.class);

        when(session.getObjectByPath(folderPath)).thenReturn(folder);

        Folder result = repository.getFolder(folderPath);

        assertEquals(folder, result);
    }

    @Test
    void testGetFolder_NotFound() {
        String folderPath = "/folder";
        when(session.getObjectByPath(folderPath)).thenThrow(new CmisObjectNotFoundException(""));

        assertThrows(IOFileException.class, () -> repository.getFolder(folderPath));
    }

    @Test
    void testDeleteFile_CanDelete() {
        String id = "id";
        Document doc = mock(Document.class);
        Set<Action> actions = new HashSet<>();
        actions.add(Action.CAN_DELETE_OBJECT);
        AllowableActions allowableActions = mock(AllowableActions.class);

        when(session.getObject(id)).thenReturn(doc);
        when(doc.getAllowableActions()).thenReturn(allowableActions);
        when(allowableActions.getAllowableActions()).thenReturn(actions);

        String result = repository.deleteFile(id);

        assertEquals(id, result);
        verify(doc).delete(true);
    }

    @Test
    void testDeleteFile_CannotDelete() {
        String id = "id";
        Document doc = mock(Document.class);
        Set<Action> actions = new HashSet<>();
        AllowableActions allowableActions = mock(AllowableActions.class);

        when(session.getObject(id)).thenReturn(doc);
        when(doc.getAllowableActions()).thenReturn(allowableActions);
        when(allowableActions.getAllowableActions()).thenReturn(actions);

        assertThrows(CmisPermissionDeniedException.class, () -> repository.deleteFile(id));
    }

    @Test
    void testUpdateContent_Success() throws IOException {
        String id = "id";
        Document doc = mock(Document.class);
        MultipartFile file = mock(MultipartFile.class);

        when(session.getObject(id)).thenReturn(doc);
        when(session.getRepositoryInfo()).thenReturn(mock(RepositoryInfo.class));
        when(session.getRepositoryInfo().getCapabilities()).thenReturn(mock(RepositoryCapabilities.class));
        when(session.getRepositoryInfo().getCapabilities().getContentStreamUpdatesCapability())
                .thenReturn(CapabilityContentStreamUpdates.ANYTIME);
        when(file.getName()).thenReturn("file.txt");
        when(file.getSize()).thenReturn(3L);
        when(file.getContentType()).thenReturn("text/plain");
        when(file.getBytes()).thenReturn("abc".getBytes());

        assertDoesNotThrow(() -> repository.updateContent(id, file));
        verify(doc).setContentStream(any(ContentStream.class), eq(true), eq(true));
    }

    @Test
    void testUpdateContent_ThrowsGlobalException() throws IOException {
        String id = "id";
        Document doc = mock(Document.class);
        MultipartFile file = mock(MultipartFile.class);

        when(session.getObject(id)).thenReturn(doc);
        when(session.getRepositoryInfo()).thenReturn(mock(RepositoryInfo.class));
        when(session.getRepositoryInfo().getCapabilities()).thenReturn(mock(RepositoryCapabilities.class));
        when(session.getRepositoryInfo().getCapabilities().getContentStreamUpdatesCapability())
                .thenReturn(CapabilityContentStreamUpdates.ANYTIME);
        when(file.getName()).thenReturn("file.txt");
        when(file.getSize()).thenReturn(3L);
        when(file.getContentType()).thenReturn("text/plain");
        when(file.getBytes()).thenReturn("abc".getBytes());

        doThrow(new RuntimeException("fail")).when(doc).setContentStream(any(ContentStream.class), eq(true), eq(true));

        assertThrows(GlobalException.class, () -> repository.updateContent(id, file));
    }

    @Test
    void testCheckContentStreamUpdatesCapability_Throws() {
        when(session.getRepositoryInfo()).thenReturn(mock(RepositoryInfo.class));
        when(session.getRepositoryInfo().getCapabilities()).thenReturn(mock(RepositoryCapabilities.class));
        when(session.getRepositoryInfo().getCapabilities().getContentStreamUpdatesCapability())
                .thenReturn(CapabilityContentStreamUpdates.NONE);

        assertThrows(CmisServiceUnavailableException.class, () -> repository.checkContentStreamUpdatesCapability());
    }

    @Test
    void testCreateContentStream() throws IOException {
        MultipartFile file = mock(MultipartFile.class);
        when(file.getName()).thenReturn("file.txt");
        when(file.getSize()).thenReturn(3L);
        when(file.getContentType()).thenReturn("text/plain");
        when(file.getBytes()).thenReturn("abc".getBytes());

        ContentStream cs = repository.createContentStream(file);

        assertEquals("file.txt", cs.getFileName());
        assertEquals("text/plain", cs.getMimeType());
        assertEquals(3L, cs.getLength());
    }

    @Test
    void testGetAllChildsFromAlfrescoDirectory_Success() {
        String folderPath = "/folder";
        Folder folder = mock(Folder.class);
        ItemIterable<CmisObject> iterable = mock(ItemIterable.class);

        when(session.getObjectByPath(folderPath)).thenReturn(folder);
        when(session.createOperationContext()).thenReturn(new OperationContextImpl());
        when(folder.getChildren(any(OperationContext.class))).thenReturn(iterable);

        ItemIterable<CmisObject> result = repository.getAllChildsFromAlfrescoDirectory(folderPath);

        assertEquals(iterable, result);
    }

    @Test
    void testGetAllChildsFromAlfrescoDirectory_FolderNotFound() {
        String folderPath = "/folder";
        when(session.getObjectByPath(folderPath)).thenThrow(new CmisObjectNotFoundException(""));

        ItemIterable<CmisObject> result = repository.getAllChildsFromAlfrescoDirectory(folderPath);

        assertNull(result);
    }

}
