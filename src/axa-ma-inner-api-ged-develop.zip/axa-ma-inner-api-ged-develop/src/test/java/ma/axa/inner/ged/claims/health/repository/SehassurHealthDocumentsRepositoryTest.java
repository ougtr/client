package ma.axa.inner.ged.claims.health.repository;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import static  org.mockito.ArgumentMatchers.eq;
import static  org.mockito.ArgumentMatchers.any;
import static  org.mockito.ArgumentMatchers.anyString;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import ma.axa.inner.ged.claim.health.dto.DocumentUploadInvoiceRequest;
import ma.axa.inner.ged.claim.health.repository.SehassurHealthDocumentsRepository;
import ma.axa.inner.ged.exception.CallStoredProcedureException;
import ma.axa.inner.ged.util.DataGenerator;
import ma.axa.inner.ged.util.FormatterUtils;
 
@ContextConfiguration(classes = {SehassurHealthDocumentsRepository.class})
@ExtendWith(SpringExtension.class)
public class SehassurHealthDocumentsRepositoryTest {

 
	@MockBean
    private JdbcTemplate jdbcTemplate;
	@MockBean
    private FormatterUtils formatterUtils;
 
    @Autowired
    private SehassurHealthDocumentsRepository repository;
    

	@BeforeEach
	void initMockRepositories() {
		when(jdbcTemplate.update(Mockito.<String>any(), Mockito.<Object>any()
		)).thenReturn(1);
	}
  
    @Test
    void should_update_id_ged_uploaded()  {
 
		DocumentUploadInvoiceRequest request = DataGenerator.createDocumentUploadInvoiceRequest();
 
		assertDoesNotThrow(() -> repository.updateIdGed(request));
		
    }
    
 
    @Test()
   	void when_update_id_ged_uploaded_shouldThrowCallStoredProcedureException() {
    	when(formatterUtils.toBigDecimal(any())).thenReturn(new BigDecimal(20221212));
    	
    	when(jdbcTemplate.update(Mockito.<String>any(), Mockito.<Object>any()
           )).thenThrow(CallStoredProcedureException.class);
    	
		DocumentUploadInvoiceRequest request = DataGenerator.createDocumentUploadInvoiceRequest();
 
   		assertThrows(CallStoredProcedureException.class, () -> repository.updateIdGed(request));
   	}
    
    
    

	
}
