package ma.axa.inner.ged.mapper;

import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import ma.axa.inner.ged.claim.rd.domain.DocumentClaimRdEs;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdAddReq;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdResponse;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdUpdateReq;
import ma.axa.inner.ged.claim.rd.mapper.ClaimRdMapperImpl;

@ExtendWith(MockitoExtension.class)
public class ClaimRdMapperTest {
    
    @Mock
    private DocumentClaimRdEs document;

    @InjectMocks
    private ClaimRdMapperImpl claimRdMapper;

    @Test
    public void testToDto() {
        when(document.getAssureNom()).thenReturn("John");
        when(document.getAssurePrenom()).thenReturn("Doe");
        // mock other properties of document object
        
        DocClaimRdResponse docClaimRdResponse = claimRdMapper.toDto(document);
        
        assertNotNull(docClaimRdResponse);
        assertEquals("John", docClaimRdResponse.getAssureNom());
        assertEquals("Doe", docClaimRdResponse.getAssurePrenom());
        // test other properties of docClaimRdResponse object
    }

    @Test
    public void testToDtoList() {
        List<DocumentClaimRdEs> documents = new ArrayList<DocumentClaimRdEs>();
        // add some mock document objects to documents list

        List<DocClaimRdResponse> docClaimRdResponseList = claimRdMapper.toDto(documents);

        assertNotNull(docClaimRdResponseList);
        // test other properties of docClaimRdResponseList object
    }

    @Test
    public void testFromDto() {
        DocClaimRdAddReq docClaimRdAddReq = new DocClaimRdAddReq();
        docClaimRdAddReq.setAssureNom("John");
        docClaimRdAddReq.setAssurePrenom("Doe");
        // set other properties of docClaimRdAddReq object
        
        DocumentClaimRdEs documentClaimRdEs = claimRdMapper.fromDto(docClaimRdAddReq);

        assertNotNull(documentClaimRdEs);
        assertEquals("John", documentClaimRdEs.getAssureNom());
        assertEquals("Doe", documentClaimRdEs.getAssurePrenom());
        // test other properties of documentClaimRdEs object
    }

    @Test
    public void testFromDtoList() {
        List<DocClaimRdAddReq> docClaimRdAddReqList = new ArrayList<DocClaimRdAddReq>();
        // add some mock docClaimRdAddReq objects to docClaimRdAddReqList

        List<DocumentClaimRdEs> documentClaimRdEsList = claimRdMapper.fromDto(docClaimRdAddReqList);

        assertNotNull(documentClaimRdEsList);
        // test other properties of documentClaimRdEsList object
    }

//    @Test
//    public void testUpdateFromDto() {
//        DocClaimRdUpdateReq docClaimRdUpdateReq = new DocClaimRdUpdateReq();
//        docClaimRdUpdateReq.setAssureNom("John");
//        docClaimRdUpdateReq.setAssurePrenom("Doe");
//        // set other properties of docClaimRdUpdateReq object
//        
//        claimRdMapper.updateFromDto(docClaimRdUpdateReq, document);
//
//        assertEquals("John", document.getAssureNom());
//        assertEquals("Doe", document.getAssurePrenom());
//
//    }
    
}