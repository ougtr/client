package ma.axa.inner.ged.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import ma.axa.inner.ged.domain.parametrage.TypeDocumentParametrage;
import ma.axa.inner.ged.dto.parametrage.TypeDocumentResponseDto;
import ma.axa.inner.ged.mapper.parametrage.TypeDocumentParametrageMapper;
import ma.axa.inner.ged.mapper.parametrage.TypeDocumentParametrageMapperImpl;

public class TypeDocumentParametrageMapperTest {

    private TypeDocumentParametrageMapper mapper;

    @Mock
    private TypeDocumentParametrage typeDocumentParametrage;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mapper = new TypeDocumentParametrageMapperImpl();
    }

    @Test
    public void testMapToEntityDto() {
        // Set up the input object
        BigDecimal code = new BigDecimal("123");
        String libelle = "Test";
        when(typeDocumentParametrage.getCode()).thenReturn(code);
        when(typeDocumentParametrage.getLibelle()).thenReturn(libelle);

        // Call the mapToEntityDto() method
        TypeDocumentResponseDto result = mapper.mapToEntityDto(typeDocumentParametrage);

        // Verify the output object
        assertEquals(code.intValue(), result.getCodeTypeDocument());
        assertEquals(libelle, result.getLibelleTypeDocument());
    }

    @Test
    public void testMapToEntityDtoList() {
        // Set up the input list
        List<TypeDocumentParametrage> inputList = new ArrayList<>();
        BigDecimal code1 = new BigDecimal("123");
        String libelle1 = "Test1";
        TypeDocumentParametrage typeDocumentParametrage1 = new TypeDocumentParametrage(code1, libelle1);
        BigDecimal code2 = new BigDecimal("456");
        String libelle2 = "Test2";
        TypeDocumentParametrage typeDocumentParametrage2 = new TypeDocumentParametrage(code2, libelle2);
        inputList.add(typeDocumentParametrage1);
        inputList.add(typeDocumentParametrage2);

        // Call the mapToEntityDtoList() method
        List<TypeDocumentResponseDto> resultList = mapper.mapToEntityDtoList(inputList);

        // Verify the output list
        assertEquals(inputList.size(), resultList.size());
        assertEquals(code1.intValue(), resultList.get(0).getCodeTypeDocument());
        assertEquals(libelle1, resultList.get(0).getLibelleTypeDocument());
        assertEquals(code2.intValue(), resultList.get(1).getCodeTypeDocument());
        assertEquals(libelle2, resultList.get(1).getLibelleTypeDocument());
    }
}
