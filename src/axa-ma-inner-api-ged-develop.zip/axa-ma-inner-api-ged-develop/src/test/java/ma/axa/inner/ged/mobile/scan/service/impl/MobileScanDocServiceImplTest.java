package ma.axa.inner.ged.mobile.scan.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import ma.axa.inner.ged.claims.ls.util.ClaimLsDataGenerator;
import ma.axa.inner.ged.config.GedProperties;
import ma.axa.inner.ged.config.properties.GedMobileScanPropreties;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.domain.IndexOrPathToUse;
import ma.axa.inner.ged.exception.BusinessException;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.helper.ElasticSearchHelper;
import ma.axa.inner.ged.mapper.DocumentMapper;
import ma.axa.inner.ged.mobile.scan.dto.OcrDoc;
import ma.axa.inner.ged.mobile.scan.dto.OcrDocDto;
import ma.axa.inner.ged.mobile.scan.repository.OcrDocRepository;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.service.ManageDocumentService;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;
import ma.axa.inner.ged.util.constants.MobileScanStatutEnum;

@ExtendWith(MockitoExtension.class)
class MobileScanDocServiceImplTest {

	@Mock
	GedProperties gedProperties;
	@Mock
	private GedMobileScanPropreties.MsProperties msProperties;
	@Mock
	ElasticSearchHelper elasticSearchHelper;
	@Mock
	OcrDocRepository ocrDocRepository;
	@Mock
	ClaimDocumentRepository claimDocumentRepository;
	@Mock
	ManageDocumentService manageDocumentService;
	@InjectMocks
	MobileScanDocServiceImpl mobileScanDocServiceImpl;
	@Mock
	private Folder folder;
	@Mock
	private Document document;
	@Mock
	private MultipartFile file1;

	@Mock
	private MultipartFile file2;
	private static final String DATE_DELIMITOR = "/";

	@BeforeEach
	void setup() {

		mobileScanDocServiceImpl = new MobileScanDocServiceImpl(claimDocumentRepository, msProperties, gedProperties,
				elasticSearchHelper, ocrDocRepository);
		manageDocumentService = new ManageDocumentService(claimDocumentRepository);
	}

	@Test
	void uploadFileTempTestWithNullFile() {
		OcrDocDto ocrDocument = new OcrDocDto();
		String token = "test";
		assertThrows(BusinessException.class, () -> {
			mobileScanDocServiceImpl.uploadFileTemp(null, null, ocrDocument, token);
		});
	}

	@Test
	void testuploadMsFile() {
		GedDocument gedDoc = new GedDocument();
		assertThrows(GlobalException.class, () -> {
			mobileScanDocServiceImpl.uploadMsFile(IndexOrPathToUse.DEFAULT, gedDoc);
		});
	}

	@Test
	void uploadFileTempTest() throws IOException {
		OcrDoc ocrDocument = new OcrDoc();
		OcrDocDto ocrDocument2 = new OcrDocDto();
		ocrDocument.setToken("your_token");
		Mockito.lenient().when(ocrDocRepository.findByToken("your_token")).thenReturn(ocrDocument);
		Mockito.lenient().when(ocrDocRepository.save(ocrDocument)).thenReturn(ocrDocument);
		MockMultipartFile mockFile1 = new MockMultipartFile("file1", "file1.txt", "text/plain",
				"File 1 Content".getBytes());
		MockMultipartFile mockFile2 = new MockMultipartFile("file2", "file2.txt", "text/plain",
				"File 2 Content".getBytes());
		Mockito.lenient().when(file1.getOriginalFilename()).thenReturn(mockFile1.getOriginalFilename());
		Mockito.lenient().when(file1.getContentType()).thenReturn(mockFile1.getContentType());
		Mockito.lenient().when(file2.getOriginalFilename()).thenReturn(mockFile2.getOriginalFilename());
		Mockito.lenient().when(file2.getContentType()).thenReturn(mockFile2.getContentType());
		//when(mobileScanDocServiceImpl.copyProperties(ocrDocument, ocrDocument2)).thenReturn(new OcrDoc());
		

	}

	@Test
	void indexDocumentTest() {
		Mockito.lenient().when(ocrDocRepository.findByToken(any(String.class))).thenReturn(new OcrDoc());
		OcrDoc ocrDocument = new OcrDoc();
		ocrDocument.setIdAlfrescoVerso(ClaimLsDataGenerator.DOCUMENT_ID);
		ocrDocument.setIdAlfrescoRecto(ClaimLsDataGenerator.DOCUMENT_ID);
		assertNotNull(ocrDocument);
		assertNotNull(ocrDocument.getIdAlfrescoRecto());
		assertNotNull(ocrDocument.getIdAlfrescoVerso());

	}

	@Test
	public void testIndexDocument() {
		String token = "sampleToken";

		OcrDoc ocrDocument = mock(OcrDoc.class);
		when(ocrDocRepository.findByToken(token)).thenReturn(ocrDocument);

		// Set up mock values for ocrDocument
		String rectoId = "sampleRectoId";
		String versoId = "sampleVersoId";
		when(ocrDocument.getIdAlfrescoRecto()).thenReturn(rectoId);
		when(ocrDocument.getIdAlfrescoVerso()).thenReturn(versoId);
		MobileScanDocServiceImpl spyService = spy(mobileScanDocServiceImpl);
		spyService.indexDocument(token);
		verify(spyService).indexMetadaDocument(rectoId, ocrDocument);
		verify(spyService).indexMetadaDocument(versoId, ocrDocument);

		verify(ocrDocument).setStatut(MobileScanStatutEnum.INDEXE.toString());

		verify(ocrDocRepository).save(ocrDocument);
	}


	@Test
	public void testUploadDoc_Exception() throws Exception {
		MockMultipartFile file = new MockMultipartFile("file", null, "application/pdf", "content".getBytes());
		OcrDoc ocrDocument = mock(OcrDoc.class);
		assertThrows(GlobalException.class,
				() -> mobileScanDocServiceImpl.uploadDoc(IndexOrPathToUse.DEFAULT, ocrDocument, file));
	}

	@Test
	public void testUploadFileTemp_Exception() throws Exception {
		MockMultipartFile file1 = new MockMultipartFile("file", null, "application/pdf", "content".getBytes());
		MockMultipartFile file2 = new MockMultipartFile("file", null, "application/pdf", "content".getBytes());
		OcrDocDto ocrDocument = mock(OcrDocDto.class);
		String token = "test";
		assertThrows(GlobalException.class,
				() -> mobileScanDocServiceImpl.uploadFileTemp(file1, file2, ocrDocument, token));
	}

	@Test
	public void testUploadFileTempfileNull_Exception() throws Exception {
		OcrDocDto ocrDocument = mock(OcrDocDto.class);
		String token = "test";
		assertThrows(GlobalException.class,
				() -> mobileScanDocServiceImpl.uploadFileTemp(null, null, ocrDocument, token));
	}

	@Test
	void testCopyProperties() {
		OcrDoc ocrDocExist = mock(OcrDoc.class);
		OcrDocDto ocrDocDto = mock(OcrDocDto.class);
		// Arrange
		when(ocrDocExist.getId()).thenReturn(1);
		when(ocrDocExist.getTypeDocument()).thenReturn("cin");
		when(ocrDocExist.getToken()).thenReturn("ABC123");
		when(ocrDocDto.getTypeDocument()).thenReturn("cin");
		OcrDoc result = mobileScanDocServiceImpl.copyProperties(ocrDocExist, ocrDocDto);
		assertEquals(1, result.getId());
		assertEquals("cin", result.getTypeDocument());
		assertEquals("ABC123", result.getToken());
		assertEquals(MobileScanStatutEnum.OCIRISER.toString(), result.getStatut());

	}

	@Test
	void testWithExistingTokenAndNoFiles() {
		// Mock input parameters
		String token = "existingToken";
		MultipartFile file1 = null;
		MultipartFile file2 = null;
		OcrDocDto ocrDocumentDto = new OcrDocDto();
		OcrDoc ocrDocBDD = new OcrDoc();
		when(ocrDocRepository.findByToken(token)).thenReturn(ocrDocBDD);
		BusinessException exception = assertThrows(BusinessException.class,
				() -> mobileScanDocServiceImpl.uploadFileTemp(file1, file2, ocrDocumentDto, token));

		// Verify the repository interactions
		verify(ocrDocRepository).findByToken(token);
		verify(ocrDocRepository, never()).save(any());

		// Verify the thrown exception
		assertEquals("IL FAUT UPLOAD AU MOINS UN DOCUMENT !", exception.getMessage());
	}

	@Test
	void testUploadFileTempWithNonExistingToken() {
		// Mock input parameters
		String token = "nonExistingToken";
		MultipartFile file1 = new MockMultipartFile("file1", "file1.txt", "text/plain", "file1Content".getBytes());
		MultipartFile file2 = new MockMultipartFile("file2", "file2.txt", "text/plain", "file2Content".getBytes());
		OcrDocDto ocrDocumentDto = new OcrDocDto();

		// Mock repository behavior
		when(ocrDocRepository.findByToken(token)).thenReturn(null);

		// Perform the method call
		BusinessException exception = assertThrows(BusinessException.class,
				() -> mobileScanDocServiceImpl.uploadFileTemp(file1, file2, ocrDocumentDto, token));

		// Verify the repository interactions
		verify(ocrDocRepository).findByToken(token);
		verify(ocrDocRepository, never()).save(any());

		// Verify the thrown exception
		assertEquals("Token doesn't exist in data base !", exception.getMessage());
	}

	@Test
	void testUploadMsFileWithTemporaryIndex() {
		// Mock input parameters
		IndexOrPathToUse index = IndexOrPathToUse.TEMPORARY;
		GedDocument gedDocument = new GedDocument();
		Map<String, String> map = null;
		// Mock properties
		String prefixPath = "alfrescoSitePathalfrescoRootFolder";
		String alfrescoSitePath = "alfrescoSitePath";
		String alfrescoRootFolder = "alfrescoRootFolder";
		var date = LocalDate.now();
		String path= date.getYear() + DATE_DELIMITOR + date.getMonthValue() + DATE_DELIMITOR + date.getDayOfMonth();
		Map<String, Object> properties = new HashMap<>();
		properties.put(AXADocPropertyIds.IDENTIFIANT_SCANER,
				LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
		properties.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
		when(gedProperties.getOutbox()).thenReturn(prefixPath);
		when(msProperties.getAlfrescoSitePath()).thenReturn(alfrescoSitePath);
		when(msProperties.getAlfrescoRootFolder()).thenReturn(alfrescoRootFolder);
		when(claimDocumentRepository.createArboFoldersByPath(prefixPath, path)).thenReturn(folder);
		when(claimDocumentRepository.createDocument(folder, gedDocument)).thenReturn(document);

		when(mobileScanDocServiceImpl.uploadFile(properties, gedDocument, folder)).thenReturn(map);
		String result = mobileScanDocServiceImpl.uploadMsFile(index, gedDocument);

		verify(gedProperties).getOutbox();
		verify(msProperties).getAlfrescoSitePath();
		verify(msProperties).getAlfrescoRootFolder();
		verify(claimDocumentRepository).createArboFoldersByPath(prefixPath, path);

	}

	@Test
	void testUploadMsFileWithNonTemporaryIndex() {
		// Mock input parameters
		IndexOrPathToUse index = IndexOrPathToUse.DEFAULT;
		GedDocument gedDocument = new GedDocument();
		Map<String, String> map = null;
		Map<String, Object> properties = new HashMap<>();
		properties.put(AXADocPropertyIds.IDENTIFIANT_SCANER,
				LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
		properties.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
		String prefixPath = "prefixPath";
		var date = LocalDate.now();
		String path= date.getYear() + DATE_DELIMITOR + date.getMonthValue() + DATE_DELIMITOR + date.getDayOfMonth();	
		when(gedProperties.getOutbox()).thenReturn(prefixPath);
		when(claimDocumentRepository.createArboFoldersByPath(prefixPath, path)).thenReturn(folder);
		when(claimDocumentRepository.createDocument(folder, gedDocument)).thenReturn(document);
		when(mobileScanDocServiceImpl.uploadFile(properties, gedDocument, folder)).thenReturn(map);

		String result = mobileScanDocServiceImpl.uploadMsFile(index, gedDocument);

		// Verify the repository interactions
		verify(gedProperties).getOutbox();
		verify(claimDocumentRepository).createArboFoldersByPath(prefixPath, path);

	}
	
//	 @Test
//	    void testUploadFileTempWithValidTokenAndBothFiles() {
//	        // Mock input parameters
//	        MultipartFile file1 = new MockMultipartFile("file1", "file1.txt", "text/plain", "file1Content".getBytes());
//	        MultipartFile file2 = new MockMultipartFile("file2", "file2.txt", "text/plain", "file2Content".getBytes());
//	        OcrDocDto ocrDocumentDto = new OcrDocDto();
//	        String token = "validToken";
//	        OcrDoc ocrDocBDD = new OcrDoc();
//			Map<String, String> map = null;
//			//map.put("idAlfresco", "idAlfresco");
//			IndexOrPathToUse index = IndexOrPathToUse.TEMPORARY;
//			GedDocument gedDocument = new GedDocument();
//			String prefixPath = "alfrescoSitePathalfrescoRootFolder";
//			String alfrescoSitePath = "alfrescoSitePath";
//			String alfrescoRootFolder = "alfrescoRootFolder";
//			String path = "2023/5/30";
//			Map<String, Object> properties = new HashMap<>();
//			properties.put(AXADocPropertyIds.IDENTIFIANT_SCANER,
//					LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
//			properties.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
//			when(ocrDocRepository.findByToken(token)).thenReturn(new OcrDoc());
//			when(gedProperties.getOutbox()).thenReturn(prefixPath);
//			when(msProperties.getAlfrescoSitePath()).thenReturn(alfrescoSitePath);
//			when(msProperties.getAlfrescoRootFolder()).thenReturn(alfrescoRootFolder);
//			when(claimDocumentRepository.createArboFoldersByPath(prefixPath, path)).thenReturn(folder);
//			when(claimDocumentRepository.createDocument(folder, gedDocument)).thenReturn(document);
//			when(mobileScanDocServiceImpl.uploadFile(properties, gedDocument, folder)).thenReturn(map);				
//		  // when(mobileScanDocServiceImpl.uploadFileTemp(file1, file1, ocrDocumentDto, token)).thenReturn(new OcrDoc());
//		       
//			
//	        //when(ocrDocRepository.findByToken(token)).thenReturn(ocrDocBDD);
//	       // when(ocrDocRepository.save(ocrDocBDD)).thenReturn(ocrDocBDD);
//
//	        // Mock external method calls
//	        String idAlfrescoRecto = "rectoId";
//	        String idAlfrescoVerso = "versoId";
//	        when(mobileScanDocServiceImpl.uploadMsFile(index, gedDocument))
//	                .thenReturn(idAlfrescoRecto);
//	        when(mobileScanDocServiceImpl.uploadMsFile(index, gedDocument))
//	                .thenReturn(idAlfrescoVerso);
//           
//	        // Perform the method call
//            //MobileScanDocServiceImpl spyService = spy(mobileScanDocServiceImpl);
//            //verify(spyService).uploadFileTemp(file1, file2, ocrDocumentDto, token);
//	        when(mobileScanDocServiceImpl.uploadFile(properties, gedDocument, folder)).thenReturn(map);
//			
//	        when(mobileScanDocServiceImpl.uploadFileTemp(file1, file2, ocrDocumentDto, token)).thenReturn(new OcrDoc());
//	        //OcrDoc result = mobileScanDocServiceImpl.uploadFileTemp(file1, file2, ocrDocumentDto, token);
//
//	        // Verify the repository interactions
//	        //verify(ocrDocRepository).findByToken(token);
//	        //verify(ocrDocRepository).save(ocrDocBDD);
//
//	        // Verify the external method calls
//	       // verify(mobileScanDocServiceImpl).uploadMsFile(IndexOrPathToUse.TEMPORARY, DocumentMapper.mapFileToGedDocument(file1));
//	        //verify(mobileScanDocServiceImpl).uploadMsFile(IndexOrPathToUse.TEMPORARY, DocumentMapper.mapFileToGedDocument(file2));
//
//	        // Verify the assigned values
////	        assertEquals(idAlfrescoRecto, ocrDocBDD.getIdAlfrescoRecto());
////	        assertEquals(idAlfrescoVerso, ocrDocBDD.getIdAlfrescoVerso());
////	        assertEquals(ocrDocBDD, result);
//	    }
}
