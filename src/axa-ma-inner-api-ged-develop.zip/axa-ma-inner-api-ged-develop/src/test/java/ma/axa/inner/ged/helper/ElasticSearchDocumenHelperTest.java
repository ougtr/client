package ma.axa.inner.ged.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import lombok.val;
import ma.axa.inner.ged.config.ConcurrentCompletableFuture;
import ma.axa.inner.ged.domain.*;
import ma.axa.inner.ged.domain.at.DocumentSinistreATES;
import ma.axa.inner.ged.domain.at.ESDocumentAtSchema;
import ma.axa.inner.ged.domain.at.EsDocumentAtCountSchema;
import ma.axa.inner.ged.dto.at.DocumentMetadataQueryDto;
import ma.axa.inner.ged.exception.BusinessException;
import ma.axa.inner.ged.exception.ESIndexingException;
import ma.axa.inner.ged.helper.update.ESDoc;
import ma.axa.inner.ged.helper.update.ESUpdateQuery;
import ma.axa.inner.ged.repository.ElasticSearchDocumentRepository;
import ma.axa.inner.ged.util.DataGenerator;
import ma.axa.inner.ged.util.EsPropertiesAtDoc;
import ma.axa.inner.ged.util.EsPropertiesAutoDocument;
import ma.axa.inner.ged.util.EsPropertiesCimaDoc;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.util.AssertionErrors.assertTrue;


@ExtendWith(MockitoExtension.class)
@EnableConfigurationProperties(value = EsPropertiesAutoDocument.class)
@TestPropertySource("classpath:test.properties")
class ElasticSearchDocumenHelperTest {
    @Mock
    ElasticSearchDocumentRepository elasticSearchDocumentRepository;
    @Mock
    EsPropertiesAutoDocument esPropertiesAutoDocument;

    @Mock
    EsPropertiesAtDoc esPropertiesAtDoc;
    @Mock
    EsPropertiesCimaDoc esPropertiesCimaDoc;
    ;
    @InjectMocks
    ElasticSearchHelper elasticSearchHelper;


    @BeforeEach
    void setup() {
        esPropertiesAutoDocument.setIndex("sinistre");
        esPropertiesAutoDocument.setTempIndex("temporary");
        esPropertiesAtDoc.setIndex("claimat");
        esPropertiesAtDoc.setTempIndex("temporary-at");
        elasticSearchHelper = new ElasticSearchHelper(elasticSearchDocumentRepository, esPropertiesAutoDocument, esPropertiesAtDoc, esPropertiesCimaDoc);

    }

    @Test
    void getDossiers_test() throws JsonMappingException, JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        var output = "{\r\n"
                + "    \"took\": 1,\r\n"
                + "    \"timed_out\": false,\r\n"
                + "    \"_shards\": {\r\n"
                + "        \"total\": 5,\r\n"
                + "        \"successful\": 5,\r\n"
                + "        \"failed\": 0\r\n"
                + "    },\r\n"
                + "    \"hits\": {\r\n"
                + "        \"total\": 163,\r\n"
                + "        \"max_score\": 1.0,\r\n"
                + "        \"hits\": [\r\n"
                + "            {\r\n"
                + "                \"_index\": \"dossier_sin_auto\",\r\n"
                + "                \"_type\": \"dossier_sin_auto\",\r\n"
                + "                \"_id\": \"547477112\",\r\n"
                + "                \"_score\": 1.0,\r\n"
                + "                \"_source\": {\r\n"
                + "                    \"predec\": \"P202100006444\",\r\n"
                + "                    \"numSinistre\": 2.02100000163E11,\r\n"
                + "                    \"polnum\": 1.5602011100004E13,\r\n"
                + "                    \"dateSinistre\": 0,\r\n"
                + "                    \"codeAgent\": 1560,\r\n"
                + "                    \"nomAssure\": null,\r\n"
                + "                    \"nomVictimes\": [\r\n"
                + "                        \"STE ENTREPRISE E.N.I.B.A.C\"\r\n"
                + "                    ],\r\n"
                + "                    \"numJuridiction\": [],\r\n"
                + "                    \"matricule\": \"012447-A -58\",\r\n"
                + "                    \"natureSin\": null\r\n"
                + "                }\r\n"
                + "            },\r\n"
                + "            {\r\n"
                + "                \"_index\": \"dossier_sin_auto\",\r\n"
                + "                \"_type\": \"dossier_sin_auto\",\r\n"
                + "                \"_id\": \"303329894\",\r\n"
                + "                \"_score\": 1.0,\r\n"
                + "                \"_source\": {\r\n"
                + "                    \"predec\": \"P202100017425\",\r\n"
                + "                    \"numSinistre\": 2.01900120219E11,\r\n"
                + "                    \"polnum\": 3.762018100919E12,\r\n"
                + "                    \"dateSinistre\": 0,\r\n"
                + "                    \"codeAgent\": 376,\r\n"
                + "                    \"nomAssure\": null,\r\n"
                + "                    \"nomVictimes\": [\r\n"
                + "                        \"MME BAYADARA HANANE\"\r\n"
                + "                    ],\r\n"
                + "                    \"numJuridiction\": [],\r\n"
                + "                    \"matricule\": \"036321-A -55\",\r\n"
                + "                    \"natureSin\": null\r\n"
                + "                }\r\n"
                + "            }\r\n"
                + "        ]\r\n"
                + "    }\r\n"
                + "}";
        var repoShouldReturn = objectMapper.readValue(output, ESDossierSchema.class);
        when(elasticSearchDocumentRepository.getDossiers(any(RequestQuery.class)))
                .thenReturn(repoShouldReturn);
        var expectedOutput = "[\r\n"
                + "  {\r\n"
                + "    \"predec\": \"P202100006444\",\r\n"
                + "    \"numSinistre\": 202100000163,\r\n"
                + "    \"polnum\": 15602011100004,\r\n"
                + "    \"dateSinistre\": 0,\r\n"
                + "    \"codeAgent\": 1560,\r\n"
                + "    \"nomAssure\": null,\r\n"
                + "    \"nomVictimes\": [\r\n"
                + "      \"STE ENTREPRISE E.N.I.B.A.C\"\r\n"
                + "    ],\r\n"
                + "    \"numJuridiction\": [],\r\n"
                + "    \"matricule\": \"012447-A -58\",\r\n"
                + "    \"natureSin\": null\r\n"
                + "  },\r\n"
                + "  {\r\n"
                + "    \"predec\": \"P202100017425\",\r\n"
                + "    \"numSinistre\": 201900120219,\r\n"
                + "    \"polnum\": 3762018100919,\r\n"
                + "    \"dateSinistre\": 0,\r\n"
                + "    \"codeAgent\": 376,\r\n"
                + "    \"nomAssure\": null,\r\n"
                + "    \"nomVictimes\": [\r\n"
                + "      \"MME BAYADARA HANANE\"\r\n"
                + "    ],\r\n"
                + "    \"numJuridiction\": [],\r\n"
                + "    \"matricule\": \"036321-A -55\",\r\n"
                + "    \"natureSin\": null\r\n"
                + "  }\r\n"
                + "]";
        var serviceShouldReturn = objectMapper.readValue(expectedOutput, DossierSinistreAuto[].class);
        var dossier = new DossierSinistreAuto();
        assertThat(elasticSearchHelper.getDossierSinAutoList(dossier))
                .isEqualTo(Arrays.asList(serviceShouldReturn));
    }

    @Test
    void getDocuments_test() throws JsonMappingException, JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        var output = "{\r\n"
                + "  \"took\": 16,\r\n"
                + "  \"timed_out\": false,\r\n"
                + "  \"_shards\": {\r\n"
                + "    \"total\": 5,\r\n"
                + "    \"successful\": 5,\r\n"
                + "    \"failed\": 0\r\n"
                + "  },\r\n"
                + "  \"hits\": {\r\n"
                + "    \"total\": 1430,\r\n"
                + "    \"max_score\": 1,\r\n"
                + "    \"hits\": [\r\n"
                + "      {\r\n"
                + "        \"_index\": \"sinistre\",\r\n"
                + "        \"_type\": \"sinistre\",\r\n"
                + "        \"_id\": \"workspace://SpacesStore/a47386b4-47b1-4fa6-afc4-840d314f4298\",\r\n"
                + "        \"_score\": 1,\r\n"
                + "        \"_source\": {\r\n"
                + "          \"idPredeclaration\": \"P202100017425\",\r\n"
                + "          \"idAlfresco\": \"workspace://SpacesStore/a47386b4-47b1-4fa6-afc4-840d314f4298\",\r\n"
                + "          \"nSin\": \"201900120219\",\r\n"
                + "          \"polnum\": 3762018100919,\r\n"
                + "          \"typeDoc\": \"2\",\r\n"
                + "          \"nomFile\": \"202000073480_01_ca_1.pdf\",\r\n"
                + "          \"nomVictime\": \"\",\r\n"
                + "          \"emplacement\": \"\",\r\n"
                + "          \"userC\": \"crmsiege\",\r\n"
                + "          \"dateC\": 20210503,\r\n"
                + "          \"dateHeureC\": \"03/05/2021 12:28:25\",\r\n"
                + "          \"dateA\": 0,\r\n"
                + "          \"Aclasser\": 0,\r\n"
                + "          \"AclasserPar\": \"\",\r\n"
                + "          \"AclasserLe\": 0,\r\n"
                + "          \"formDoc\": \"pdf\"\r\n"
                + "        }\r\n"
                + "      }\r\n"
                + "    ]\r\n"
                + "  }\r\n"
                + "}";
        var repoShouldReturn = objectMapper.readValue(output, ESDocumentSchema.class);
        when(elasticSearchDocumentRepository.getDocuments(any(), any(RequestQuery.class)))
                .thenReturn(repoShouldReturn);
        var expectedOutput = "[\r\n"
                + "  {\r\n"
                + "    \"idPredeclaration\": \"P202100017425\",\r\n"
                + "    \"idAlfresco\": \"workspace://SpacesStore/a47386b4-47b1-4fa6-afc4-840d314f4298\",\r\n"
                + "    \"nSin\": \"201900120219\",\r\n"
                + "    \"polnum\": 3762018100919,\r\n"
                + "    \"typeDoc\": \"2\",\r\n"
                + "    \"nomFile\": \"202000073480_01_ca_1.pdf\",\r\n"
                + "    \"nomVictime\": \"\",\r\n"
                + "    \"emplacement\": \"\",\r\n"
                + "    \"userC\": \"crmsiege\",\r\n"
                + "    \"dateC\": 20210503,\r\n"
                + "    \"dateHeureC\": \"03/05/2021 12:28:25\",\r\n"
                + "    \"dateA\": 0,\r\n"
                + "    \"Aclasser\": 0,\r\n"
                + "    \"AclasserPar\": \"\",\r\n"
                + "    \"AclasserLe\": 0,\r\n"
                + "    \"formDoc\": \"pdf\"\r\n"
                + "  }\r\n"
                + "]";
        var serviceShouldReturn = objectMapper.readValue(expectedOutput, PreDeclarationTypeDoc[].class);
        assertThat(elasticSearchHelper.getDocumentsList(IndexOrPathToUse.DEFAULT, "nSin", "test"))
                .isEqualTo(Arrays.asList(serviceShouldReturn));
    }


    @Test
    void addDossierSinistre_id_random_test() throws JsonMappingException, JsonProcessingException {
        var dossierSinistreAuto = new DossierSinistreAuto();
        dossierSinistreAuto.setPolnum(BigDecimal.valueOf(123.456));
        dossierSinistreAuto.setPredec("test");
        dossierSinistreAuto.setPredec(dossierSinistreAuto.getPredec().trim());

        var res = new ESResponse();
        res.setCreated(true);
        res.setId("id");
        when(elasticSearchDocumentRepository.addIndexDossierSinAuto(any(DossierSinistreAuto.class), any(String.class))).thenReturn(res);
        dossierSinistreAuto.setId(null);
        var spyService = spy(elasticSearchHelper);
        doReturn(null).when(spyService).getDossierSinAutoList(any(DossierSinistreAuto.class));
        var out = spyService.addDossierSinistre(dossierSinistreAuto);
        assertThat(out).isNotNull();

    }

    @Test
    void addDossierSinistre_id_from_dossierlist_test() throws JsonMappingException, JsonProcessingException {
        var dossierSinistreAuto = new DossierSinistreAuto();
        dossierSinistreAuto.setPolnum(BigDecimal.valueOf(123.456));
        dossierSinistreAuto.setPredec("test");

        var output = "{\r\n"
                + "    \"took\": 1,\r\n"
                + "    \"timed_out\": false,\r\n"
                + "    \"_shards\": {\r\n"
                + "        \"total\": 5,\r\n"
                + "        \"successful\": 5,\r\n"
                + "        \"failed\": 0\r\n"
                + "    },\r\n"
                + "    \"hits\": {\r\n"
                + "        \"total\": 163,\r\n"
                + "        \"max_score\": 1.0,\r\n"
                + "        \"hits\": [\r\n"
                + "            {\r\n"
                + "                \"_index\": \"dossier_sin_auto\",\r\n"
                + "                \"_type\": \"dossier_sin_auto\",\r\n"
                + "                \"_id\": \"547477112\",\r\n"
                + "                \"_score\": 1.0,\r\n"
                + "                \"_source\": {\r\n"
                + "                    \"predec\": \"P202100006444\",\r\n"
                + "                    \"numSinistre\": 2.02100000163E11,\r\n"
                + "                    \"polnum\": 1.5602011100004E13,\r\n"
                + "                    \"dateSinistre\": 0,\r\n"
                + "                    \"codeAgent\": 1560,\r\n"
                + "                    \"nomAssure\": null,\r\n"
                + "                    \"nomVictimes\": [\r\n"
                + "                        \"STE ENTREPRISE E.N.I.B.A.C\"\r\n"
                + "                    ],\r\n"
                + "                    \"numJuridiction\": [],\r\n"
                + "                    \"matricule\": \"012447-A -58\",\r\n"
                + "                    \"natureSin\": null\r\n"
                + "                }\r\n"
                + "            },\r\n"
                + "            {\r\n"
                + "                \"_index\": \"dossier_sin_auto\",\r\n"
                + "                \"_type\": \"dossier_sin_auto\",\r\n"
                + "                \"_id\": \"303329894\",\r\n"
                + "                \"_score\": 1.0,\r\n"
                + "                \"_source\": {\r\n"
                + "                    \"predec\": \"P202100017425\",\r\n"
                + "                    \"numSinistre\": 2.01900120219E11,\r\n"
                + "                    \"polnum\": 3.762018100919E12,\r\n"
                + "                    \"dateSinistre\": 0,\r\n"
                + "                    \"codeAgent\": 376,\r\n"
                + "                    \"nomAssure\": null,\r\n"
                + "                    \"nomVictimes\": [\r\n"
                + "                        \"MME BAYADARA HANANE\"\r\n"
                + "                    ],\r\n"
                + "                    \"numJuridiction\": [],\r\n"
                + "                    \"matricule\": \"036321-A -55\",\r\n"
                + "                    \"natureSin\": null\r\n"
                + "                }\r\n"
                + "            }\r\n"
                + "        ]\r\n"
                + "    }\r\n"
                + "}";

        ObjectMapper objectMapper = new ObjectMapper();
        var repoShouldReturn = objectMapper.readValue(output, ESDossierSchema.class);

        when(elasticSearchDocumentRepository.getDossiers(any(RequestQuery.class)))
                .thenReturn(repoShouldReturn);

        dossierSinistreAuto.setPredec(dossierSinistreAuto.getPredec().trim());

        var res = new ESResponse();
        res.setCreated(true);
        res.setId("id");
        when(elasticSearchDocumentRepository.addIndexDossierSinAuto(any(DossierSinistreAuto.class), any(String.class))).thenReturn(res);
        var out = elasticSearchHelper.addDossierSinistre(dossierSinistreAuto);
        assertThat(out).isNotNull();

    }

    @Test
    void addDossierSinAutoAndSinistres_with_predec_test() throws JsonMappingException, JsonProcessingException {
        var dossierSinistreAuto = new DossierSinistreAuto();
        dossierSinistreAuto.setPredec("test");

        ObjectMapper objectMapper = new ObjectMapper();
        var output = "{\r\n"
                + "  \"took\": 16,\r\n"
                + "  \"timed_out\": false,\r\n"
                + "  \"_shards\": {\r\n"
                + "    \"total\": 5,\r\n"
                + "    \"successful\": 5,\r\n"
                + "    \"failed\": 0\r\n"
                + "  },\r\n"
                + "  \"hits\": {\r\n"
                + "    \"total\": 1430,\r\n"
                + "    \"max_score\": 1,\r\n"
                + "    \"hits\": [\r\n"
                + "      {\r\n"
                + "        \"_index\": \"sinistre\",\r\n"
                + "        \"_type\": \"sinistre\",\r\n"
                + "        \"_id\": \"workspace://SpacesStore/a47386b4-47b1-4fa6-afc4-840d314f4298\",\r\n"
                + "        \"_score\": 1,\r\n"
                + "        \"_source\": {\r\n"
                + "          \"idPredeclaration\": \"P202100017425\",\r\n"
                + "          \"idAlfresco\": \"workspace://SpacesStore/a47386b4-47b1-4fa6-afc4-840d314f4298\",\r\n"
                + "          \"nSin\": \"201900120219\",\r\n"
                + "          \"polnum\": 3762018100919,\r\n"
                + "          \"typeDoc\": \"2\",\r\n"
                + "          \"nomFile\": \"202000073480_01_ca_1.pdf\",\r\n"
                + "          \"nomVictime\": \"\",\r\n"
                + "          \"emplacement\": \"\",\r\n"
                + "          \"userC\": \"crmsiege\",\r\n"
                + "          \"dateC\": 20210503,\r\n"
                + "          \"dateHeureC\": \"03/05/2021 12:28:25\",\r\n"
                + "          \"dateA\": 0,\r\n"
                + "          \"Aclasser\": 0,\r\n"
                + "          \"AclasserPar\": \"\",\r\n"
                + "          \"AclasserLe\": 0,\r\n"
                + "          \"formDoc\": \"pdf\"\r\n"
                + "        }\r\n"
                + "      }\r\n"
                + "    ]\r\n"
                + "  }\r\n"
                + "}";
        var repoShouldReturn = objectMapper.readValue(output, ESDocumentSchema.class);
        when(elasticSearchDocumentRepository.getDocuments(any(), any(RequestQuery.class)))
                .thenReturn(repoShouldReturn);

        var res = new ESResponse();

        res.setCreated(true);

        when(elasticSearchDocumentRepository.addIndex(any(), any(), any())).thenReturn(res);
        var spyService = spy(elasticSearchHelper);
        doReturn(res).when(spyService).addDossierSinistre(any(DossierSinistreAuto.class));
        var out = spyService.addDossierSinAutoAndSinistres(dossierSinistreAuto);
        assertThat(out).isNotNull();

    }

    @Test
    void addDossierSinAutoAndSinistres_with_sinistre_test() throws JsonMappingException, JsonProcessingException {
        var dossierSinistreAuto = new DossierSinistreAuto();
        dossierSinistreAuto.setNumSinistre(BigDecimal.valueOf(123.456));

        ObjectMapper objectMapper = new ObjectMapper();
        var output = "{\r\n"
                + "  \"took\": 16,\r\n"
                + "  \"timed_out\": false,\r\n"
                + "  \"_shards\": {\r\n"
                + "    \"total\": 5,\r\n"
                + "    \"successful\": 5,\r\n"
                + "    \"failed\": 0\r\n"
                + "  },\r\n"
                + "  \"hits\": {\r\n"
                + "    \"total\": 1430,\r\n"
                + "    \"max_score\": 1,\r\n"
                + "    \"hits\": [\r\n"
                + "      {\r\n"
                + "        \"_index\": \"sinistre\",\r\n"
                + "        \"_type\": \"sinistre\",\r\n"
                + "        \"_id\": \"workspace://SpacesStore/a47386b4-47b1-4fa6-afc4-840d314f4298\",\r\n"
                + "        \"_score\": 1,\r\n"
                + "        \"_source\": {\r\n"
                + "          \"idPredeclaration\": \"P202100017425\",\r\n"
                + "          \"idAlfresco\": \"workspace://SpacesStore/a47386b4-47b1-4fa6-afc4-840d314f4298\",\r\n"
                + "          \"nSin\": \"201900120219\",\r\n"
                + "          \"polnum\": 3762018100919,\r\n"
                + "          \"typeDoc\": \"2\",\r\n"
                + "          \"nomFile\": \"202000073480_01_ca_1.pdf\",\r\n"
                + "          \"nomVictime\": \"\",\r\n"
                + "          \"emplacement\": \"\",\r\n"
                + "          \"userC\": \"crmsiege\",\r\n"
                + "          \"dateC\": 20210503,\r\n"
                + "          \"dateHeureC\": \"03/05/2021 12:28:25\",\r\n"
                + "          \"dateA\": 0,\r\n"
                + "          \"Aclasser\": 0,\r\n"
                + "          \"AclasserPar\": \"\",\r\n"
                + "          \"AclasserLe\": 0,\r\n"
                + "          \"formDoc\": \"pdf\"\r\n"
                + "        }\r\n"
                + "      }\r\n"
                + "    ]\r\n"
                + "  }\r\n"
                + "}";
        var repoShouldReturn = objectMapper.readValue(output, ESDocumentSchema.class);
        when(elasticSearchDocumentRepository.getDocuments(any(), any(RequestQuery.class)))
                .thenReturn(repoShouldReturn);

        var res = new ESResponse();

        res.setCreated(true);

        when(elasticSearchDocumentRepository.addIndex(any(), any(), any())).thenReturn(res);
        var spyService = spy(elasticSearchHelper);
        doReturn(res).when(spyService).addDossierSinistre(any(DossierSinistreAuto.class));
        var out = spyService.addDossierSinAutoAndSinistres(dossierSinistreAuto);
        assertThat(out).isNotNull();

    }

    @Test
    void Should_Add_Index_Dossier_AT() {
        var esResponse = new ESResponse();
        when(elasticSearchDocumentRepository.addIndexDossierAT(any(), any())).thenReturn(esResponse);

        var out = elasticSearchHelper.addIndexDossierAT(new ESDossierATRequest(), "");
        assertThat(out).isNotNull();
    }

    @Test
    void Should_Throw_ESIndexingException_When_Add_Index_Dossier_AT() {
        when(elasticSearchDocumentRepository.addIndexDossierAT(any(), any())).thenThrow(FeignException.class);
        var request = new ESDossierATRequest();
        assertThrows(ESIndexingException.class, () -> elasticSearchHelper.addIndexDossierAT(request, ""));
    }

    @Test
    void Should_Add_Index_Document_AT() {
        var esResponse = new ESResponse();
        when(elasticSearchDocumentRepository.addIndexDocumentAT(any())).thenReturn(esResponse);

        var out = elasticSearchHelper.addIndexDocumentAT(new ESDocumentATRequest());
        assertThat(out).isNotNull();
    }

    @Test
    void Should_Add_Index_Document_Production() {
        var esResponse = new ESResponse();
        when(elasticSearchDocumentRepository.addIndexProduction(any(), any())).thenReturn(esResponse);
        var out = elasticSearchHelper.addDocumentProduction(new ESDocumentProductionRequest(), "idAlfresco");
        assertThat(out).isNotNull();
    }

    @Test
    void Should_Throw_ESIndexingException_When_Add_Index_Document_AT() {
        when(elasticSearchDocumentRepository.addIndexDocumentAT(any())).thenThrow(FeignException.class);
        var request = new ESDocumentATRequest();
        assertThrows(ESIndexingException.class, () -> elasticSearchHelper.addIndexDocumentAT(request));
    }

    @Test
    void updateMetadata_test() throws JsonProcessingException {
        val idAlfresco = "123-345-567";
        val mapper = new ObjectMapper();
        ESUpdateQuery updateQuery = ESUpdateQuery.builder()
                .doc(new ESDoc(DataGenerator.preDeclarationTypeDocBuilder().get(0)))
                .build();
        val strJson = mapper.writeValueAsString(updateQuery);

        assertTrue("", containsString("entiteEnregistrement").matches(strJson));
        assertTrue("", !containsString("receptionDate").matches(strJson));
        when(elasticSearchDocumentRepository.updateMetadata(any(), any(), any())).thenReturn(
                DataGenerator.esResponseBuilder().get(0)
        );
        var out = elasticSearchHelper.updateMetadata(IndexOrPathToUse.DEFAULT, DataGenerator.preDeclarationTypeDocBuilder().get(0), idAlfresco);
        assertThat(out).isNotNull();
    }

    @Test
    void updateMetadata_test_with_no_prefixed_id() throws JsonProcessingException {
        val idAlfresco = "123-345-567";
        val mapper = new ObjectMapper();
        ESUpdateQuery updateQuery = ESUpdateQuery.builder()
                .doc(new ESDoc(DataGenerator.preDeclarationTypeDocBuilder().get(0)))
                .build();
        val strJson = mapper.writeValueAsString(updateQuery);

        assertTrue( "",containsString("entiteEnregistrement").matches(strJson));
        assertTrue("",!containsString("receptionDate").matches(strJson));
        when(elasticSearchDocumentRepository.updateMetadata(any(),any(),any()))
                .thenThrow(BusinessException.class)
                .thenReturn(
                        DataGenerator.esResponseBuilder().get(0));
        var out  = elasticSearchHelper.updateMetadata(IndexOrPathToUse.DEFAULT,DataGenerator.preDeclarationTypeDocBuilder().get(0),idAlfresco);
        assertThat(out).isNotNull();
    }

    @Test
    void addDocumentSinistre_test_temporary_branch() {
        val result = ESResponse.builder().build();
        val respIndex = ESResponseIndex.builder().acknowledged(true).build();

        when(elasticSearchDocumentRepository.addIndex(any(), any(), any())).thenReturn(result);
        when(elasticSearchDocumentRepository.createTemporaryIndex()).thenReturn(respIndex);

        doThrow(FeignException.class).when(elasticSearchDocumentRepository).checkIndexExistence(any());
        assertEquals(
                elasticSearchHelper.addDocumentSinistre(PreDeclarationTypeDoc.builder().build(), "123-456-789", IndexOrPathToUse.TEMPORARY), result
        );
        respIndex.setAcknowledged(false);
        assertThrows(ESIndexingException.class, () -> elasticSearchHelper.addDocumentSinistre(PreDeclarationTypeDoc.builder().build(), "123-456-789", IndexOrPathToUse.TEMPORARY));

    }

    @Test
    void deleteMetadata() {
        val result = ESResponse.builder().build();

        when(elasticSearchDocumentRepository.deleteDocumentsMetadata(any(), any())).thenReturn(result);

        assertEquals(elasticSearchHelper.deleteMetadata("123-456-789", IndexOrPathToUse.TEMPORARY), result);
    }


    @Test
    void deleteAtMetadata() {
        val result = ESResponse.builder().build();

        when(elasticSearchDocumentRepository.deleteAtDocumentsMetadata(any(), any())).thenReturn(result);

        assertEquals(elasticSearchHelper.deleteAtMetadata(IndexOrPathToUse.TEMPORARY, "123-456-789"), result);
    }

    @Test
    void updateAtMetadata_test() throws JsonProcessingException {
        val idAlfresco = "123";
        ESDocumentATRequest docClaimAtReqDto = new ESDocumentATRequest();
        docClaimAtReqDto.setNumSinistre("123456");
        docClaimAtReqDto.setTypeDocument("cin");
        val mapper = new ObjectMapper();
        ESUpdateQuery updateQuery = ESUpdateQuery.builder()
                .doc(new ESDoc(DataGenerator.preDeclarationTypeDocBuilder().get(0)))
                .build();
        val strJson = mapper.writeValueAsString(updateQuery);

        assertTrue("", containsString("entiteEnregistrement").matches(strJson));
        assertTrue("", !containsString("receptionDate").matches(strJson));
        when(elasticSearchDocumentRepository.updateAtMetadata(any(), any(), any())).thenReturn(
                DataGenerator.esResponseBuilder().get(0)
        );
        var out = elasticSearchHelper.updateAtMetadata(IndexOrPathToUse.DEFAULT, docClaimAtReqDto, idAlfresco);
        assertThat(out).isNotNull();
    }

    @Test
    void testAddAtDocument_temporary() {
        ESDocumentATRequest esDocumentATRequest = new ESDocumentATRequest();
        String idAlfresco = "123";

        val result = ESResponse.builder().build();
        val respIndex = ESResponseIndex.builder().acknowledged(true).build();

        when(elasticSearchDocumentRepository.addAtIndex(any(), any(), any())).thenReturn(result);
        when(elasticSearchDocumentRepository.createAtTemporaryIndex(any())).thenReturn(respIndex);

        doThrow(FeignException.class).when(elasticSearchDocumentRepository).checkIndexExistence(any());
        assertEquals(
                elasticSearchHelper.addAtDocument(IndexOrPathToUse.TEMPORARY, esDocumentATRequest, idAlfresco), result
        );
        respIndex.setAcknowledged(false);
        assertThrows(ESIndexingException.class, () -> elasticSearchHelper.addAtDocument(IndexOrPathToUse.TEMPORARY, esDocumentATRequest, idAlfresco));

    }

    @Test
    void getAtDocuments_test() throws JsonMappingException, JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        var output = "{\r\n"
                + "  \"took\": 16,\r\n"
                + "  \"timed_out\": false,\r\n"
                + "  \"_shards\": {\r\n"
                + "    \"total\": 5,\r\n"
                + "    \"successful\": 5,\r\n"
                + "    \"failed\": 0\r\n"
                + "  },\r\n"
                + "  \"hits\": {\r\n"
                + "    \"total\": 1430,\r\n"
                + "    \"max_score\": 1,\r\n"
                + "    \"hits\": [\r\n"
                + "      {\r\n"
                + "        \"_index\": \"temporary-at\",\r\n"
                + "        \"_type\": \"documentat\",\r\n"
                + "        \"_id\": \"workspace://SpacesStore/a47386b4-47b1-4fa6-afc4-840d314f4298\",\r\n"
                + "        \"_score\": 1,\r\n"
                + "        \"_source\": {\r\n"
                + "          \"idalfersco\": \"workspace://SpacesStore/a47386b4-47b1-4fa6-afc4-840d314f4298\",\r\n"
                + "          \"numsinistre\": \"201900120219\",\r\n"
                + "          \"typeDocument\": \"cin\",\r\n"
                + "          \"nomdocument\": \"202000073480_01_ca_1.pdf\",\r\n"
                + "          \"iddoc\": \"user\",\r\n"
                + "          \"uploadedby\": \"20230202\"\r\n"
                + "      }\r\n"
                + "      }\r\n"
                + "    ]\r\n"
                + "  }\r\n"
                + "}";
        var repoShouldReturn = objectMapper.readValue(output, ESDocumentAtSchema.class);
        when(elasticSearchDocumentRepository.getAtDocuments(any(), any(RequestQuery.class)))
                .thenReturn(repoShouldReturn);
        var expectedOutput = "[\r\n"
                + "  {\r\n"
                + "    \"idalfersco\": \"workspace://SpacesStore/a47386b4-47b1-4fa6-afc4-840d314f4298\",\r\n"
                + "    \"numsinistre\": \"201900120219\",\r\n"
                + "     \"typeDocument\": \"cin\",\r\n"
                + "      \"nomdocument\": \"202000073480_01_ca_1.pdf\",\r\n"
                + "       \"iddoc\": \"user\",\r\n"
                + "        \"uploadedby\": \"20230202\"\r\n"
                + "  }\r\n"
                + "]";
        var serviceShouldReturn = objectMapper.readValue(expectedOutput, DocumentSinistreATES[].class);
        assertThat(elasticSearchHelper.getAtDocumentsList(IndexOrPathToUse.DEFAULT, "numsinistre", "test"))
                .isEqualTo(Arrays.asList(serviceShouldReturn));
    }

    @Test
    void testSearchInDocumentsListsByQuery() {
        DocumentMetadataQueryDto document = DocumentMetadataQueryDto.builder()
                .id("1234")
                .claimNumber("1234")
                .documentId("abc")
                .isReturnedRO(true)
                .build();
        var esCountDocument = new EsDocumentAtCountSchema();
        esCountDocument.setCount(DataGenerator.searchInDocumentsATResponse().getHits().getTotal());

        when(elasticSearchDocumentRepository.getAtDocuments(any(), any()))
                .thenReturn(DataGenerator.searchInDocumentsATResponse());
        when(elasticSearchDocumentRepository.countAtDocumentsByQuery(any(), any())).thenReturn(
                esCountDocument
        );
        assertNotNull(elasticSearchHelper.searchInDocumentsListsByQuery(IndexOrPathToUse.DEFAULT, document, 0, 20));
        document.setIsReturnedRO(false);
        assertNotNull(elasticSearchHelper.searchInDocumentsListsByQuery(IndexOrPathToUse.TEMPORARY, document, 0, 20));
        assertNotNull(elasticSearchHelper.searchInDocumentsListsByQuery(IndexOrPathToUse.TEMPORARY, DocumentMetadataQueryDto.builder().build(), 0, 20));

    }

    @Test
    void testGetAllInDocumentsMetadataAt() {
        ReflectionTestUtils.setField(ConcurrentCompletableFuture.class, "poolSize", 200);
        DocumentMetadataQueryDto metadataQuery = DocumentMetadataQueryDto.builder()
                .id("1234")
                .claimNumber("1234")
                .documentId("abc")
                .isReturnedRO(true)
                .build();
        var esCountDocument = new EsDocumentAtCountSchema();
        esCountDocument.setCount(DataGenerator.searchInDocumentsATResponse().getHits().getTotal());

        when(elasticSearchDocumentRepository.getAtDocuments(any(), any()))
                .thenReturn(DataGenerator.searchInDocumentsATResponse());
        when(elasticSearchDocumentRepository.countAtDocumentsByQuery(any(), any())).thenReturn(
                esCountDocument
        );
        assertNotNull(elasticSearchHelper.getAllInDocumentsMetadataAt(IndexOrPathToUse.DEFAULT, metadataQuery));
        metadataQuery.setIsReturnedRO(false);
        assertNotNull(elasticSearchHelper.getAllInDocumentsMetadataAt(IndexOrPathToUse.TEMPORARY, metadataQuery));
        assertNotNull(elasticSearchHelper.getAllInDocumentsMetadataAt(IndexOrPathToUse.TEMPORARY, DocumentMetadataQueryDto.builder().build()));

    }
}