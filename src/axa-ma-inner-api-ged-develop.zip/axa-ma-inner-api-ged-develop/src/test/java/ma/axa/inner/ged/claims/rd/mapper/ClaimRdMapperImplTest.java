package ma.axa.inner.ged.claims.rd.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import ma.axa.inner.ged.claim.rd.domain.DocumentClaimRdEs;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdAddReq;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdResponse;
import ma.axa.inner.ged.claim.rd.mapper.ClaimRdMapperImpl;

@ExtendWith(MockitoExtension.class)
class ClaimRdMapperImplTest {

	@Mock
	private DocumentClaimRdEs document;
	
	@Mock
	private DocClaimRdAddReq documentReq;

	ClaimRdMapperImpl mapper = new ClaimRdMapperImpl();

	@Test
	void testToDtoWithNonNullDocument() {
		// set up mock DocumentClaimRdEs object

		when(document.getAssureNom()).thenReturn("John");
		when(document.getAssurePrenom()).thenReturn("Doe");
		// add other property mocks as needed

		// call the method being tested
		DocClaimRdResponse result = mapper.toDto(document);

		// verify that the result is not null
		assertNotNull(result);

		// verify that the properties were set correctly
		assertEquals("John", result.getAssureNom());
		assertEquals("Doe", result.getAssurePrenom());
		// add other property assertions as needed
	}

	@Test
	void testToDtoWithNullDocument() {
		// call the method being tested with a null parameter
		document = null;
		DocClaimRdResponse result = mapper.toDto(document);

		// verify that the result is null
		assertNull(result);
	}

	@Test
	void testToDtoWithNullDocument_list() {
		// call the method being tested with a null parameter
		List<DocumentClaimRdEs> doc = null;
		List<DocClaimRdResponse> result = mapper.toDto(doc);

		// verify that the result is null
		assertNull(result);
	}
	
	@Test
	void testToDtoWithNonNullDocument_list() {
		// set up mock DocumentClaimRdEs object
		List<DocumentClaimRdEs> doc = new ArrayList<DocumentClaimRdEs>();
		doc.add(document);
		when(document.getAssureNom()).thenReturn("John");
		when(document.getAssurePrenom()).thenReturn("Doe");
		// add other property mocks as needed

		// call the method being tested
		List<DocClaimRdResponse> result = mapper.toDto(doc);

		// verify that the result is not null
		assertNotNull(result);

		
	}
	
	@Test
	void testfromDtoWithNonNullDocument() {
		// set up mock DocumentClaimRdEs object

		when(documentReq.getAssureNom()).thenReturn("John");
		when(documentReq.getAssurePrenom()).thenReturn("Doe");
		// add other property mocks as needed

		// call the method being tested
		DocumentClaimRdEs  result = mapper.fromDto(documentReq);

		// verify that the result is not null
		assertNotNull(result);

		// verify that the properties were set correctly
		assertEquals("John", result.getAssureNom());
		assertEquals("Doe", result.getAssurePrenom());
		// add other property assertions as needed
	}

	@Test
	void testFromDtoWithNullDocument_list() {
		// call the method being tested with a null parameter
		List<DocClaimRdAddReq> doc = null;
		List<DocumentClaimRdEs> result = mapper.fromDto(doc);

		// verify that the result is null
		assertNull(result);
	}

}
