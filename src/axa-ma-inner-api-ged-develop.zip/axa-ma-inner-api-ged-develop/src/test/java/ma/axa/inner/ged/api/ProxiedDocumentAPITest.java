package ma.axa.inner.ged.api;

import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.api.ac.ClaimAutoDocumentAPI;
import ma.axa.inner.ged.dto.proxied.SignedPayloadDto;
import ma.axa.inner.ged.service.ProxiedDocumentService;
import ma.axa.inner.ged.util.ResponseUtils;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.request.RequestFacade;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.nio.charset.StandardCharsets;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@Slf4j
 
@ExtendWith(SpringExtension.class)
 
@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@ExtendWith(SpringExtension.class)
@WebMvcTest(ProxiedDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
@ContextConfiguration(classes = {ProxiedDocumentAPI.class})
public class ProxiedDocumentAPITest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private ProxiedDocumentService documentService;

    @Test
    @WithMockUser(authorities = {GlobalConstants.SCOPE_GED})
    void Should_Return_Signed_Payload_For_Valid_Document_Id() throws Exception {
        // Given
        SignedPayloadDto payloadDto = SignedPayloadDto.builder()
                .documentId("b3707583-2158-4ba3-9f34-48e74e517c13")
                .signature("K3YpA1tJHe92u44mAClMYzZ7d2wuqKZRemq1Rsba9M")
                .expiresAt(1647080170000L)
                .build();

        when(documentService.generateSignedPayload("b3707583-2158-4ba3-9f34-48e74e517c13"))
                .thenReturn(payloadDto);
        // When
        ResultActions ra = mockMvc.perform(
                MockMvcRequestBuilders.get("/v1/documents/b3707583-2158-4ba3-9f34-48e74e517c13/signed-payload")
        );
        // Then
        ra.andExpect(status().isOk())
                .andExpect(header().string("Content-Type", "application/json"))
                .andExpect(jsonPath("$.documentId")
                        .value("b3707583-2158-4ba3-9f34-48e74e517c13"))
                .andExpect(jsonPath("$.signature")
                        .value("K3YpA1tJHe92u44mAClMYzZ7d2wuqKZRemq1Rsba9M"))
                .andExpect(jsonPath("$.expiresAt")
                        .value(1647080170000L)
                );
    }


    @Test
    @WithMockUser(authorities = {GlobalConstants.SCOPE_GED})
    void Should_Return_Document_Content_For_A_Valid_Signature() throws Exception {
        // Given
        var resource = new ByteArrayResource("content".getBytes(StandardCharsets.UTF_8));
        var headers = ResponseUtils.getDownloadHeaders("document_b3707583-2158-4ba3-9f34-48e74e517c13.pdf",
                resource.contentLength(),
                "application/pdf");

        when(documentService.downloadDocument("b3707583-2158-4ba3-9f34-48e74e517c13", 1647080170000L,
                "K3YpA1tJHe92u44mAClMYzZ7d2wuqKZRemq1Rsba9M"))
                .thenReturn(ResponseEntity.ok().headers(headers).body(resource));
        // When
        ResultActions ra = mockMvc.perform(
                MockMvcRequestBuilders.get("/v1/documents/content")
                        .param("document_id", "b3707583-2158-4ba3-9f34-48e74e517c13")
                        .param("expires_at", "1647080170000")
                        .param("signature", "K3YpA1tJHe92u44mAClMYzZ7d2wuqKZRemq1Rsba9M")
        );
        // Then
        ra.andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_PDF))
                .andExpect(content().bytes("content".getBytes(StandardCharsets.UTF_8)));

        Mockito.verify(documentService, Mockito.times(1))
                .downloadDocument(
                        "b3707583-2158-4ba3-9f34-48e74e517c13",
                        1647080170000L,
                        "K3YpA1tJHe92u44mAClMYzZ7d2wuqKZRemq1Rsba9M"
                );
    }
}