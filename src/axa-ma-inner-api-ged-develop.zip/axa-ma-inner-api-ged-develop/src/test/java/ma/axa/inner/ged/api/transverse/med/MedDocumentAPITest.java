package ma.axa.inner.ged.api.transverse.med;

import ma.axa.inner.ged.api.cima.auto.CimaAutoDocumentAPI;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentRequest;
import ma.axa.inner.ged.dto.transverse.med.MEDDocumentRequest;
import ma.axa.inner.ged.service.ac.DirectoriesService;
import ma.axa.inner.ged.service.cima.auto.CimaAutoDocumentService;
import ma.axa.inner.ged.service.transverse.med.MedDocumentService;
import ma.axa.inner.ged.util.CimaDataGenerator;
import ma.axa.inner.ged.util.MedDataGenerator;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;

import static ma.axa.inner.ged.util.constants.CimaConstants.CIMA_AUTO_BASE_URL;
import static ma.axa.inner.ged.util.constants.MedConstants.MED_BASE_URL;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebAppConfiguration
@MockBean({ Tracer.class })
@Import({ RequestFacade.class })
@WebMvcTest(MedDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
class MedDocumentAPITest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MedDocumentService medDocumentService;

    @MockBean
    private DirectoriesService directoriesService;

    @Autowired
    private MedDocumentAPI medAutoDocumentAPI;

    @MockBean
    private DataSourceContextHolder dataSourceContextHolder;

    @Test
    @WithMockUser(authorities = {GlobalConstants.SCOPE_GED})
    void uploadDocuments_shouldReturnStatusOK() throws Exception {
        MEDDocumentRequest medDocumentRequest = MedDataGenerator.generateMEDDocumentRequest();
        MultipartFile multipartFile = MedDataGenerator.MULTIPART_FILE;

        when(medDocumentService.uploadFile(medDocumentRequest, multipartFile))
                .thenReturn(MedDataGenerator.generateMedDocumentResponse());

        var request = multipart(MED_BASE_URL).file("file", multipartFile.getBytes())
                .contentType(MediaType.MULTIPART_FORM_DATA_VALUE)

                .param("quittancesId", "QUITTANCE002")
          /*      .param("idTypeAnnotation", "456L").param("dateEffet", "2014-01-01").param("acceptation", "0")
                .param("idProfilAnnote", "PROFIL002").param("userAjouteAudit", "user3")
                .param("dateAjoutAudit", "2014-01-01")*/
                ;
        mockMvc.perform(request).andExpect(status().isCreated());

    }


    @WithMockUser
    @Test
    void download_file_return_success() throws Exception {
        String document_id = "alfresco";

        ByteArrayResource output = new ByteArrayResource("content".getBytes());

        when(medDocumentService.downloadFile(document_id)).thenReturn(output);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/transverse/med/documents/" +document_id+ "/content")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser
    void download_return_success() throws Exception {
        String id = "document_Id";

        ByteArrayResource output = new ByteArrayResource("content".getBytes());
        when(medDocumentService.downloadFile(id)).thenReturn(output);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/transverse/med/documents/document_Id/content")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }


}

