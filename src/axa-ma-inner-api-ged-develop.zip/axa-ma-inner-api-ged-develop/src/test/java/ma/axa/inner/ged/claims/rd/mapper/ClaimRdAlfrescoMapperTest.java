package ma.axa.inner.ged.claims.rd.mapper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import ma.axa.inner.ged.claim.rd.dto.DocClaimRdAddReq;
import ma.axa.inner.ged.claim.rd.mapper.ClaimRdAlfrescoMapper;
import ma.axa.inner.ged.util.StringUtil;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;

@ExtendWith(MockitoExtension.class)
class ClaimRdAlfrescoMapperTest {

	@Test
	@DisplayName("ClaimRdAlfrescoMapper_classMustNotBeInstantiate")
	void testClaimRdAlfrescoMapperClass()
			throws IllegalAccessException, InstantiationException {
		final Class<?> cls = ClaimRdAlfrescoMapper.class;
		final Constructor<?> c = cls.getDeclaredConstructors()[0];
		c.setAccessible(true);

		Throwable targetException = null;
		try {
			c.newInstance((Object[]) null);
		} catch (InvocationTargetException e) {
			targetException = e.getTargetException();
		}

		assertThat(targetException)
				.overridingErrorMessage("The expected value should not null")
				.isNotNull();

		assertThat(targetException.getClass())
				.overridingErrorMessage("The expected value should be [InstantiationException.class]")
				.isEqualTo(InstantiationException.class);
	}

	@Test
	@DisplayName("ClaimRdAlfrescoMapper_toFolderProperties_shouldReturnTheRighProperties")
	void toFolderProperties_shouldReturnTheRighProperties() {
		var addRequest = DocClaimRdAddReq.builder().sinistreNumber("102093029").intermediaireCode(205).build();
		
		var mappedRequest = ClaimRdAlfrescoMapper.toFolderProperties(addRequest);
		
		assertEquals(mappedRequest.get(AXADocPropertyIds.NUMERO_SINISTRE_DOSSIER),
				addRequest.getSinistreNumber());
		assertEquals(mappedRequest.get(AXADocPropertyIds.INTERMEDIARE_DOSSIER),
				StringUtil.toString(addRequest.getIntermediaireCode()));
		
		var otherProps = new HashMap<String, Object>();
		otherProps.put("custom", "value");
		var mappedRequest2 = ClaimRdAlfrescoMapper.toFolderProperties(addRequest, otherProps);
		
		assertEquals(mappedRequest2.get(AXADocPropertyIds.NUMERO_SINISTRE_DOSSIER),
				addRequest.getSinistreNumber());
		assertEquals(mappedRequest2.get(AXADocPropertyIds.INTERMEDIARE_DOSSIER),
				StringUtil.toString(addRequest.getIntermediaireCode()));
		assertEquals(mappedRequest2.get(AXADocPropertyIds.INTERMEDIARE_DOSSIER),
				StringUtil.toString(addRequest.getIntermediaireCode()));

	}
	
	@Test
	@DisplayName("ClaimRdAlfrescoMapper_toDocumentProperties_shouldReturnTheRighProperties")
	void toDocumentProperties_shouldReturnTheRighProperties() {
		var addRequest = DocClaimRdAddReq.builder().sinistreNumber("102093029").intermediaireCode(205).build();
		var mappedRequest = ClaimRdAlfrescoMapper.toDocumentProperties(addRequest);
		assertEquals(mappedRequest.get(AXADocPropertyIds.NUMERO_SINISTRE),
				addRequest.getSinistreNumber());
		assertEquals(mappedRequest.get(AXADocPropertyIds.AGENT_INTERMEDIAIRE),
				StringUtil.toString(addRequest.getIntermediaireCode()));
	}

}
