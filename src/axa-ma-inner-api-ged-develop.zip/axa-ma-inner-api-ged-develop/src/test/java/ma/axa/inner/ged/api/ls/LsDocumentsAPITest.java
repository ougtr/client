package ma.axa.inner.ged.api.ls;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.dto.DocumentLsPrevoyanceRequest;
import ma.axa.inner.ged.dto.LsDocumentRequest;
import ma.axa.inner.ged.dto.SearchLsPrevoyanceResponse;
import ma.axa.inner.ged.service.ac.ClaimAutoDocumentService;
import ma.axa.inner.ged.service.ls.LsDocumentsService;
import ma.axa.inner.ged.service.ls.LsSaveDocument;
import ma.axa.inner.ged.util.GedDataGenerator;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.request.RequestFacade;


@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(ma.axa.inner.ged.api.ls.LsDocumentsAPI.class)
@AutoConfigureMockMvc(addFilters = false)
public class LsDocumentsAPITest {


	@Autowired
	private MockMvc mockMvc;

	@MockBean
	ClaimAutoDocumentService claimAutoDocumentService;
	@MockBean
	LsSaveDocument saveDoc;
	@MockBean
	LsDocumentsService  lsDocumentService;
	@Autowired
	WebApplicationContext webApplicationContext;
	
	
	@MockBean
	private DataSourceContextHolder dataSourceContextHolder;

	@Test
	void upload_file_return_success() throws Exception {
		MockMultipartFile multiPartFile = new MockMultipartFile("data","test.pdf","application/pdf","content".getBytes());
		String alfrescoReponse = "workspace://SpacesStore/436d85a0-0c02-496c-8945-936ea29ece77";
 
		when(lsDocumentService.uploadFile(any(MockMultipartFile.class)))
		.thenReturn(alfrescoReponse);

		mockMvc.perform(
			multipart("/v1/ls/upload/document?token=8588&codeProduct=0214&typeDoc=cin")
			.file("file", multiPartFile.getBytes()))
        .andExpect(status().isOk());
	}
	
	@Test
	void upload_files_return_success() throws Exception {
		 MockMultipartFile multiPartFile = new MockMultipartFile("data","test.pdf","application/pdf","content".getBytes());

        String alfrescoReponse = "workspace://SpacesStore/436d85a0-0c02-496c-8945-936ea29ece77";


	       when(saveDoc.saveLsMetadataDocument(new LsDocumentRequest("8588","0214","SO","CIN","436d85a0-0c02-496c-8945-936ea29ece7", "filename"))).thenReturn("ok");

	   when(lsDocumentService.uploadFile(any(MockMultipartFile.class))).thenReturn(alfrescoReponse);
	        mockMvc.perform(multipart("/v1/ls/upload?token=8588&codeProduct=0214&typeDoc=cin-uc")
	                .file("files", multiPartFile.getBytes())
	                )
	                .andExpect(status().isOk());
	}

	@WithMockUser
    @Test
    void download_file_return_success() throws Exception {
        String id = "alfresco";

        ByteArrayResource output = new ByteArrayResource("content".getBytes());

        when(lsDocumentService.downloadFile(id)).thenReturn(output);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/ls/documents/" + id)
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }

	/***
	 * ls prevoyance test
	 * @throws Exception
	 */

	@Test
	void uploadLsPrevoyanceFile_return_success() throws Exception {
		MockMultipartFile multiPartFile = new MockMultipartFile("data","file.pdf","application/pdf","content".getBytes());

		String alfrescoId = "436d85a0-0c02-496c-8945-936ea29ece77";


		when(saveDoc.saveNewLsPrevoyaneDoc( DocumentLsPrevoyanceRequest.builder().libDocument("file.pdf").typeDocument("cin").uploadedBy("userX").idGestion("12345678").build(),alfrescoId)).thenReturn("ok");

		when(lsDocumentService.uploadFile(any(MockMultipartFile.class))).thenReturn(alfrescoId);

		mockMvc.perform(multipart("/v1/prevoyance/ls/documents?idGestion=123456&typeDocument=cin&libDocument=file&uploadedBy=userX")
				.file("file", multiPartFile.getBytes())
		)
				.andExpect(status().isCreated());
	}

	@Test
	void searchLsPrevoyanceDocuments_by_idGestion_shouldPass() throws Exception {
		String id_gestion = "123456";
		List<SearchLsPrevoyanceResponse> result=List.of();
		assertEquals(result,saveDoc.searchLsPrevoyanceDocuments(id_gestion));
	}

	@Test
	void searchLsPrevoyanceDocuments_by_idGestion_succes() throws Exception {
		mockMvc.perform(
				MockMvcRequestBuilders
						.get("/v1/prevoyance/ls/documents/metadatas")
						.param("idGestion","123456")
						.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	@Test
	void searchLsPrevoyanceDocuments_return_error_when_id_gestion_missing() throws Exception {

		mockMvc.perform(
				MockMvcRequestBuilders
						.get("/v1/prevoyance/ls/documents/metadatas")
						.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.type", is(GlobalConstants.URI_MISSING_REQUEST_PARAMETER)));

	}

	@Test
	void deleteLsPrevoyanceMetadata_return_sucess() throws Exception {
		mockMvc.perform(
				delete("/v1/prevoyance/ls/documents/"+ GedDataGenerator.ID_EXIST)
						.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}


	@Test
	void deleteSubscriptionDocument_shouldReturnKO_whenMetadataDeletionFails() throws Exception {
		// Arrange
		String token = "202600015";
		String documentId = "436d85a0-0c02-496c-8945-936ea29ece77";
		String productCode = "2235";
		String documentType = "RIB";

		when(saveDoc.deleteLsSubscriptionDocumentMetadata(eq(token), eq(documentId), eq(productCode), eq(documentType), eq("SO")))
				.thenReturn("KO");

		// Act & Assert
		mockMvc.perform(delete("/v1/ls/souscription/{token}/document/{document_id}", token, documentId)
						.param("product_code", productCode)
						.param("document_type", documentType)
						.param("action_code","SO"))
				.andExpect(status().isOk())
				.andExpect(content().string("KO"));

		verify(saveDoc).deleteLsSubscriptionDocumentMetadata(eq(token), eq(documentId), eq(productCode), eq(documentType), eq("SO"));
	}

	@Test
	void deleteSubscriptionDocument_shouldReturnDocument_whenMetadataDeletionSucceeds() throws Exception {
		// Arrange
		String token = "202600015";
		String documentId = "436d85a0-0c02-496c-8945-936ea29ece77";
		String productCode = "2235";
		String documentType = "RIB";

		when(saveDoc.deleteLsSubscriptionDocumentMetadata(eq(token), eq(documentId), eq(productCode), eq(documentType), eq("SO")))
				.thenReturn("OK");
		when(lsDocumentService.deleteDocument(eq(documentId)))
				.thenReturn("documentDeleted");

		// Act & Assert
		mockMvc.perform(delete("/v1/ls/souscription/{token}/document/{document_id}", token, documentId)
						.param("product_code", productCode)
						.param("document_type", documentType)
						.param("action_code","SO"))
				.andExpect(status().isOk())
				.andExpect(content().string("documentDeleted"));

		verify(saveDoc).deleteLsSubscriptionDocumentMetadata(eq(token), eq(documentId), eq(productCode), eq(documentType), eq("SO"));
		verify(lsDocumentService).deleteDocument(eq(documentId));
	}

}