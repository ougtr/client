package ma.axa.inner.ged.api.production.mrh;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.service.production.ProductionDocumentService;
import ma.axa.inner.ged.util.request.RequestFacade;

import java.util.Objects;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(MrhProductionDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
public class MrhProductionDocumentAPITest {
	
    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
    ProductionDocumentService documentService;
    
    @Autowired
    WebApplicationContext webApplicationContext;
    
    @MockBean
	private DataSourceContextHolder dataSourceContextHolder;
    
    @Test 
    void upload_file_return_success() throws Exception {
        MockMultipartFile multiPartFile = new MockMultipartFile("data","test.pdf","application/pdf","content".getBytes());
        String alfresco = "alfresco";
        when(documentService.uploadFile(multiPartFile,null)).thenReturn(alfresco);
        mockMvc.perform(multipart("/v1/production/mrh/documents?effectDate=19/10/2022&policeNumber=1231231236&codeIntermediaire=205&clientName=test&productCode=22660")
                .file("file", multiPartFile.getBytes())
                )
                .andExpect(status().isCreated());
    }

    @Test
    void shouldCallDownloadDocEndpointSuccess() throws Exception {
        String fileId = "ete382-fee3-392";
        Resource res = new InputStreamResource(Objects.requireNonNull(MrhProductionDocumentAPITest.class.getClassLoader().getResourceAsStream("resource.txt")));
        when(documentService.downloadFile(eq(fileId))).thenReturn(res);
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/production/mrh/documents/" + fileId))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON));
    }
}
