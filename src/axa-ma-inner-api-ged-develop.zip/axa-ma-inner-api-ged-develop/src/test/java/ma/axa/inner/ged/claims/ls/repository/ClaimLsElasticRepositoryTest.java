package ma.axa.inner.ged.claims.ls.repository;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.ShardStatistics;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import ma.axa.inner.ged.claim.ls.domain.DocumentClaimLsEs;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsSearchParams;
import ma.axa.inner.ged.claim.ls.repository.ClaimLsElasticRepository;
import ma.axa.inner.ged.claims.ls.util.ClaimLsDataGenerator;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.repository.ElasticSearchNewRepository;
import ma.axa.inner.ged.util.GedDataGenerator;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ClaimLsElasticRepositoryTest {

	@InjectMocks
	ClaimLsElasticRepository claimLsElasticRepository;
	@Mock
	BrancheProperties lsProperties;
	@Mock
	ElasticSearchNewRepository elasticRepository;

	@Test
	void createNewDocument_sucess() throws ElasticsearchException, IOException {
		when(elasticRepository.createNewDocument(any(), any(), any()))
				.thenReturn(null);
		when(elasticRepository.existsDocument(any(), any())).thenReturn(false);
		assertNull(claimLsElasticRepository.createNewDocument("42", new DocumentClaimLsEs()));
		verify(elasticRepository).createNewDocument(any(), any(), any());
		verify(elasticRepository).existsDocument(any(), any());
	}

	@Test
	void createNewDocument_IllegalArgumentException() throws ElasticsearchException, IOException {
		when(elasticRepository.createNewDocument( anyString(), anyString(), anyString()))
				.thenReturn("Create New Document");
		when(elasticRepository.existsDocument(anyString(), anyString())).thenReturn(false);
		assertThrows(IllegalArgumentException.class,
				() -> claimLsElasticRepository.createNewDocument(null, new DocumentClaimLsEs()));
	}

	@Test
	void createNewDocument_NullPointerException() throws ElasticsearchException, IOException {
		when(elasticRepository.createNewDocument( anyString(), anyString(), anyString()))
				.thenReturn("Create New Document");
		when(elasticRepository.existsDocument(anyString(), anyString())).thenReturn(false);
		assertThrows(NullPointerException.class,
				() -> claimLsElasticRepository.createNewDocument("123", null));
	}

	@Test
	void createNewDocument_shouldValidate() throws ElasticsearchException, IOException {
		when(elasticRepository.createNewDocument( anyString(), anyString(), anyString()))
				.thenReturn("Create New Document");
		when(elasticRepository.existsDocument(anyString(), anyString())).thenReturn(false);
		assertEquals(null, elasticRepository.createNewDocument("","123", null));
	}

	@Test
	void createNewDocument_ResourceAlreadyExist() throws ElasticsearchException, IOException {
		when(elasticRepository.existsDocument(any(), any())).thenReturn(true);
		assertThrows(ResourceAlreadyExist.class,
				() -> claimLsElasticRepository.createNewDocument("42", new DocumentClaimLsEs()));
		verify(elasticRepository).existsDocument(any(),any());
	}

	@Test
	@DisplayName("findByCriteria_shouldReturnCorrectResultWhenValidParamsAreProvided")
	void findByCriteria_shouldReturnCorrectResultWhenValidParamsAreProvided()
			throws ElasticsearchException, IOException {
		DocClaimLsSearchParams searchParams = new DocClaimLsSearchParams();
		searchParams.setPageNumber(0);
		searchParams.setPageSize(10);
		SearchResponse<DocumentClaimLsEs> expectedResult = SearchResponse.of(b -> b.took(0)
				.timedOut(false)
				.hits(b2 -> b2.hits(b3 -> b3.index(GedDataGenerator.IDX_CLAIM_LS)
						.id(GedDataGenerator.ID_EXIST)
						.source(ClaimLsDataGenerator.getDocumentEs())))
				.shards(ShardStatistics.of(b1 -> b1.total(1).successful(1).failed(0))));
		when(elasticRepository.search(any(SearchRequest.Builder.class), eq(DocumentClaimLsEs.class)))
				.thenReturn(expectedResult);
		when(lsProperties.getEsDocIndex()).thenReturn(GedDataGenerator.IDX_CLAIM_LS);

		SearchResponse<DocumentClaimLsEs> result = claimLsElasticRepository.findByCriteria(searchParams);
		Assertions.assertEquals(expectedResult, result);
		verify(elasticRepository).search(any(SearchRequest.Builder.class), eq(DocumentClaimLsEs.class));
	}

	@Test
	@DisplayName("getQueryForMultiSearch_shouldReturnNotNullQuery")
	void getQueryForMultiSearch_shouldReturnNotNullQuery() {
		var searchParams = new DocClaimLsSearchParams();

		searchParams.setSinistreNumber("5678");
		var query = ClaimLsElasticRepository.getQueryForMultiSearch(searchParams);
		assertNotNull(query);
	}

	@Test
	@DisplayName("findOneDocumentByReference_shouldReturnDocumentWhenReferenceExists")
	void findOneDocumentByReference_shouldReturnDocumentWhenReferenceExists()
			throws ElasticsearchException, IOException {
		String reference = "some-reference";
		var expectedDocument = ClaimLsDataGenerator.getDocumentEs();
		SearchResponse<DocumentClaimLsEs> expectedResult = SearchResponse.of(b -> b.took(0)
				.timedOut(false)
				.hits(b2 -> b2.hits(b3 -> b3.index(GedDataGenerator.IDX_CLAIM_LS)
						.id(GedDataGenerator.ID_EXIST)
						.source(ClaimLsDataGenerator.getDocumentEs())))
				.shards(ShardStatistics.of(b1 -> b1.total(1).successful(1).failed(0))));
		when(elasticRepository.search(any(SearchRequest.Builder.class), eq(DocumentClaimLsEs.class)))
				.thenReturn(expectedResult);
		when(lsProperties.getEsDocIndex()).thenReturn(GedDataGenerator.IDX_CLAIM_LS);
		DocumentClaimLsEs result = claimLsElasticRepository.findOneDocumentByReference(reference);
		Assertions.assertEquals(expectedDocument, result);
	}

	@Test
	void findOneDocumentByReference_shouldThrowIOException() throws ElasticsearchException, IOException {
		when(elasticRepository.search((co.elastic.clients.elasticsearch.core.SearchRequest.Builder) any(),any())).thenThrow(new IOException("An error occurred"));
		doNothing().when(elasticRepository).refreshIndex(any());
		assertNull(claimLsElasticRepository.findOneDocumentByReference("Reference"));
		verify(elasticRepository).refreshIndex( any());
		verify(elasticRepository).search((co.elastic.clients.elasticsearch.core.SearchRequest.Builder) any(),any());
	}

	@Test
	@DisplayName("deleteDocument_shouldReturnTrueWhenDocumentIsDeleted")
	void deleteDocument_shouldReturnTrueWhenDocumentIsDeleted() {
		boolean expectedResult = true;
		when(elasticRepository.deleteDocument(anyString(), anyString())).thenReturn(expectedResult);
		when(lsProperties.getEsDocIndex()).thenReturn(GedDataGenerator.IDX_CLAIM_LS);
		boolean result = claimLsElasticRepository.deleteDocument(ClaimLsDataGenerator.DOCUMENT_ID);
		assertEquals(expectedResult, result);
		verify(elasticRepository).deleteDocument(GedDataGenerator.IDX_CLAIM_LS, ClaimLsDataGenerator.DOCUMENT_ID);
	}

	@Test
	@DisplayName("deleteDocument_shouldThrowIllegalArgumentExceptionWhenDocumentIdIsBlank")
	void deleteDocument_shouldThrowIllegalArgumentExceptionWhenDocumentIdIsBlank() {
		String documentId = "";
		assertThrows(IllegalArgumentException.class, () -> claimLsElasticRepository.deleteDocument(documentId));
	}


	@Test
	void updateDocument_shouldReturnDocumentSucess() throws ElasticsearchException, IOException {
		when(elasticRepository.updateDocument(any(), any(),  any(), anyBoolean(),
				any())).thenReturn(false);
		assertFalse(claimLsElasticRepository.updateDocument("42", new DocumentClaimLsEs()));
		verify(elasticRepository).updateDocument( any(),  any(),  any(), anyBoolean(),
				any());
	}

	@Test
	void updateDocument_shouldThrowIllegalArgumentExceptionWhenDocumentIdIsBlank() throws ElasticsearchException, IOException {
		when(elasticRepository.updateDocument(any(), any(),any(), anyBoolean(),any())).thenReturn(true);
		assertThrows(IllegalArgumentException.class,
				() -> claimLsElasticRepository.updateDocument(null, new DocumentClaimLsEs()));
	}


	@Test
	void updateDocument_shouldThrowNullPointerExceptionWhenDocumentClaimLsEsNull() throws IOException {
		when(elasticRepository.updateDocument(any(), any(),any(), anyBoolean(),any())).thenReturn(true);
		assertThrows(NullPointerException.class,
				() -> claimLsElasticRepository.updateDocument("12", null));
	}

	@Test
	void findById_shouldReturnSucces() throws ElasticsearchException, IOException {
		when(elasticRepository.findById( any(), any(), any()))
				.thenReturn("By Id");
		doNothing().when(elasticRepository).refreshIndex(any());
		assertFalse(claimLsElasticRepository.findById("12").isPresent());
		verify(elasticRepository).findById( any(), any(), any());
		verify(elasticRepository).refreshIndex( any());
	}

	@Test
	void findById_shouldthrowIOException() throws ElasticsearchException, IOException {
		when(elasticRepository.findById( any(), any(),  any()))
				.thenThrow(new IOException("An error occurred"));
		doNothing().when(elasticRepository).refreshIndex( any());
		assertFalse(claimLsElasticRepository.findById("12").isPresent());
		verify(elasticRepository).findById( any(),  any(), any());
		verify(elasticRepository).refreshIndex( any());
	}




	@Test
	void testFindByCriteria5() throws ElasticsearchException, IOException {
		when(this.elasticRepository.search((co.elastic.clients.elasticsearch.core.SearchRequest.Builder) any(),
				(Class<Object>) any())).thenReturn((SearchResponse<Object>) mock(SearchResponse.class));
		doNothing().when(this.elasticRepository).refreshIndex((String) any());
		DocClaimLsSearchParams docClaimLsSearchParams = mock(DocClaimLsSearchParams.class);
		when(docClaimLsSearchParams.getPageSize()).thenReturn(3);
		when(docClaimLsSearchParams.getPageNumber()).thenReturn(10);
		when(docClaimLsSearchParams.getSinistreNumber()).thenReturn("42");
		this.claimLsElasticRepository.findByCriteria(docClaimLsSearchParams);
		verify(this.elasticRepository).refreshIndex((String) any());
		verify(this.elasticRepository).search((co.elastic.clients.elasticsearch.core.SearchRequest.Builder) any(),
				(Class<Object>) any());
		verify(docClaimLsSearchParams).getPageNumber();
		verify(docClaimLsSearchParams, atLeast(1)).getPageSize();
		verify(docClaimLsSearchParams).getSinistreNumber();
	}

	@Test
	void testFindByCriteria6() throws ElasticsearchException, IOException {
		when(this.elasticRepository.search((co.elastic.clients.elasticsearch.core.SearchRequest.Builder) any(),
				(Class<Object>) any())).thenReturn((SearchResponse<Object>) mock(SearchResponse.class));
		doNothing().when(this.elasticRepository).refreshIndex((String) any());
		DocClaimLsSearchParams docClaimLsSearchParams = mock(DocClaimLsSearchParams.class);
		when(docClaimLsSearchParams.getPageSize()).thenThrow(new IllegalArgumentException("foo"));
		when(docClaimLsSearchParams.getPageNumber()).thenReturn(10);
		when(docClaimLsSearchParams.getSinistreNumber()).thenReturn("42");
		assertNull(this.claimLsElasticRepository.findByCriteria(docClaimLsSearchParams));
		verify(this.elasticRepository).refreshIndex((String) any());
		verify(docClaimLsSearchParams).getPageNumber();
		verify(docClaimLsSearchParams).getPageSize();
		verify(docClaimLsSearchParams).getSinistreNumber();
	}


	@Test
	void refreshIndex_retutnSucess() {
		doNothing().when(elasticRepository).refreshIndex(anyString());
		claimLsElasticRepository.refreshIndex();
	}

	@Test
	void refreshIndex_ThrowIllegalArgumentException() {
		doThrow(new IllegalArgumentException("12")).when(elasticRepository).refreshIndex(anyString());
		claimLsElasticRepository.refreshIndex();
	}

	@Test
	void testDeleteDocument() {
		when(this.elasticRepository.deleteDocument((String) any(), (String) any())).thenReturn(true);
		assertTrue(this.claimLsElasticRepository.deleteDocument("42"));
		verify(this.elasticRepository).deleteDocument((String) any(), (String) any());
	}

	@Test
	void testDeleteDocument2() {
		when(this.elasticRepository.deleteDocument((String) any(), (String) any()))
				.thenThrow(new IllegalArgumentException("foo"));
		assertFalse(this.claimLsElasticRepository.deleteDocument("42"));
		verify(this.elasticRepository).deleteDocument((String) any(), (String) any());
	}

	@Test
	void testDeleteDocument3() {
		when(this.elasticRepository.deleteDocument((String) any(), (String) any())).thenReturn(false);
		assertFalse(this.claimLsElasticRepository.deleteDocument("42"));
		verify(this.elasticRepository).deleteDocument((String) any(), (String) any());
	}

	@Test
	void testDeleteDocument4() {
		when(this.elasticRepository.deleteDocument((String) any(), (String) any())).thenReturn(true);
		assertThrows(IllegalArgumentException.class, () -> this.claimLsElasticRepository.deleteDocument(""));
	}
}
