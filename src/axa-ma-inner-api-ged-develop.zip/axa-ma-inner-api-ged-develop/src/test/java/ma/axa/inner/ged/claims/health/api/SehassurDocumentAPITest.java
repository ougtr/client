package ma.axa.inner.ged.claims.health.api;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;

import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import ma.axa.inner.ged.claim.health.api.SehassurHealthDocumentAPI;
import ma.axa.inner.ged.claim.health.service.SehassurHealthDocumentService;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;


@MockBean({Tracer.class})
@Import({RequestFacade.class})
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(SehassurHealthDocumentAPI.class)
class SehassurDocumentAPITest {

	private static final String service_path = "/v1/sehassur/documents";
	@MockBean
	SehassurHealthDocumentService sehassurHealthDocumentService;
	@Autowired
	MockMvc mockMvc;
	@MockBean
	private DataSourceContextHolder dataSourceContextHolder;

	@BeforeEach
	void setUp() throws Exception {

	}
	
	 
	@Test
	@DisplayName("Upload invoice and execute facturation")
	void upload_invoice_nd_execute_facturation_isOK() throws Exception {
	 	//String content = (new ObjectMapper()).writeValueAsString(DataGenerator.createDocumentUploadInvoiceRequest());
	 	MockMultipartFile file 
	      = new MockMultipartFile(
	        "invoice", 
	        "invoice.txt", 
	        MediaType.TEXT_PLAIN_VALUE, 
	        "invoice".getBytes()
	      );
	 
		mockMvc.perform(multipart(service_path).file(file))
		         .andDo(MockMvcResultHandlers.print())
		         .andExpect(status().isCreated());
	}
	



	
 
}