package ma.axa.inner.ged.api;

import ma.axa.inner.ged.api.at.TypesDocumentsReferentialATApi;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.service.at.TypeDocumentsReferentialAtService;
import ma.axa.inner.ged.util.DataGenerator;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@ExtendWith(SpringExtension.class)
@WebMvcTest(TypesDocumentsReferentialATApi.class)
@MockBean({Tracer.class})
@Import({RequestFacade.class})
class TypesDocumentsReferentialATApiTest {

    private final String ENDPOINT_PREFIX = "/v1/claims/at";
    private final String DOCUMENT_TYPES_ENDPOINT = "/params/type-documents";
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private TypeDocumentsReferentialAtService mockTypeDocumentsReferentialService;
    
    @MockBean
	private DataSourceContextHolder dataSourceContextHolder;


    @Test
    @WithMockUser(authorities = {GlobalConstants.SCOPE_GED})
    void testGetListTypeDocs_TypeDocumentsReferentialAtServiceReturnsNoItems() throws Exception {
        // Setup
        when(mockTypeDocumentsReferentialService.getAtListTypeDocs()).thenReturn(Collections.emptyList());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get(ENDPOINT_PREFIX + DOCUMENT_TYPES_ENDPOINT)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("[]");
    }

    @Test
    @WithMockUser(authorities = {GlobalConstants.SCOPE_GED})
    void get_intermediary_document_types() throws Exception {
        // Setup
        when(mockTypeDocumentsReferentialService.getIntermediaryTypeDocs())
                .thenReturn(DataGenerator.buildListIntermediaryTypeDocs());

        // Run the test
        MockHttpServletResponse response = mockMvc.perform(get(ENDPOINT_PREFIX + "/intermediary" + DOCUMENT_TYPES_ENDPOINT)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
    }
}
