package ma.axa.inner.ged.claims.common.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import ma.axa.inner.ged.mapper.parametrage.BrancheParametrageMapper;
import ma.axa.inner.ged.mapper.parametrage.EntityParametrageMapper;
import ma.axa.inner.ged.mapper.parametrage.RepertoireMapper;
import ma.axa.inner.ged.mapper.parametrage.TypeDocumentParametrageMapper;
import ma.axa.inner.ged.repository.parametrage.ParametrageRepository;
import ma.axa.inner.ged.service.parametrage.ParametrageService;
import ma.axa.inner.ged.util.ClaimParamGenerator;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ParametrageGEDServiceTest {
	
	@Mock
	public ParametrageRepository parametrageRepository;
	
	@Mock
	public BrancheParametrageMapper mapperBranche;
	
	@Mock
	public EntityParametrageMapper mapperEntity;
	
	@Mock
	public TypeDocumentParametrageMapper mapperTypeDocument;
	
	@Mock
	public RepertoireMapper mapperRepertoire;
	
	@InjectMocks
	ParametrageService parametrageService;
	
	
	@Test
	void get_all_branches() {
		
		when(parametrageRepository.getAll()).thenReturn(ClaimParamGenerator.getListBrancheDomain());
		assertThat(parametrageService.getAllBranches()).isNotNull();
		

	}
	
	@Test
	void get_all_entities_by_branche() {
		when(parametrageRepository.getListEntityByIdBranche(1)).thenReturn(ClaimParamGenerator.getListEntitiesDomain());
		assertThat(parametrageService.getEntityByBranche(1)).isNotNull();
	}

	@Test
	void get_all_type_documents_by_entity() {
		when(parametrageRepository.getListTypeDocumentByIdEntity(1)).thenReturn(ClaimParamGenerator.getListTypeDocumentDomain());
		assertThat(parametrageService.getTypeDocumentByEntity(0)).isNotNull();
	}
	
	@Test
	void get_all_directories_by_type_document() {
		when(parametrageRepository.getListRepertoireByIdDocument(1, 1)).thenReturn(ClaimParamGenerator.getListRepertoiresDomain());
		assertThat(parametrageService.getListRepertoireByIdTypeDocument(1,1)).isNotNull();
	}

	@Test
	void get_all_directories() {
		when(parametrageRepository.getListRepertoire()).thenReturn(ClaimParamGenerator.getListRepertoiresDomain());
		assertThat(parametrageService.getListRepertoire()).isNotNull();
	}
}
