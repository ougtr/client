package ma.axa.inner.ged.postls.mapper;

import ma.axa.inner.ged.postels.dto.DocPosteLsReq;
import ma.axa.inner.ged.postels.dto.DocPosteLsUpdateReq;
import ma.axa.inner.ged.postels.mapper.DocPosteLsMapper;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class DocPosteLsMapperTest {

    @Test
    void toFolderProperties_withNullMetaData_returnsEmptyMap() {
        Map<String, Object> result = DocPosteLsMapper.toFolderProperties((DocPosteLsReq) null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void toFolderProperties_withValidMetaData_returnsMapWithNumPolice() {
        DocPosteLsReq req = new DocPosteLsReq();
        req.setNumPolice("12345");
        Map<String, Object> result = DocPosteLsMapper.toFolderProperties(req);
        assertNotNull(result);
        // The key depends on AlfrescoFolderProperties mapping, so we check for any value
        assertTrue(result.values().contains("12345"));
    }

    @Test
    void toDocumentProperties_withNullDocPosteLsReq_returnsEmptyMap() {
        Map<String, Object> result = DocPosteLsMapper.toDocumentProperties((DocPosteLsReq) null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void toDocumentProperties_withValidDocPosteLsReq_returnsMapWithNumPoliceAndReference() {
        DocPosteLsReq req = new DocPosteLsReq();
        req.setNumPolice("54321");
        req.setReference("REF-001");
        Map<String, Object> result = DocPosteLsMapper.toDocumentProperties(req);
        assertNotNull(result);
        assertTrue(result.values().contains("54321"));
        assertTrue(result.values().contains("REF-001"));
    }

    @Test
    void toDocumentProperties_withNullDocPosteLsUpdateReq_returnsEmptyMap() {
        Map<String, Object> result = DocPosteLsMapper.toDocumentProperties((DocPosteLsUpdateReq) null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void toDocumentProperties_withValidDocPosteLsUpdateReq_returnsMapWithNumPoliceAndIsAuthentique() {
        DocPosteLsUpdateReq req = new DocPosteLsUpdateReq();
        req.setNumPolice("99999");
        req.setOriginal(true);
        Map<String, Object> result = DocPosteLsMapper.toDocumentProperties(req);
        assertNotNull(result);
        assertTrue(result.values().contains("99999"));
        assertTrue(result.values().contains(true));
    }
}
