package ma.axa.inner.ged.api.production.rc;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.dto.DemandUploadResponseDto;
import ma.axa.inner.ged.service.production.ProductionDocumentService;
import ma.axa.inner.ged.util.request.RequestFacade;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(RcProductionDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
class RcProductionDocumentAPITest {

    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
    ProductionDocumentService prodRcDocumentService;
    
    @Autowired
    WebApplicationContext webApplicationContext;
    
    @MockBean
	private DataSourceContextHolder dataSourceContextHolder;

    @Test 
    void upload_file_return_success() throws Exception {
        MockMultipartFile multiPartFile = new MockMultipartFile("data","test.pdf","application/pdf","content".getBytes());
        
//      MockMultipartFile jsonDocumentInformation = new MockMultipartFile("data",null,"application/json"
//              ,"{ \"effectDate\": \"19/10/2022\", \"policyNumber\": 1231231231}".getBytes());
//      
        String alfresco = "alfresco";
        
        when(prodRcDocumentService.uploadFile(multiPartFile,null)).thenReturn(alfresco);
        mockMvc.perform(multipart("/v1/production/rc/documents/upload?effectDate=19/10/2022&policeNumber=1231231236&codeIntermediaire=205&clientName=MounaqidMohamed&productCode=21")
                .file("file", multiPartFile.getBytes())
//              .file("dossierSinistreAuto", jsonDocumentInformation.getBytes())
                )
                .andExpect(status().isCreated());
    }
    
    @Test 
    void upload_file_demand_return_success() throws Exception {
        MockMultipartFile multiPartFile = new MockMultipartFile("data","test.pdf","application/pdf","content".getBytes());
        
//      MockMultipartFile jsonDocumentInformation = new MockMultipartFile("data",null,"application/json"
//              ,"{ \"effectDate\": \"19/10/2022\", \"policyNumber\": 1231231231}".getBytes());
//      
        List<DemandUploadResponseDto> alfrescoReponse = new ArrayList<>();
        
        when(prodRcDocumentService.uploadDemandFiles(List.of(multiPartFile),null)).thenReturn(alfrescoReponse);
        
        mockMvc.perform(multipart("/v1/production/rc/documents/demands/upload?effectDate=19/10/2022&demandId=21")
                .file("files", multiPartFile.getBytes())
//              .file("dossierSinistreAuto", jsonDocumentInformation.getBytes())
                )
                .andExpect(status().isOk());
    }
    
    @WithMockUser
    @Test 
    void download_file_return_success() throws Exception {
        String id = "alfresco";

        ByteArrayResource output = new ByteArrayResource("content".getBytes());

        when(prodRcDocumentService.downloadFile(id)).thenReturn(output);
        
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/production/rc/documents/" + id)
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }
    
    
}
