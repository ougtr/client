package ma.axa.inner.ged.mapper;

import ma.axa.inner.ged.domain.TypeDocAs400;
import ma.axa.inner.ged.dto.TypeDocResponse;
import ma.axa.inner.ged.mapper.ac.TypeDocAutoMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(MockitoExtension.class)
class TypeDocMapperTest {
    private TypeDocAutoMapper typeDocMapper = Mappers.getMapper(TypeDocAutoMapper.class);

    @Test
    void trimTest(){
        assertEquals(
             typeDocMapper.typeDocToTypeDocResponse(TypeDocAs400.builder()
                             .label("trim     ")
                     .build()),
                TypeDocResponse.builder().label("trim").build()
        );
    }

}
