package ma.axa.inner.ged.api;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.val;
import ma.axa.inner.ged.api.ac.ClaimAutoDocumentAPI;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.domain.DossierSinistreAuto;
import ma.axa.inner.ged.domain.IndexOrPathToUse;
import ma.axa.inner.ged.domain.PreDeclarationTypeDoc;
import ma.axa.inner.ged.dto.ChangesQueryDto;
import ma.axa.inner.ged.dto.CopyDocumentsQueryDto;
import ma.axa.inner.ged.helper.ElasticSearchHelper;
import ma.axa.inner.ged.service.ac.ClaimAutoDocumentService;
import ma.axa.inner.ged.util.DataGenerator;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@ExtendWith(SpringExtension.class)
@WebMvcTest(ClaimAutoDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
@ContextConfiguration(classes = {ClaimAutoDocumentAPI.class})
class ClaimAutoDocumentAPITest {

    @Autowired
    private ClaimAutoDocumentAPI claimAutoDocumentAPI;

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    ClaimAutoDocumentService claimAutoDocumentService;

    @MockBean
    ElasticSearchHelper elasticSearchHelper;
    
    @MockBean
	private DataSourceContextHolder dataSourceContextHolder;

    @Autowired
    WebApplicationContext webApplicationContext;
    private final static String ID_ALFRESCO = "123-456-789";
    private final static String ID_ALFRESCO2 = "111-111-111";

    private final static String DEFAULT_URL = "/v1/claims/ac";
    private final static String SUFFIX_UPLOAD = "/documents";
    private final static String SUFFIX_DOWNLOAD = "/documents/" + ID_ALFRESCO + "/content";

    private final static String SUFFIX_FOLDERS = "/folders";
    private final static String SUFFIX_DOCUMENTS_METADATA = "/documents/metadatas";
    private final static String SUFFIX_MODIFY = "/documents/" + ID_ALFRESCO;
    private final static String SUFFIX_DELETE = "/documents/" + ID_ALFRESCO;
    private final static String SUFFIX_TEST_DELETE = "/documents/auto-tests/cleanup";

    private final static String NUM_SINISTRE = "123444";
    private final static String SUFFIX_VALIDATION = "/documents/" + ID_ALFRESCO + "/validate";

    @WithMockUser
    @Test
    void download_file_return_success() throws Exception {
        ByteArrayResource output = new ByteArrayResource("content".getBytes());
        when(claimAutoDocumentService.downloadFile(ID_ALFRESCO)).thenReturn(output);
        mockMvc.perform(MockMvcRequestBuilders.get(DEFAULT_URL + SUFFIX_DOWNLOAD)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    /**
     * Method under test: {@link ClaimAutoDocumentAPI#copyDocumentsByAlfrescoIds(Boolean, CopyDocumentsQueryDto)}
     */
    @Test
    void testCopyDocumentsByAlfrescoIds() throws Exception {
        CopyDocumentsQueryDto copyDocumentsQueryDto = new CopyDocumentsQueryDto();
        copyDocumentsQueryDto.setChanges(new ArrayList<>());
        copyDocumentsQueryDto.setUserName("janedoe");
        String content = (new ObjectMapper()).writeValueAsString(copyDocumentsQueryDto);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/v1/claims/ac/documents/copy")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(claimAutoDocumentAPI)
                .build()
                .perform(requestBuilder);
        actualPerformResult.andExpect(MockMvcResultMatchers.status().is(400));
    }

    @WithMockUser
    @Test
    void upload_file_return_success() throws Exception {
        MockMultipartFile multiPartFile = new MockMultipartFile("data", "test.pdf", "application/pdf", "content".getBytes());

        MockMultipartFile jsonDocumentInformation = new MockMultipartFile("data", null, "application/json"
                , "{ \"id\": \"doc\", \"nSin\": \"781434345678\", \"idAlfresco\": \"p78\" }".getBytes());


        when(claimAutoDocumentService.uploadFile(any(), any())).thenReturn(ID_ALFRESCO);

        mockMvc.perform(multipart(DEFAULT_URL + SUFFIX_UPLOAD)
                        .file("file", multiPartFile.getBytes())
                        .file("dossierSinistreAuto", jsonDocumentInformation.getBytes()))
                .andExpect(status().isOk());
    }
    @WithMockUser
    @Test
    void upload_test_multi_file_return_success() throws Exception {
        MockMultipartFile multiPartFile = new MockMultipartFile("data", "test.pdf", "application/pdf", "content".getBytes());

        ObjectMapper objectMapper = new ObjectMapper();
        MockMultipartFile jsonDocumentsInformation = new MockMultipartFile(
                "data",
                null,
                "application/json",
                objectMapper.writeValueAsString(DataGenerator.getTestFilesMetadata()).getBytes()
        );

        when(claimAutoDocumentService.uploadTestFile(any(), any())).thenReturn(ID_ALFRESCO);

        mockMvc.perform(multipart(DEFAULT_URL + SUFFIX_UPLOAD)
                        .file("file", multiPartFile.getBytes())
                        .file("data", jsonDocumentsInformation.getBytes()))
                .andExpect(status().isOk());
    }

    @WithMockUser
    @Test
    void searchDossier_test() throws Exception {
        when(elasticSearchHelper.getDossierSinAutoList(any(DossierSinistreAuto.class))).thenReturn(Arrays.asList(new DossierSinistreAuto()));

        mockMvc.perform(MockMvcRequestBuilders.get(DEFAULT_URL + SUFFIX_FOLDERS)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    /**
     * Method under test: {@link ClaimAutoDocumentAPI#copyDocumentsByAlfrescoIds(Boolean, CopyDocumentsQueryDto)}
     */
    @Test
    void testCopyDocumentsByAlfrescoIds2() throws Exception {
        when(claimAutoDocumentService.copyDocumentsByAlfrescoIds( org.mockito.Mockito.any(),
                (CopyDocumentsQueryDto) org.mockito.Mockito.any())).thenReturn(new ArrayList<>());

        ArrayList<ChangesQueryDto> changesQueryDtoList = new ArrayList<>();
        changesQueryDtoList
                .add(new ChangesQueryDto(1L, "42", "42", "42", "42", "Immatriculation", "Tpi", "42", true));

        CopyDocumentsQueryDto copyDocumentsQueryDto = new CopyDocumentsQueryDto();
        copyDocumentsQueryDto.setChanges(changesQueryDtoList);
        copyDocumentsQueryDto.setUserName("janedoe");
        String content = (new ObjectMapper()).writeValueAsString(copyDocumentsQueryDto);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/v1/claims/ac/documents/copy")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        MockMvcBuilders.standaloneSetup(claimAutoDocumentAPI)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("[]"));
    }

    /**
     * Method under test: {@link ClaimAutoDocumentAPI#copyDocumentsByAlfrescoIds(Boolean, CopyDocumentsQueryDto)}
     */
    @Test
    void testCopyDocumentsByAlfrescoIds3() throws Exception {
        when(claimAutoDocumentService.copyDocumentsByAlfrescoIds( org.mockito.Mockito.any(),
                (CopyDocumentsQueryDto) org.mockito.Mockito.any()))
                .thenThrow(new ResponseStatusException(HttpStatus.CONTINUE));

        ArrayList<ChangesQueryDto> changesQueryDtoList = new ArrayList<>();
        changesQueryDtoList
                .add(new ChangesQueryDto(1L, "42", "42", "42", "42", "Immatriculation", "Tpi", "42", true));

        CopyDocumentsQueryDto copyDocumentsQueryDto = new CopyDocumentsQueryDto();
        copyDocumentsQueryDto.setChanges(changesQueryDtoList);
        copyDocumentsQueryDto.setUserName("janedoe");
        String content = (new ObjectMapper()).writeValueAsString(copyDocumentsQueryDto);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/v1/claims/ac/documents/copy")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(claimAutoDocumentAPI)
                .build()
                .perform(requestBuilder);
        actualPerformResult.andExpect(MockMvcResultMatchers.status().is(100));
    }

    @WithMockUser
    @Test
    void searchDocument_test() throws Exception {
        when(elasticSearchHelper.getDocumentsList(IndexOrPathToUse.DEFAULT, "nSin", NUM_SINISTRE)).thenReturn(Arrays.asList(new PreDeclarationTypeDoc()));

        mockMvc.perform(MockMvcRequestBuilders.get(DEFAULT_URL + SUFFIX_DOCUMENTS_METADATA)
                        .param("claim_number", NUM_SINISTRE)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }


    @Test
    void modifyMetadata() throws Exception {

        val predDeclaration = DataGenerator.preDeclarationTypeDocBuilder().get(0);
        when(claimAutoDocumentService.modifyDocumentsMetadata(IndexOrPathToUse.DEFAULT, ID_ALFRESCO, predDeclaration)).thenReturn(
                ID_ALFRESCO
        );
        val mapper = new ObjectMapper();

        mockMvc.perform(put(DEFAULT_URL + SUFFIX_MODIFY)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(predDeclaration)))
                .andExpect(status().isOk());

    }

    @Test
    void getTempDocumentMetadata_shouldpass() throws Exception {
        val result = DataGenerator.preDeclarationTypeDocBuilder();

        when(claimAutoDocumentService.getDocumentsList(IndexOrPathToUse.TEMPORARY, null, "owner")).thenReturn(result);
        mockMvc.perform(get(DEFAULT_URL + SUFFIX_DOCUMENTS_METADATA)
                        .param("temporary", "true")
                        .param("uploaded_by", "owner")
                        .contentType(MediaType.APPLICATION_JSON)
                )

                .andExpect(status().isOk());
    }

    @Test
    void getTempDocumentMetadata_shouldThrow() throws Exception {
        val result = DataGenerator.preDeclarationTypeDocBuilder();

        when(claimAutoDocumentService.getDocumentsList(IndexOrPathToUse.TEMPORARY, null, "owner")).thenReturn(result);
        mockMvc.perform(get(DEFAULT_URL + SUFFIX_DOCUMENTS_METADATA)
                        .contentType(MediaType.APPLICATION_JSON)
                )

                .andExpect(status().isBadRequest());
    }

    @Test
    void deleteMapping() throws Exception {

        when(claimAutoDocumentService.deleteDocument(IndexOrPathToUse.DEFAULT, ID_ALFRESCO, false)).thenReturn(ID_ALFRESCO);
        mockMvc.perform(delete(DEFAULT_URL + SUFFIX_DELETE)
                        .contentType(MediaType.APPLICATION_JSON)
                )

                .andExpect(status().isOk());

    }

    @Test
    void deleteMapping_badRequest() throws Exception {
        mockMvc.perform(delete(DEFAULT_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                )

                .andExpect(status().isNotFound());

    }

    @Test
    void saveTempToDefault_shouldPass() throws Exception {
        val param2 = PreDeclarationTypeDoc.builder().build();
        when(claimAutoDocumentService.validateTempFile(ID_ALFRESCO, param2)).thenReturn(ID_ALFRESCO);
        val mapper = new ObjectMapper();
        mockMvc.perform(
                post(DEFAULT_URL + SUFFIX_VALIDATION)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(param2))
        ).andExpect(status().isOk());
    }

    @Test
    void saveTempToDefault_shouldBreak() throws Exception {
        val result = "123-456-789";
        PreDeclarationTypeDoc param2 = null;
        val mapper = new ObjectMapper();
        mockMvc.perform(
                post(DEFAULT_URL + SUFFIX_VALIDATION)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(param2))
        ).andExpect(status().isBadRequest());
    }

    @Test
    void testDeleteTestMetadatas() throws Exception {
        when(claimAutoDocumentService.deleteDocument(IndexOrPathToUse.DEFAULT, ID_ALFRESCO, false)).thenReturn(ID_ALFRESCO);
        when(claimAutoDocumentService.deleteDocument(IndexOrPathToUse.DEFAULT, ID_ALFRESCO2, false)).thenReturn(ID_ALFRESCO2);

        var objectMapper = new ObjectMapper();
        var content = mockMvc.perform(
                delete(DEFAULT_URL + SUFFIX_TEST_DELETE)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .param("document_ids", ID_ALFRESCO, ID_ALFRESCO2)
                )
                .andExpect(status().isOk())
                .andReturn()
                .getResponse().getContentAsString();

        var resultList = objectMapper.readValue(content, new TypeReference<List<String>>() {});
        assertTrue(resultList.contains(ID_ALFRESCO));
        assertTrue(resultList.contains(ID_ALFRESCO2));
    }

    @Test
    void testSearchInDocumentsByQuery() throws Exception {
        // Setup
        // Configure ClaimAutoDocumentService.searchInDocumentsByQuery(...).
        final List<PreDeclarationTypeDoc> preDeclarationTypeDocs = List.of(PreDeclarationTypeDoc.builder().build());
        when(claimAutoDocumentService.searchInDocumentsByQuery(IndexOrPathToUse.DEFAULT,
                PreDeclarationTypeDoc.builder().build())).thenReturn(preDeclarationTypeDocs);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/v1/claims/ac/documents/search")
                        .param("temporary", "false")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("[{\"idAlfresco\":null,\"polnum\":null,\"statutBordereau\":null,\"codeExp\":null,\"userC\":null,\"userM\":null,\"dateC\":null,\"dateA\":null,\"heureC\":null,\"dateM\":null,\"heureM\":null,\"nomVictime\":null,\"emplacement\":null,\"dateHeureC\":null,\"tpi\":null,\"numeroDossier\":null,\"documentOriginal\":null,\"commentaire\":null,\"entiteEnregistrement\":null,\"intermediaire\":null,\"immatriculation\":null,\"idDocument\":null,\"receptionDate\":null,\"survenanceDate\":null,\"typeDocLabel\":null,\"tagLabel\":null,\"type\":null,\"sendingDate\":null,\"size\":null,\"repositoryId\":null,\"objectHash\":null,\"idTransaction\":null,\"nSin\":null,\"typeDoc\":null,\"nomFile\":null,\"idPredeclaration\":null,\"formDoc\":null,\"Aclasser\":null,\"AclasserPar\":null,\"AclasserLe\":null}]");
    }

    @Test
    void testSearchInDocumentsByQuery_ClaimAutoDocumentServiceReturnsNoItems() throws Exception {
        // Setup
        when(claimAutoDocumentService.searchInDocumentsByQuery(IndexOrPathToUse.DEFAULT,
                PreDeclarationTypeDoc.builder().build())).thenReturn(Collections.emptyList());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/v1/claims/ac/documents/search")
                        .param("temporary", "false")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("[]");
    }
}
