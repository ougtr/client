package ma.axa.inner.ged.mapper.cima.production;

import ma.axa.inner.ged.util.CimaDataGenerator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class CimaMrpAlfrescoMapperTest {

    @Test
    void privateConstructor_shouldThrowAssertionError() throws NoSuchMethodException {
        Constructor<CimaMrpAlfrescoMapper> constructor = CimaMrpAlfrescoMapper.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);

        assertThrows(InvocationTargetException.class, constructor::newInstance);
    }

    @Test
    void toFolderProperties_shouldReturnEmptyMap_whenMetaDataIsNull() {
        var result = CimaMrpAlfrescoMapper.toFolderProperties(null, new HashMap<>());
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void toFolderProperties_shouldReturnValidData() {
        var metaData = CimaDataGenerator.generateCimaMrpDocumentRequest();
        var result = CimaMrpAlfrescoMapper.toFolderProperties(metaData);
        assertNotNull(result);
        assertFalse(result.isEmpty());
    }

    @Test
    void toDocumentProperties_shouldReturnEmptyMap_whenMetaDataIsNull() {
        var result = CimaMrpAlfrescoMapper.toDocumentProperties(null, null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void toDocumentProperties_shouldReturnValidData() {
        var metaData = CimaDataGenerator.generateCimaMrpDocumentRequest();
        var result = CimaMrpAlfrescoMapper.toFolderProperties(metaData);
        assertNotNull(result);
        assertFalse(result.isEmpty());
    }
}