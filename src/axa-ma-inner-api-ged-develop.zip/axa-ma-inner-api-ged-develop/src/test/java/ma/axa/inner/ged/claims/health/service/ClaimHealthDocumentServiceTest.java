package ma.axa.inner.ged.claims.health.service;

import ma.axa.inner.ged.claim.health.domain.GedHealthEntityRes;
import ma.axa.inner.ged.claim.health.dto.DocClaimHealthReq;
import ma.axa.inner.ged.claim.health.dto.DocProductionHealthReq;
import ma.axa.inner.ged.claim.health.dto.ResponseDto;
import ma.axa.inner.ged.claim.health.mapper.RepoHealthMapper;
import ma.axa.inner.ged.claim.health.repository.HealthDocumentsRepository;
import ma.axa.inner.ged.claim.health.service.ClaimHealthDocumentService;
import ma.axa.inner.ged.config.GedHealthProperties;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.RequestValidationException;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.service.ManageDocumentService;
import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.Property;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.Resource;
import org.springframework.mock.web.MockMultipartFile;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ClaimHealthDocumentServiceTest {
    @Mock
    ClaimDocumentRepository claimDocumentRepository;
    @Mock
    GedHealthProperties gedHealthProperties;
    @Mock
    Document document;
    @Mock
    Folder folder;
    @Mock
    ManageDocumentService manageDocumentService;

    @Mock
    RepoHealthMapper repoHealthMapper;


    @Mock
    ClaimHealthDocumentService claimHealthDocumentService;


    @Mock
    HealthDocumentsRepository healthDocumentsRepository;


    @BeforeEach
    void setup() {
        claimHealthDocumentService = new ClaimHealthDocumentService(claimDocumentRepository, repoHealthMapper, gedHealthProperties, healthDocumentsRepository);
        manageDocumentService = new ManageDocumentService(claimDocumentRepository);
    }

    private Document getMockedDocument(String id) {
        return createMockedCmisObject(new Object[][]{
                {PropertyIds.NAME, "Name", "test" + id + ".txt"},
                {PropertyIds.CONTENT_STREAM_LENGTH, "Content stream length", "210"},
                {PropertyIds.BASE_TYPE_ID, "Base type id", "cmis:document"},
                {PropertyIds.OBJECT_TYPE_ID, "Object type id", "cmis:document"},
                {PropertyIds.LAST_MODIFICATION_DATE, "Last modification date", new Date()},
                {PropertyIds.CONTENT_STREAM_MIME_TYPE, "Content stream mime type", "text/plain"},
                {PropertyIds.OBJECT_ID, "Object type id", id}}, Document.class);
    }

    private <T extends CmisObject> T createMockedCmisObject(Object[][] properties, Class<T> tClass) {
        T object = mock(tClass);
        List<Property<?>> documentProperties = new ArrayList<Property<?>>();
        for (Object[] mockProp : properties) {
            Property<?> prop = createMockedProperty(mockProp[0], mockProp[1], mockProp[2]);
            documentProperties.add(prop);
        }

        return object;
    }

    private Property<?> createMockedProperty(Object id, Object displayName, Object value) {
        Property<String> property = mock(Property.class);
        return property;
    }


    @Test
    void upload_file_should_pass() throws Exception {
        document = getMockedDocument("test");
        assertThat(claimDocumentRepository).isNotNull();

        MockMultipartFile multiPartFile = new MockMultipartFile("data", "test.pdf", "application/pdf",
                "content".getBytes());

        DocClaimHealthReq claimHealthReq = new DocClaimHealthReq();
        claimHealthReq.setNomDoc("CIN");
        claimHealthReq.setTypeDoc("LETM");
        claimHealthReq.setTypeGestion("CVA");
        claimHealthReq.setIdAlfresco("5905d039-d9ec-4fed-8bdc-6240606e6042");

        var alfrescoID = "5905d039-d9ec-4fed-8bdc-6240606e6042";

        GedDocument gedDocument = new GedDocument();
        gedDocument.setFileByte("content".getBytes());
        gedDocument.setFileName("test.pdf");
        gedDocument.setMimeType("application/pdf");

        Map<String, String> output = new HashMap<>();
        output.put("5905d039-d9ec-4fed-8bdc-6240606e6042", alfrescoID);


        lenient().when(gedHealthProperties.getOutbox())
                .thenReturn("/Sites/groupe-indexation/documentLibrary/health");
        lenient().when(document.getVersionSeriesId()).thenReturn(alfrescoID);
        lenient().when(claimDocumentRepository.createArboFoldersByPath(any(String.class), any(String.class)))
                .thenReturn(folder);
        lenient().when(claimDocumentRepository.createDocument(any(Folder.class), any(GedDocument.class)))
                .thenReturn(document);

        ClaimHealthDocumentService spyService = spy(claimHealthDocumentService);
        when(spyService.uploadFile(multiPartFile, claimHealthReq)).thenReturn("5905d039-d9ec-4fed-8bdc-6240606e6042");

        var id = spyService.uploadFile(multiPartFile, claimHealthReq);
        assertThat(id).isEqualTo(alfrescoID);
    }


    @Test
    void download_file() {

        assertThat(claimDocumentRepository).isNotNull();

        String docId = "5905d039-d9ec-4fed-8bdc-6240606e6042";

        var file = new GedDocument();
        file.setFileByte(new byte[]{1, 2});
        file.setFileName("test.pdf");
        file.setMimeType("application/pdf");

        when(claimDocumentRepository.getFileDocument(docId)).thenReturn(file);

        Resource resource = claimHealthDocumentService.downloadFileFromGed(docId);

        ArgumentCaptor<String> id = ArgumentCaptor.forClass(String.class);
        verify(claimDocumentRepository).getFileDocument(id.capture());
        assertThat(id.getValue()).isEqualTo(docId);
        assertThat(resource).isNotNull();
    }


    @Test
    void getDocument_shouldPass() throws Exception {
        String type_gestion = "HON";
        String nom_doc = "Note d'honoraire ";

        List<GedHealthEntityRes> result = List.of();
        assertEquals(result, claimHealthDocumentService.getDocuments(type_gestion, nom_doc));
    }

    @Test
    void testGetDocuments_shouldThrow_RequestValidationException() {
      /*  lenient().when(any(HealthSearchReqDTO.class))
                .thenReturn(new HealthSearchResponseDto("TYPGES", "NOMDOC"));*/
        lenient().when(this.healthDocumentsRepository.getDocuments(anyString(), anyString())).thenReturn(new ArrayList<>());
        assertThrows(RequestValidationException.class,
                () -> this.claimHealthDocumentService.getDocuments("Type Gestion", null));
    }

    @Test
    void testGetDocuments2() {
       /* lenient().when(this.repoHealthMapper.toHealthEntity(any(HealthSearchReqDTO.class)))
                .thenReturn(new GedSearchEntity("TYPGES", "NOMDOC"));*/
        lenient().when(this.healthDocumentsRepository.getDocuments(anyString(), anyString())).thenReturn(new ArrayList<>());
        assertThrows(RequestValidationException.class, () -> this.claimHealthDocumentService.getDocuments(null, "Nom Doc"));
    }

    @Test
    void testDeleteHealthMetadata_pass_sucess() {
        lenient().when(this.healthDocumentsRepository.deleteHealthMetadata(anyString(), anyString()))
                .thenReturn("ok");
        assertEquals("ok", this.claimHealthDocumentService.deleteHealthMetadata("dossier", "DOS"));
        verify(this.healthDocumentsRepository).deleteHealthMetadata(anyString(), anyString());
    }

    @Test
    void testDeleteHealthMetadata_throw_exception_when_NomDoc_Null() {
        lenient().when(this.healthDocumentsRepository.deleteHealthMetadata(anyString(), anyString()))
                .thenReturn("Delete Health Metadata");
        assertThrows(RequestValidationException.class,
                () -> this.claimHealthDocumentService.deleteHealthMetadata(null, "Type Doc"));
    }

    @Test
    void testDeleteHealthMetadata_throw_exception_when_typeDoc_Null() {
        lenient().when(this.healthDocumentsRepository.deleteHealthMetadata(anyString(), anyString()))
                .thenReturn("Delete Health Metadata");
        assertThrows(RequestValidationException.class,
                () -> this.claimHealthDocumentService.deleteHealthMetadata("Nom Doc", null));
    }

    @Test
    void testDeleteHealthMetadata_GlobalException() {
        when(healthDocumentsRepository.deleteHealthMetadata(anyString(), anyString())).thenThrow(GlobalException.class);

        assertThrows(GlobalException.class, () -> {
            claimHealthDocumentService.deleteHealthMetadata("0", "0");
        });
    }

    @Test
    void testUploadFile() throws IOException {
        MockMultipartFile file = new MockMultipartFile("file", "test.pdf", "application/pdf", "Test file content".getBytes());
        DocClaimHealthReq documentSinistreHealth = new DocClaimHealthReq();
        documentSinistreHealth.setNomDoc("nom1");
        documentSinistreHealth.setTypeDoc("type1");
        documentSinistreHealth.setTypeGestion("gestion1");

        lenient().when(gedHealthProperties.getOutbox()).thenReturn("outbox/");
        lenient().when(claimDocumentRepository.createArboFoldersByPath(anyString(), anyString())).thenReturn(folder);
        lenient().when(healthDocumentsRepository.addMetaDataDocument(any())).thenReturn("metadata-id");

        assertThrows(GlobalException.class, () -> claimHealthDocumentService.uploadFile(file, documentSinistreHealth));
    }


    @Test
    void upload_file_psi_should_pass() {
        document = getMockedDocument("test");
        assertThat(claimDocumentRepository).isNotNull();

        MockMultipartFile multiPartFile = new MockMultipartFile("data", "test.pdf", "application/pdf",
                "content".getBytes());
        var alfrescoID = "5905d039-d9ec-4fed-8bdc-6240606e6042";
        var productionHealthReq = DocProductionHealthReq.builder().cotationId(BigDecimal.valueOf(2023000888))
                .codeProduit("0337").typeDoc("C").typeCode("C").idAlfresco(alfrescoID).numOrder(0).police1("")
                .police2("").user("amci").build();

        GedDocument gedDocument = new GedDocument();
        gedDocument.setFileByte("content".getBytes());
        gedDocument.setFileName("test.pdf");
        gedDocument.setMimeType("application/pdf");

        Map<String, String> output = new HashMap<>();
        output.put("5905d039-d9ec-4fed-8bdc-6240606e6042", alfrescoID);
        lenient().when(gedHealthProperties.getOutbox())
                .thenReturn("/Sites/groupe-indexation/documentLibrary/health");
        lenient().when(document.getVersionSeriesId()).thenReturn(alfrescoID);
        lenient().when(claimDocumentRepository.createArboFoldersByPath(any(String.class), any(String.class)))
                .thenReturn(folder);
        lenient().when(claimDocumentRepository.createDocument(any(Folder.class), any(GedDocument.class)))
                .thenReturn(document);

        ClaimHealthDocumentService spyService = spy(claimHealthDocumentService);
        when(spyService.uploadFilePsi(multiPartFile, productionHealthReq)).thenReturn(alfrescoID);

        var id = spyService.uploadFilePsi(multiPartFile, productionHealthReq);
        assertThat(id).isEqualTo(alfrescoID);
    }

    @Test
    void testUploadFile_Exception() throws IOException {
        MockMultipartFile file = new MockMultipartFile("file", "test.pdf", "application/pdf", "Test file content".getBytes());
        var productionHealthReq = DocProductionHealthReq.builder().cotationId(BigDecimal.valueOf(2023000888))
                .codeProduit("0337").typeDoc("C").typeCode("C").idAlfresco("").numOrder(0).police1("")
                .police2("").user("amci").build();
        lenient().when(gedHealthProperties.getOutbox()).thenReturn("outbox/");
        lenient().when(claimDocumentRepository.createArboFoldersByPath(anyString(), anyString())).thenReturn(folder);
        lenient().when(healthDocumentsRepository.addMetaDataDocumentPsi(any())).thenReturn("metadata-id");

        assertThrows(GlobalException.class, () -> claimHealthDocumentService.uploadFilePsi(file, productionHealthReq));
    }
    @Test
    void testUploadFile_returnNull() throws IOException {
        MockMultipartFile file = new MockMultipartFile("file", "test.pdf", "application/pdf", "Test file content".getBytes());
        DocClaimHealthReq documentSinistreHealth = new DocClaimHealthReq();
        documentSinistreHealth.setNomDoc("nom1");
        documentSinistreHealth.setTypeDoc("type1");
        documentSinistreHealth.setTypeGestion("gestion1");

        lenient().when(gedHealthProperties.getOutbox()).thenReturn("outbox/");
        lenient().when(claimDocumentRepository.createArboFoldersByPath(anyString(), anyString())).thenReturn(folder);
        lenient().when(healthDocumentsRepository.addMetaDataDocument(any())).thenReturn("metadata-id");

        assertThat(claimHealthDocumentService.uploadFile(null, documentSinistreHealth)).isEqualTo(null);
    }


    @Test
    void testUpdateDocContent() throws UnsupportedEncodingException {
        this.claimHealthDocumentService.updateDocContent("42",
                new MockMultipartFile("Name", "AAAAAAAAAAAAAAAAAAAAAAAA".getBytes("UTF-8")));
        verify(this.claimDocumentRepository).updateContent((String) any(),
                (org.springframework.web.multipart.MultipartFile) any());
    }
}
