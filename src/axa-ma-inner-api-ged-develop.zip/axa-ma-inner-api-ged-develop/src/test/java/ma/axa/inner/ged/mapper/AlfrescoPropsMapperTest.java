package ma.axa.inner.ged.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.HashMap;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import ma.axa.inner.ged.mapper.AlfrescoPropsMapper.AlfrescoDocumentProperties;
import ma.axa.inner.ged.mapper.AlfrescoPropsMapper.AlfrescoFolderProperties;
import ma.axa.inner.ged.util.DateUtils;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;

@ExtendWith(MockitoExtension.class)
class AlfrescoPropsMapperTest {

	@Test
	@DisplayName("AlfrescoPropsMapper_toFolderProperties_shouldReturnTheRighProperties")
	void toFolderProperties_shouldReturnTheRighProperties() {
		var otherProps = new HashMap<String, Object>();
		otherProps.put("custom", "value");
		var alfrescoProps = AlfrescoFolderProperties.builder()
				.intermediareDossier("205")
				.numeroPoliceDossier("0102903909")
				.numeroSinistreDossier("20201903888")
				.codeProduit("10")
				.dateSurvenanaceDossier(DateUtils.getCurrentDateTime().toLocalDate())
				.nomVictimeDossier("salim")
				.build();

		var folderProps = AlfrescoPropsMapper.toFolderProperties(otherProps, alfrescoProps);
		
		assertEquals(folderProps.get(AXADocPropertyIds.NUMERO_POLICE_DOSSIER),
				alfrescoProps.getNumeroPoliceDossier());
		assertEquals(folderProps.get(AXADocPropertyIds.NUMERO_SINISTRE_DOSSIER),
				alfrescoProps.getNumeroSinistreDossier());
		assertEquals(folderProps.get(AXADocPropertyIds.INTERMEDIARE_DOSSIER),
				alfrescoProps.getIntermediareDossier());
		assertEquals(folderProps.get(AXADocPropertyIds.NUMERO_POLICE_DOSSIER),
				alfrescoProps.getNumeroPoliceDossier());
		assertEquals(folderProps.get("custom"),otherProps.get("custom"));
	}

	@Test
	@DisplayName("AlfrescoPropsMapper_toDocumentProperties_shouldReturnTheRighProperties")
	void stringUtil_shouldBeDone_convertNumbers() {
		var otherProps = new HashMap<String, Object>();
		otherProps.put("custom", "value");
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numPolice("0102903909")
				.numSinistre("20201903888")
				.identifiantScaner("ref-202019020-rd")
				.agentIntermediaire("205")
				.isAuthentique(true)
				.build();

		var documentProps = AlfrescoPropsMapper.toDocumentProperties(otherProps, alfrescoProps);
		assertEquals(documentProps.get(AXADocPropertyIds.NUMERO_POLICE),
				alfrescoProps.getNumPolice());
		assertEquals(documentProps.get(AXADocPropertyIds.NUMERO_SINISTRE),
				alfrescoProps.getNumSinistre());
		assertEquals(documentProps.get(AXADocPropertyIds.AGENT_INTERMEDIAIRE),
				alfrescoProps.getAgentIntermediaire());
		assertEquals(documentProps.get(AXADocPropertyIds.AUTHENTIQUE),
				alfrescoProps.isAuthentique());
		assertEquals(documentProps.get("custom"),otherProps.get("custom"));
	}
}
