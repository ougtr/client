package ma.axa.inner.ged.claims.health.util;


import lombok.experimental.UtilityClass;
import ma.axa.inner.ged.claim.health.domain.GedHealthEntityAS400;
import ma.axa.inner.ged.claim.health.domain.GedHealthEntityRes;
import ma.axa.inner.ged.claim.health.domain.GedProductionHealthEntityAS400;
import ma.axa.inner.ged.claim.health.domain.UploadedDocumentAs400;

import java.math.BigDecimal;
import java.util.List;

@UtilityClass
public class DataGeneratorHealth {

    public GedHealthEntityAS400 healthRequest() {
        return GedHealthEntityAS400.builder().nomdoc("dossier").typedoc("DOS").typges("CVA").ideged("123456789").usercr("user").build();
    }


    public GedHealthEntityRes healthGetDocResponse() {
        return GedHealthEntityRes.builder().TYPDOC("DOS").IDEGED("123456789").build();
    }


    public GedHealthEntityRes healthGetDocRequest() {
        return GedHealthEntityRes.builder().TYPDOC("CVA").IDEGED("dossier").build();
    }

    public GedProductionHealthEntityAS400 productionHealthRequest() {
        return GedProductionHealthEntityAS400.builder().codpro("0337").ideamc(BigDecimal.valueOf(2023000888)).bdlusr("intermpsi ").colng4("C").rectype("C").ponpo1("").ponpo2("").ideged("5905d039-d9ec-4fed-8bdc-6240606e6042").menuor(0).build();
    }
    public static List<UploadedDocumentAs400> getUploadedDocumentsAs400() {
        return List.of(
                UploadedDocumentAs400.builder()
                        .nulign(BigDecimal.valueOf(11))
                        .colng4("pieceType")
                        .libpre("label")
                        .ideged("idGed")
                        .rectyp("typeCode")
                        .build()
        );
    }


}
