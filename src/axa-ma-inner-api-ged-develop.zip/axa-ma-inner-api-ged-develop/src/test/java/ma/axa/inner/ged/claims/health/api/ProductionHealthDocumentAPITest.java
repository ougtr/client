package ma.axa.inner.ged.claims.health.api;

import ma.axa.inner.ged.claim.health.api.ProductionHealthDocumentAPI;
import ma.axa.inner.ged.claim.health.domain.GedProductionHealthEntityAS400;
import ma.axa.inner.ged.claim.health.dto.DocProductionHealthReq;
import ma.axa.inner.ged.claim.health.repository.HealthDocumentsRepository;
import ma.axa.inner.ged.claim.health.service.ClaimHealthDocumentService;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(ProductionHealthDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
class ProductionHealthDocumentAPITest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
	private DataSourceContextHolder dataSourceContextHolder;

    @MockBean
    ClaimHealthDocumentService claimHealthDocumentService;


    @MockBean
    HealthDocumentsRepository healthSaveDoc;

    private final static String ID_ALFRESCO = "a162223f-9a5c-466e-a678-b6cc0a37bbc7";

    @Test
    void upload_files_psi_return_success() throws Exception {
        MockMultipartFile multiPartFile = new MockMultipartFile("data", "test11.pdf", "application/pdf", "content".getBytes());
        String idAlfresco = "5905d039-d9ec-4fed-8bdc-6240606e6042";
        when(healthSaveDoc.addMetaDataDocumentPsi(GedProductionHealthEntityAS400.builder().ponpo1("123").ponpo2("1478").rectype("C").codpro("C").build())).thenReturn("ok");
        when(claimHealthDocumentService.uploadFilePsi(any(MockMultipartFile.class), any(DocProductionHealthReq.class))).thenReturn(idAlfresco);
        mockMvc.perform(multipart("/v1/production/health/documents")
                        .file("file", multiPartFile.getBytes())
                        .param("typeCode", "C")
                        .param("user", "intermpsi")
                        .param("idAlfresco", "C")
                        .param("typeDoc", "C")
                        .param("codeProduit", "0337")
                        .param("police2", "")
                        .param("police1", "")
                        .param("cotationId", String.valueOf(new BigDecimal("15555")))
                        .param("numOrder", "0"))
                .andExpect(status().isOk());

    }

}
