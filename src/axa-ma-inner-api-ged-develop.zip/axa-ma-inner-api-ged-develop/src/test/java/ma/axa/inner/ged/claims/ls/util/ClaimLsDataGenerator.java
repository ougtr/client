package ma.axa.inner.ged.claims.ls.util;

import lombok.experimental.UtilityClass;
import ma.axa.inner.ged.claim.ls.domain.DocumentClaimLsEs;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsReq;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsResp;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsUpdateReq;
import ma.axa.inner.ged.domain.alfresco.DocumentAlfresco;
import ma.axa.inner.ged.enums.GedClaimStatus;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;


import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@UtilityClass
public class ClaimLsDataGenerator {

	public static final String DOCUMENT_ID = "64a7fb0a-c4d3-4487-8e97-8d453c458adb";
	public static final String DOCUMENT_ID_NOT = "64a7fb0a-c4d3-4487-8e97";
	public static final String APP_CODE = "GED_CLAIM";
	public static final String REFERENCE = "ref-20230202-01";
	public static final String SINISTRE_NUMBER = "ref-20230202-01";

	/** ======== Request ======== **/
	public static final MultiValueMap<String, String> getAddRequest() {
		return getAddRequest(APP_CODE, REFERENCE, SINISTRE_NUMBER, GedClaimStatus.EN_INSTANCE.name());
	}

	public static final MultiValueMap<String, String> getAddRequest(String reference) {
		return getAddRequest(APP_CODE, reference, SINISTRE_NUMBER, GedClaimStatus.EN_INSTANCE.name());
	}

	public static final MultiValueMap<String, String> getAddRequestForFaildValidation() {
		return getAddRequest(APP_CODE, REFERENCE, null, GedClaimStatus.IDENTIFIE.name());
	}

	public static final MultiValueMap<String, String> getAddRequest(String appCode,
			String reference, String sinistreNumber, String status) {
		MultiValueMap<String, String> meta = new LinkedMultiValueMap<>();
		// required
		meta.set("reference", reference);
		meta.set("filename", "new_filename.pdf");
		meta.set("original", "false");
		meta.set("sinistreNumber", sinistreNumber);
		meta.set("status", status);
		meta.set("typeDocumentCode", "3");
		meta.set("typeDocumentLabel", "cin");
		return meta;
	}
	
	public static final DocClaimLsReq getAddRequestDto() {
		return DocClaimLsReq.builder()
				.reference(REFERENCE)
				.sinistreNumber(SINISTRE_NUMBER)
				.typeDocumentCode("3")
				.build();
	}

	public static final DocClaimLsUpdateReq getUpdateRequestDto() {
		return DocClaimLsUpdateReq.builder()
				.sinistreNumber(SINISTRE_NUMBER)
				.build();
	}
	
	public static final MultiValueMap<String, String> getSearchParams(int pageNumber, int pageSize) {
		MultiValueMap<String, String> meta = new LinkedMultiValueMap<>();
		meta.set("pageNumber", String.valueOf(pageNumber));
		meta.set("pageSize", String.valueOf(pageSize));
		meta.set("status", GedClaimStatus.IDENTIFIE.name());
		meta.set("sinistreNumber", SINISTRE_NUMBER);
		meta.set("reference", REFERENCE);
		return meta;
	}
	
	public static final Map<String, Object> getFolderProperties() {
		Map<String, Object> meta = new HashMap<String, Object>();
		meta.put("axa:dossier:codeIntermediaire", 1);
		return meta;
	}
	
	public static final DocumentAlfresco getDocumentAlfresco() {
		return DocumentAlfresco.builder()
				.id(DOCUMENT_ID)
				.mimeType("application/pdf")
				.path("/site/folder/to/upload")
				.build();
	}

	/** ======== Response DTOs ======== **/

	public static DocumentClaimLsEs getDocumentEs() {
		return DocumentClaimLsEs.builder()
				.id(DOCUMENT_ID)
				.brancheLabel("LS")
				.filename("filename.pdf")
				.original(false)
				.path("/site/folder/to/upload")
				.reference(REFERENCE)
				.sinistreNumber(SINISTRE_NUMBER)
				.status("Identifié")
				.typeDocumentCode(3)
				.typeDocumentLabel("cin")
				.build();
	}

	public static DocClaimLsResp getOnResponseDoc() {
		return DocClaimLsResp.builder()
				.id(DOCUMENT_ID)
				.brancheLabel("LS")
				.filename("filename.pdf")
				.path("/site/folder/to/upload")
				.reference(REFERENCE)
				.sinistreNumber(SINISTRE_NUMBER)
				.build();
	}
	
	
	public static DocClaimLsResp getOnResponseAfterUpdateDoc() {
		return DocClaimLsResp.builder()
				.id(DOCUMENT_ID)
				.brancheLabel("LS")
				.filename("filename.pdf")
				.path("/site/folder/to/upload")
				.reference(REFERENCE)
				.sinistreNumber(SINISTRE_NUMBER)
				.build();
	}
}
