package ma.axa.inner.ged.claims.transport.mapper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import ma.axa.inner.ged.claim.transport.mapper.ClaimTransportAlfrescoMapper;
import ma.axa.inner.ged.claims.transport.util.ClaimTransportDataGenerator;
import ma.axa.inner.ged.util.StringUtil;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;

@ExtendWith(MockitoExtension.class)
class ClaimTransportAlfrescoMapperTest {

	@Test
	@DisplayName("ClaimTransportAlfrescoMapper_classMustNotBeInstantiate")
	void testClaimTransportAlfrescoMapperClass()
			throws IllegalAccessException, InstantiationException {
		final Class<?> cls = ClaimTransportAlfrescoMapper.class;
		final Constructor<?> c = cls.getDeclaredConstructors()[0];
		c.setAccessible(true);
		Throwable targetException = null;
		try {
			c.newInstance((Object[]) null);
		} catch (InvocationTargetException e) {
			targetException = e.getTargetException();
		}
		assertThat(targetException.getClass())
				.overridingErrorMessage("The expected value should be [InstantiationException.class]")
				.isEqualTo(InstantiationException.class);

		assertThat(targetException)
				.overridingErrorMessage("The expected value should not null")
				.isNotNull();
	}

	@Test
	@DisplayName("ClaimTransportAlfrescoMapper_toFolderProperties_shouldReturnTheRighProperties")
	void toFolderProperties_shouldReturnTheRighProperties() {
		var request = ClaimTransportDataGenerator.getAddRequestDto();
		var mappedRequest = ClaimTransportAlfrescoMapper
				.toFolderProperties(ClaimTransportDataGenerator.getAddRequestDto());
		assertEquals(mappedRequest.get(AXADocPropertyIds.NUMERO_SINISTRE_DOSSIER),
				request.getSinistreNumber());
		assertEquals(mappedRequest.get(AXADocPropertyIds.INTERMEDIARE_DOSSIER),
				StringUtil.toString(request.getIntermediaireCode()));
	}

	@Test
	@DisplayName("ClaimTransportAlfrescoMapper_toDocumentProperties_shouldReturnTheRighProperties")
	void toDocumentProperties_shouldReturnTheRighProperties() {
		var request = ClaimTransportDataGenerator.getAddRequestDto();

		var mappedRequest = ClaimTransportAlfrescoMapper.toDocumentProperties(request);
		assertEquals(mappedRequest.get(AXADocPropertyIds.NUMERO_SINISTRE),
				request.getSinistreNumber());
		assertEquals(mappedRequest.get(AXADocPropertyIds.AGENT_INTERMEDIAIRE),
				StringUtil.toString(request.getIntermediaireCode()));
	}

}
