package ma.axa.inner.ged.claims.transport.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Optional;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.web.multipart.MultipartFile;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import ma.axa.inner.ged.claim.transport.domain.DocumentClaimTransportEs;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportResponse;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportSearchParams;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportUpdateReq;
import ma.axa.inner.ged.claim.transport.mapper.ClaimTransportMapper;
import ma.axa.inner.ged.claim.transport.repository.ClaimTransportElasticRepository;
import ma.axa.inner.ged.claim.transport.service.ClaimTransportDocumentService;
import ma.axa.inner.ged.claims.rd.util.ClaimRdDataGenerator;
import ma.axa.inner.ged.claims.transport.util.ClaimTransportDataGenerator;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.dto.CommonResponse;
import ma.axa.inner.ged.enums.Branche;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.exception.ResourceNotFoundException;
import ma.axa.inner.ged.service.AlfrescoGedService;
import ma.axa.inner.ged.util.FileGenerator;
import ma.axa.inner.ged.util.MessageUtils;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@EnableConfigurationProperties(value = BrancheProperties.class)
public class ClaimTransportDocumentServiceTest {
	@InjectMocks
	private ClaimTransportDocumentService service;
	@Mock
	private ClaimTransportMapper transportMapper;
	@Mock
	private ClaimTransportElasticRepository elasticRepository;
	@Mock
	private AlfrescoGedService alfrescoService;
	@Mock
	MessageSource messageSource;
	@Mock
	private DocumentClaimTransportEs documentEsMock;
	@Mock
	BrancheProperties brancheProperties;
	@Mock
	Folder folder;
	
	@BeforeEach
	void initMockRepositories() throws ElasticsearchException, IOException {
		when(alfrescoService.exists(ClaimTransportDataGenerator.DOCUMENT_ID)).thenReturn(true);
		when(alfrescoService.exists(ClaimTransportDataGenerator.DOCUMENT_ID_NOT)).thenReturn(false);
		when(elasticRepository.exists(ClaimTransportDataGenerator.DOCUMENT_ID)).thenReturn(true);
		when(elasticRepository.exists(ClaimTransportDataGenerator.DOCUMENT_ID_NOT)).thenReturn(false);
		when(elasticRepository.findById(ClaimTransportDataGenerator.DOCUMENT_ID))
				.thenReturn(Optional.of(ClaimTransportDataGenerator.getDocumentEs()));

	}
	
	@Test
	void testGetMessage() throws NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		String code = "some.code";
		Object[] args = { "arg1", "arg2" };

		
		// Mock the behavior of the MessageUtils.getMessage() method
		when(MessageUtils.getMessage(messageSource, code, args)).thenReturn("test message");

		// Use reflection to access the private getMessage() method
		Method getMessageMethod = ClaimTransportDocumentService.class.getDeclaredMethod("getMessage", String.class,
				Object[].class);
		getMessageMethod.setAccessible(true);

		// Call the private getMessage() method and assert the result
		String result = (String) getMessageMethod.invoke(service, code, args);
		assertEquals("test message", result);

	}


//	@Test
//	@DisplayName("ClaimTransport_getDocumentById_ShouldReturnValidDocument")
//	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
//	void getDocumentById_ShouldReturnValidDocument() throws Exception {
//		var response = service.getDocumentById(ClaimTransportDataGenerator.DOCUMENT_ID);
//		assertThat(response).isNotNull();
//		
//	}

	@Test
	@DisplayName("ClaimTransport_getDocumentById_ShouldThrowRecordNotFoundException")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void getDocumentById_ShouldThrowRecordNotFoundException() throws Exception {
		assertThatThrownBy(() -> service.getDocumentById(ClaimTransportDataGenerator.DOCUMENT_ID_NOT))
				.isInstanceOf(ResourceNotFoundException.class);
	}

//	@Test
//	@DisplayName("claimTransport_downloadFile_mustReturnAValideFile")
//	void downloadFile_mustReturnAValideFile() {
//		var document = mock(Document.class);
//		var contentStream = mock(ContentStream.class);
//		var isv1 = new ByteArrayInputStream("test file content".getBytes());
//		when(contentStream.getStream()).thenReturn(isv1);
//		when(contentStream.getMimeType()).thenReturn("application/pdf");
//		when(contentStream.getLength()).thenReturn(1000L);
//		when(document.getContentStream()).thenReturn(contentStream);
//		when(document.getContentStream().getStream()).thenReturn(isv1);
//		when(document.getName()).thenReturn("test.pdf");
//		when(document.getContentStreamLength()).thenReturn(1000L);
//		when(service.getFileFromAlfresco(ClaimTransportDataGenerator.DOCUMENT_ID)).thenReturn(document);
//
//		var responseEntity = service.downloadFile(ClaimTransportDataGenerator.DOCUMENT_ID);
//		assertThat(responseEntity).isNotNull();
//		assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
//		assertThat(responseEntity.getHeaders().getContentLength()).isEqualTo(1000);
//		assertThat(responseEntity.getHeaders().getContentType()).hasToString("application/pdf");
//		assertThat(responseEntity.getHeaders().getContentDisposition().getFilename()).hasToString("test.pdf");
//	}
//
	@Test
	@DisplayName("claimTransport_downloadFile_ShouldThrowResourceNotFoundException")
	void downloadFile_ShouldThrowResourceNotFoundException() {
		assertThrows(ResourceNotFoundException.class, () -> service.downloadFile(ClaimTransportDataGenerator.DOCUMENT_ID_NOT));
	}

//	@Test
//	@DisplayName("claimTransport_uploadDocumentWithMetaData_ShouldReturnResourceAlreadyExists")
//	void uploadDocumentWithMetaData_ShouldReturnResourceAlreadyExists() throws Exception {
//		var metaData = ClaimTransportDataGenerator.getAddRequestDto();
//		var file = FileGenerator.getPdfFile();
//		var documentExist = ClaimTransportDataGenerator.getDocumentEs();
//		when(elasticRepository.findOneDocumentByReference(ClaimTransportDataGenerator.REFERENCE)).thenReturn(documentExist);
//		try {
//			service.uploadDocumentWithMetaData(metaData, file);
//			fail("Expected ResourceAlreadyExist exception");
//		} catch (ResourceAlreadyExist e) {
//			assertEquals(GlobalConstants.URI_RECORDE_ALREADY_EXIST, e.getType());
//			assertEquals(GlobalConstants.ERROR_MSG_RD_REFERENCE_ALREADY_EXIST, e.getMessage());
//			assertArrayEquals(new String[] { ClaimTransportDataGenerator.REFERENCE }, e.getArgs());
//		}
//	}
//	
//	@Test
//	@DisplayName("claimTransport_uploadDocumentWithMetaData_ShouldReturnAddedObject")
//	void uploadDocumentWithMetaData_ShouldReturnAddedObject() throws Exception {
//		// create mock input data
//		var metaData = ClaimTransportDataGenerator.getAddRequestDto();
//		// Folder f = alfrescoService.createTreeFolder("/claim/rd/2023/03/08",
//		// "/Sites/groupe-indexation/documentLibrary",ClaimRdDataGenerator.getFolderProperties());
//		// BrancheProperties brancheProperties = new BrancheProperties();
//		// mock the behavior of the elasticRepository and alfrescoService methods
//		when(elasticRepository.findOneDocumentByReference(anyString())).thenReturn(null);
//
//		when(brancheProperties.getAlfrescoRootFolder()).thenReturn("/claim/transport/2023/03/08");
//		when(brancheProperties.getAlfrescoSitePath()).thenReturn("/Sites/groupe-indexation/documentLibrary");
//		when(alfrescoService.createTreeFolder(anyString(), anyString(), any())).thenReturn(folder);
//		// when(alfrescoService.createTreeFolder(anyString(),anyString(),ClaimRdDataGenerator.getFolderProperties())).thenReturn(folder);
//		// when(brancheProperties.getAlfrescoRootFolder()).thenReturn(null);
//		when(service.prepareDocumentFolder(ClaimRdDataGenerator.getFolderProperties())).thenReturn(folder);
//
//		var createdDocument = ClaimRdDataGenerator.getDocumentAlfresco();
//		when(alfrescoService.createDocument(any(), anyString(), any(MultipartFile.class),
//				ArgumentMatchers.<String, Object>anyMap(), anyBoolean())).thenReturn(createdDocument);
//
//		// create a mock DocumentEs object for mapping
//		var documentEs = ClaimTransportDataGenerator.getDocumentEs();
//		// set any other required fields in documentEs object
//		when(rdMapper.fromDto(metaData)).thenReturn(documentEs);
//		when(rdMapper.toDto(documentEs)).thenReturn(ClaimTransportDataGenerator.getOnResponseDoc());
//
//		// call the method being tested
//		var result = service.uploadDocumentWithMetaData(metaData, FileGenerator.getPdfFile());
//
//		// assert the expected result
//		assertNotNull(result);
//		// add more assertions as needed
//	}
//
//	@DisplayName("claimRd_ValidationRequest_ShouldReturnError")
//	@Test
//	void testValidationRequest() {
//		// Arrange
//		var sut = new CommonResponse();
//		var error = new HashMap<String, String>();
//		error.put("status", "Must fill sinistre number to update status = IDENTIFIE");
//		Mockito.when(documentEsMock.getStatus()).thenReturn("Identifié");
//		Mockito.when(documentEsMock.getSinistreNumber()).thenReturn("");
//
//		// Act
//		var result = service.validationRequest(documentEsMock);
//
//		// Assert
//		Assertions.assertFalse(result.isSuccess());
//		Assertions.assertEquals(error, result.getMsgErrors());
//	}
//
	@Test
	void testValidStatus_identifiedWithNumSinistre() {
		String status = "Identifié";
		String numSinistre = "12345";
		boolean result = service.validStatus(status, numSinistre);
		assertTrue(result);
	}

	@Test
	void testValidStatus_identifiedWithoutNumSinistre() {
		String status = "Identifié";
		String numSinistre = null;
		boolean result = service.validStatus(status, numSinistre);
		assertFalse(result);
	}

	@Test
	public void testValidStatus_notIdentified() {
		String status = "Non identifié";
		String numSinistre = "12345";
		boolean result = service.validStatus(status, numSinistre);
		assertTrue(result);
	}

	
	@Test
	void testDeleteDocument() {
		// Mocking
		String id = "123";
		boolean withMetaData = true;
		Mockito.when(alfrescoService.exists(id)).thenReturn(true);
		Mockito.when(alfrescoService.deleteDocument(id)).thenReturn(true);
		Mockito.when(elasticRepository.exists(id)).thenReturn(true);
		Mockito.when(elasticRepository.deleteDocument(id)).thenReturn(true);

		// Execution
		CommonResponse response = service.deleteDocument(id, withMetaData);

		// Assertion
		assertTrue(response.isSuccess());
		assertNull(response.getMsgErrors());
		assertNotNull(response.getMsgSuccess());
		assertEquals(2, response.getMsgSuccess().size());
		assertEquals("true", response.getMsgSuccess().get("ALFRESCO"));
		assertEquals("true", response.getMsgSuccess().get("ELASTIC"));

		// Verify
		Mockito.verify(alfrescoService).exists(id);
		Mockito.verify(alfrescoService).deleteDocument(id);
		Mockito.verify(elasticRepository).exists(id);
		Mockito.verify(elasticRepository).deleteDocument(id);
	}
	
	@Test
	void testDeleteDocument_throwsResourceNotFound() {
		// Mocking
		String id = "123";
		boolean withMetaData = true;
		Mockito.when(alfrescoService.exists(id)).thenReturn(false);
		Mockito.when(alfrescoService.deleteDocument(id)).thenReturn(true);
		// Execution
		assertThrows(ResourceNotFoundException.class,()->service.deleteDocument(id, withMetaData));
		
	}
	
	@Test
	void testDeleteDocument_tryCatch() {
		String id = "123";
		boolean withMetaData = true;
		// Mocking
		Mockito.when(alfrescoService.exists(id)).thenReturn(true);
		Mockito.when(alfrescoService.deleteDocument(id)).thenThrow(NullPointerException.class);
		Mockito.when(elasticRepository.exists(id)).thenReturn(true);
		Mockito.when(elasticRepository.deleteDocument(id)).thenReturn(true);
		
		
		      // Call the method you want to test
			 CommonResponse result = service.deleteDocument(id, withMetaData); 
		      // If no exception is thrown, fail the test
		  
		      assertNotNull(result);
		  
		  }

	@Test
	void testDeleteDocument_withId() {
		String id = "123";
		boolean withMetaData = true;
		// Mocking
		Mockito.when(alfrescoService.exists(id)).thenReturn(true);
		Mockito.when(alfrescoService.deleteDocument(id)).thenThrow(NullPointerException.class);
		Mockito.when(elasticRepository.exists(id)).thenReturn(true);
		Mockito.when(elasticRepository.deleteDocument(id)).thenReturn(true);
		
		
		      // Call the method you want to test
			 CommonResponse result = service.deleteDocument(id); 
		      // If no exception is thrown, fail the test
		  
		      assertNotNull(result);
		  
		  }


	@SuppressWarnings("unchecked")
	@Test
	void search_returnsPageOfDocClaimRdResponses_whenSearchParamsProvided() {
		DocClaimTransportSearchParams searchParams = new DocClaimTransportSearchParams();
		searchParams.setPageNumber(1);
		searchParams.setPageSize(10);
		Page<DocClaimTransportResponse> result = service.search(searchParams);
		assertNotNull(result);

	}

	@SuppressWarnings("unchecked")
	@Test
	void updateDocument_returnsok_whenSearchParamsMetaDataNotProvided() {
		DocClaimTransportUpdateReq req = null;
		String documentId = "12345";
		assertThrows(NullPointerException.class, () -> service.updateDocument(documentId, req));
	}

	@SuppressWarnings("unchecked")
	@Test
	void updateDocument_returnsok_whenSearchParamsMetaIdDocNotProvided() {
		DocClaimTransportUpdateReq req = new DocClaimTransportUpdateReq();
		req.setAssureNom("test");
		String documentId = "";
		assertThrows(IllegalArgumentException.class, () -> service.updateDocument(documentId, req));
	}

	@SuppressWarnings("unchecked")
	@Test
	void updateDocument_returnsok_whenNotExistsInElasticSearch() {
		DocClaimTransportUpdateReq req;
		req = ClaimTransportDataGenerator.getUpdateRequestDto();
		String documentId = "12345";

		assertThrows(GlobalException.class, () -> service.updateDocument(documentId, req));
	}

	@SuppressWarnings("unchecked")
	@Test
	void updateDocument_returnsok_whenExistsInElasticSearch() {
		DocClaimTransportUpdateReq req;
		req = ClaimTransportDataGenerator.getUpdateRequestDto();
		String documentId = "12345";
		when(elasticRepository.exists(documentId)).thenReturn(true);
		when(elasticRepository.findById(documentId)).thenReturn(Optional.of(ClaimTransportDataGenerator.getDocumentEs()));
		when(transportMapper.toDto(any(DocumentClaimTransportEs.class))).thenReturn(ClaimTransportDataGenerator.getOnResponseDoc());
		DocClaimTransportResponse result = service.updateDocument(documentId, req);
		assertNotNull(result);

	}

}
