package ma.axa.inner.ged.mapper;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import ma.axa.inner.ged.domain.parametrage.RepertoireParametrage;
import ma.axa.inner.ged.dto.parametrage.RepertoireResponseDto;
import ma.axa.inner.ged.mapper.parametrage.RepertoireMapper;
import ma.axa.inner.ged.mapper.parametrage.RepertoireMapperImpl;

public class RepertoireMapperTest {

    private RepertoireMapper repertoireMapper;

    @Mock
    private RepertoireParametrage repertoireParametrage;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        repertoireMapper = new RepertoireMapperImpl();
    }

    @Test
    public void testMapToRepertoireDto() {
        // Set up the input object
        BigDecimal code = new BigDecimal("123");
        String libelle = "Test";
        when(repertoireParametrage.getCode()).thenReturn(code);
        when(repertoireParametrage.getLibelle()).thenReturn(libelle);

        // Call the mapToRepertoireDto() method
        RepertoireResponseDto result = repertoireMapper.mapToRepertoireDto(repertoireParametrage);

        // Verify the output object
        assertEquals(code.intValue(), result.getCodeRepertoire());
        assertEquals(libelle, result.getLibelleRepertoire());
    }

    @Test
    public void testMapToRepertoireDtoList() {
        // Set up the input list
        List<RepertoireParametrage> inputList = new ArrayList<>();
        BigDecimal code1 = new BigDecimal("123");
        String libelle1 = "Test1";
        RepertoireParametrage repertoireParametrage1 = new RepertoireParametrage(code1, libelle1);
        BigDecimal code2 = new BigDecimal("456");
        String libelle2 = "Test2";
        RepertoireParametrage repertoireParametrage2 = new RepertoireParametrage(code2, libelle2);
        inputList.add(repertoireParametrage1);
        inputList.add(repertoireParametrage2);

        // Call the mapToRepertoireDtoList() method
        List<RepertoireResponseDto> resultList = repertoireMapper.mapToRepertoireDtoList(inputList);

        // Verify the output list
        assertEquals(inputList.size(), resultList.size());
        assertEquals(code1.intValue(), resultList.get(0).getCodeRepertoire());
        assertEquals(libelle1, resultList.get(0).getLibelleRepertoire());
        assertEquals(code2.intValue(), resultList.get(1).getCodeRepertoire());
        assertEquals(libelle2, resultList.get(1).getLibelleRepertoire());
    }
}
