package ma.axa.inner.ged.claims.transport.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.ShardStatistics;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import ma.axa.inner.ged.claim.transport.domain.DocumentClaimTransportEs;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportSearchParams;
import ma.axa.inner.ged.claim.transport.repository.ClaimTransportElasticRepository;
import ma.axa.inner.ged.claims.transport.util.ClaimTransportDataGenerator;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.repository.ElasticSearchNewRepository;
import ma.axa.inner.ged.util.GedDataGenerator;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ClaimTransportElasticRepositoryTest {

	@InjectMocks
	ClaimTransportElasticRepository claimTransportElasticRepository;
	@Mock
	BrancheProperties transportProperties;
	@Mock
	ElasticSearchNewRepository elasticRepository;

	@Test
	@DisplayName("deleteDocument_shouldReturnTrueWhenDocumentIsDeleted")
	void deleteDocument_shouldReturnTrueWhenDocumentIsDeleted() {
		boolean expectedResult = true;
		when(elasticRepository.deleteDocument(anyString(), anyString())).thenReturn(expectedResult);
		when(transportProperties.getEsDocIndex()).thenReturn(GedDataGenerator.IDX_CLAIM_TRANSPORT);
		boolean result = claimTransportElasticRepository.deleteDocument(ClaimTransportDataGenerator.DOCUMENT_ID);
		assertEquals(expectedResult, result);
		verify(elasticRepository).deleteDocument(GedDataGenerator.IDX_CLAIM_TRANSPORT,
				ClaimTransportDataGenerator.DOCUMENT_ID);
	}

	@Test
	@DisplayName("deleteDocument_shouldThrowIllegalArgumentExceptionWhenDocumentIdIsBlank")
	void deleteDocument_shouldThrowIllegalArgumentExceptionWhenDocumentIdIsBlank() {
		String documentId = "";
		assertThrows(IllegalArgumentException.class, () -> claimTransportElasticRepository.deleteDocument(documentId));
	}

	@Test
	@DisplayName("findByCriteria_shouldReturnCorrectResultWhenValidParamsAreProvided")
	void findByCriteria_shouldReturnCorrectResultWhenValidParamsAreProvided()
			throws ElasticsearchException, IOException {
		DocClaimTransportSearchParams searchParams = new DocClaimTransportSearchParams();
		searchParams.setPageNumber(0);
		searchParams.setPageSize(10);
		SearchResponse<DocumentClaimTransportEs> expectedResult = SearchResponse.of(b -> b.took(0)
				.timedOut(false)
				.hits(b2 -> b2.hits(b3 -> b3.index(GedDataGenerator.IDX_CLAIM_TRANSPORT)
						.id(GedDataGenerator.ID_EXIST)
						.source(ClaimTransportDataGenerator.getDocumentEs())))
				.shards(ShardStatistics.of(b1 -> b1.total(1).successful(1).failed(0))));
		when(elasticRepository.search(any(SearchRequest.Builder.class), eq(DocumentClaimTransportEs.class)))
				.thenReturn(expectedResult);
		when(transportProperties.getEsDocIndex()).thenReturn(GedDataGenerator.IDX_CLAIM_TRANSPORT);

		SearchResponse<DocumentClaimTransportEs> result = claimTransportElasticRepository.findByCriteria(searchParams);
		Assertions.assertEquals(expectedResult, result);
		verify(elasticRepository).search(any(SearchRequest.Builder.class), eq(DocumentClaimTransportEs.class));
	}

	@Test
	@DisplayName("getQueryForMultiSearch_shouldReturnNotNullQuery")
	void getQueryForMultiSearch_shouldReturnNotNullQuery() {
		var searchParams = new DocClaimTransportSearchParams();
		searchParams.setNumPolice("1234");
		searchParams.setSinistreNumber("5678");
		searchParams.setIntermediaireCode(205);
		var query = ClaimTransportElasticRepository.getQueryForMultiSearch(searchParams);
		assertNotNull(query);
	}

	@Test
	@DisplayName("findOneDocumentByReference_shouldReturnDocumentWhenReferenceExists")
	void findOneDocumentByReference_shouldReturnDocumentWhenReferenceExists()
			throws ElasticsearchException, IOException {
		var expectedDocument = ClaimTransportDataGenerator.getDocumentEs();
		SearchResponse<DocumentClaimTransportEs> expectedResult = SearchResponse.of(b -> b.took(0)
				.timedOut(false)
				.hits(b2 -> b2.hits(b3 -> b3.index(GedDataGenerator.IDX_CLAIM_TRANSPORT)
						.id(GedDataGenerator.ID_EXIST)
						.source(ClaimTransportDataGenerator.getDocumentEs())))
				.shards(ShardStatistics.of(b1 -> b1.total(1).successful(1).failed(0))));
		when(elasticRepository.search(any(SearchRequest.Builder.class), eq(DocumentClaimTransportEs.class)))
				.thenReturn(expectedResult);
		when(transportProperties.getEsDocIndex()).thenReturn(GedDataGenerator.IDX_CLAIM_TRANSPORT);
		var result = claimTransportElasticRepository.findOneDocumentByReference(ClaimTransportDataGenerator.REFERENCE);
		Assertions.assertEquals(expectedDocument, result);
	}

}
