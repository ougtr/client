package ma.axa.inner.ged.postls.api;

import ma.axa.inner.ged.postels.api.DocPosteLsAPI;
import ma.axa.inner.ged.postels.dto.DocPosteLsReq;
import ma.axa.inner.ged.postels.dto.DocPosteLsResp;
import ma.axa.inner.ged.postels.dto.DocPosteLsUpdateReq;
import ma.axa.inner.ged.postels.dto.SearchEsReq;
import ma.axa.inner.ged.postels.service.DocPosteLsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DocPosteLsAPITest {

    @Mock
    private DocPosteLsService docPosteLsService;

    @InjectMocks
    private DocPosteLsAPI docPosteLsAPI;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void uploadPosteLsDoc_shouldReturnCreatedResponse() throws IOException {
        DocPosteLsReq req = new DocPosteLsReq();
        MultipartFile file = new MockMultipartFile("file", "test.txt", "text/plain", "test content".getBytes());
        DocPosteLsResp resp = new DocPosteLsResp();

        when(docPosteLsService.uploadDocWithMetaData(any(DocPosteLsReq.class), any(MultipartFile.class))).thenReturn(resp);

        ResponseEntity<DocPosteLsResp> response = docPosteLsAPI.uploadPosteLsDoc(req, file);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(resp, response.getBody());
        verify(docPosteLsService).uploadDocWithMetaData(req, file);
    }

    @Test
    void downloadPosteLsDocContent_shouldReturnResource() {
        String documentId = "doc123";
        Resource resource = new ByteArrayResource("data".getBytes());
        ResponseEntity<Resource> expected = ResponseEntity.ok(resource);

        when(docPosteLsService.downloadFile(documentId)).thenReturn(expected);

        ResponseEntity<Resource> response = docPosteLsAPI.downloadPosteLsDocContent(documentId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(resource, response.getBody());
        verify(docPosteLsService).downloadFile(documentId);
    }

    @Test
    void searchPosteLsMetadataByDocumentId_shouldReturnMetadata() {
        String documentId = "doc123";
        DocPosteLsResp resp = new DocPosteLsResp();

        when(docPosteLsService.getMetadataById(documentId)).thenReturn(resp);

        ResponseEntity<DocPosteLsResp> response = docPosteLsAPI.searchPosteLsMetadataByDocumentId(documentId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(resp, response.getBody());
        verify(docPosteLsService).getMetadataById(documentId);
    }

    @Test
    void searchPosteLsMetadataByCriteria_shouldReturnList() {
        SearchEsReq searchReq = new SearchEsReq();
        List<DocPosteLsResp> respList = Collections.singletonList(new DocPosteLsResp());

        when(docPosteLsService.getMetadataByCriteria(searchReq)).thenReturn(respList);

        ResponseEntity<List<DocPosteLsResp>> response = docPosteLsAPI.searchPosteLsMetadataByCriteria(searchReq);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(respList, response.getBody());
        verify(docPosteLsService).getMetadataByCriteria(searchReq);
    }

    @Test
    void searchPosteLsMetadataByCriteria_shouldHandleException() {
        SearchEsReq searchReq = new SearchEsReq();

        when(docPosteLsService.getMetadataByCriteria(searchReq)).thenThrow(new RuntimeException("error"));

        ResponseEntity<List<DocPosteLsResp>> response = docPosteLsAPI.searchPosteLsMetadataByCriteria(searchReq);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNull(response.getBody());
        verify(docPosteLsService).getMetadataByCriteria(searchReq);
    }

    @Test
    void updatePosteLsDoc_shouldReturnUpdatedDoc() {
        String documentId = "doc123";
        DocPosteLsUpdateReq updateReq = new DocPosteLsUpdateReq();
        DocPosteLsResp resp = new DocPosteLsResp();

        when(docPosteLsService.updateDocument(documentId, updateReq)).thenReturn(resp);

        ResponseEntity<DocPosteLsResp> response = docPosteLsAPI.updatePosteLsDoc(documentId, updateReq);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(resp, response.getBody());
        verify(docPosteLsService).updateDocument(documentId, updateReq);
    }

    @Test
    void deleteDocument_shouldReturnOk() {
        String documentId = "doc123";
        String result = "deleted";

        when(docPosteLsService.deleteDocument(documentId)).thenReturn(result);

        ResponseEntity<String> response = docPosteLsAPI.deleteDocument(documentId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(result, response.getBody());
        verify(docPosteLsService).deleteDocument(documentId);
    }
}
