package ma.axa.inner.ged.claims.ls.mapper;

import ma.axa.inner.ged.claim.ls.dto.DocClaimLsReq;
import ma.axa.inner.ged.claim.ls.mapper.ClaimLsAlfrescoMapper;

import ma.axa.inner.ged.util.constants.AXADocPropertyIds;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ClaimLsAlfrescoMapperTest {

	@Test
	@DisplayName("ClaimLsAlfrescoMapper_classMustNotBeInstantiate")
	void testClaimLsAlfrescoMapperClass()
			throws IllegalAccessException, InstantiationException {
		final Class<?> cls = ClaimLsAlfrescoMapper.class;
		final Constructor<?> c = cls.getDeclaredConstructors()[0];
		c.setAccessible(true);

		Throwable targetException = null;
		try {
			c.newInstance((Object[]) null);
		} catch (InvocationTargetException e) {
			targetException = e.getTargetException();
		}

		assertThat(targetException)
				.overridingErrorMessage("The expected value should not null")
				.isNotNull();

		assertThat(targetException.getClass())
				.overridingErrorMessage("The expected value should be [InstantiationException.class]")
				.isEqualTo(InstantiationException.class);
	}

	@Test
	@DisplayName("ClaimLsAlfrescoMapper_toFolderProperties_shouldReturnTheRighProperties")
	void toFolderProperties_shouldReturnTheRighProperties() {
		var addRequest = DocClaimLsReq.builder().sinistreNumber("102093029").build();
		
		var mappedRequest = ClaimLsAlfrescoMapper.toFolderProperties(addRequest);
		
		assertEquals(mappedRequest.get(AXADocPropertyIds.NUMERO_SINISTRE_DOSSIER),
				addRequest.getSinistreNumber());

		
		var otherProps = new HashMap<String, Object>();
		otherProps.put("custom", "value");
		var mappedRequest2 = ClaimLsAlfrescoMapper.toFolderProperties(addRequest, otherProps);
		
		assertEquals(mappedRequest2.get(AXADocPropertyIds.NUMERO_SINISTRE_DOSSIER),
				addRequest.getSinistreNumber());
	}
	
	@Test
	@DisplayName("ClaimLsAlfrescoMapper_toDocumentProperties_shouldReturnTheRighProperties")
	void toDocumentProperties_shouldReturnTheRighProperties() {
		var addRequest = DocClaimLsReq.builder().sinistreNumber("102093029").build();
		var mappedRequest = ClaimLsAlfrescoMapper.toDocumentProperties(addRequest);
		assertEquals(mappedRequest.get(AXADocPropertyIds.NUMERO_SINISTRE),
				addRequest.getSinistreNumber());
	}

}
