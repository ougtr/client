package ma.axa.inner.ged.claims.ls.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.ls.api.ClaimLsDocumentAPI;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsResp;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsSearchParams;
import ma.axa.inner.ged.claim.ls.service.ClaimLsDocumentService;
import ma.axa.inner.ged.claims.ls.util.ClaimLsDataGenerator;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.dto.CommonResponse;
import ma.axa.inner.ged.exception.RequestValidationException;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.exception.ResourceNotFoundException;
import ma.axa.inner.ged.util.FileGenerator;
import ma.axa.inner.ged.util.ResponseUtils;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.nio.charset.StandardCharsets;
import java.util.Collections;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@Slf4j
@WebMvcTest(ClaimLsDocumentAPI.class)
@Import({RequestFacade.class})
@MockBean({Tracer.class})
@ExtendWith(SpringExtension.class)
class ClaimLsDocumentAPITest {

	private static final String service_path = "/v1/claims/ls/documents";

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private ClaimLsDocumentService service;
	@Autowired
	private ObjectMapper mapper;
	
	@MockBean
	private DataSourceContextHolder dataSourceContextHolder;

	@BeforeEach
	void initMockServices() {
		try {
			when(service.getDocumentById(any(String.class))).thenReturn(ClaimLsDataGenerator.getOnResponseDoc());
		} catch (Exception e) {
			log.error("Error during init test class, err: {}", e.getMessage());
		}
	}

	@Test
	@DisplayName("claimLs_uploadDocument_ShouldReturn200WithContent")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void uploadDocument_ShouldReturn200WithContent() throws Exception {
		when(service.uploadDocWithMetaData(any(), any())).thenReturn(ClaimLsDataGenerator.getOnResponseDoc());
		var meta = ClaimLsDataGenerator.getAddRequest();
		var request = multipart(service_path)
				.file(FileGenerator.getPdfFile())
				.contentType(MediaType.MULTIPART_FORM_DATA_VALUE)
				.params(meta);
		mockMvc.perform(request)
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.id", is(ClaimLsDataGenerator.DOCUMENT_ID)));
	}

	@Test
	@DisplayName("claimLs_uploadDocument_ShouldThrowReferenceAlreadyExist")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void uploadDocument_ShouldThrowReferenceAlreadyExist() throws Exception {
		when(service.uploadDocWithMetaData(any(), any()))
				.thenThrow(new ResourceAlreadyExist(GlobalConstants.URI_RECORDE_ALREADY_EXIST,
						"Document with reference '{0}' already exist",
						new String[] { ClaimLsDataGenerator.REFERENCE }));

		var meta = ClaimLsDataGenerator.getAddRequest(ClaimLsDataGenerator.REFERENCE);
		var request = multipart(service_path)
				.file(FileGenerator.getPdfFile())
				.contentType(MediaType.MULTIPART_FORM_DATA_VALUE)
				.params(meta);
		mockMvc.perform(request)
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.type", is(GlobalConstants.URI_RECORDE_ALREADY_EXIST)));
	}

	@Test
	@DisplayName("claimLs_uploadDocument_ShouldThrowRequestValidationException")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void uploadDocument_ShouldThrowRequestValidationException() throws Exception {
		when(service.uploadDocWithMetaData(any(), any()))
				.thenThrow(new RequestValidationException("Error validation",
						Collections.singletonMap("status", "Must fill sinistre number to update status = IDENTIFIE")));

		var meta = ClaimLsDataGenerator.getAddRequestForFaildValidation();
		var request = multipart(service_path)
				.file(FileGenerator.getPdfFile())
				.contentType(MediaType.MULTIPART_FORM_DATA_VALUE)
				.params(meta);
		mockMvc.perform(request)
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.type", is(GlobalConstants.URI_BUSINESS_REQUEST_VALIDATION)))
				.andExpect(jsonPath("$.errors", notNullValue()));
	}

	@Test
	@DisplayName("claimLs_downloadPdfById_shouldReturn200WithContent")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void downloadPdfById_shouldReturn200WithContent() throws Exception {
		var resource = new ByteArrayResource("content".getBytes(StandardCharsets.UTF_8));
		var headers = ResponseUtils.getDownloadHeaders("filename.pdf", resource.contentLength(), "application/pdf");
		when(service.downloadFile(any(String.class)))
				.thenReturn(ResponseEntity.ok().headers(headers).body(resource));
		var fullPath = String.format("%s/%s/content", service_path, ClaimLsDataGenerator.DOCUMENT_ID);
		var requestBuilder = MockMvcRequestBuilders.get(fullPath);
		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_PDF))
				.andExpect(content().bytes("content".getBytes(StandardCharsets.UTF_8)));
	}

	@Test
	@DisplayName("claimLs_downloadDocumentById_shouldReturn404DocumentIdNotFound")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void downloadDocumentById_shouldThrow404DocumentIdNotFound() throws Exception {
		when(service.downloadFile(any(String.class)))
				.thenThrow(new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
						"Document with id '{0}' not found",
						new String[] { ClaimLsDataGenerator.DOCUMENT_ID }));

		var fullPath = String.format("%s/%s/content", service_path, ClaimLsDataGenerator.DOCUMENT_ID);
		var requestBuilder = MockMvcRequestBuilders.get(fullPath);
		mockMvc.perform(requestBuilder)
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("$.type", is(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND)));
	}

	@Test
	@DisplayName("claimLs_deleteDocumentById_ShouldSucceed")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void deleteDocumentById_ShouldSucceed() throws Exception {
		when(service.deleteDocument(anyString())).thenReturn("deleted");

		var fullPath = String.format("%s/%s", service_path, ClaimLsDataGenerator.DOCUMENT_ID);
		var requestBuilder = MockMvcRequestBuilders
				.delete(fullPath);
		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk());
	}


	@Test
	@DisplayName("claimLs_searchDocuments_ShouldThrowBadRequest400")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void searchDocuments_ShouldThrowBadRequest400() throws Exception {
		var requestBuilder = MockMvcRequestBuilders
				.get(service_path)
				.queryParams(ClaimLsDataGenerator.getSearchParams(-1, 10));
		mockMvc.perform(requestBuilder)
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errors", notNullValue()))
				.andExpect(jsonPath("$.errors").isArray())
				.andExpect(jsonPath("$.type", is(GlobalConstants.URI_VALIDATION_CONSTRAINT_VIOLATION)));
	}

	@Test
	@DisplayName("claimLs_searchDocuments_shouldReturn200WhenDocumentsAreFound")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void searchDocuments_shouldReturn200WhenDocumentsAreFound() throws Exception {
		var searchParams = new DocClaimLsSearchParams();
		var expectedResult = new PageImpl<>(Collections.singletonList(new DocClaimLsResp()));
		when(service.search(searchParams)).thenReturn(expectedResult);
		var requestBuilder = MockMvcRequestBuilders
				.get(service_path)
				.queryParams(ClaimLsDataGenerator.getSearchParams(1, 10));
		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk());
	}

	@Test
	@DisplayName("claimLs_searchDocuments_shouldReturn200WhenDocumentsAreFound")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void update_shouldReturn200() throws Exception {
		var documentReq = ClaimLsDataGenerator.getUpdateRequestDto();
		var expectedResponse = ClaimLsDataGenerator.getOnResponseAfterUpdateDoc();
		when(service.updateDocument(ClaimLsDataGenerator.DOCUMENT_ID, documentReq)).thenReturn(expectedResponse);
		var fullPath = String.format("%s/%s", service_path, ClaimLsDataGenerator.DOCUMENT_ID);
		var requestBuilder = MockMvcRequestBuilders
				.put(fullPath)
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(documentReq));
		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk());

	}

}
