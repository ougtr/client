package ma.axa.inner.ged.api;

import ma.axa.inner.ged.api.ac.DocumentDirectoryApi;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.service.ac.DirectoriesService;
import ma.axa.inner.ged.util.DataGenerator;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(DocumentDirectoryApi.class)
@AutoConfigureMockMvc(addFilters = false)
class DocumentDirectoryApiTest {

    @MockBean
    DirectoriesService directoriesService;

    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
	private DataSourceContextHolder dataSourceContextHolder;

    @WithMockUser
    @Test
    void getListRepositories_Ok() throws Exception {

        when(directoriesService.getAllRepositories()).thenReturn(DataGenerator.repositoryListBuilder());

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/claims/ac/params/directories")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }

}