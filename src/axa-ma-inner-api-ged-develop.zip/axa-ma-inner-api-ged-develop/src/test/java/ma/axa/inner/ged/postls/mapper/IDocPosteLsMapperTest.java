package ma.axa.inner.ged.postls.mapper;

import ma.axa.inner.ged.postels.domain.DocPosteLsEs;
import ma.axa.inner.ged.postels.dto.DocPosteLsReq;
import ma.axa.inner.ged.postels.dto.DocPosteLsResp;
import ma.axa.inner.ged.postels.dto.DocPosteLsUpdateReq;
import ma.axa.inner.ged.postels.mapper.IDocPosteLsMapperImpl;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class IDocPosteLsMapperTest {

    private final IDocPosteLsMapperImpl mapper = new IDocPosteLsMapperImpl();

    @Test
    void testToDto_NullInput() {
        assertNull(mapper.toDto((DocPosteLsEs) null));
    }

    @Test
    void testToDto_ValidInput() {
        DocPosteLsEs doc = DocPosteLsEs.builder()
                .idAlfresco("id1")
                .filename("file.pdf")
                .numPolice("NP123")
                .numQuotation("NQ456")
                .reference("REF789")
                .createdBy("user1")
                .updatedBy("user2")
                .applicationCode("APP")
                .comment("A comment")
                .original(true)
                .typeDocumentCode("TDC")
                .repertoire("REP")
                .repertoireCode("RC")
                .path("/path/to/file")
                .brancheLabel("Branche")
                .typeDocumentLabel("TypeDoc")
                .build();

        DocPosteLsResp resp = mapper.toDto(doc);

        assertNotNull(resp);
        assertEquals("id1", resp.getIdAlfresco());
        assertEquals("file.pdf", resp.getFilename());
        assertEquals("NP123", resp.getNumPolice());
        assertEquals("NQ456", resp.getNumQuotation());
        assertEquals("REF789", resp.getReference());
        assertEquals("user1", resp.getCreatedBy());
        assertEquals("user2", resp.getUpdatedBy());
        assertEquals("APP", resp.getApplicationCode());
        assertEquals("A comment", resp.getComment());
        assertTrue(resp.isOriginal());
        assertEquals("TDC", resp.getTypeDocumentCode());
        assertEquals("REP", resp.getRepertoire());
        assertEquals("RC", resp.getRepertoireCode());
        assertEquals("/path/to/file", resp.getPath());
        assertEquals("Branche", resp.getBrancheLabel());
        assertEquals("TypeDoc", resp.getTypeDocumentLabel());
    }

    @Test
    void testToDto_List() {
        DocPosteLsEs doc1 = DocPosteLsEs.builder().idAlfresco("id1").build();
        DocPosteLsEs doc2 = DocPosteLsEs.builder().idAlfresco("id2").build();
        List<DocPosteLsEs> docs = Arrays.asList(doc1, doc2);

        List<DocPosteLsResp> resps = mapper.toDto(docs);

        assertNotNull(resps);
        assertEquals(2, resps.size());
        assertEquals("id1", resps.get(0).getIdAlfresco());
        assertEquals("id2", resps.get(1).getIdAlfresco());
    }

    @Test
    void testFromDto_NullInput() {
        assertNull(mapper.fromDto((DocPosteLsReq) null));
        assertNull(mapper.fromDto((DocPosteLsUpdateReq) null));
    }

    @Test
    void testFromDto_ValidDocPosteLsReq() {
        DocPosteLsReq req = new DocPosteLsReq();
        req.setFilename("file.pdf");
        req.setNumPolice("NP123");
        req.setNumQuotation("NQ456");
        req.setReference("REF789");
        req.setCreatedBy("user1");
        req.setUpdatedBy("user2");
        req.setApplicationCode("APP");
        req.setComment("A comment");
        req.setOriginal(true);
        req.setTypeDocumentCode("TDC");
        req.setRepertoire("REP");
        req.setRepertoireCode("RC");
        req.setPath("/path/to/file");
        req.setBrancheLabel("Branche");
        req.setTypeDocumentLabel("TypeDoc");

        DocPosteLsEs doc = mapper.fromDto(req);

        assertNotNull(doc);
        assertEquals("file.pdf", doc.getFilename());
        assertEquals("NP123", doc.getNumPolice());
        assertEquals("NQ456", doc.getNumQuotation());
        assertEquals("REF789", doc.getReference());
        assertEquals("user1", doc.getCreatedBy());
        assertEquals("user2", doc.getUpdatedBy());
        assertEquals("APP", doc.getApplicationCode());
        assertEquals("A comment", doc.getComment());
        assertTrue(doc.isOriginal());
        assertEquals("TDC", doc.getTypeDocumentCode());
        assertEquals("REP", doc.getRepertoire());
        assertEquals("RC", doc.getRepertoireCode());
        assertEquals("/path/to/file", doc.getPath());
        assertEquals("Branche", doc.getBrancheLabel());
        assertEquals("TypeDoc", doc.getTypeDocumentLabel());
    }

    @Test
    void testFromDto_ValidDocPosteLsUpdateReq() {
        DocPosteLsUpdateReq req = new DocPosteLsUpdateReq();
        req.setNumPolice("NP123");
        req.setNumQuotation("NQ456");
        req.setComment("A comment");
        req.setOriginal(false);
        req.setTypeDocumentCode("TDC");

        DocPosteLsEs doc = mapper.fromDto(req);

        assertNotNull(doc);
        assertEquals("NP123", doc.getNumPolice());
        assertEquals("NQ456", doc.getNumQuotation());
        assertEquals("A comment", doc.getComment());
        assertFalse(doc.isOriginal());
        assertEquals("TDC", doc.getTypeDocumentCode());
    }

    @Test
    void testFromDto_List() {
        DocPosteLsReq req1 = new DocPosteLsReq();
        req1.setFilename("file1.pdf");
        DocPosteLsReq req2 = new DocPosteLsReq();
        req2.setFilename("file2.pdf");
        List<DocPosteLsReq> reqs = Arrays.asList(req1, req2);

        List<DocPosteLsEs> docs = mapper.fromDto(reqs);

        assertNotNull(docs);
        assertEquals(2, docs.size());
        assertEquals("file1.pdf", docs.get(0).getFilename());
        assertEquals("file2.pdf", docs.get(1).getFilename());
    }

    @Test
    void testUpdateFromDto() {
        DocPosteLsUpdateReq req = new DocPosteLsUpdateReq();
        req.setNumPolice("NP999");
        req.setNumQuotation("NQ888");
        req.setComment("Updated comment");
        req.setOriginal(true);
        req.setTypeDocumentCode("TDC999");

        DocPosteLsEs doc = DocPosteLsEs.builder()
                .numPolice("oldPolice")
                .numQuotation("oldQuotation")
                .comment("old comment")
                .original(false)
                .typeDocumentCode("oldTDC")
                .build();

        mapper.updateFromDto(req, doc);

        assertEquals("NP999", doc.getNumPolice());
        assertEquals("NQ888", doc.getNumQuotation());
        assertEquals("Updated comment", doc.getComment());
        assertTrue(doc.isOriginal());
        assertEquals("TDC999", doc.getTypeDocumentCode());
    }

    @Test
    void testUpdateFromDto_NullReq() {
        DocPosteLsEs doc = DocPosteLsEs.builder()
                .numPolice("oldPolice")
                .numQuotation("oldQuotation")
                .comment("old comment")
                .original(false)
                .typeDocumentCode("oldTDC")
                .build();

        mapper.updateFromDto(null, doc);

        // Should remain unchanged
        assertEquals("oldPolice", doc.getNumPolice());
        assertEquals("oldQuotation", doc.getNumQuotation());
        assertEquals("old comment", doc.getComment());
        assertFalse(doc.isOriginal());
        assertEquals("oldTDC", doc.getTypeDocumentCode());
    }
}
