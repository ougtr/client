package ma.axa.inner.ged.api.at;

import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.service.at.DirectoriesATService;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(DocumentDirectoryAtApi.class)
@AutoConfigureMockMvc(addFilters = false)
@WebAppConfiguration
class DocumentDirectoryApiTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DirectoriesATService mockDirectoriesATService;
    
    @MockBean
   	private DataSourceContextHolder dataSourceContextHolder;


    @Test
    void testGetListOfRepositories_DirectoriesServiceReturnsNoItems() throws Exception {
        // Setup
        when(mockDirectoriesATService.getAllRepositories()).thenReturn(Collections.emptyList());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/v1/claims/at/params/directories")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("[]");
    }
}
