package ma.axa.inner.ged.helper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import feign.FeignException;

import java.math.BigDecimal;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ma.axa.inner.ged.domain.*;
import ma.axa.inner.ged.domain.at.DocumentSinistreATES;
import ma.axa.inner.ged.dto.CimaRequestDocument;
import ma.axa.inner.ged.enums.ESBulkOperationsEnum;
import ma.axa.inner.ged.repository.ElasticSearchDocumentRepository;
import ma.axa.inner.ged.util.EsPropertiesAtDoc;
import ma.axa.inner.ged.util.EsPropertiesAutoDocument;
import ma.axa.inner.ged.util.EsPropertiesCimaDoc;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.core.JsonProcessingException;

@ContextConfiguration(classes = {ElasticSearchHelper.class, EsPropertiesAutoDocument.class, EsPropertiesAtDoc.class, EsPropertiesCimaDoc.class})
@ExtendWith(SpringExtension.class)
class ElasticSearchHelperTest {
    @MockBean
    private ElasticSearchDocumentRepository elasticSearchDocumentRepository;

    @Autowired
    private ElasticSearchHelper elasticSearchHelper;

    @Autowired
    private EsPropertiesAtDoc esPropertiesAtDoc;

    @Autowired
    private EsPropertiesAutoDocument esPropertiesAutoDocument;

    @Mock
    private EsPropertiesCimaDoc esPropertiesCimaDoc;

    @Test
    void testGetUnionOfMetadatasWithFieldQuery() {
        assertTrue(
                elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse.DEFAULT, new HashMap<>()).isEmpty());
        assertTrue(elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse.TEMPORARY, new HashMap<>())
                .isEmpty());
    }

    @Test
    void testGetUnionOfMetadatasWithFieldQuery2() {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        ESDocumentSchema esDocumentSchema = new ESDocumentSchema();
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);

        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "42");
        assertTrue(
                elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse.DEFAULT, objectStringMap).isEmpty());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
    }


    @Test
    void testGetUnionOfMetadatasWithFieldQuery3() {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHit documentSinistreAutoHit = new DocumentSinistreAutoHit();
        documentSinistreAutoHit.setId("42");
        documentSinistreAutoHit.setIndex("Index");
        documentSinistreAutoHit.setScore(10.0d);
        documentSinistreAutoHit.setSource(new PreDeclarationTypeDoc());
        documentSinistreAutoHit.setType("Type");

        ArrayList<DocumentSinistreAutoHit> documentSinistreAutoHitList = new ArrayList<>();
        documentSinistreAutoHitList.add(documentSinistreAutoHit);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(documentSinistreAutoHitList);
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);

        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "42");
        assertEquals(1,
                elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse.DEFAULT, objectStringMap).size());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
        verify(esDocumentSchema).getHits();
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }


    @Test
    void testGetUnionOfMetadatasWithFieldQuery4() {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHit documentSinistreAutoHit = new DocumentSinistreAutoHit();
        documentSinistreAutoHit.setId("42");
        documentSinistreAutoHit.setIndex("Index");
        documentSinistreAutoHit.setScore(10.0d);
        documentSinistreAutoHit.setSource(new PreDeclarationTypeDoc());
        documentSinistreAutoHit.setType("Type");

        DocumentSinistreAutoHit documentSinistreAutoHit1 = new DocumentSinistreAutoHit();
        documentSinistreAutoHit1
                .setId("Start helper : get metadatas where at least one (key,value) matches its fields '{}'");
        documentSinistreAutoHit1.setIndex("nSin");
        documentSinistreAutoHit1.setScore(0.5d);
        documentSinistreAutoHit1.setSource(new PreDeclarationTypeDoc());
        documentSinistreAutoHit1.setType("nSin");

        ArrayList<DocumentSinistreAutoHit> documentSinistreAutoHitList = new ArrayList<>();
        documentSinistreAutoHitList.add(documentSinistreAutoHit1);
        documentSinistreAutoHitList.add(documentSinistreAutoHit);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(documentSinistreAutoHitList);
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);

        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "42");
        assertEquals(2,
                elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse.DEFAULT, objectStringMap).size());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
        verify(esDocumentSchema).getHits();
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }

    /**
     * Method under test: {@link ElasticSearchHelper#getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse, HashMap)}
     */
    @Test
    void testGetUnionOfMetadatasWithFieldQuery5() throws FeignException {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(new ArrayList<>());
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);

        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "42");
        assertTrue(
                elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse.TEMPORARY, objectStringMap).isEmpty());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
        verify(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        verify(esDocumentSchema).getHits();
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }

    /**
     * Method under test: {@link ElasticSearchHelper#getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse, HashMap)}
     */
    @Test
    void testGetUnionOfMetadatasWithFieldQuery6() throws FeignException {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(new ArrayList<>());
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);

        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "42");
        assertTrue(elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(null, objectStringMap).isEmpty());
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }

    /**
     * Method under test: {@link ElasticSearchHelper#getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse, HashMap)}
     */
    @Test
    void testGetUnionOfMetadatasWithFieldQuery7() throws FeignException {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(new ArrayList<>());
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);

        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "nSin");
        assertTrue(
                elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse.TEMPORARY, objectStringMap).isEmpty());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
        verify(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        verify(esDocumentSchema).getHits();
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }

    /**
     * Method under test: {@link ElasticSearchHelper#getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse, HashMap)}
     */
    @Test
    void testGetUnionOfMetadatasWithFieldQuery8() throws FeignException {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(new ArrayList<>());
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);

        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "idPredeclaration");
        assertTrue(
                elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse.TEMPORARY, objectStringMap).isEmpty());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
        verify(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        verify(esDocumentSchema).getHits();
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }

    @Test
    void testGetUnionOfMetadatasWithFieldQuery10() throws FeignException {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(new ArrayList<>());
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);

        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "idAlfresco");
        assertTrue(
                elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse.TEMPORARY, objectStringMap).isEmpty());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
        verify(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        verify(esDocumentSchema).getHits();
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }

    /**
     * Method under test: {@link ElasticSearchHelper#getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse, HashMap)}
     */
    @Test
    void testGetUnionOfMetadatasWithFieldQuery11() throws FeignException {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(new ArrayList<>());
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);

        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "userC");
        assertTrue(
                elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse.TEMPORARY, objectStringMap).isEmpty());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
        verify(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        verify(esDocumentSchema).getHits();
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }

    /**
     * Method under test: {@link ElasticSearchHelper#getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse, HashMap)}
     */
    @Test
    void testGetUnionOfMetadatasWithFieldQuery12() throws FeignException {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(new ArrayList<>());
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);

        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "userM");
        assertTrue(
                elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse.TEMPORARY, objectStringMap).isEmpty());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
        verify(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        verify(esDocumentSchema).getHits();
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }

    @Test
    void testGetUnionOfMetadatasWithFieldQuery15() throws FeignException {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(new ArrayList<>());
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);

        ESResponseIndex esResponseIndex = new ESResponseIndex();
        esResponseIndex.setAcknowledged(true);
        when(elasticSearchDocumentRepository.createTemporaryIndex()).thenReturn(esResponseIndex);
        doThrow(mock(FeignException.class)).when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);

        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "42");
        assertTrue(
                elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse.TEMPORARY, objectStringMap).isEmpty());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
        verify(elasticSearchDocumentRepository).createTemporaryIndex();
        verify(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        verify(esDocumentSchema).getHits();
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }

    @Test
    void testInsertMultipleMetadatas2() {
        EsMultipleResponses esMultipleResponses = new EsMultipleResponses();
        esMultipleResponses.setItems(new ArrayList<>());
        when(elasticSearchDocumentRepository.multipleActionRequests((String) any())).thenReturn(esMultipleResponses);
        assertTrue(elasticSearchHelper.insertMultipleMetadatas(IndexOrPathToUse.DEFAULT, new ArrayList<>()).isEmpty());
        verify(elasticSearchDocumentRepository).multipleActionRequests((String) any());
    }

    @Test
    void testInsertMultipleMetadatas7() throws FeignException {
        EsMultipleResponses esMultipleResponses = mock(EsMultipleResponses.class);
        when(esMultipleResponses.getItems()).thenReturn(new ArrayList<>());
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.multipleActionRequests((String) any())).thenReturn(esMultipleResponses);

        ArrayList<PreDeclarationTypeDoc> preDeclarationTypeDocList = new ArrayList<>();
        preDeclarationTypeDocList.add(new PreDeclarationTypeDoc());
        assertTrue(
                elasticSearchHelper.insertMultipleMetadatas(IndexOrPathToUse.TEMPORARY, preDeclarationTypeDocList).isEmpty());
        verify(elasticSearchDocumentRepository).multipleActionRequests((String) any());
        verify(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        verify(esMultipleResponses).getItems();
    }

    /**
     * Method under test: {@link ElasticSearchHelper#insertMultipleMetadatas(IndexOrPathToUse, List)}
     */
    @Test
    void testInsertMultipleMetadatas8() throws FeignException {
        EsMultipleResponses esMultipleResponses = mock(EsMultipleResponses.class);
        when(esMultipleResponses.getItems()).thenReturn(new ArrayList<>());
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.multipleActionRequests((String) any())).thenReturn(esMultipleResponses);

        ArrayList<PreDeclarationTypeDoc> preDeclarationTypeDocList = new ArrayList<>();
        preDeclarationTypeDocList.add(new PreDeclarationTypeDoc());
        assertTrue(
                elasticSearchHelper.insertMultipleMetadatas(IndexOrPathToUse.DEFAULT, preDeclarationTypeDocList).isEmpty());
        verify(elasticSearchDocumentRepository).multipleActionRequests((String) any());
        verify(esMultipleResponses).getItems();
    }

    /**
     * Method under test: {@link ElasticSearchHelper#insertMultipleMetadatas(IndexOrPathToUse, List)}
     */
    @Test
    void testInsertMultipleMetadatas9() throws FeignException {
        EsMultipleResponses esMultipleResponses = mock(EsMultipleResponses.class);
        when(esMultipleResponses.getItems()).thenReturn(new ArrayList<>());
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.multipleActionRequests((String) any())).thenReturn(esMultipleResponses);

        ArrayList<PreDeclarationTypeDoc> preDeclarationTypeDocList = new ArrayList<>();
        preDeclarationTypeDocList.add(new PreDeclarationTypeDoc());
        preDeclarationTypeDocList.add(new PreDeclarationTypeDoc());
        assertTrue(
                elasticSearchHelper.insertMultipleMetadatas(IndexOrPathToUse.DEFAULT, preDeclarationTypeDocList).isEmpty());
        verify(elasticSearchDocumentRepository).multipleActionRequests((String) any());
        verify(esMultipleResponses).getItems();
    }

    /**
     * Method under test: {@link ElasticSearchHelper#insertMultipleMetadatas(IndexOrPathToUse, List)}
     */
    @Test
    void testInsertMultipleMetadatas10() throws FeignException {
        EsMultipleResponses esMultipleResponses = mock(EsMultipleResponses.class);
        when(esMultipleResponses.getItems()).thenReturn(new ArrayList<>());
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.multipleActionRequests((String) any())).thenReturn(esMultipleResponses);

        PreDeclarationTypeDoc preDeclarationTypeDoc = new PreDeclarationTypeDoc();
        preDeclarationTypeDoc.setIdAlfresco("Start helper : insert multiple metadata in elastic search to  '{}'");

        ArrayList<PreDeclarationTypeDoc> preDeclarationTypeDocList = new ArrayList<>();
        preDeclarationTypeDocList.add(preDeclarationTypeDoc);
        assertTrue(
                elasticSearchHelper.insertMultipleMetadatas(IndexOrPathToUse.DEFAULT, preDeclarationTypeDocList).isEmpty());
        verify(elasticSearchDocumentRepository).multipleActionRequests((String) any());
        verify(esMultipleResponses).getItems();
    }
    /**
     * Method under test: {@link ElasticSearchHelper#searchInDocumentsListsByQuery(IndexOrPathToUse, PreDeclarationTypeDoc)}
     */
    @Test
    void testSearchInDocumentsListsByQuery() {
        assertTrue(
                elasticSearchHelper.searchInDocumentsListsByQuery(IndexOrPathToUse.DEFAULT, new PreDeclarationTypeDoc())
                        .isEmpty());
        assertTrue(
                elasticSearchHelper.searchInDocumentsListsByQuery(IndexOrPathToUse.TEMPORARY, new PreDeclarationTypeDoc())
                        .isEmpty());
    }

    /**
     * Method under test: {@link ElasticSearchHelper#searchInDocumentsListsByQuery(IndexOrPathToUse, PreDeclarationTypeDoc)}
     */
    @Test
    void testSearchInDocumentsListsByQuery2() {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        ESDocumentSchema esDocumentSchema = new ESDocumentSchema();
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);
        BigDecimal codeExp = BigDecimal.valueOf(42L);
        BigDecimal dateC = BigDecimal.valueOf(42L);
        BigDecimal dateA = BigDecimal.valueOf(42L);
        BigDecimal heureC = BigDecimal.valueOf(42L);
        BigDecimal dateM = BigDecimal.valueOf(42L);
        BigDecimal heureM = BigDecimal.valueOf(42L);
        BigDecimal aclasserLe = BigDecimal.valueOf(42L);
        assertTrue(elasticSearchHelper
                .searchInDocumentsListsByQuery(IndexOrPathToUse.DEFAULT, new PreDeclarationTypeDoc(
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'", codeExp,
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'", dateC,
                        dateA, heureC, dateM, heureM, "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", 9, "Start: Search list of documents by query '{}'",
                        aclasserLe, "2020-03-01", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", true, "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", 9, "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "2020-03-01", "2020-03-01",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "2020-03-01", 3L, new ArrayList<>(), "42",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'"))
                .isEmpty());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
    }

    /**
     * Method under test: {@link ElasticSearchHelper#searchInDocumentsListsByQuery(IndexOrPathToUse, PreDeclarationTypeDoc)}
     */
    @Test
    void testSearchInDocumentsListsByQuery3() {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHit documentSinistreAutoHit = new DocumentSinistreAutoHit();
        documentSinistreAutoHit.setId("42");
        documentSinistreAutoHit.setIndex("Index");
        documentSinistreAutoHit.setScore(10.0d);
        documentSinistreAutoHit.setSource(new PreDeclarationTypeDoc());
        documentSinistreAutoHit.setType("Type");

        ArrayList<DocumentSinistreAutoHit> documentSinistreAutoHitList = new ArrayList<>();
        documentSinistreAutoHitList.add(documentSinistreAutoHit);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(documentSinistreAutoHitList);
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);
        BigDecimal codeExp = BigDecimal.valueOf(42L);
        BigDecimal dateC = BigDecimal.valueOf(42L);
        BigDecimal dateA = BigDecimal.valueOf(42L);
        BigDecimal heureC = BigDecimal.valueOf(42L);
        BigDecimal dateM = BigDecimal.valueOf(42L);
        BigDecimal heureM = BigDecimal.valueOf(42L);
        BigDecimal aclasserLe = BigDecimal.valueOf(42L);
        assertEquals(1, elasticSearchHelper
                .searchInDocumentsListsByQuery(IndexOrPathToUse.DEFAULT, new PreDeclarationTypeDoc(
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'", codeExp,
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'", dateC,
                        dateA, heureC, dateM, heureM, "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", 9, "Start: Search list of documents by query '{}'",
                        aclasserLe, "2020-03-01", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", true, "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", 9, "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "2020-03-01", "2020-03-01",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "2020-03-01", 3L, new ArrayList<>(), "42",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'"))
                .size());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
        verify(esDocumentSchema).getHits();
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }

    /**
     * Method under test: {@link ElasticSearchHelper#searchInDocumentsListsByQuery(IndexOrPathToUse, PreDeclarationTypeDoc)}
     */
    @Test
    void testSearchInDocumentsListsByQuery4() {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHit documentSinistreAutoHit = new DocumentSinistreAutoHit();
        documentSinistreAutoHit.setId("42");
        documentSinistreAutoHit.setIndex("Index");
        documentSinistreAutoHit.setScore(10.0d);
        documentSinistreAutoHit.setSource(new PreDeclarationTypeDoc());
        documentSinistreAutoHit.setType("Type");

        DocumentSinistreAutoHit documentSinistreAutoHit1 = new DocumentSinistreAutoHit();
        documentSinistreAutoHit1.setId("Start: Search list of documents by query '{}'");
        documentSinistreAutoHit1.setIndex("nSin");
        documentSinistreAutoHit1.setScore(0.5d);
        documentSinistreAutoHit1.setSource(new PreDeclarationTypeDoc());
        documentSinistreAutoHit1.setType("nSin");

        ArrayList<DocumentSinistreAutoHit> documentSinistreAutoHitList = new ArrayList<>();
        documentSinistreAutoHitList.add(documentSinistreAutoHit1);
        documentSinistreAutoHitList.add(documentSinistreAutoHit);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(documentSinistreAutoHitList);
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);
        BigDecimal codeExp = BigDecimal.valueOf(42L);
        BigDecimal dateC = BigDecimal.valueOf(42L);
        BigDecimal dateA = BigDecimal.valueOf(42L);
        BigDecimal heureC = BigDecimal.valueOf(42L);
        BigDecimal dateM = BigDecimal.valueOf(42L);
        BigDecimal heureM = BigDecimal.valueOf(42L);
        BigDecimal aclasserLe = BigDecimal.valueOf(42L);
        assertEquals(2, elasticSearchHelper
                .searchInDocumentsListsByQuery(IndexOrPathToUse.DEFAULT, new PreDeclarationTypeDoc(
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'", codeExp,
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'", dateC,
                        dateA, heureC, dateM, heureM, "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", 9, "Start: Search list of documents by query '{}'",
                        aclasserLe, "2020-03-01", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", true, "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", 9, "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "2020-03-01", "2020-03-01",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "2020-03-01", 3L, new ArrayList<>(), "42",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'"))
                .size());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
        verify(esDocumentSchema).getHits();
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }

    /**
     * Method under test: {@link ElasticSearchHelper#searchInDocumentsListsByQuery(IndexOrPathToUse, PreDeclarationTypeDoc)}
     */
    @Test
    void testSearchInDocumentsListsByQuery5() throws FeignException {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(new ArrayList<>());
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);
        BigDecimal codeExp = BigDecimal.valueOf(42L);
        BigDecimal dateC = BigDecimal.valueOf(42L);
        BigDecimal dateA = BigDecimal.valueOf(42L);
        BigDecimal heureC = BigDecimal.valueOf(42L);
        BigDecimal dateM = BigDecimal.valueOf(42L);
        BigDecimal heureM = BigDecimal.valueOf(42L);
        BigDecimal aclasserLe = BigDecimal.valueOf(42L);
        assertTrue(elasticSearchHelper
                .searchInDocumentsListsByQuery(IndexOrPathToUse.TEMPORARY, new PreDeclarationTypeDoc(
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'", codeExp,
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'", dateC,
                        dateA, heureC, dateM, heureM, "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", 9, "Start: Search list of documents by query '{}'",
                        aclasserLe, "2020-03-01", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", true, "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", 9, "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "2020-03-01", "2020-03-01",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                        "Start: Search list of documents by query '{}'", "2020-03-01", 3L, new ArrayList<>(), "42",
                        "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'"))
                .isEmpty());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
        verify(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        verify(esDocumentSchema).getHits();
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }

    /**
     * Method under test: {@link ElasticSearchHelper#searchInDocumentsListsByQuery(IndexOrPathToUse, PreDeclarationTypeDoc)}
     */
    @Test
    void testSearchInDocumentsListsByQuery6() throws FeignException {
        DocumentSinistreAutoHits documentSinistreAutoHits = new DocumentSinistreAutoHits();
        documentSinistreAutoHits.setHits(new ArrayList<>());
        documentSinistreAutoHits.setMaxScore(10.0d);
        documentSinistreAutoHits.setTotal(1);

        Shards shards = new Shards();
        shards.setFailed(1);
        shards.setSuccessful(1);
        shards.setTotal(1);

        DocumentSinistreAutoHits documentSinistreAutoHits1 = new DocumentSinistreAutoHits();
        documentSinistreAutoHits1.setHits(new ArrayList<>());
        documentSinistreAutoHits1.setMaxScore(10.0d);
        documentSinistreAutoHits1.setTotal(1);
        ESDocumentSchema esDocumentSchema = mock(ESDocumentSchema.class);
        when(esDocumentSchema.getHits()).thenReturn(documentSinistreAutoHits1);
        doNothing().when(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        doNothing().when(esDocumentSchema).setShards((Shards) any());
        doNothing().when(esDocumentSchema).setTimedOut((Boolean) any());
        doNothing().when(esDocumentSchema).setTook(anyInt());
        esDocumentSchema.setHits(documentSinistreAutoHits);
        esDocumentSchema.setShards(shards);
        esDocumentSchema.setTimedOut(true);
        esDocumentSchema.setTook(1);
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        when(elasticSearchDocumentRepository.getDocuments((String) any(), (RequestQuery) any()))
                .thenReturn(esDocumentSchema);
        BigDecimal codeExp = BigDecimal.valueOf(42L);
        BigDecimal dateC = BigDecimal.valueOf(42L);
        BigDecimal dateA = BigDecimal.valueOf(42L);
        BigDecimal heureC = BigDecimal.valueOf(42L);
        BigDecimal dateM = BigDecimal.valueOf(42L);
        BigDecimal heureM = BigDecimal.valueOf(42L);
        BigDecimal aclasserLe = BigDecimal.valueOf(42L);
        assertTrue(elasticSearchHelper.searchInDocumentsListsByQuery(IndexOrPathToUse.TEMPORARY,
                        new PreDeclarationTypeDoc("", "Start: Search list of documents by query '{}'",
                                "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                                "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'", codeExp,
                                "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'", dateC,
                                dateA, heureC, dateM, heureM, "Start: Search list of documents by query '{}'",
                                "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                                "Start: Search list of documents by query '{}'", 9, "Start: Search list of documents by query '{}'",
                                aclasserLe, "2020-03-01", "Start: Search list of documents by query '{}'",
                                "Start: Search list of documents by query '{}'", true, "Start: Search list of documents by query '{}'",
                                "Start: Search list of documents by query '{}'", 9, "Start: Search list of documents by query '{}'",
                                "Start: Search list of documents by query '{}'", "2020-03-01", "2020-03-01",
                                "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'",
                                "Start: Search list of documents by query '{}'", "2020-03-01", 3L, new ArrayList<>(), "42",
                                "Start: Search list of documents by query '{}'", "Start: Search list of documents by query '{}'"))
                .isEmpty());
        verify(elasticSearchDocumentRepository).getDocuments((String) any(), (RequestQuery) any());
        verify(elasticSearchDocumentRepository).checkIndexExistence((String) any());
        verify(esDocumentSchema).getHits();
        verify(esDocumentSchema).setHits((DocumentSinistreAutoHits) any());
        verify(esDocumentSchema).setShards((Shards) any());
        verify(esDocumentSchema).setTimedOut((Boolean) any());
        verify(esDocumentSchema).setTook(anyInt());
    }

    @Test
    void testAddCimaDocument() throws FeignException {

        var cimaRequestDocument = new CimaRequestDocument();
        var esResponse = new ESResponse();

        cimaRequestDocument.setIdAlfresco("a162223f-9a5c-466e-a678-b6cc0a37bbc7");
        cimaRequestDocument.setContractNumber("123456");
        cimaRequestDocument.setCountryCode("SE");

        esResponse.setCreated(true);
        esResponse.setIndex("cimaindex");
        esResponse.setType("cimatype");
        esResponse.setId("a162223f-9a5c-466e-a678-b6cc0a37bbc7");

        when(elasticSearchDocumentRepository.addDocumentCima(any(CimaRequestDocument.class), anyString()))
                .thenReturn(esResponse);
        when(esPropertiesCimaDoc.getIndex()).thenReturn("cimaindex");
        when(elasticSearchDocumentRepository.createCimaIndex()).thenReturn(new ESResponseIndex(true));
        doNothing().when(elasticSearchDocumentRepository).checkIndexExistence(anyString());

        assertEquals(esResponse, elasticSearchHelper.addCimaDocument(cimaRequestDocument, "a162223f-9a5c-466e-a678-b6cc0a37bbc7"));

    }

    @Test
    void testInsertATMultipleMetadatas_success() throws JsonProcessingException {
        // Arrange
        String indexName = "test-index";
        String docType = "doc-type";
        String documentId = "doc-123";

        IndexOrPathToUse indexOrPathToUse = IndexOrPathToUse.TEMPORARY; // or PATH, depending on your enum
        DocumentSinistreATES document = DocumentSinistreATES.builder()
                .idalfersco(documentId)
                .build();

        List<DocumentSinistreATES> documents = List.of(document);

        // Mock getType and index resolution
        esPropertiesAtDoc.setType(docType);

        // Mock QueryBuilder and Repository
        Map.Entry<ESBulkOperationMetadata, Object> fakeEntry = Map.entry(
                ESBulkOperationMetadata.builder()
                        .index(indexName)
                        .type(docType)
                        .id(documentId)
                        .operation(ESBulkOperationsEnum.CREATE)
                        .build(),
                document
        );
        
        // Mock ESResponse
        ESResponse esResponse = ESResponse.builder()
                .id(documentId)
                .status(HttpStatus.CREATED.value())
                .build();

        Map.Entry<String, ESResponse> item = new AbstractMap.SimpleEntry<>("create", esResponse);
        EsMultipleResponses esMultipleResponses = EsMultipleResponses.builder()
                .items(List.of(item))
                .build();
        

        // Mock static method
        try (MockedStatic<QueryBuilder> mocked = mockStatic(QueryBuilder.class)) {
            mocked.when(() -> QueryBuilder.createABulkQuery(any()))
                  .thenReturn("mocked-bulk-query");

            when(elasticSearchDocumentRepository.multipleActionRequests("mocked-bulk-query"))
            .thenReturn(esMultipleResponses);
            
            // Act
            Map<String, Boolean> result = elasticSearchHelper.insertATMultipleMetadatas(indexOrPathToUse, documents);

            // Assert
            assertEquals(1, result.size());
            assertTrue(result.get(documentId));
        }
    }
    
}

