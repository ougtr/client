package ma.axa.inner.ged.helper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import ma.axa.inner.ged.domain.ESBulkOperationMetadata;
import ma.axa.inner.ged.domain.PreDeclarationTypeDoc;
import ma.axa.inner.ged.enums.AutoAtBranchEnum;
import ma.axa.inner.ged.enums.ESBulkOperationsEnum;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import ma.axa.inner.ged.domain.DossierSinistreAuto;

@ExtendWith(MockitoExtension.class)
class QueryBuilderTest {

    @Test
    void builder_test_id_not_null() {
        var input = new DossierSinistreAuto();
        input.setId("id");

        var request = QueryBuilder.dossierSinistreAutoRequestQueryBuilder(input);

        assertThat(request.getQuery().getBool().getMust().get(0).get(CriteriaTypes.TERM.value())).containsEntry("_id", "id");
    }

    @Test
    void builder_test_numsinistre_not_null() {
        var input = new DossierSinistreAuto();
        input.setNumSinistre(BigDecimal.valueOf(123456789));
        var request = QueryBuilder.dossierSinistreAutoRequestQueryBuilder(input);

        assertThat(request.getQuery().getBool().getMust().get(0).get(CriteriaTypes.TERM.value())).containsEntry("numSinistre", BigDecimal.valueOf(123456789));
    }

    @Test
    void builder_test_id_and_numsinistre_are_null() {
        var input = new DossierSinistreAuto();
        input.setPredec("Predec");
        input.setMatricule("Matricule");
        input.setPolnum(BigDecimal.valueOf(123456789));
        input.setNomAssure("NomAssure");

        input.setCodeAgent(100);
        input.setNomVictimes(Arrays.asList("test1"));
        input.setNumJuridiction(Arrays.asList("test2"));
        input.setDateSinistre(BigDecimal.valueOf(123456789));

        var request = QueryBuilder.dossierSinistreAutoRequestQueryBuilder(input);

        assertThat(request.getQuery().getBool().getMust().get(0).get(CriteriaTypes.MATCH_PHRASE.value())).containsEntry("predec", "Predec");
        assertThat(request.getQuery().getBool().getMust().get(1).get(CriteriaTypes.MATCH_PHRASE.value())).containsEntry("matricule", "Matricule");
        assertThat(request.getQuery().getBool().getMust().get(2).get(CriteriaTypes.TERM.value())).containsEntry("polnum", BigDecimal.valueOf(123456789));
        assertThat(request.getQuery().getBool().getMust().get(3).get(CriteriaTypes.MATCH_PHRASE.value())).containsEntry("nomAssure", "NomAssure");
        assertThat(request.getQuery().getBool().getMust().get(4).get(CriteriaTypes.TERM.value())).containsEntry("codeAgent", 100);
        assertThat(request.getQuery().getBool().getMust().get(5).get(CriteriaTypes.FUZZY.value())).containsEntry("nomVictimes", "test1");
        assertThat(request.getQuery().getBool().getMust().get(6).get(CriteriaTypes.TERM.value())).containsEntry("numJuridiction", "test2");
        assertThat(request.getQuery().getBool().getMust().get(7).get(CriteriaTypes.TERM.value())).containsEntry("dateSinistre", BigDecimal.valueOf(123456789));

    }

    @Test
    void documentSinistreAutoRequestQueryBuilder_test_userc() {
        val request = QueryBuilder.documentSinistreAutoRequestQueryBuilder("userC", "owner");
        assertThat(request.getQuery().getBool().getMust().get(0).get(CriteriaTypes.MATCH_PHRASE.value)).containsEntry("userC", "owner");
    }

    @Test
    void addCriteria_test() {
        var query = new Query();
        var bool = new Bool();
        bool.setMust(new ArrayList<>());
        query.setBool(bool);
        query = QueryBuilder.addCriteria(CriteriaTypes.TERM, query, "key1", "value1");
        query = QueryBuilder.addCriteria(CriteriaTypes.MATCH, query, "key2", "value2");
        query = QueryBuilder.addCriteria(CriteriaTypes.FUZZY, query, "key3", "value3");
        query = QueryBuilder.addCriteria(CriteriaTypes.MATCH_PHRASE, query, "key4", "value4");
        assertThat(query.getBool().getMust().get(0).get(CriteriaTypes.TERM.value())).containsEntry("key1", "value1");
        assertThat(query.getBool().getMust().get(1).get(CriteriaTypes.MATCH.value())).containsEntry("key2", "value2");
        assertThat(query.getBool().getMust().get(2).get(CriteriaTypes.FUZZY.value())).containsEntry("key3", "value3");
        assertThat(query.getBool().getMust().get(3).get(CriteriaTypes.MATCH_PHRASE.value())).containsEntry("key4", "value4");
    }


    @Test
    void testDocumentSinistreAutoRequestQueryBuilderGetUnion() {
        RequestQuery actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult = QueryBuilder
                .documentSinistreAutoRequestQueryBuilderGetUnion(new HashMap<>(), AutoAtBranchEnum.SAC);
        assertEquals(0, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getFrom());
        assertEquals(500, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getSize());
        assertTrue(
                actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getQuery().getBool().getShould().isEmpty());
    }


    @Test
    void testDocumentSinistreAutoRequestQueryBuilderGetUnion2() {
        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "42");
        RequestQuery actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult = QueryBuilder
                .documentSinistreAutoRequestQueryBuilderGetUnion(objectStringMap,AutoAtBranchEnum.SAT);
        assertEquals(0, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getFrom());
        assertEquals(500, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getSize());
        List<Map<String, Map<String, Object>>> should = actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult
                .getQuery()
                .getBool()
                .getShould();
        assertEquals(1, should.size());
        Map<String, Map<String, Object>> getResult = should.get(0);
        assertEquals(1, getResult.size());
        assertEquals(1, getResult.get("term").size());
    }


    @Test
    void testDocumentSinistreAutoRequestQueryBuilderGetUnion3() {
        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "nSin");
        RequestQuery actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult = QueryBuilder
                .documentSinistreAutoRequestQueryBuilderGetUnion(objectStringMap,AutoAtBranchEnum.SAC);
        assertEquals(0, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getFrom());
        assertEquals(500, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getSize());
        List<Map<String, Map<String, Object>>> should = actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult
                .getQuery()
                .getBool()
                .getShould();
        assertEquals(1, should.size());
        Map<String, Map<String, Object>> getResult = should.get(0);
        assertEquals(1, getResult.size());
        assertEquals(1, getResult.get("match").size());
    }

    @Test
    void testDocumentSinistreAutoRequestQueryBuilderGetUnion7() {
        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "numsinistre");
        RequestQuery actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult = QueryBuilder
                .documentSinistreAutoRequestQueryBuilderGetUnion(objectStringMap,AutoAtBranchEnum.SAT);
        assertEquals(0, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getFrom());
        assertEquals(500, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getSize());
        List<Map<String, Map<String, Object>>> should = actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult
                .getQuery()
                .getBool()
                .getShould();
        assertEquals(1, should.size());
        Map<String, Map<String, Object>> getResult = should.get(0);
        assertEquals(1, getResult.size());
        assertEquals(1, getResult.get("match").size());
    }

    @Test
    void testDocumentSinistreAutoRequestQueryBuilderGetUnion4() {
        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "idPredeclaration");
        RequestQuery actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult = QueryBuilder
                .documentSinistreAutoRequestQueryBuilderGetUnion(objectStringMap,AutoAtBranchEnum.SAC);
        assertEquals(0, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getFrom());
        assertEquals(500, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getSize());
        List<Map<String, Map<String, Object>>> should = actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult
                .getQuery()
                .getBool()
                .getShould();
        assertEquals(1, should.size());
        Map<String, Map<String, Object>> getResult = should.get(0);
        assertEquals(1, getResult.size());
        assertEquals(1, getResult.get("match").size());
    }


    @Test
    void testDocumentSinistreAutoRequestQueryBuilderGetUnion5() {
        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "idAlfresco");
        RequestQuery actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult = QueryBuilder
                .documentSinistreAutoRequestQueryBuilderGetUnion(objectStringMap,AutoAtBranchEnum.SAC);
        assertEquals(0, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getFrom());
        assertEquals(500, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getSize());
        List<Map<String, Map<String, Object>>> should = actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult
                .getQuery()
                .getBool()
                .getShould();
        assertEquals(1, should.size());
        Map<String, Map<String, Object>> getResult = should.get(0);
        assertEquals(1, getResult.size());
        assertEquals(1, getResult.get("match_phrase").size());
    }

    @Test
    void testDocumentSinistreAutoRequestQueryBuilderGetUnion8() {
        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "idalfersco");
        RequestQuery actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult = QueryBuilder
                .documentSinistreAutoRequestQueryBuilderGetUnion(objectStringMap,AutoAtBranchEnum.SAT);
        assertEquals(0, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getFrom());
        assertEquals(500, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getSize());
        List<Map<String, Map<String, Object>>> should = actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult
                .getQuery()
                .getBool()
                .getShould();
        assertEquals(1, should.size());
        Map<String, Map<String, Object>> getResult = should.get(0);
        assertEquals(1, getResult.size());
        assertEquals(1, getResult.get("match_phrase").size());
    }


    @Test
    void testDocumentSinistreAutoRequestQueryBuilderGetUnion6() {
        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "userC");
        RequestQuery actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult = QueryBuilder
                .documentSinistreAutoRequestQueryBuilderGetUnion(objectStringMap,AutoAtBranchEnum.SAC);
        assertEquals(0, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getFrom());
        assertEquals(500, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getSize());
        List<Map<String, Map<String, Object>>> should = actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult
                .getQuery()
                .getBool()
                .getShould();
        assertEquals(1, should.size());
        Map<String, Map<String, Object>> getResult = should.get(0);
        assertEquals(1, getResult.size());
        assertEquals(1, getResult.get("match_phrase").size());
    }


    @Test
    void testDocumentSinistreAutoRequestQueryBuilderGetUnion9() {
        HashMap<Object, String> objectStringMap = new HashMap<>();
        objectStringMap.put("Key", "userM");
        RequestQuery actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult = QueryBuilder
                .documentSinistreAutoRequestQueryBuilderGetUnion(objectStringMap,AutoAtBranchEnum.SAC);
        assertEquals(0, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getFrom());
        assertEquals(500, actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult.getSize());
        List<Map<String, Map<String, Object>>> should = actualDocumentSinistreAutoRequestQueryBuilderGetUnionResult
                .getQuery()
                .getBool()
                .getShould();
        assertEquals(1, should.size());
        Map<String, Map<String, Object>> getResult = should.get(0);
        assertEquals(1, getResult.size());
        assertEquals(1, getResult.get("match_phrase").size());
    }

    @SneakyThrows
    @Test
    void bulkQuery_test() {
        HashMap<ESBulkOperationMetadata, Object> hashMap = new HashMap<>() {{
            put(ESBulkOperationMetadata.builder()
                    .index("sinistre")
                    .type("sinistre")
                    .id("workspace://SpacesStore/2e1c5a0a-710-4c2c-bfcf-5d55a7ad2ba1")
                    .operation(ESBulkOperationsEnum.CREATE)
                    .build(), PreDeclarationTypeDoc.builder().nSin("0").build());

        }};

        var str = QueryBuilder.createABulkQuery(hashMap);
        assertThat(str).contains(ESBulkOperationsEnum.CREATE.getOperation(), "\"_index\"", "\"_type\"", "\"nSin\":\"0\"");
    }

    @Test
    void testDocumentSinistreAutoRequestQueryBuilder() throws JsonProcessingException {

        HashMap<String, Object> hashMap = new HashMap<String,Object>();
        hashMap.put("nSin","22322");
        hashMap.put("idPredeclaration","P23232");
        hashMap.put("idAlfresco","E22324A-4646453-353255-3434");
        hashMap.put("typeDoc","3");
        var request = QueryBuilder.documentSinistreAutoRequestQueryBuilder(hashMap);

        assertThat(new ObjectMapper().writeValueAsString(request.getQuery())).isEqualTo("{\"bool\":{\"must\":[{\"match_phrase\":{\"idAlfresco\":\"E22324A-4646453-353255-3434\"}},{\"term\":{\"typeDoc\":\"3\"}},{\"match\":{\"nSin\":\"22322\"}},{\"match\":{\"idPredeclaration\":\"P23232\"}}]}}");
    }
}
