package ma.axa.inner.ged.claim.common.service;

import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class DownloadHelperTest {
    private final static String ID_ALFRESCO = "a162223f-9a5c-466e-a678-b6cc0a37bbc7";
    @Mock
    ClaimDocumentRepository claimDocumentRepository;
    @InjectMocks
    DownloadHelper downloadHelper;

    @Test
    void download() throws Exception {

        assertThat(claimDocumentRepository).isNotNull();

        var file = new GedDocument();
        file.setFileByte(new byte[]{1, 2});
        file.setFileName("test.pdf");
        file.setMimeType("application/pdf");

        ByteArrayResource output = new ByteArrayResource("content".getBytes());

        when(claimDocumentRepository.getFileDocument(ID_ALFRESCO)).thenReturn(file);
        Resource resource = downloadHelper.downloadFileFromGed(ID_ALFRESCO);

        ArgumentCaptor<String> id = ArgumentCaptor.forClass(String.class);
        verify(claimDocumentRepository).getFileDocument(id.capture());
        assertThat(id.getValue()).isEqualTo(ID_ALFRESCO);
        assertThat(resource).isNotNull();

    }
}
