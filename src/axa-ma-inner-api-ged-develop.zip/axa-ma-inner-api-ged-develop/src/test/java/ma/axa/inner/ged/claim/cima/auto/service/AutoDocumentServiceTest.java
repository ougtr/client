package ma.axa.inner.ged.claim.cima.auto.service;

import ma.axa.inner.ged.claim.common.service.DownloadHelper;
import ma.axa.inner.ged.claim.common.service.UploadHelper;
import ma.axa.inner.ged.config.OpenInsurClaimProperties;
import ma.axa.inner.ged.domain.ESResponse;
import ma.axa.inner.ged.dto.CimaRequestDocument;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class AutoDocumentServiceTest {

    private final static String ID_ALFRESCO = "a162223f-9a5c-466e-a678-b6cc0a37bbc7";
    private final static String CONTRACT_NUMBER = "/v1/cima/claims";
    private final static String COUNTRY_CODE = "SE";
    private final static String INDEX = "cimaindex";
    private final static String TYPE = "cimatype";


    @InjectMocks
    AutoDocumentService autoDocumentService;

    @Mock
    UploadHelper uploadHelper;

    @Mock
    DownloadHelper downloadHelper;

    @Mock
    OpenInsurClaimProperties openInsurClaimProperties;


    @Test
    void downloadDocByIdAlfresco() {
        var resource = new ByteArrayResource("doc".getBytes());
        when(downloadHelper.downloadFileFromGed(anyString())).thenReturn(resource);
        var actual = autoDocumentService.downloadDocByIdAlfresco("id");
        assertThat(actual).isNotNull();
    }


    @Test
    void upload() {
        MockMultipartFile multiPartFile = new MockMultipartFile("data", "test.pdf", "application/pdf",
                "content".getBytes());
        var alfrescoID = "5905d039-d9ec-4fed-8bdc-6240606e6042";
        Map<String, String> output = new HashMap<>();
        output.put("idAlfresco", alfrescoID);

        when(uploadHelper.uploadFile(any(MultipartFile.class), anyString())).thenReturn(output);
        when(openInsurClaimProperties.getOutbox()).thenReturn("/Sites/groupe-indexation/documentLibrary/health");

        var id = autoDocumentService.upload(multiPartFile, "CA");
        assertThat(id).isEqualTo(alfrescoID);
    }

    @Test
    void upload_return_null() {
        MockMultipartFile multiPartFile = new MockMultipartFile("data", "test.pdf", null,
                "content".getBytes());
        when(openInsurClaimProperties.getOutbox()).thenReturn("/Sites/groupe-indexation/documentLibrary/health");

        var id = autoDocumentService.upload(multiPartFile, "CA");
        assertThat(id).isNull();
    }

    @Test
    void uploadFiles() {
        MockMultipartFile multiPartFile = new MockMultipartFile("data", "test.pdf", "application/pdf",
                "content".getBytes());
        List<MultipartFile> multipartFileList = List.of(multiPartFile);
        var alfrescoID = "5905d039-d9ec-4fed-8bdc-6240606e6042";
        Map<String, String> output = new HashMap<>();
        output.put("idAlfresco", alfrescoID);
        var ids = List.of(alfrescoID);

        when(uploadHelper.uploadFile(any(MultipartFile.class), anyString())).thenReturn(output);
        when(openInsurClaimProperties.getOutbox()).thenReturn("/Sites/groupe-indexation/documentLibrary/health");

        var id = autoDocumentService.uploadFiles(multipartFileList, "SE");
        assertThat(id).isEqualTo(ids);
    }

    @Test
    void indexDocumentInEs() {
        var cimaRequestDocument = new CimaRequestDocument();
        var esResponse = new ESResponse();
        cimaRequestDocument.setIdAlfresco(ID_ALFRESCO);
        cimaRequestDocument.setContractNumber(CONTRACT_NUMBER);
        cimaRequestDocument.setCountryCode(COUNTRY_CODE);
        esResponse.setCreated(true);
        esResponse.setIndex(INDEX);
        esResponse.setType(TYPE);
        esResponse.setId(ID_ALFRESCO);

        when(uploadHelper.createDocumentInEs(any(CimaRequestDocument.class), anyString())).thenReturn(esResponse);

        var response = autoDocumentService.indexDocumentInEs(cimaRequestDocument, ID_ALFRESCO);
        assertThat(response).isEqualTo(esResponse);
    }
}
