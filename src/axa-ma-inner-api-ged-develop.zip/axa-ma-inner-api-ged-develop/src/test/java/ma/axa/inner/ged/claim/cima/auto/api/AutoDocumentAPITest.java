package ma.axa.inner.ged.claim.cima.auto.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import ma.axa.inner.ged.claim.cima.auto.service.AutoDocumentService;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.domain.ESResponse;
import ma.axa.inner.ged.dto.CimaRequestDocument;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(AutoDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
class AutoDocumentAPITest {
    private final static String ID_ALFRESCO = "a162223f-9a5c-466e-a678-b6cc0a37bbc7";
    private final static String BASE_URL = "/v1/cima/claims";
    private final static String SUFFIX_DOWNLOAD = "/documents/" + ID_ALFRESCO + "/content";
    private final static String CONTRACT_NUMBER = "/v1/cima/claims";
    private final static String COUNTRY_CODE = "SE";
    private final static String INDEX = "cimaindex";
    private final static String TYPE = "cimatype";
    @MockBean
    AutoDocumentService autoDocumentService;
    
    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
	private DataSourceContextHolder dataSourceContextHolder;

    @Test
    void download() throws Exception {
        ByteArrayResource output = new ByteArrayResource("content".getBytes());

        when(autoDocumentService.downloadDocByIdAlfresco(ID_ALFRESCO)).thenReturn(output);

        mockMvc.perform(MockMvcRequestBuilders.get(BASE_URL + SUFFIX_DOWNLOAD)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void upload() throws Exception {
        MockMultipartFile multiPartFile = new MockMultipartFile("data", "test11.pdf", "application/pdf", "content".getBytes());
        String idAlfresco = "5905d039-d9ec-4fed-8bdc-6240606e6042";
        when(autoDocumentService.upload(multiPartFile, "CA")).thenReturn(idAlfresco);
        mockMvc.perform(multipart("/v1/cima/claims/documents")
                .file("file", multiPartFile.getBytes())
                .param("country", "CA"))
                .andExpect(status().isOk());
    }

    @Test
    void uploadFiles() throws Exception {
        MockMultipartFile multiPartFile = new MockMultipartFile("data", "test11.pdf", "application/pdf", "content".getBytes());
        List<MultipartFile> multipartFiles = List.of(multiPartFile);
        List<String> ids = List.of(ID_ALFRESCO);
        when(autoDocumentService.uploadFiles(multipartFiles, "CA")).thenReturn(ids);
        mockMvc.perform(multipart("/v1/cima/claims/allDocuments")
                .file("files", multiPartFile.getBytes())
                .param("country", COUNTRY_CODE))
                .andExpect(status().isOk());
    }

    @Test
    void indexFile() throws Exception {
        var cimaRequestDocument = new CimaRequestDocument();
        var esResponse = new ESResponse();
        ObjectMapper mapper = new ObjectMapper();
        cimaRequestDocument.setIdAlfresco(ID_ALFRESCO);
        cimaRequestDocument.setContractNumber(CONTRACT_NUMBER);
        cimaRequestDocument.setCountryCode(COUNTRY_CODE);
        esResponse.setCreated(true);
        esResponse.setIndex(INDEX);
        esResponse.setType(TYPE);
        esResponse.setId(ID_ALFRESCO);
        when(autoDocumentService.indexDocumentInEs(cimaRequestDocument, ID_ALFRESCO)).thenReturn(esResponse);
        mockMvc.perform(post("/v1/cima/claims/indexFile/{idAlfresco}", ID_ALFRESCO)
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(cimaRequestDocument)))
                .andExpect(status().isOk());
    }
}
