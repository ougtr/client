package ma.axa.inner.ged;

import static org.assertj.core.api.Assertions.assertThatNoException;

import org.apache.chemistry.opencmis.client.api.Session;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

@SpringBootTest(classes = AxaInnerGedApiApplication.class)
class AxaInnerGedApiApplicationTests {

	@MockBean
	Session session;


	//@Test
	void contextLoads() {
		// ignore java:S2699
		assertThatNoException().isThrownBy(() -> System.out.println("Testing"));
	}

}
