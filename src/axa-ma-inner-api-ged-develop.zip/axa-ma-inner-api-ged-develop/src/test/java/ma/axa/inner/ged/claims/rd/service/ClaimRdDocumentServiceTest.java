package ma.axa.inner.ged.claims.rd.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Optional;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.web.multipart.MultipartFile;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import ma.axa.inner.ged.claim.rd.domain.DocumentClaimRdEs;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdResponse;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdSearchParams;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdUpdateReq;
import ma.axa.inner.ged.claim.rd.mapper.ClaimRdMapper;
import ma.axa.inner.ged.claim.rd.repository.ClaimRdElasticRepository;
import ma.axa.inner.ged.claim.rd.service.ClaimRdDocumentService;
import ma.axa.inner.ged.claims.rd.util.ClaimRdDataGenerator;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.dto.CommonResponse;
import ma.axa.inner.ged.enums.Branche;
import ma.axa.inner.ged.exception.RequestValidationException;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.exception.ResourceNotFoundException;
import ma.axa.inner.ged.service.AlfrescoGedService;
import ma.axa.inner.ged.util.FileGenerator;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@EnableConfigurationProperties(value = BrancheProperties.class)
@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
class ClaimRdDocumentServiceTest {
	@InjectMocks
	private ClaimRdDocumentService service;
	@Mock
	private ClaimRdMapper rdMapper;
	@Mock
	private ClaimRdElasticRepository elasticRepository;
	@Mock
	private AlfrescoGedService alfrescoService;
	@Mock
	BrancheProperties brancheProperties;
	@Mock
	Folder folder;
	@Mock
	Session session;

	@Mock
	private DocumentClaimRdEs documentEsMock;

	@Mock
	private MessageSource messageSource;

	@BeforeEach
	void initMockRepositories() throws ElasticsearchException, IOException {
		when(alfrescoService.exists(ClaimRdDataGenerator.DOCUMENT_ID)).thenReturn(true);
		when(alfrescoService.exists(ClaimRdDataGenerator.DOCUMENT_ID_NOT)).thenReturn(false);
		when(elasticRepository.exists(ClaimRdDataGenerator.DOCUMENT_ID)).thenReturn(true);
		when(elasticRepository.exists(ClaimRdDataGenerator.DOCUMENT_ID_NOT)).thenReturn(false);
		when(elasticRepository.findById(ClaimRdDataGenerator.DOCUMENT_ID))
				.thenReturn(Optional.of(ClaimRdDataGenerator.getDocumentEs()));
		when(rdMapper.toDto(any(DocumentClaimRdEs.class))).thenReturn(ClaimRdDataGenerator.getOnResponseDoc());
	}

	@Test
	@DisplayName("claimRd_getDocumentById_ShouldReturnValidDocument")
	void getDocumentById_ShouldReturnValidDocument() throws Exception {
		var response = service.getDocumentById(ClaimRdDataGenerator.DOCUMENT_ID);
		assertThat(response).isNotNull();
		assertThat(response.getId()).isEqualTo(ClaimRdDataGenerator.DOCUMENT_ID);
		assertThat(response.getBrancheCode()).isEqualTo(Branche.RD.getCode());
	}

	@Test
	@DisplayName("claimRd_getDocumentById_ShouldThrowRecordNotFoundException")
	void getDocumentById_ShouldThrowRecordNotFoundException() throws Exception {
		assertThatThrownBy(() -> service.getDocumentById(ClaimRdDataGenerator.DOCUMENT_ID_NOT))
				.isInstanceOf(ResourceNotFoundException.class);
	}

	@Test
	@DisplayName("claimRd_downloadFile_mustReturnAValideFile")
	void downloadFile_mustReturnAValideFile() {
		var document = mock(Document.class);
		var contentStream = mock(ContentStream.class);
		var isv1 = new ByteArrayInputStream("test file content".getBytes());
		when(contentStream.getStream()).thenReturn(isv1);
		when(contentStream.getMimeType()).thenReturn("application/pdf");
		when(contentStream.getLength()).thenReturn(1000L);
		when(document.getContentStream()).thenReturn(contentStream);
		when(document.getContentStream().getStream()).thenReturn(isv1);
		when(document.getName()).thenReturn("test.pdf");
		when(document.getContentStreamLength()).thenReturn(1000L);
		when(service.getFileFromAlfresco(ClaimRdDataGenerator.DOCUMENT_ID)).thenReturn(document);

		var responseEntity = service.downloadFile(ClaimRdDataGenerator.DOCUMENT_ID);
		assertThat(responseEntity).isNotNull();
		assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(responseEntity.getHeaders().getContentLength()).isEqualTo(1000);
		assertThat(responseEntity.getHeaders().getContentType()).hasToString("application/pdf");
		assertThat(responseEntity.getHeaders().getContentDisposition().getFilename()).hasToString("test.pdf");
	}

	@Test
	@DisplayName("claimRd_downloadFile_ShouldThrowResourceNotFoundException")
	void downloadFile_ShouldThrowResourceNotFoundException() {
		assertThrows(ResourceNotFoundException.class, () -> service.downloadFile(ClaimRdDataGenerator.DOCUMENT_ID_NOT));
	}


	@Test
	@DisplayName("claimRd_uploadDocumentWithMetaData_ShouldReturnResourceAlreadyExists")
	void uploadDocumentWithMetaData_ShouldReturnResourceAlreadyExists() throws Exception {
		var metaData = ClaimRdDataGenerator.getAddRequestDto();
		var file = FileGenerator.getPdfFile();
		var documentExist = ClaimRdDataGenerator.getDocumentEs();
		when(elasticRepository.findOneDocumentByReference(ClaimRdDataGenerator.REFERENCE)).thenReturn(documentExist);
		metaData.setEnableGestionnaire(true);

		try {
			service.uploadDocumentWithMetaData(metaData, file);
			fail("Expected ResourceAlreadyExist exception");
		} catch (ResourceAlreadyExist e) {
			assertEquals(GlobalConstants.URI_RECORDE_ALREADY_EXIST, e.getType());
			assertEquals(GlobalConstants.ERROR_MSG_RD_REFERENCE_ALREADY_EXIST, e.getMessage());
			assertArrayEquals(new String[] { ClaimRdDataGenerator.REFERENCE }, e.getArgs());
		} catch (RequestValidationException ex) {
			assertThrows(RequestValidationException.class, () -> service.uploadDocumentWithMetaData(metaData, file));
		}
	}

	@Test
	@DisplayName("claimRd_uploadDocumentWithMetaData_ShouldReturnAddedObject")
	void uploadDocumentWithMetaData_ShouldReturnAddedObject() throws Exception {
		// create mock input data
		var metaData = ClaimRdDataGenerator.getAddRequestDto();
		// Folder f = alfrescoService.createTreeFolder("/claim/rd/2023/03/08",
		// "/Sites/groupe-indexation/documentLibrary",ClaimRdDataGenerator.getFolderProperties());
		// BrancheProperties brancheProperties = new BrancheProperties();
		// mock the behavior of the elasticRepository and alfrescoService methods
		when(elasticRepository.findOneDocumentByReference(anyString())).thenReturn(null);

		when(brancheProperties.getAlfrescoRootFolder()).thenReturn("/claim/rd/2023/03/08");
		when(brancheProperties.getAlfrescoSitePath()).thenReturn("/Sites/groupe-indexation/documentLibrary");
		when(alfrescoService.createTreeFolder(anyString(), anyString(), any())).thenReturn(folder);
		// when(alfrescoService.createTreeFolder(anyString(),anyString(),ClaimRdDataGenerator.getFolderProperties())).thenReturn(folder);
		// when(brancheProperties.getAlfrescoRootFolder()).thenReturn(null);
		when(service.prepareDocumentFolder(ClaimRdDataGenerator.getFolderProperties())).thenReturn(folder);

		var createdDocument = ClaimRdDataGenerator.getDocumentAlfresco();
		when(alfrescoService.createDocument(any(), anyString(), any(MultipartFile.class),
				ArgumentMatchers.<String, Object>anyMap(), anyBoolean())).thenReturn(createdDocument);

		// create a mock DocumentEs object for mapping
		var documentEs = ClaimRdDataGenerator.getDocumentEs();
		// set any other required fields in documentEs object
		when(rdMapper.fromDto(metaData)).thenReturn(documentEs);
		when(rdMapper.toDto(documentEs)).thenReturn(ClaimRdDataGenerator.getOnResponseDoc());

		metaData.setEnableGestionnaire(false);
		// call the method being tested
		var result = service.uploadDocumentWithMetaData(metaData, FileGenerator.getPdfFile());

		// assert the expected result
		assertNotNull(result);
		// add more assertions as needed
	}





	@DisplayName("claimRd_ValidationRequest_ShouldReturnError")
	@Test
	void testValidationRequest() {
		// Arrange
		var sut = new CommonResponse();
		var error = new HashMap<String, String>();
		error.put("status", "Must fill sinistre number to update status = IDENTIFIE");
		Mockito.when(documentEsMock.getStatus()).thenReturn("Identifié");
		Mockito.when(documentEsMock.getSinistreNumber()).thenReturn("");

		// Act
		var result = service.validationRequest(documentEsMock);

		// Assert
		Assertions.assertFalse(result.isSuccess());
		Assertions.assertEquals(error, result.getMsgErrors());
	}

	@Test
	void testValidStatus_identifiedWithNumSinistre() {
		String status = "Identifié";
		String numSinistre = "12345";
		boolean result = service.validStatus(status, numSinistre);
		assertTrue(result);
	}

	@Test
	void testValidStatus_identifiedWithoutNumSinistre() {
		String status = "Identifié";
		String numSinistre = null;
		boolean result = service.validStatus(status, numSinistre);
		assertFalse(result);
	}

	@Test
	public void testValidStatus_notIdentified() {
		String status = "Non identifié";
		String numSinistre = "12345";
		boolean result = service.validStatus(status, numSinistre);
		assertTrue(result);
	}

	
	@Test
	void testDeleteDocument() {
		// Mocking
		String id = "123";
		boolean withMetaData = true;
		Mockito.when(alfrescoService.exists(id)).thenReturn(true);
		Mockito.when(alfrescoService.deleteDocument(id)).thenReturn(true);
		Mockito.when(elasticRepository.exists(id)).thenReturn(true);
		Mockito.when(elasticRepository.deleteDocument(id)).thenReturn(true);

		// Execution
		CommonResponse response = service.deleteDocument(id, withMetaData);

		// Assertion
		assertTrue(response.isSuccess());
		assertNull(response.getMsgErrors());
		assertNotNull(response.getMsgSuccess());
		assertEquals(2, response.getMsgSuccess().size());
		assertEquals("true", response.getMsgSuccess().get("ALFRESCO"));
		assertEquals("true", response.getMsgSuccess().get("ELASTIC"));

		// Verify
		Mockito.verify(alfrescoService).exists(id);
		Mockito.verify(alfrescoService).deleteDocument(id);
		Mockito.verify(elasticRepository).exists(id);
		Mockito.verify(elasticRepository).deleteDocument(id);
	}
	
	@Test
	void testDeleteDocument_throwsResourceNotFound() {
		// Mocking
		String id = "123";
		boolean withMetaData = true;
		Mockito.when(alfrescoService.exists(id)).thenReturn(false);
		Mockito.when(alfrescoService.deleteDocument(id)).thenReturn(true);
		// Execution
		assertThrows(ResourceNotFoundException.class,()->service.deleteDocument(id, withMetaData));
		
	}
	
	@Test
	void testDeleteDocument_throwsException() {
		// Mocking
		String id = "123";
		boolean withMetaData = true;
		Mockito.when(alfrescoService.exists(id)).thenReturn(true);
		Mockito.when(elasticRepository.exists(id)).thenReturn(true);
		Mockito.when(elasticRepository.deleteDocument(id)).thenThrow(new NullPointerException());
		// Execution
		assertNotNull(service.deleteDocument(id, withMetaData));
		
	}
	
	@Test
	void testDeleteDocument_tryCatch() {
		String id = "123";
		boolean withMetaData = true;
		// Mocking
		Mockito.when(alfrescoService.exists(id)).thenReturn(true);
		Mockito.when(alfrescoService.deleteDocument(id)).thenThrow(NullPointerException.class);
		Mockito.when(elasticRepository.exists(id)).thenReturn(true);
		Mockito.when(elasticRepository.deleteDocument(id)).thenReturn(true);
		
		
		      // Call the method you want to test
			 CommonResponse result = service.deleteDocument(id, withMetaData); 
		      // If no exception is thrown, fail the test
		  
		      assertNotNull(result);
		  
		  }

	@Test
	void testDeleteDocument_withId() {
		String id = "123";
		boolean withMetaData = true;
		// Mocking
		Mockito.when(alfrescoService.exists(id)).thenReturn(true);
		Mockito.when(alfrescoService.deleteDocument(id)).thenThrow(NullPointerException.class);
		Mockito.when(elasticRepository.exists(id)).thenReturn(true);
		Mockito.when(elasticRepository.deleteDocument(id)).thenReturn(true);
		
		
		      // Call the method you want to test
			 CommonResponse result = service.deleteDocument(id); 
		      // If no exception is thrown, fail the test
		  
		      assertNotNull(result);
		  
		  }


	@SuppressWarnings("unchecked")
	@Test
	void search_returnsPageOfDocClaimRdResponses_whenSearchParamsProvided() {
		DocClaimRdSearchParams searchParams = new DocClaimRdSearchParams();
		searchParams.setPageNumber(1);
		searchParams.setPageSize(10);
		Page<DocClaimRdResponse> result = service.search(searchParams);
		assertNotNull(result);

	}

	@SuppressWarnings("unchecked")
	@Test
	void updateDocument_returnsok_whenSearchParamsMetaDataNotProvided() {
		DocClaimRdUpdateReq req = null;
		String documentId = "12345";
		assertThrows(NullPointerException.class, () -> service.updateDocument(documentId, req));
	}

	@SuppressWarnings("unchecked")
	@Test
	void updateDocument_returnsok_whenSearchParamsMetaIdDocNotProvided() {
		DocClaimRdUpdateReq req = new DocClaimRdUpdateReq();
		req.setAssureNom("test");
		String documentId = "";
		assertThrows(IllegalArgumentException.class, () -> service.updateDocument(documentId, req));
	}

	@SuppressWarnings("unchecked")
	@Test
	void updateDocument_returnsok_whenNotExistsInElasticSearch() {
		DocClaimRdUpdateReq req;
		req = ClaimRdDataGenerator.getUpdateRequestDto();
		String documentId = "12345";

		assertThrows(ResourceNotFoundException.class, () -> service.updateDocument(documentId, req));
	}

	@SuppressWarnings("unchecked")
	@Test
	void updateDocument_returnsok_whenExistsInElasticSearch() {
		DocClaimRdUpdateReq req;
		req = ClaimRdDataGenerator.getUpdateRequestDto();
		String documentId = "12345";
		when(elasticRepository.exists(documentId)).thenReturn(true);
		when(elasticRepository.findById(documentId)).thenReturn(Optional.of(ClaimRdDataGenerator.getDocumentEs()));
		DocClaimRdResponse result = service.updateDocument(documentId, req);
		assertNotNull(result);

	}

	
}
