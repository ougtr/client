package ma.axa.inner.ged.enums;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class OldGedRepositoryEnumTest {

    @Test
    void getByCode() {
        assertEquals(OldGedRepositoryEnum.TRANSACTION,
                OldGedRepositoryEnum.getByCode(OldGedRepositoryEnum.TRANSACTION.getCode()));
    }

    @Test
    void getByNullCode() {
        assertNull(OldGedRepositoryEnum.getByCode(""));
    }
}
