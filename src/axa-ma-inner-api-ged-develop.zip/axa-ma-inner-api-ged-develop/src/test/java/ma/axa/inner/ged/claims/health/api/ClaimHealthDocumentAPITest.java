package ma.axa.inner.ged.claims.health.api;

import ma.axa.inner.ged.claim.health.api.ClaimHealthDocumentAPI;
import ma.axa.inner.ged.claim.health.domain.GedHealthEntityAS400;
import ma.axa.inner.ged.claim.health.domain.GedHealthEntityRes;
import ma.axa.inner.ged.claim.health.dto.DocClaimHealthReq;
import ma.axa.inner.ged.claim.health.repository.HealthDocumentsRepository;
import ma.axa.inner.ged.claim.health.service.ClaimHealthDocumentService;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.request.RequestPostProcessor;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;



@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(ClaimHealthDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
class ClaimHealthDocumentAPITest {

        @Autowired
        private MockMvc mockMvc;

        @MockBean
    	private DataSourceContextHolder dataSourceContextHolder;

        @MockBean
        ClaimHealthDocumentService claimHealthDocumentService;


        @MockBean
        HealthDocumentsRepository healthSaveDoc;

        private final static String ID_ALFRESCO = "a162223f-9a5c-466e-a678-b6cc0a37bbc7";
        private final static String BASE_URL = "/v1/claims/health";
        private final static String SUFFIX_DOWNLOAD = "/documents/"+ID_ALFRESCO+"/content";


        @WithMockUser
        @Test
        void download_file_return_success() throws Exception {

            ByteArrayResource output = new ByteArrayResource("content".getBytes());

            when(claimHealthDocumentService.downloadFileFromGed(ID_ALFRESCO)).thenReturn(output);

            mockMvc.perform(MockMvcRequestBuilders.get(BASE_URL+SUFFIX_DOWNLOAD)

                    .contentType(MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk());
        }

        @Test
        void upload_files_return_success() throws Exception {
            MockMultipartFile multiPartFile = new MockMultipartFile("data","test.pdf","application/pdf","content".getBytes());


            String idAlfresco = "5905d039-d9ec-4fed-8bdc-6240606e6042";


            GedHealthEntityAS400 gedHealthEntityAS400 = new GedHealthEntityAS400();
            gedHealthEntityAS400.setNomdoc("CIN");
            gedHealthEntityAS400.setTypedoc("LETM");
            gedHealthEntityAS400.setTypges("CVA");
            gedHealthEntityAS400.setIdeged("5905d039-d9ec-4fed-8bdc-6240606e6042");


            when(healthSaveDoc.addMetaDataDocument(gedHealthEntityAS400)).thenReturn("ok");


            when(claimHealthDocumentService.uploadFile(any(MockMultipartFile.class),any(DocClaimHealthReq.class))).thenReturn(idAlfresco);

            mockMvc.perform(multipart("/v1/claims/health/documents")
                    .file("file", multiPartFile.getBytes())
                    .param("typeDoc", "FIC")
                    .param("nomDoc", "Dossier")
                    .param("typeGestion", "VAC")
                    .param("idAlfresco", ""))
                    .andExpect(status().isOk());

        }


        @Test
        void getDocument_shouldPass() throws Exception {
            String type_gestion = "HON";
            String nom_doc = "Note d'honoraire ";

            List<GedHealthEntityRes> result=List.of();
            assertEquals(result,claimHealthDocumentService.getDocuments(type_gestion,nom_doc));
        }

    @Test
    void getHealthDocByClaimNumber_succes() throws Exception {
        mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/v1/claims/health/documents/metadatas")
                        .param("nomDoc","dossier")
                        .param("typeGestion","CVA")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void getHealthDoc_return_error_when_claim_number_missing() throws Exception {

        mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/v1/claims/health/documents/metadatas")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.type", is(GlobalConstants.URI_MISSING_REQUEST_PARAMETER)));

    }

    @Test
    void deleteHealthDoc_return_sucess() throws Exception {
            mockMvc.perform(
                    MockMvcRequestBuilders
                            .delete("/v1/claims/health/documents")
                            .param("nomDoc","dossier")
                            .param("typeDoc","CVA")
                            .contentType(MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk());
        }

    @Test
    void updateContentHealthDoc_return_sucess() throws Exception {
        MockMultipartFile multiPartFile = new MockMultipartFile("data",
                "test.pdf","application/pdf","content".getBytes());

        MockMultipartHttpServletRequestBuilder builder =
                MockMvcRequestBuilders.multipart("/v1/claims/health/documents/{document_Id}/content","1234");
        builder.with(new RequestPostProcessor() {
            @Override
            public MockHttpServletRequest postProcessRequest(MockHttpServletRequest request) {
                request.setMethod("PUT");
                return request;
            }
        });
        mockMvc.perform(builder
                .file("file", multiPartFile.getBytes()))
                .andExpect(status().isNoContent());
    }

}
