package ma.axa.inner.ged.claims.health.repository;


import ma.axa.inner.ged.claim.health.domain.GedHealthEntityAS400;
import ma.axa.inner.ged.claim.health.domain.GedHealthEntityRes;
import ma.axa.inner.ged.claim.health.domain.GedProductionHealthEntityAS400;
import ma.axa.inner.ged.claim.health.domain.UploadedDocumentAs400;
import ma.axa.inner.ged.claim.health.repository.HealthDocumentsRepository;
import ma.axa.inner.ged.claims.health.util.DataGeneratorHealth;
import ma.axa.inner.ged.exception.CallStoredProcedureException;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class HealthDocumentsRepositoryTest {
    @Mock
    JdbcTemplate jdbcTemplate;

    @InjectMocks
    HealthDocumentsRepository docRepository;

    @Test
    void addMetaDataDocument_success() throws Exception {

        Mockito.lenient().when(jdbcTemplate.queryForObject("CALL LGRPP.PSGDCV010(?,?,?,?,?)", String.class,

                DataGeneratorHealth.healthRequest().getTypges(), DataGeneratorHealth.healthRequest().getNomdoc(),
                DataGeneratorHealth.healthRequest().getTypedoc(), DataGeneratorHealth.healthRequest().getIdeged(),
                DataGeneratorHealth.healthRequest().getUsercr()
        )).thenReturn(new String("ok"));

        assertEquals(new String("ok"), docRepository.addMetaDataDocument(DataGeneratorHealth.healthRequest()));

    }

    @Test
    void addMetaDataDocument_tryCatch() throws Exception {

        when(this.jdbcTemplate.queryForObject(anyString(), (Class<Object>) any(), any()))
                .thenThrow(new CallStoredProcedureException("An error occurred"));
        assertThrows(CallStoredProcedureException.class, () -> docRepository
                .addMetaDataDocument(new GedHealthEntityAS400("TYPDOC", "IDEGED", "NOMDOC", "TYPGES", "user")));
        verify(this.jdbcTemplate).queryForObject(anyString(), (Class<Object>) any(), any());

    }

    @Test
    void AddMetaDataDocument_exception() throws DataAccessException {
        when(this.jdbcTemplate.queryForObject(anyString(), (Class<Object>) any(), any()))
                .thenReturn("Query For Object");
        GedHealthEntityAS400 gedHealthEntityAS400 = mock(GedHealthEntityAS400.class);
        when(gedHealthEntityAS400.getIdeged()).thenReturn("Ideged");
        when(gedHealthEntityAS400.getTypedoc()).thenReturn("Typdoc");
        when(gedHealthEntityAS400.getNomdoc()).thenReturn("Nomdoc");
        when(gedHealthEntityAS400.getTypges()).thenReturn("Typges");
        assertEquals("Query For Object", docRepository.addMetaDataDocument(gedHealthEntityAS400));
        verify(this.jdbcTemplate).queryForObject(anyString(), (Class<Object>) any(), any());
        verify(gedHealthEntityAS400).getIdeged();
        verify(gedHealthEntityAS400).getNomdoc();
        verify(gedHealthEntityAS400).getTypedoc();
        verify(gedHealthEntityAS400).getTypges();
    }

    @Test
    @DisplayName("Test getDocuments")
    void getDocuments_succes() throws IllegalAccessException, InstantiationException {
        Mockito.lenient().when(docRepository.getDocuments("DOS", "dossier")).thenReturn(List.of(DataGeneratorHealth.healthGetDocResponse()));
        assertNotEquals(List.of(DataGeneratorHealth.healthGetDocResponse()), docRepository.getDocuments("DOS", "dossier"));
    }

    @Test
    void getDocuments_exception() throws DataAccessException {
        when(this.jdbcTemplate.query(anyString(), (RowMapper<Object>) any(),
                any())).thenThrow(new CallStoredProcedureException("An error occurred"));
        assertThrows(CallStoredProcedureException.class,
                () -> docRepository.getDocuments("TYPGES", "NOMDOC"));
        verify(this.jdbcTemplate).query(anyString(), (RowMapper<Object>) any(),
                any());
    }

    @Test
    void getDocuments_tryCatch() throws DataAccessException {
        ArrayList<Object> objectList = new ArrayList<>();
        when(this.jdbcTemplate.query(anyString(), (RowMapper<Object>) any(),
                any())).thenReturn(objectList);
        List<GedHealthEntityRes> actualDocuments = docRepository.getDocuments("DOS", "dossier");
        assertSame(objectList, actualDocuments);
        assertTrue(actualDocuments.isEmpty());
        verify(this.jdbcTemplate).query(anyString(), (RowMapper<Object>) any(),
                any());
    }

    @Test
    void delete_metadata_return_OK() {

        Mockito.when(
                jdbcTemplate.queryForObject("CALL LGRPP.PSGDCV013(?,?)",
                        String.class,
                        "nomDoc",
                        "typeDoc"
                )
        ).thenReturn("ok");

        assertEquals("ok", docRepository.deleteHealthMetadata("nomDoc", "typeDoc"));
    }

    @Test
    void delete_metadata_return_KO() {

        Mockito.when(
                jdbcTemplate.queryForObject("CALL LGRPP.PSGDCV013(?,?,?)",
                        String.class,
                        "typeGestion",
                        "nomDoc",
                        "typeDoc"
                )
        ).thenThrow(CallStoredProcedureException.class);

        assertThrows(CallStoredProcedureException.class, () -> docRepository.deleteHealthMetadata("nomDoc", "typeDoc"));
    }

    @Test
    void addMetaDataDocument_psi_success() throws Exception {
        var productionHealthRequest = DataGeneratorHealth.productionHealthRequest();
        Mockito.lenient().when(jdbcTemplate.queryForObject("CALL LGRPP.PSGAMD003(?,?,?,?,?,?,?,?,?)", String.class,
                productionHealthRequest.getCodpro(), productionHealthRequest.getIdeamc(), productionHealthRequest.getColng4(),
                productionHealthRequest.getIdeged(), productionHealthRequest.getBdlusr(), productionHealthRequest.getRectype(),
                productionHealthRequest.getPonpo1(), productionHealthRequest.getPonpo2(), productionHealthRequest.getMenuor()
        )).thenReturn(new String("ok"));
        var resultat = docRepository.addMetaDataDocumentPsi(DataGeneratorHealth.productionHealthRequest());

        assertThat(resultat).isEqualTo("ok");
    }
    @Test
    void AddMetaDataDocument_psi_exception() throws DataAccessException {
        when(this.jdbcTemplate.queryForObject(anyString(), (Class<Object>) any(), any()))
                .thenReturn("Query For Object");
        GedProductionHealthEntityAS400 gedProductionHealthEntityAS400 = mock(GedProductionHealthEntityAS400.class);
        when(gedProductionHealthEntityAS400.getIdeged()).thenReturn("");
        when(gedProductionHealthEntityAS400.getCodpro()).thenReturn("C");
        when(gedProductionHealthEntityAS400.getBdlusr()).thenReturn("intermpsi");
        when(gedProductionHealthEntityAS400.getMenuor()).thenReturn(0);
        assertEquals("Query For Object", docRepository.addMetaDataDocumentPsi(gedProductionHealthEntityAS400));
        verify(this.jdbcTemplate).queryForObject(anyString(), (Class<Object>) any(), any());
        verify(gedProductionHealthEntityAS400).getIdeged();
        verify(gedProductionHealthEntityAS400).getCodpro();
        verify(gedProductionHealthEntityAS400).getBdlusr();
        verify(gedProductionHealthEntityAS400).getMenuor();
    }
    @Test
    void addMetaDataDocument_psi_tryCatch() throws Exception {

        when(this.jdbcTemplate.queryForObject(anyString(), (Class<Object>) any(), any()))
                .thenThrow(new CallStoredProcedureException("An error occurred"));
        assertThrows(CallStoredProcedureException.class, () -> docRepository
                .addMetaDataDocumentPsi(DataGeneratorHealth.productionHealthRequest()));
        verify(this.jdbcTemplate).queryForObject(anyString(), (Class<Object>) any(), any());

    }
    @Test
    void testGetUploadedDocuments_ok() {
        when(this.jdbcTemplate.query(anyString(), ArgumentMatchers.<RowMapper<UploadedDocumentAs400>>any(),
                ArgumentMatchers.any())).thenReturn(DataGeneratorHealth.getUploadedDocumentsAs400());
        Assertions.assertThat(docRepository.getUploadedDocuments("011", BigDecimal.valueOf(1231), 0))
                .isNotNull();
    }
    @Test
    void testGetUploadedDocuments_ko() {
        when(this.jdbcTemplate.query(anyString(), ArgumentMatchers.<RowMapper<UploadedDocumentAs400>>any(),
                ArgumentMatchers.any())).thenThrow(CallStoredProcedureException.class);
        assertThrows(CallStoredProcedureException.class,
                () -> docRepository.getUploadedDocuments("011", BigDecimal.valueOf(1231), 0));
    }

}

