package ma.axa.inner.ged.api.ls.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.boot.test.mock.mockito.MockBean;

import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.dto.LsDocumentRequest;
import ma.axa.inner.ged.repository.LsDocumentsRepository;
import ma.axa.inner.ged.service.ls.LsSaveDocument;
@ExtendWith(MockitoExtension.class)
//@MockitoSettings(strictness = Strictness.LENIENT) 
class LsSaveDocumentTest {
	@Mock
	private LsDocumentsRepository  docRepo;
	@InjectMocks
	LsSaveDocument saveDoc;
	@MockBean
	private DataSourceContextHolder dataSourceContextHolder;
	
	
       @Test
       public void test_service_save_idAlfresco() {
	      when(docRepo.saveLsMetadataDocument(any(LsDocumentRequest.class))).thenReturn("OK");
	      assertThat(saveDoc.saveLsMetadataDocument(new LsDocumentRequest())).isEqualTo("OK");
         }
       /*
       @Test
       public void test_service_throws_Exception() {
	     when(docRepo.addUrlDocument(any(LsDocumentRequest.class))).thenThrow(CallStoredProcedureException.class);	
	      assertThrows(CallStoredProcedureException.class, () -> saveDoc.saveIdAlfresco(new LsDocumentRequest()));
}
*/
}
