package ma.axa.inner.ged.claims.health.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.Property;
import org.apache.chemistry.opencmis.commons.PropertyIds;

import ma.axa.inner.ged.claim.health.dto.DocumentUploadInvoiceRequest;
import ma.axa.inner.ged.claim.health.dto.GedHealthFolderProperties;
import ma.axa.inner.ged.claim.health.repository.SehassurHealthDocumentsRepository;
import ma.axa.inner.ged.claim.health.service.ClaimHealthDocumentService;
import ma.axa.inner.ged.claim.health.service.SehassurHealthDocumentService;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.service.ManageDocumentService;
import ma.axa.inner.ged.util.DataGenerator;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
 
@ExtendWith(SpringExtension.class)
class SehassurHealthDocumentServiceTest {
  
	@Mock
    private SehassurHealthDocumentService sehassurHealthDocumentService;
	
	  
	@Mock
	private ClaimHealthDocumentService claimHealthDocumentService;
 
    @Mock
    Document document;
    @Mock
    Folder folder;
  
 
    @Mock
    ManageDocumentService manageDocumentService;
 
    @Mock
    private ClaimDocumentRepository claimDocumentRepository;
    
    @Mock
    private SehassurHealthDocumentsRepository sehassurHealthDocumentsRepository;
    
    private String alfrescoID = "5905d039-d9ec-4fed-8bdc-6240606e6042";
    
    MockMultipartFile multiPartFile = new MockMultipartFile("data", "test.pdf", "application/pdf", "content".getBytes());
    
    @BeforeEach
    void setup() {
    	sehassurHealthDocumentService = new SehassurHealthDocumentService(claimDocumentRepository,sehassurHealthDocumentsRepository,claimHealthDocumentService); 
        manageDocumentService = new ManageDocumentService(claimDocumentRepository);
        
        Map<String, Object> properties = new HashMap<>();
        properties.put(AXADocPropertyIds.IDENTIFIANT_SCANER, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
        properties.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
 
      	when(claimHealthDocumentService.indexDossier(any())).thenReturn(GedHealthFolderProperties.builder().folder(folder).properties(properties).build());
      	 
       	when(sehassurHealthDocumentsRepository.updateIdGed(any(DocumentUploadInvoiceRequest.class))).thenReturn(1);
       	
        Map<String, String> output = new HashMap<>();
		output.put("idAlfresco",alfrescoID);
		output.put("filename", document.getName());
		when(claimHealthDocumentService.uploadFile(any(), any(GedDocument.class), any(Folder.class))).thenReturn(output);
 
    }

    private Document getMockedDocument(String id) {
        return createMockedCmisObject(new Object[][]{
                {PropertyIds.NAME, "Name", "test" + id + ".txt"},
                {PropertyIds.CONTENT_STREAM_LENGTH, "Content stream length", "210"},
                {PropertyIds.BASE_TYPE_ID, "Base type id", "cmis:document"},
                {PropertyIds.OBJECT_TYPE_ID, "Object type id", "cmis:document"},
                {PropertyIds.LAST_MODIFICATION_DATE, "Last modification date", new Date()},
                {PropertyIds.CONTENT_STREAM_MIME_TYPE, "Content stream mime type", "text/plain"},
                {PropertyIds.OBJECT_ID, "Object type id", id}}, Document.class);
    }

    private <T extends CmisObject> T createMockedCmisObject(Object[][] properties, Class<T> tClass) {
        T object = mock(tClass);
        List<Property<?>> documentProperties = new ArrayList<Property<?>>();
        for (Object[] mockProp : properties) {
            Property<?> prop = createMockedProperty(mockProp[0], mockProp[1], mockProp[2]);
            documentProperties.add(prop);
        }

        return object;
    }

    private Property<?> createMockedProperty(Object id, Object displayName, Object value) {
        Property<String> property = mock(Property.class);
        return property;
    }


    @Test
    void upload_file_should_pass() throws Exception {
        document = getMockedDocument("test");
        assertThat(claimDocumentRepository).isNotNull();
  
        DocumentUploadInvoiceRequest docInfo = DataGenerator.createDocumentUploadInvoiceRequest();
   
        var id = sehassurHealthDocumentService.uploadFacture(multiPartFile, docInfo);
        assertThat(id).isEqualTo(alfrescoID);
 
 
    } 
    
    
    @Test
    void testUploadFile_Exception() throws IOException {
 

        DocumentUploadInvoiceRequest docInfo = DataGenerator.createDocumentUploadInvoiceRequest();
  
    	when(sehassurHealthDocumentsRepository.updateIdGed(any(DocumentUploadInvoiceRequest.class))).thenThrow(GlobalException.class);
 
        assertThrows(GlobalException.class, () ->  sehassurHealthDocumentService.uploadFacture(multiPartFile, docInfo));
    }
    
    @Test
    void testUploadFile_returnNull() throws IOException {
 
         DocumentUploadInvoiceRequest docInfo = DataGenerator.createDocumentUploadInvoiceRequest();
       
         assertThat(sehassurHealthDocumentService.uploadFacture(null, docInfo)).isEmpty();
    }
    
    
}
