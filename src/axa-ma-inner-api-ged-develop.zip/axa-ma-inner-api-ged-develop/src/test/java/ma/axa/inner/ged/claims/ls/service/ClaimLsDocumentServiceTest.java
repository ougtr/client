package ma.axa.inner.ged.claims.ls.service;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import ma.axa.inner.ged.claim.ls.domain.DocumentClaimLsEs;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsReq;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsResp;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsSearchParams;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsUpdateReq;
import ma.axa.inner.ged.claim.ls.mapper.ClaimLsAlfrescoMapper;
import ma.axa.inner.ged.claim.ls.mapper.ClaimLsMapper;
import ma.axa.inner.ged.claim.ls.repository.ClaimLsElasticRepository;
import ma.axa.inner.ged.claim.ls.service.ClaimLsDocumentService;
import ma.axa.inner.ged.claims.ls.util.ClaimLsDataGenerator;
import ma.axa.inner.ged.claims.rd.util.ClaimRdDataGenerator;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.dto.CommonResponse;
import ma.axa.inner.ged.enums.GedClaimStatus;
import ma.axa.inner.ged.exception.*;
import ma.axa.inner.ged.service.AlfrescoGedService;
import ma.axa.inner.ged.util.DataGenerator;
import ma.axa.inner.ged.util.FileGenerator;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.MessageSource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.web.multipart.MultipartFile;
import org.xmlunit.validation.ValidationResult;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.*;

import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@EnableConfigurationProperties(value = BrancheProperties.class)
@WithMockUser(authorities = {GlobalConstants.SCOPE_GED})
class ClaimLsDocumentServiceTest {
	@Mock
	BrancheProperties brancheProperties;
	@Mock
	Folder folder;
	@Mock
	Session session;
	@InjectMocks
	private ClaimLsDocumentService service;
	@Mock
	private ClaimLsMapper lsMapper;
	@Mock
	private ClaimLsElasticRepository elasticRepository;
	@Mock
	private AlfrescoGedService alfrescoService;
	@Mock
	private DocumentClaimLsEs documentEsMock;

	@Mock
	private MessageSource messageSource;

	@BeforeEach
	void initMockRepositories() throws ElasticsearchException, IOException {
		when(alfrescoService.exists(ClaimLsDataGenerator.DOCUMENT_ID)).thenReturn(true);
		when(alfrescoService.exists(ClaimLsDataGenerator.DOCUMENT_ID_NOT)).thenReturn(false);
		when(elasticRepository.exists(ClaimLsDataGenerator.DOCUMENT_ID)).thenReturn(true);
		when(elasticRepository.exists(ClaimLsDataGenerator.DOCUMENT_ID_NOT)).thenReturn(false);
		when(elasticRepository.findById(ClaimLsDataGenerator.DOCUMENT_ID))
				.thenReturn(Optional.of(ClaimLsDataGenerator.getDocumentEs()));
		when(lsMapper.toDto(any(DocumentClaimLsEs.class))).thenReturn(ClaimLsDataGenerator.getOnResponseDoc());
	}

	@Test
	@DisplayName("claimLs_getDocumentById_ShouldReturnValidDocument")
	void getDocumentById_ShouldReturnValidDocument() throws Exception {
		var response = service.getDocumentById(ClaimLsDataGenerator.DOCUMENT_ID);
		assertThat(response).isNotNull();
		assertThat(response.getId()).isEqualTo(ClaimLsDataGenerator.DOCUMENT_ID);
		assertThat(response.getBrancheLabel()).isEqualTo("LS");
	}

	@Test
	@DisplayName("claimLs_getDocumentById_ShouldThrowRecoLsNotFoundException")
	void getDocumentById_ShouldThrowRecoLsNotFoundException() throws Exception {
		assertThatThrownBy(() -> service.getDocumentById(ClaimLsDataGenerator.DOCUMENT_ID_NOT))
				.isInstanceOf(ResourceNotFoundException.class);
	}

	@Test
	@DisplayName("claimLs_downloadFile_mustReturnAValideFile")
	void downloadFile_mustReturnAValideFile() throws Exception {
			var document = mock(Document.class);
			var contentStream = mock(ContentStream.class);
			var isv1 = new ByteArrayInputStream("test file content".getBytes());
			when(contentStream.getStream()).thenReturn(isv1);
			when(contentStream.getMimeType()).thenReturn("application/pdf");
			when(contentStream.getLength()).thenReturn(1000L);
			when(document.getContentStream()).thenReturn(contentStream);
			when(document.getContentStream().getStream()).thenReturn(isv1);
			when(document.getName()).thenReturn("test.pdf");
			when(document.getContentStreamLength()).thenReturn(1000L);
			when(service.getFileFromAlfresco(ClaimLsDataGenerator.DOCUMENT_ID)).thenReturn(document);

			var responseEntity = service.downloadFile(ClaimLsDataGenerator.DOCUMENT_ID);
			assertThat(responseEntity).isNotNull();
			assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
			assertThat(responseEntity.getHeaders().getContentLength()).isEqualTo(1000);
			assertThat(responseEntity.getHeaders().getContentType()).hasToString("application/pdf");
			assertThat(responseEntity.getHeaders().getContentDisposition().getFilename()).hasToString("test.pdf");
			assertThrows(ResourceNotFoundException.class, () -> service.downloadFile(ClaimLsDataGenerator.DOCUMENT_ID_NOT));
	}

	@Test
	@DisplayName("claimLs_downloadFile_ShouldThrowResourceNotFoundException")
	void downloadFile_ShouldThrowResourceNotFoundException() {
		assertThrows(ResourceNotFoundException.class, () -> service.downloadFile(ClaimLsDataGenerator.DOCUMENT_ID_NOT));
	}

	@Test
	@DisplayName("claimLs_uploadDocumentWithMetaData_ShouldReturnResourceAlreadyExists")
	void uploadDocumentWithMetaData_ShouldReturnResourceAlreadyExists() throws Exception {
		var metaData = ClaimLsDataGenerator.getAddRequestDto();
		var file = FileGenerator.getPdfFile();
		var documentExist = ClaimLsDataGenerator.getDocumentEs();
		when(elasticRepository.findOneDocumentByReference(ClaimLsDataGenerator.REFERENCE)).thenReturn(documentExist);

		try {
			service.uploadDocWithMetaData(metaData, file);
			//fail("Expected ResourceAlreadyExist exception");
		} catch (ResourceAlreadyExist e) {
			assertEquals(GlobalConstants.URI_RECORDE_ALREADY_EXIST, e.getType());
			assertEquals(GlobalConstants.ERROR_MSG_RD_REFERENCE_ALREADY_EXIST, e.getMessage());
			assertArrayEquals(new String[]{ClaimLsDataGenerator.REFERENCE}, e.getArgs());
		} catch (RequestValidationException ex) {
			assertThrows(RequestValidationException.class, () -> service.uploadDocWithMetaData(metaData, file));
		}
	}

	@Test
	@DisplayName("claimLs_uploadDocumentWithMetaData_ShouldReturnAddedObject")
	void uploadDocumentWithMetaData_ShouldReturnAddedObject() throws Exception {
		// create mock input data
		var metaData = ClaimLsDataGenerator.getAddRequestDto();
		when(elasticRepository.findOneDocumentByReference(anyString())).thenReturn(null);

		when(brancheProperties.getAlfrescoRootFolder()).thenReturn("/claim/ls/2023/03/08");
		when(brancheProperties.getAlfrescoSitePath()).thenReturn("/Sites/groupe-indexation/documentLibrary");
		when(alfrescoService.createTreeFolder(anyString(), anyString(), any())).thenReturn(folder);
		when(service.prepareDocumentFolder(ClaimLsDataGenerator.getFolderProperties())).thenReturn(folder);

		var createdDocument = ClaimLsDataGenerator.getDocumentAlfresco();
		when(alfrescoService.createDocument(any(), anyString(), any(MultipartFile.class),
				ArgumentMatchers.<String, Object>anyMap(), anyBoolean())).thenReturn(createdDocument);

		// create a mock DocumentEs object for mapping
		var documentEs = ClaimLsDataGenerator.getDocumentEs();
		// set any other required fields in documentEs object
		when(lsMapper.fromDto(metaData)).thenReturn(documentEs);
		when(lsMapper.toDto(documentEs)).thenReturn(ClaimLsDataGenerator.getOnResponseDoc());

		// call the method being tested
		var result = service.uploadDocWithMetaData(metaData, FileGenerator.getPdfFile());

		// assert the expected result
		assertNotNull(result);
		// add more assertions as needed
	}



	@DisplayName("claimLs_ValidationRequest_ShouldReturnError")
	@Test
	void testValidationRequest() {
		// Arrange
		var sut = new CommonResponse();
		var error = new HashMap<String, String>();
		error.put("status", "Must fill sinistre number to update status = IDENTIFIE");
		Mockito.when(documentEsMock.getStatus()).thenReturn("Identifié");
		Mockito.when(documentEsMock.getSinistreNumber()).thenReturn("");

		// Act
		var result = service.validationRequest(documentEsMock);

		// Assert
		Assertions.assertFalse(result.isSuccess());
		Assertions.assertEquals(error, result.getMsgErrors());
	}

	@Test
	void testValidStatus() {
		assertTrue(ClaimLsDocumentService.validStatus("Status", "Num Sinistre"));
		assertTrue(ClaimLsDocumentService.validStatus("Identifié", "Num Sinistre"));
		assertFalse(ClaimLsDocumentService.validStatus("Identifié", ""));
	}

	@Test
	void testValidStatus_identifiedWithNumSinistre() {
		String status = "Identifié";
		String numSinistre = "12345";
		boolean result = service.validStatus(status, numSinistre);
		assertTrue(result);
	}

	@Test
	void search_returnsPageOfDocClaimLsResponses_whenSearchParamsProvided() {
		DocClaimLsSearchParams searchParams = new DocClaimLsSearchParams();
		searchParams.setPageNumber(1);
		searchParams.setPageSize(10);
		Page<DocClaimLsResp> result = service.search(searchParams);
		assertNotNull(result);

	}

	@Test
	void updateDocument_returnsok_whenSearchParamsMetaDataNotProvided() {
		DocClaimLsUpdateReq req = null;
		String documentId = "12345";
		assertThrows(NullPointerException.class, () -> service.updateDocument(documentId, req));
	}

	@Test
	void updateDocument_returnsok_whenSearchParamsMetaIdDocNotProvided() {
		DocClaimLsUpdateReq req = new DocClaimLsUpdateReq();
		req.setReference("test");
		String documentId = "";
		assertThrows(IllegalArgumentException.class, () -> service.updateDocument(documentId, req));
	}


	@Test
	void updateDocument_returnsok_whenNotExistsInElasticSearch() {
		DocClaimLsUpdateReq req;
		req = ClaimLsDataGenerator.getUpdateRequestDto();
		String documentId = "12345";
		assertThrows(ResourceNotFoundException.class, () -> service.updateDocument(documentId, req));
	}

	@Test
	void updateDocument_returnsok_whenExistsInElasticSearch() {
		DocClaimLsUpdateReq req;
		req = ClaimLsDataGenerator.getUpdateRequestDto();
		String documentId = "12345";
		when(elasticRepository.exists(documentId)).thenReturn(true);
		when(elasticRepository.findById(documentId)).thenReturn(Optional.of(ClaimLsDataGenerator.getDocumentEs()));
		DocClaimLsResp result = service.updateDocument(documentId, req);
		assertNotNull(result);


	}

	@Test
	void testDeleteDocument_tryCatch() {

		String id = "";
		when(service.deleteDocument(id)).thenThrow(new GlobalException("problem/some-error-type"));
		assertThrows(GlobalException.class, () -> service.deleteDocument(id));
	}



	@Test
	void prepareDocumentFolder_throwsInternalErrorException() {
		Map<String, Object> properties = new HashMap<>();
		assertThrows(InternalErrorException.class, () -> service.prepareDocumentFolder(properties));
	}

	@Test
	void getFileFromAlfresco_throwsResourceNotFoundException() {
		// Arrange
		String idAlfresco = "123456";
		when(alfrescoService.exists(idAlfresco)).thenReturn(false);

		// Act & Assert
		assertThrows(ResourceNotFoundException.class, () -> service.getFileFromAlfresco(idAlfresco));
	}

	@Test
	void getFileFromAlfresco_throwsGlobalException() {
		// Arrange
		String idAlfresco = "123456";
		when(alfrescoService.exists(idAlfresco)).thenReturn(true);
		when(alfrescoService.getDocument(idAlfresco)).thenThrow(new RuntimeException("Something went wrong!"));
		// Act & Assert
		assertThrows(GlobalException.class, () -> service.getFileFromAlfresco(idAlfresco));
	}

	@Test
	void testUpdateDocumentWithNonExistingDocumentId() {
		// arrange
		String documentId = "test";
		DocClaimLsUpdateReq metaData = new DocClaimLsUpdateReq();
		when(elasticRepository.exists(documentId)).thenReturn(false);

		// act and assert
		assertThrows(ResourceNotFoundException.class, () -> service.updateDocument(documentId, metaData));
	}
/*	@Test
	@DisplayName("Test updateDocumentAlfrescoProps with valid parameters")
	void testUpdateDocumentAlfrescoPropsValid() {
		String documentId = "123";
		DocClaimLsUpdateReq metaData = new DocClaimLsUpdateReq();
		metaData.setSinistreNumber("12345");

		boolean result = service.updateDocumentAlfrescoProps(documentId, metaData);

		assertTrue(result);
		verify(alfrescoService).updateDocumentProperties(documentId, ClaimLsAlfrescoMapper.toDocumentProperties(metaData));
	}

	@Test
	@DisplayName("Test updateDocumentAlfrescoProps with invalid parameters")
	void testUpdateDocumentAlfrescoPropsInvalid() {
		String documentId = "123";
		DocClaimLsUpdateReq metaData = new DocClaimLsUpdateReq();
		metaData.setSinistreNumber("1234");

		doThrow(new RuntimeException("Some error")).when(alfrescoService).updateDocumentProperties(documentId, ClaimLsAlfrescoMapper.toDocumentProperties(metaData));

		boolean result = service.updateDocumentAlfrescoProps(documentId, metaData);

		assertFalse(result);
		verify(alfrescoService).updateDocumentProperties(documentId, ClaimLsAlfrescoMapper.toDocumentProperties(metaData));
	}*/
	@Test
	void testUpdateDocumentAlfrescoProps() throws Exception {
		String documentId = "123";
		DocClaimLsUpdateReq metaData = new DocClaimLsUpdateReq();

		service.updateDocumentAlfrescoProps(documentId, metaData);

		verify(alfrescoService).updateDocumentProperties(eq(documentId), any(Map.class));
	}

}
