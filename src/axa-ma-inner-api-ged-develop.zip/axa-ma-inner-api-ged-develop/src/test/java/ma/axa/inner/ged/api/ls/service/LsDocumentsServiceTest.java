package ma.axa.inner.ged.api.ls.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.Property;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.Resource;
import org.springframework.mock.web.MockMultipartFile;

import ma.axa.inner.ged.config.GedLsProperties;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.domain.ProductionTypeDoc;
import ma.axa.inner.ged.helper.ElasticSearchHelper;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.service.ManageDocumentService;
import ma.axa.inner.ged.service.ls.LsDocumentsService;
@ExtendWith(MockitoExtension.class)
public class LsDocumentsServiceTest {
	@Mock
    ClaimDocumentRepository claimDocumentRepository;
    @Mock
    GedLsProperties gedProductionProperties;
    @Mock
    Document document;

    @Mock
    List<Document> documents;

    @Mock
    Folder folder;
    @Mock
    ManageDocumentService manageDocumentService;
    @Mock
    ElasticSearchHelper elasticSearchHelper;
    
    @Mock
   LsDocumentsService prodAtDocumentService;
    
    @BeforeEach
    void setup() {
        prodAtDocumentService = new  LsDocumentsService(claimDocumentRepository, gedProductionProperties,
                elasticSearchHelper);
        manageDocumentService = new ManageDocumentService(claimDocumentRepository);
    } 
    @Test
    void download_file() {
        
        assertThat(claimDocumentRepository).isNotNull();
        
        String docId = "id";
        
        var file = new GedDocument();
        file.setFileByte(new byte[] {1,2});
        file.setFileName("test.pdf");
        file.setMimeType("application/pdf");
         
        when(claimDocumentRepository.getFileDocument(docId)).thenReturn(file);
        
        Resource resource = prodAtDocumentService.downloadFile(docId);
       
       ArgumentCaptor<String> id = ArgumentCaptor.forClass(String.class);
      verify(claimDocumentRepository).getFileDocument(id.capture());
      assertThat(id.getValue()).isEqualTo(docId);
        assertThat(resource).isNotNull();
    }
    private <T extends CmisObject> T createMockedCmisObject(Object[][] properties, Class<T> clazz) {
        T object = mock(clazz);
        List<Property<?>> documentProperties = new ArrayList<Property<?>>();
        for (Object[] mockProp : properties) {
            Property<?> prop = createMockedProperty(mockProp[0], mockProp[1], mockProp[2]);
            documentProperties.add(prop);
        }

        return object;
    }
    
    private Property<?> createMockedProperty(Object id, Object displayName, Object value) {
        Property<String> property = mock(Property.class);
        return property;
    }


    private Document getMockedDocument(String id) {
        var documentObject = createMockedCmisObject(new Object[][] {
                { PropertyIds.NAME, "Name", "test" + id + ".txt" },
                { PropertyIds.CONTENT_STREAM_LENGTH, "Content stream length", "210" },
                { PropertyIds.BASE_TYPE_ID, "Base type id", "cmis:document" },
                { PropertyIds.OBJECT_TYPE_ID, "Object type id", "cmis:document" },
                { PropertyIds.LAST_MODIFICATION_DATE, "Last modification date", new Date() },
                { PropertyIds.CONTENT_STREAM_MIME_TYPE, "Content stream mime type", "text/plain" },
                { PropertyIds.OBJECT_ID, "Object type id", id } }, Document.class);
        return documentObject;
    } 
    @Test
    void upload_file_should_pass() {
        document = getMockedDocument("test");
        assertThat(claimDocumentRepository).isNotNull();

        MockMultipartFile multiPartFile = new MockMultipartFile("data", "test.pdf", "application/pdf",
                "content".getBytes());

        ProductionTypeDoc productionTypeDoc = new ProductionTypeDoc();
        productionTypeDoc.setEffectDate(LocalDate.now());
        productionTypeDoc.setPoliceNumber("123456");
        productionTypeDoc.setIdAlfresco("ifAlfresco");

        var alfrescoID = "alfrescoId";

        GedDocument gedDocument = new GedDocument();
        gedDocument.setFileByte("content".getBytes());
        gedDocument.setFileName("test.pdf");
        gedDocument.setMimeType("application/pdf");

        Map<String, String> output = new HashMap<>();
        output.put("alfrescoId", alfrescoID);

      

        lenient().when(gedProductionProperties.getLsDoc())
                .thenReturn("/Sites/Ls");
        lenient().when(document.getVersionSeriesId()).thenReturn(alfrescoID);
        lenient().when(claimDocumentRepository.createArboFoldersByPath(any(String.class), any(String.class)))
                .thenReturn(folder);
        lenient().when(claimDocumentRepository.createDocument(any(Folder.class), any(GedDocument.class)))
                .thenReturn(document);
     
        LsDocumentsService spyService = spy(prodAtDocumentService);
        when(spyService.uploadFile(gedDocument)).thenReturn("alfrescoId");

        var id = spyService.uploadFile(multiPartFile);
        assertThat(id).isEqualTo(alfrescoID);
    }

}
