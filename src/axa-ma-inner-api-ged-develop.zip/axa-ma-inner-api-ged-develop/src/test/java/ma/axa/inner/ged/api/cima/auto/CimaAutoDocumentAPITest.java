package ma.axa.inner.ged.api.cima.auto;

import static ma.axa.inner.ged.util.constants.CimaConstants.CIMA_AUTO_BASE_URL;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.request.RequestPostProcessor;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;

import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.domain.cima.auto.CimaAutoDocumentEs;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentRequest;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentTypeResponse;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoItemResponse;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoSearchParams;
import ma.axa.inner.ged.dto.cima.auto.CountryCode;
import ma.axa.inner.ged.service.ac.DirectoriesService;
import ma.axa.inner.ged.service.cima.auto.CimaAutoDocumentService;
import ma.axa.inner.ged.util.CimaDataGenerator;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.request.RequestFacade;


@WebAppConfiguration
@MockBean({ Tracer.class })
@Import({ RequestFacade.class })
@WebMvcTest(CimaAutoDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
class CimaAutoDocumentAPITest {
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private CimaAutoDocumentService cimaAutoDocumentService;

	@MockBean
	private DirectoriesService directoriesService;

	@Autowired
	private CimaAutoDocumentAPI cimaAutoDocumentAPI;
	
	@MockBean
	private DataSourceContextHolder dataSourceContextHolder;

	@Test
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void uploadDocuments_shouldReturnStatusOK() throws Exception {
		CimaAutoDocumentRequest cimaAutoDocumentRequest = CimaDataGenerator.generateCimaAutoDocumentRequest();
		MultipartFile multipartFile = CimaDataGenerator.MULTIPART_FILE;

		when(cimaAutoDocumentService.uploadFile(cimaAutoDocumentRequest, multipartFile))
				.thenReturn(CimaDataGenerator.generateCimaAutoDocumentResponse());

		var request = multipart(CIMA_AUTO_BASE_URL).file("file", multipartFile.getBytes())
				.contentType(MediaType.MULTIPART_FORM_DATA_VALUE)
				.param("countryCode", "SN")
				.param("typeDocument", "DECLARATION")
				.param("dateNumerisation", "2014-01-01")
				.param("numPolice", "pol012")
		        .param("createdBy", "user")
		        .param("createdAt", "2014-01-01T10:10:10");
		mockMvc.perform(request).andExpect(status().isCreated());

	}

	@Test
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void updateAutoDocuments_shouldReturnStatusKO() throws Exception {

		CimaAutoDocumentRequest cimaAutoDocumentRequest = CimaDataGenerator.generateCimaAutoDocumentRequest();
		MultipartFile multipartFile = CimaDataGenerator.MULTIPART_FILE;

		when(cimaAutoDocumentService.updateAutoDocuments("DOC_ID", cimaAutoDocumentRequest, multipartFile))
				.thenReturn(CimaDataGenerator.generateCimaAutoDocumentResponse());

		var request = multipart(CIMA_AUTO_BASE_URL + "/DOC_ID").file("file", multipartFile.getBytes())
				.contentType(MediaType.MULTIPART_FORM_DATA_VALUE).param("countryCode", "SN")
				.param("typeDocument", "DECLARATION").param("dateEffet", "2014-01-01").param("numPolice", "pol012");

		request.with(new RequestPostProcessor() {
			@Override
			public MockHttpServletRequest postProcessRequest(MockHttpServletRequest request) {
				request.setMethod("PUT");
				return request;
			}
		});
		mockMvc.perform(request).andExpect(status().isCreated());

	}

	@Test
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void download_return_success() throws Exception {
		String id = "document_Id";

		ByteArrayResource output = new ByteArrayResource("content".getBytes());
		when(cimaAutoDocumentService.downloadDocByIdAlfresco(id)).thenReturn(output);

		mockMvc.perform(MockMvcRequestBuilders.get(CIMA_AUTO_BASE_URL + "/document_Id/content")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	@Test
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void deleteDocument_return_success() throws Exception {
		String id = "document_Id";
		when(cimaAutoDocumentService.deleteDocument(id)).thenReturn(id);

		mockMvc.perform(MockMvcRequestBuilders.delete(CIMA_AUTO_BASE_URL + "/document_Id")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}


	@Test
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void findBranches_return_success() throws Exception {
		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(CIMA_AUTO_BASE_URL +"/params/branches")
				.contentType(MediaType.APPLICATION_JSON)
				.header("countryCode", "CA");

		when(cimaAutoDocumentService.findBranches())
				.thenReturn(List.of(CimaAutoItemResponse.builder().id("ID").build()));

		MockMvcBuilders.standaloneSetup(cimaAutoDocumentAPI).build().perform(requestBuilder).andExpect(status().isOk())
				.andExpect(jsonPath("$[0].id", is("ID")));

	}
	
	@Test
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void findDirectories_return_success() throws Exception {
		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(CIMA_AUTO_BASE_URL +"/params/directories")
				.contentType(MediaType.APPLICATION_JSON)
				.header("countryCode", "CA");

		when(cimaAutoDocumentService.findDirectories())
				.thenReturn(List.of(CimaAutoItemResponse.builder().id("ID").build()));

		MockMvcBuilders.standaloneSetup(cimaAutoDocumentAPI).build().perform(requestBuilder).andExpect(status().isOk())
				.andExpect(jsonPath("$[0].id", is("ID")));

	}
	
	@Test
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void findEntities_return_success() throws Exception {
		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(CIMA_AUTO_BASE_URL +"/params/braches/1/entities")
				.contentType(MediaType.APPLICATION_JSON)
				.header("countryCode", "CA");

		when(cimaAutoDocumentService.findEntities(1L))
				.thenReturn(List.of(CimaAutoItemResponse.builder().id("ID").build()));

		MockMvcBuilders.standaloneSetup(cimaAutoDocumentAPI).build().perform(requestBuilder).andExpect(status().isOk())
				.andExpect(jsonPath("$[0].id", is("ID")));

	}
	
	@Test
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void findDocumentTypes_return_success() throws Exception {
		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(CIMA_AUTO_BASE_URL +"/params/entities/1/directories/1")
				.contentType(MediaType.APPLICATION_JSON)
				.header("countryCode", "CA");

		when(cimaAutoDocumentService.findDocumentTypes(1L,1L))
				.thenReturn(List.of(CimaAutoItemResponse.builder().id("ID").build()));

		MockMvcBuilders.standaloneSetup(cimaAutoDocumentAPI).build().perform(requestBuilder).andExpect(status().isOk())
				.andExpect(jsonPath("$[0].id", is("ID")));

	}
	
	@Test
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void findAllDocumentTypes_return_success() throws Exception {
		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(CIMA_AUTO_BASE_URL +"/params/documenttypes")
				.contentType(MediaType.APPLICATION_JSON)
				.header("countryCode", "CA");

		when(cimaAutoDocumentService.findAllDocumentTypes())
				.thenReturn(List.of(CimaAutoDocumentTypeResponse.builder().id("ID").build()));

		MockMvcBuilders.standaloneSetup(cimaAutoDocumentAPI).build().perform(requestBuilder).andExpect(status().isOk())
				.andExpect(jsonPath("$[0].id", is("ID")));

	}
	
	
	@Test
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void find_by_criteria_success() throws Exception {
		   ObjectMapper objectMapper = new ObjectMapper();
		   
		CimaAutoSearchParams searchParams = new CimaAutoSearchParams();
		searchParams.setCountryCode(CountryCode.CA);
		searchParams.setPageNumber(0);
		searchParams.setPageSize(10);
		String jsonContent = objectMapper.writeValueAsString(searchParams);
		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post(CIMA_AUTO_BASE_URL +"/search")
				.contentType(MediaType.APPLICATION_JSON)
				.content(jsonContent);

		when(cimaAutoDocumentService.findByCriteria(searchParams))
				.thenReturn(List.of(CimaAutoDocumentEs.builder().id("ID").build()));

		MockMvcBuilders.standaloneSetup(cimaAutoDocumentAPI).build().perform(requestBuilder).andExpect(status().isOk())
				.andExpect(jsonPath("$[0].id", is("ID")));

	}

	@Test
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void downloadZip_success() throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();

		CimaAutoSearchParams searchParams = new CimaAutoSearchParams();
		searchParams.setCountryCode(CountryCode.CA);
		searchParams.setPageNumber(0);
		searchParams.setPageSize(10);

		String jsonContent = objectMapper.writeValueAsString(searchParams);

		byte[] zipBytes = new byte[]{1, 2, 3};

		when(cimaAutoDocumentService.streamDocumentsZip(any(CimaAutoSearchParams.class)))
				.thenReturn(zipBytes);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post(CIMA_AUTO_BASE_URL + "/zip")
				.contentType(MediaType.APPLICATION_JSON)
				.content(jsonContent);

		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(header().string(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=documents.zip"))
				.andExpect(header().string(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE))
				.andExpect(content().bytes(zipBytes));

		verify(cimaAutoDocumentService).streamDocumentsZip(any(CimaAutoSearchParams.class));
	}

}
