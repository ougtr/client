package ma.axa.inner.ged.claims.transport.util;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import lombok.experimental.UtilityClass;
import ma.axa.inner.ged.claim.transport.domain.DocumentClaimTransportEs;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportAddReq;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportResponse;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportUpdateReq;
import ma.axa.inner.ged.enums.Branche;
import ma.axa.inner.ged.enums.GedClaimStatus;
import ma.axa.inner.ged.util.DateUtils;

@UtilityClass
public class ClaimTransportDataGenerator {

	public static final String DOCUMENT_ID = "64a7fb0a-c4d3-4487-8e97-8d453c458adb";
	public static final String DOCUMENT_ID_NOT = "64a7fb0a-c4d3-4487-8e97";
	public static final String APP_CODE = "GED_CLAIM";
	public static final String CREATED_BY = "a205mohamed";
	public static final String LASTUPDATED_BY = "jihad";
	public static final String REFERENCE = "ref-20230202-01";
	public static final String SINISTRE_NUMBER = "ref-20230202-01";
	public static final LocalDateTime CREATE_DATE_TIME = LocalDateTime.now();

	/** ======== Request ======== **/
	public static final MultiValueMap<String, String> getAddRequest() {
		return getAddRequest(APP_CODE, CREATED_BY, REFERENCE, SINISTRE_NUMBER, GedClaimStatus.EN_INSTANCE.name());
	}

	public static final MultiValueMap<String, String> getAddRequest(String reference) {
		return getAddRequest(APP_CODE, CREATED_BY, reference, SINISTRE_NUMBER, GedClaimStatus.EN_INSTANCE.name());
	}

	public static final MultiValueMap<String, String> getAddRequestForFaildValidation() {
		return getAddRequest(APP_CODE, CREATED_BY, REFERENCE, null, GedClaimStatus.IDENTIFIE.name());
	}

	public static final MultiValueMap<String, String> getAddRequest(String appCode, String createdBy,
			String reference, String sinistreNumber, String status) {
		MultiValueMap<String, String> meta = new LinkedMultiValueMap<>();
		// required
		meta.set("applicationCode", appCode);
		meta.set("createdBy", createdBy);
		meta.set("reference", reference);

		meta.set("assureNom", "achref");
		meta.set("assurePrenom", "hakimi");
		meta.set("comment", null);
		meta.set("dateNumerisation", LocalDate.now().format(DateUtils.dateFormatter));
		meta.set("dateReception", LocalDate.now().minusDays(1).format(DateUtils.dateFormatter));
		meta.set("dateSurvenance", LocalDate.now().minusDays(4).format(DateUtils.dateFormatter));
		meta.set("draft", "false");
		meta.set("entityCode", "1");
		meta.set("entityLabel", "");
		meta.set("filename", "new_filename.pdf");
		meta.set("intermediaireCode", "205");
		meta.set("intermediaireNom", "Marrache et Dor");
		meta.set("original", "false");
		meta.set("produitCode", "4");
		meta.set("produitLabel", "Product name");
		meta.set("sinistreNumber", sinistreNumber);
		meta.set("sinistreUserCreator", "mohamed");
		meta.set("status", status);
		meta.set("typeDocumentCode", "3");
		meta.set("typeDocumentLabel", "cin");
		return meta;
	}

	public static final DocClaimTransportAddReq getAddRequestDto() {
		return DocClaimTransportAddReq.builder()
				.createdBy(CREATED_BY)
				.applicationCode(APP_CODE)
				.reference(REFERENCE)
				.sinistreNumber(SINISTRE_NUMBER)
				.intermediaireCode(205)
				.build();
	}

	public static final DocClaimTransportUpdateReq getUpdateRequestDto() {
		return DocClaimTransportUpdateReq.builder()
				.lastUpdatedBy(LASTUPDATED_BY)
				.intermediaireCode(205)
				.sinistreNumber(SINISTRE_NUMBER)
				.reference(REFERENCE)
				.build();
	}

	public static final MultiValueMap<String, String> getSearchParams(int pageNumber, int pageSize) {
		MultiValueMap<String, String> meta = new LinkedMultiValueMap<>();
		meta.set("pageNumber", String.valueOf(pageNumber));
		meta.set("pageSize", String.valueOf(pageSize));
		meta.set("createdBy", CREATED_BY);
		meta.set("status", GedClaimStatus.IDENTIFIE.name());
		meta.set("sinistreNumber", SINISTRE_NUMBER);
		meta.set("reference", REFERENCE);
		return meta;
	}

	/** ======== Response DTOs ======== **/

	public static DocumentClaimTransportEs getDocumentEs() {
		return DocumentClaimTransportEs.builder()
				.id(DOCUMENT_ID)
				.applicationCode("GED_CLAIM")
				.assureNom("achref")
				.assurePrenom("hakimi")
				.brancheCode(Branche.TRANSPORT.getCode())
				.brancheLabel(Branche.TRANSPORT.getLabel())
				.comment(null)
				.createdAt(CREATE_DATE_TIME)
				.createdBy(CREATED_BY)
				.dateNumerisation(LocalDate.now())
				.dateReception(LocalDate.now().minusDays(1))
				.dateSurvenance(LocalDate.now().minusDays(4))
				.draft(false)
				.entityCode(1)
				.entityLabel("")
				.filename("filename.pdf")
				.intermediaireCode(205)
				.intermediaireNom("Marrache et Dor")
				.lastUpdatedAt(null)
				.lastUpdatedBy(null)
				.original(false)
				.path("/site/folder/to/upload")
				.produitCode(4)
				.produitLabel("Product name")
				.reference(REFERENCE)
				.sinistreNumber(SINISTRE_NUMBER)
				.sinistreUserCreator("mohamed")
				.status("Identifié")
				.typeDocumentCode(3)
				.typeDocumentLabel("cin")
				.build();
	}

	public static DocClaimTransportResponse getOnResponseDoc() {
		return DocClaimTransportResponse.builder()
				.id(DOCUMENT_ID)
				.applicationCode(APP_CODE)
				.assureNom("achref")
				.assurePrenom("hakimi")
				.brancheCode(Branche.TRANSPORT.getCode())
				.brancheLabel(Branche.TRANSPORT.getLabel())
				.comment(null)
				.createdAt(LocalDateTime.now())
				.createdBy(CREATED_BY)
				.dateNumerisation(LocalDate.now())
				.dateReception(LocalDate.now().minusDays(1))
				.dateSurvenance(LocalDate.now().minusDays(4))
				.draft(false)
				.entityCode("1")
				.entityLabel("")
				.filename("filename.pdf")
				.intermediaireCode(205)
				.intermediaireNom("Marrache et Dor")
				.lastUpdatedAt(null)
				.lastUpdatedBy(null)
				.original(false)
				.path("/site/folder/to/upload")
				.produitCode(4)
				.produitLabel("Product name")
				.reference(REFERENCE)
				.sinistreNumber(SINISTRE_NUMBER)
				.sinistreUserCreator("mohamed")
			
				.typeDocumentCode("3")
				.typeDocumentLabel("cin")
				.build();
	}

	public static DocClaimTransportResponse getOnResponseAfterUpdateDoc() {
		return DocClaimTransportResponse.builder()
				.id(DOCUMENT_ID)
				.assureNom("achref")
				.applicationCode(APP_CODE)
				.brancheCode(Branche.TRANSPORT.getCode())
				.assurePrenom("hakimi")
				.brancheLabel(Branche.TRANSPORT.getLabel())
				.createdAt(CREATE_DATE_TIME)
				.comment(null)
				.createdBy(CREATED_BY)
				.dateReception(LocalDate.now().minusDays(1))
				.dateNumerisation(LocalDate.now())
				.dateSurvenance(LocalDate.now().minusDays(4))
				.draft(false)
				.entityCode("1")
				.entityLabel("")
				.filename("filename.pdf")
				.intermediaireCode(205)
				.intermediaireNom("Marrache et Dor")
				.lastUpdatedAt(LocalDateTime.now())
				.lastUpdatedBy(LASTUPDATED_BY)
				.original(false)
				.path("/site/folder/to/transport")
				.produitCode(4)
				.reference(REFERENCE)
				.produitLabel("Product")
				.sinistreNumber(SINISTRE_NUMBER)
				.sinistreUserCreator("mohamed")
				.typeDocumentCode("3")
			
				.typeDocumentLabel("cin")
				.build();
	}
}
