package ma.axa.inner.ged.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import ma.axa.inner.ged.api.at.ClaimDocumentAPI;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.domain.IndexOrPathToUse;
import ma.axa.inner.ged.domain.at.DocumentSinistreATES;
import ma.axa.inner.ged.dto.DocClaimAtReqDto;
import ma.axa.inner.ged.dto.DocumentSinistreAT;
import ma.axa.inner.ged.dto.at.ChangesQueryDto;
import ma.axa.inner.ged.dto.at.CopyDocumentsQueryDto;
import ma.axa.inner.ged.dto.at.DocumentMetadataQueryDto;
import ma.axa.inner.ged.dto.at.PageDto;
import ma.axa.inner.ged.helper.ElasticSearchHelper;
import ma.axa.inner.ged.service.at.ClaimATDocumentService;
import ma.axa.inner.ged.util.DataGenerator;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;
import java.util.List;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(ClaimDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
class ClaimDocumentAPITest {
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	ClaimATDocumentService claimATDocumentService;

	@MockBean
	ElasticSearchHelper elasticSearchHelper;
	
	
	@MockBean
	private DataSourceContextHolder dataSourceContextHolder;

	private final static String ID_ALFRESCO = "a162223f-9a5c-466e-a678-b6cc0a37bbc7";


	@WithMockUser
	@Test
	void Should_Upload_File() throws Exception {
		MockMultipartFile multiPartFile = new MockMultipartFile("file", "test.pdf", "application/pdf",
				"content".getBytes());

		/*MockMultipartFile documentSinistreAT = new MockMultipartFile("documentSinistreAT", null, "application/json",
				"{ \"userCode\": 205, \"userLogin\": \"login\", \"identifiantScanner\": \"111\", \"typeDocument\": \"56\" }"
						.getBytes(UTF_8));*/

		when(claimATDocumentService.uploadFile(any(DocumentSinistreAT.class), any(MultipartFile.class)))
				.thenReturn("alfresco");

		mockMvc.perform(multipart("/v1/claims/at/documents")
				.file("file", multiPartFile.getBytes())
				.param("userCode", "205")
				.param("userLogin", "login")
				.param("identifiantScanner", "111")
				.param("typeDocument", "56"))
				.andExpect(status().isCreated());
	}

	@WithMockUser
	@Test
	void Upload_Missing_File() throws Exception {
		MockMultipartFile documentSinistreAT = new MockMultipartFile("documentSinistreAT", null, "application/json",
				"{ \"userCode\": 205, \"userLogin\": \"login\", \"identifiantScanner\": \"111\", \"typeDocument\": \"56\" }"
						.getBytes(UTF_8));

		when(claimATDocumentService.uploadFile(any(DocumentSinistreAT.class), any(MultipartFile.class)))
				.thenReturn("alfresco");

		mockMvc.perform(MockMvcRequestBuilders.multipart("/v1/doc/at").file(documentSinistreAT))
				.andExpect(MockMvcResultMatchers.status().is4xxClientError());
	}


	@Test
	void shouldUploadTemporaryFileAT_with_succes() throws Exception {

		MockMultipartFile multiPartFile = new MockMultipartFile("file", "test.pdf", "application/pdf",
				"content".getBytes());

		when(claimATDocumentService.uploadFileAt(any(DocClaimAtReqDto.class), any(MultipartFile.class)))
				.thenReturn(ID_ALFRESCO);

		mockMvc.perform(multipart("/v1/claims/at/documents/temporary")
				.file("file", multiPartFile.getBytes())
				.param("typeDocument", "cin"))
				.andExpect(status().isCreated());
	}


	@Test
	void shouldDownloadTemporaryFileAT_with_succes() throws Exception {

		ByteArrayResource output = new ByteArrayResource("content".getBytes());

		when(claimATDocumentService.downloadAtFile(ID_ALFRESCO)).thenReturn(output);

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/claims/at/documents/"+ ID_ALFRESCO +"/content")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	@Test
	void shouldRetriveMetaDataByClaimNumber_with_succes() throws Exception {

		when(elasticSearchHelper.getAtDocumentsList(IndexOrPathToUse.DEFAULT,"numsinistre","1234")).thenReturn(Arrays.asList(new DocumentSinistreATES()));

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/claims/at/documents/metadatas")
				.param("claim_number", "1234")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	@Test
	void shouldModifyMetadata_with_succes() throws Exception {

		 DocClaimAtReqDto docClaimAtReqDto= DocClaimAtReqDto.builder().numSinistre("1234").uploadedby("company").build();
		when(claimATDocumentService.modifyAtDocMetadata(ID_ALFRESCO,docClaimAtReqDto)).thenReturn(
				ID_ALFRESCO
		);
		ObjectMapper mapper = new ObjectMapper();

		mockMvc.perform(put("/v1/claims/at/documents/"+ID_ALFRESCO)
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(docClaimAtReqDto)))
				.andExpect(status().isOk());
	}

	@Test
	void shouldDeleteMetadataAndDocument_with_succes() throws Exception {
		when(claimATDocumentService.deleteAtDocument(ID_ALFRESCO)).thenReturn(ID_ALFRESCO);
		mockMvc.perform(delete("/v1/claims/at/documents/"+ID_ALFRESCO)
				.contentType(MediaType.APPLICATION_JSON)
		).andExpect(status().isOk());

	}

	@Test
	void deleteMetadataAndDocument_NotFoundError() throws Exception{
		when(claimATDocumentService.deleteAtDocument(ID_ALFRESCO)).thenReturn(ID_ALFRESCO);
		mockMvc.perform(delete("/v1/claims/at")
				.contentType(MediaType.APPLICATION_JSON)
		).andExpect(status().isNotFound());

	}
	@Test
	void testSearchInDocumentsByQuery() throws Exception {
		when(claimATDocumentService.searchInDocumentsByQuery(DocumentMetadataQueryDto.builder()
						.id("1234")
						.temporary(true)
				.build())).thenReturn(PageDto.<DocClaimAtReqDto>builder()
						.totalPages(0)
						.pageNumber(0)
						.totalElements(0)
						.content(List.of())
				.build());
		mockMvc.perform(get("/v1/claims/at/documents/search")
						.param("temporary","true")
						.param("id","1234")
				.contentType(MediaType.APPLICATION_JSON)
		).andExpect(status().isOk());

	}

	@Test
	void getMissingDocumentsByGroup() throws Exception{
		when(claimATDocumentService.getMissingDocumentsByQuery(any())).thenReturn(DataGenerator.buildMissingDocumentsDto());

		final MockHttpServletResponse response = mockMvc.perform(get("/v1/claims/at/documents/missing-documents")
						.param("type", "1")
						.accept(MediaType.APPLICATION_JSON))
				.andReturn().getResponse();

		assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
	}

	@Test
	void copyDocument() throws Exception {
		final MockHttpServletResponse response = mockMvc.perform(post("/v1/claims/at/documents/copy")
				.content(new ObjectMapper().writeValueAsString(CopyDocumentsQueryDto.builder()
								.userName("a.b")
								.changes(List.of(
										ChangesQueryDto.builder()
												.alfrescoId("alfrescoId")
												.build()
								))
						.build()))
				.contentType(MediaType.APPLICATION_JSON)).andReturn().getResponse();
		assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
	}
}
