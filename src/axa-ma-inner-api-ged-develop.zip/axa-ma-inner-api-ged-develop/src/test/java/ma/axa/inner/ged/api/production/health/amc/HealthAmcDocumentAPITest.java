package ma.axa.inner.ged.api.production.health.amc;


import com.fasterxml.jackson.databind.ObjectMapper;

import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCResp;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCSearchParams;
import ma.axa.inner.ged.service.production.health.amc.HealthAMCDocumentService;
import ma.axa.inner.ged.util.DataGenerator;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(HealthAMCDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
public class HealthAmcDocumentAPITest {

    private static final String SERVICE_PATH = "/v1/health/amc/documents";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    HealthAMCDocumentService healthAMCDocumentService;

    @Autowired
    WebApplicationContext webApplicationContext;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
	private DataSourceContextHolder dataSourceContextHolder;
    
   private final MockMultipartFile multiPartFile = new MockMultipartFile("test","test.pdf","application/pdf","content".getBytes());

    @Test
    @DisplayName("production health amc upload document")
    @WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
    void uploadDocument_ok() throws Exception {
        when(healthAMCDocumentService.uploadDocWithMetaData(any(), any())).thenReturn(DataGenerator.getOnResponseHealthAmcDoc());
        var meta = DataGenerator.getAddDocumentRequest();
        var request = multipart(SERVICE_PATH)
                .file("files", multiPartFile.getBytes())
                .contentType(MediaType.MULTIPART_FORM_DATA_VALUE)
                .params(meta);
        mockMvc.perform(request)
                .andExpect(status().isCreated());
    }
    @Test
    @DisplayName("production health update document")
    @WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
    void updateDocument_200() throws Exception {
        var documentReq = DataGenerator.getUpdateAmcRequestDto();
        var expectedResponse = DataGenerator.getOnAmcResponseAfterUpdateDoc();
        when(healthAMCDocumentService.updateDocument("64a7fb0a-c4d3-4487-8e97-8d453c458adb", documentReq)).thenReturn(expectedResponse);
        var fullPath = String.format("%s/%s", SERVICE_PATH, "64a7fb0a-c4d3-4487-8e97-8d453c458adb");
        var requestBuilder = MockMvcRequestBuilders
                .put(fullPath)
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(documentReq));
        mockMvc.perform(requestBuilder)
                .andExpect(status().isOk());

    }

    @Test
    @DisplayName("delete amc document")
    @WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
    void deleteDocument_ok() throws Exception {
        when(healthAMCDocumentService.deleteDocument(anyString())).thenReturn("deleted");
        var fullPath = String.format("%s/%s", SERVICE_PATH, "64a7fb0a-c4d3-4487-8e97-8d453c458adb");
        var requestBuilder = MockMvcRequestBuilders
                .delete(fullPath);
        mockMvc.perform(requestBuilder)
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("search amc documents")
    @WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
    void searchDocuments_shouldReturn200WhenDocumentsAreFound() throws Exception {
        var searchParams = new DocHealthAMCSearchParams();
        when(healthAMCDocumentService.search(searchParams)).thenReturn(new PageImpl<>(Collections.singletonList(new DocHealthAMCResp())));
        var requestBuilder = MockMvcRequestBuilders
                .get(SERVICE_PATH)
                .queryParams(DataGenerator.getSearchParams(1, 10));
        mockMvc.perform(requestBuilder)
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("tag amc documents by policy number")
    @WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
    void tagByPolicyNumber_ok() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.put(SERVICE_PATH+"/tag?quotation_id=10&policy_number=12&user_name=user")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        verify(healthAMCDocumentService).tagAllDocumentsByPolicyNumber("12","10","user");
    }

}
