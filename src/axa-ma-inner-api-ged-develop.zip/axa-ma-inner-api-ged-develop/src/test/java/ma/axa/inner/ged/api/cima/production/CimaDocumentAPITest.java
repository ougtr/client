package ma.axa.inner.ged.api.cima.production;

import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.service.cima.production.CimaDocumentService;
import ma.axa.inner.ged.util.CimaDataGenerator;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import static ma.axa.inner.ged.util.constants.CimaConstants.CIMA_PROD_BASE_URL;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(CimaDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
class CimaDocumentAPITest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private CimaDocumentService service;

    @MockBean
	private DataSourceContextHolder dataSourceContextHolder;
    
    @Test
    @WithMockUser(authorities = {GlobalConstants.SCOPE_GED})
    void uploadRcProductionDocuments_shouldReturnStatusOK() throws Exception {
        when(service.uploadFile(any(), any())).thenReturn(CimaDataGenerator.generateCimaMrpDocumentResponse());
        var meta = CimaDataGenerator.uploadMrpDocumentRequest();
        var request = multipart(CIMA_PROD_BASE_URL)
                .file("file", CimaDataGenerator.MULTIPART_FILE.getBytes())
                .contentType(MediaType.MULTIPART_FORM_DATA_VALUE)
                .params(meta);
        mockMvc.perform(request)
                .andExpect(status().isCreated());

    }
}