package ma.axa.inner.ged.api.production.fleet;


import com.fasterxml.jackson.databind.ObjectMapper;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.service.production.fleet.FleetDocumentService;
import ma.axa.inner.ged.util.DataGenerator;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(FleetDocumentAPI.class)
@AutoConfigureMockMvc(addFilters = false)
public class FleetDocumentApiTest {
    private static final String SERVICE_PATH = "/v1/fleet/documents";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FleetDocumentService service;


    @Autowired
    WebApplicationContext webApplicationContext;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private DataSourceContextHolder dataSourceContextHolder;

    private final MockMultipartFile multiPartFile = new MockMultipartFile("test", "test.pdf", "application/pdf", "content".getBytes());


    @Test
    void download_fleet_content() throws Exception {
        when(service.uploadFleetDocument(any(), any())).thenReturn(DataGenerator.getOnResponseFleetDoc());
        var meta = DataGenerator.getAddDocumentRequest();
        var request = multipart(SERVICE_PATH)
                .file("files", multiPartFile.getBytes())
                .contentType(MediaType.MULTIPART_FORM_DATA_VALUE)
                .params(meta);
        mockMvc.perform(request)
                .andExpect(status().isCreated());
    }


    @Test
    @DisplayName("download document")
    @WithMockUser(authorities = {GlobalConstants.SCOPE_GED})
    void download_file_success() throws Exception {
        String id = "alfresco";
        ByteArrayResource output = new ByteArrayResource("content".getBytes());
        when(service.downloadFile(id)).thenReturn(ResponseEntity.ok(output));
        mockMvc.perform(MockMvcRequestBuilders.get(SERVICE_PATH + "/" + id)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }


    @Test
    @DisplayName("delete document")
    @WithMockUser(authorities = {GlobalConstants.SCOPE_GED})
    void deleteDocument_ok() throws Exception {
        when(service.deleteDocument(anyString())).thenReturn("deleted");

        var fullPath = String.format("%s/%s", SERVICE_PATH, "64a7fb0a-c4d3-4487-8e97-8d453c458adb");
        var requestBuilder = MockMvcRequestBuilders
                .delete(fullPath);
        mockMvc.perform(requestBuilder)
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("tag fleet documents by quotation number")
    @WithMockUser(authorities = {GlobalConstants.SCOPE_GED})
    void tagByQuotationNumber_OK() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.put(SERVICE_PATH.concat("/tag-by-quotation-number"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .param("quotation_number", "quotation_number")
                        .param("simulation_number", "simulation_number")
                        .param("user_name", "user_name")
                )
                .andExpect(status().isOk());
        verify(service).tagAllDocumentsByQuotationNumber("quotation_number", "simulation_number", "user_name");
    }

    @Test
    @DisplayName("tag fleet documents by policy number")
    @WithMockUser(authorities = {GlobalConstants.SCOPE_GED})
    void tagByPolicyNumber_OK() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.put(SERVICE_PATH.concat("/tag-by-policy-number"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .param("quotation_number", "quotation_number")
                        .param("policy_number", "policy_number")
                        .param("user_name", "user_name")
                        .param("amendment_number","123456")
                )
                .andExpect(status().isOk());
        verify(service).tagAllDocumentsByPolicyNumber("policy_number", "quotation_number", "user_name","123456");
    }


}
