package ma.axa.inner.ged.claims.rd.api;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.charset.StandardCharsets;
import java.util.Collections;

import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.rd.api.ClaimRdDocumentAPI;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdResponse;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdSearchParams;
import ma.axa.inner.ged.claim.rd.service.ClaimRdDocumentService;
import ma.axa.inner.ged.claims.rd.util.ClaimRdDataGenerator;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.dto.CommonResponse;
import ma.axa.inner.ged.exception.RequestValidationException;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.exception.ResourceNotFoundException;
import ma.axa.inner.ged.util.FileGenerator;
import ma.axa.inner.ged.util.ResponseUtils;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.constants.PathConstants;

@Slf4j
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(ClaimRdDocumentAPI.class)
@ExtendWith(SpringExtension.class)
class ClaimRdDocumentAPITest {

	private static final String service_path = PathConstants.CLAIM_RD_DOCUMENTS;

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private ClaimRdDocumentService service;
	@Autowired
	private ObjectMapper mapper;
	
	@MockBean
	private DataSourceContextHolder dataSourceContextHolder;

	@BeforeEach
	void initMockServices() {
		try {
			when(service.getDocumentById(any(String.class))).thenReturn(ClaimRdDataGenerator.getOnResponseDoc());
		} catch (Exception e) {
			log.error("Error during init test class, err: {}", e.getMessage());
		}
	}

	@Test
	@DisplayName("claimRd_uploadDocument_ShouldReturn200WithContent")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void uploadDocument_ShouldReturn200WithContent() throws Exception {
		when(service.uploadDocumentWithMetaData(any(), any())).thenReturn(ClaimRdDataGenerator.getOnResponseDoc());
		var meta = ClaimRdDataGenerator.getAddRequest();
		var request = multipart(service_path)
				.file(FileGenerator.getPdfFile())
				.contentType(MediaType.MULTIPART_FORM_DATA_VALUE)
				.params(meta);
		mockMvc.perform(request)
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.id", is(ClaimRdDataGenerator.DOCUMENT_ID)));
	}

	@Test
	@DisplayName("claimRd_uploadDocument_ShouldThrowReferenceAlreadyExist")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void uploadDocument_ShouldThrowReferenceAlreadyExist() throws Exception {
		when(service.uploadDocumentWithMetaData(any(), any()))
				.thenThrow(new ResourceAlreadyExist(GlobalConstants.URI_RECORDE_ALREADY_EXIST,
						GlobalConstants.ERROR_MSG_RD_REFERENCE_ALREADY_EXIST,
						new String[] { ClaimRdDataGenerator.REFERENCE }));

		var meta = ClaimRdDataGenerator.getAddRequest(ClaimRdDataGenerator.REFERENCE);
		var request = multipart(service_path)
				.file(FileGenerator.getPdfFile())
				.contentType(MediaType.MULTIPART_FORM_DATA_VALUE)
				.params(meta);
		mockMvc.perform(request)
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.type", is(GlobalConstants.URI_RECORDE_ALREADY_EXIST)));
	}

	@Test
	@DisplayName("claimRd_uploadDocument_ShouldThrowRequestValidationException")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void uploadDocument_ShouldThrowRequestValidationException() throws Exception {
		when(service.uploadDocumentWithMetaData(any(), any()))
				.thenThrow(new RequestValidationException("Error validation",
						Collections.singletonMap("status", "Must fill sinistre number to update status = IDENTIFIE")));

		var meta = ClaimRdDataGenerator.getAddRequestForFaildValidation();
		var request = multipart(service_path)
				.file(FileGenerator.getPdfFile())
				.contentType(MediaType.MULTIPART_FORM_DATA_VALUE)
				.params(meta);
		mockMvc.perform(request)
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.type", is(GlobalConstants.URI_BUSINESS_REQUEST_VALIDATION)))
				.andExpect(jsonPath("$.errors", notNullValue()));
	}

	@Test
	@DisplayName("claimRd_getDocumentById_ShouldReturn200WithContent")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void getDocumentById_ShouldReturn200WithContent() throws Exception {
		var fullPath = String.format("%s/%s", service_path, ClaimRdDataGenerator.DOCUMENT_ID);
		var requestBuilder = MockMvcRequestBuilders
				.get(fullPath)
				.accept(MediaType.APPLICATION_JSON)
				.characterEncoding("UTF-8");
		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.id", is(ClaimRdDataGenerator.DOCUMENT_ID)));
	}

	@Test
	@DisplayName("claimRd_downloadPdfById_shouldReturn200WithContent")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void downloadPdfById_shouldReturn200WithContent() throws Exception {
		var resource = new ByteArrayResource("content".getBytes(StandardCharsets.UTF_8));
		var headers = ResponseUtils.getDownloadHeaders("filename.pdf", resource.contentLength(), "application/pdf");
		when(service.downloadFile(any(String.class)))
				.thenReturn(ResponseEntity.ok().headers(headers).body(resource));
		var fullPath = String.format("%s/%s/content", service_path, ClaimRdDataGenerator.DOCUMENT_ID);
		var requestBuilder = MockMvcRequestBuilders.get(fullPath);
		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_PDF))
				.andExpect(content().bytes("content".getBytes(StandardCharsets.UTF_8)));
	}

	@Test
	@DisplayName("claimRd_downloadDocumentById_shouldReturn404DocumentIdNotFound")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void downloadDocumentById_shouldThrow404DocumentIdNotFound() throws Exception {
		when(service.downloadFile(any(String.class)))
				.thenThrow(new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
						GlobalConstants.ERROR_MSG_RD_IDDOCUMENT_NOT_FOUND,
						new String[] { ClaimRdDataGenerator.DOCUMENT_ID }));

		var fullPath = String.format("%s/%s/content", service_path, ClaimRdDataGenerator.DOCUMENT_ID);
		var requestBuilder = MockMvcRequestBuilders.get(fullPath);
		mockMvc.perform(requestBuilder)
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("$.type", is(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND)));
	}

	@Test
	@DisplayName("claimRd_deleteDocumentById_ShouldSucceed")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void deleteDocumentById_ShouldSucceed() throws Exception {
		when(service.deleteDocument(anyString())).thenReturn(CommonResponse.builder().success(true).build());

		var fullPath = String.format("%s/%s", service_path, ClaimRdDataGenerator.DOCUMENT_ID);
		var requestBuilder = MockMvcRequestBuilders
				.delete(fullPath);
		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.success", is(Boolean.TRUE)));
	}

	@Test
	@DisplayName("claimRd_searchDocuments_ShouldThrowBadRequest400")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void searchDocuments_ShouldThrowBadRequest400() throws Exception {
		var requestBuilder = MockMvcRequestBuilders
				.get(service_path)
				.queryParams(ClaimRdDataGenerator.getSearchParams(-1, 10));
		mockMvc.perform(requestBuilder)
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errors", notNullValue()))
				.andExpect(jsonPath("$.errors").isArray())
				.andExpect(jsonPath("$.type", is(GlobalConstants.URI_VALIDATION_CONSTRAINT_VIOLATION)));
	}

	@Test
	@DisplayName("claimRd_searchDocuments_shouldReturn200WhenDocumentsAreFound")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void searchDocuments_shouldReturn200WhenDocumentsAreFound() throws Exception {
		var searchParams = new DocClaimRdSearchParams();
		var expectedResult = new PageImpl<>(Collections.singletonList(new DocClaimRdResponse()));
		when(service.search(searchParams)).thenReturn(expectedResult);
		var requestBuilder = MockMvcRequestBuilders
				.get(service_path)
				.queryParams(ClaimRdDataGenerator.getSearchParams(1, 10));
		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.content", hasSize(1)))
				.andExpect(jsonPath("$.totalPages", is(1)));
		verify(service).search(searchParams);
	}

	@Test
	@DisplayName("claimRd_searchDocuments_shouldReturn200WhenDocumentsAreFound")
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void update_shouldReturn200() throws Exception {
		var documentReq = ClaimRdDataGenerator.getUpdateRequestDto();
		var expectedResponse = ClaimRdDataGenerator.getOnResponseAfterUpdateDoc();
		when(service.updateDocument(ClaimRdDataGenerator.DOCUMENT_ID, documentReq)).thenReturn(expectedResponse);
		var fullPath = String.format("%s/%s", service_path, ClaimRdDataGenerator.DOCUMENT_ID);
		var requestBuilder = MockMvcRequestBuilders
				.put(fullPath)
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(documentReq));
		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.lastUpdatedBy", is(ClaimRdDataGenerator.LASTUPDATED_BY)))
				.andExpect(jsonPath("$.lastUpdatedAt", notNullValue()));
	}

}
