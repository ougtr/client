package ma.axa.inner.ged.api;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import ma.axa.inner.ged.api.ac.TypesDocumentsReferentialApi;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.service.ac.TypeDocumentsReferentialService;
import ma.axa.inner.ged.util.DataGenerator;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.request.RequestFacade;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(TypesDocumentsReferentialApi.class)
class TypeDocumentsReferentialApiTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    TypeDocumentsReferentialService typeDocumentsReferentialService;

    @MockBean
	private DataSourceContextHolder dataSourceContextHolder;
    
    @Autowired
    WebApplicationContext webApplicationContext;

    @WithMockUser(authorities = {GlobalConstants.SCOPE_GED})
    @Test
    void get_type_documents_with_success() throws Exception {
        when(typeDocumentsReferentialService.getListTypeDocs()).thenReturn(DataGenerator.typeDocResponseList());

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/claims/ac/params/type-documents/")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
    @WithMockUser(authorities = {GlobalConstants.SCOPE_GED})
    @Test
    void get_type_documents_by_entity_id_with_success() throws Exception {
        final int id = 1;
        when(typeDocumentsReferentialService.getListTypeDocsByEntityId(id)).thenReturn(DataGenerator.typeDocResponseList());

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/claims/ac/params/type-documents")
                        .param("entity_id",String.valueOf(id))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}
