package ma.axa.inner.ged.helper;

import ma.axa.inner.ged.dto.at.PageDto;
import org.apache.chemistry.opencmis.client.api.ItemIterable;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

class PaginationATHelperTest {

    @Test
    void testGetObjectOfStartAndSizeToGetFrom() {
        // Test Case 1: Default count and Temporary count are both greater than desiredSize
        Pair<Pair<Integer, Integer>, Pair<Integer, Integer>> result1 = PaginationATHelper.getObjectOfStartAndSizeToGetFrom(20, 30, 10, 0);
        assertEquals(Pair.of(Pair.of(0, 0), Pair.of(5, 5)), result1);

        // Test Case 2: Default count is less than desiredSize
        Pair<Pair<Integer, Integer>, Pair<Integer, Integer>> result2 = PaginationATHelper.getObjectOfStartAndSizeToGetFrom(5, 30, 10, 0);
        assertEquals(Pair.of(Pair.of(0, 0), Pair.of(5, 5)), result2);

        // Test Case 3: Temporary count is less than desiredSize
        Pair<Pair<Integer, Integer>, Pair<Integer, Integer>> result3 = PaginationATHelper.getObjectOfStartAndSizeToGetFrom(20, 5, 10, 0);
        assertEquals(Pair.of(Pair.of(0, 0), Pair.of(5, 5)), result3);

        // Test Case 4: Both counts are less than desiredSize
        Pair<Pair<Integer, Integer>, Pair<Integer, Integer>> result4 = PaginationATHelper.getObjectOfStartAndSizeToGetFrom(5, 5, 10, 0);
        assertEquals(Pair.of(Pair.of(0, 0), Pair.of(5, 5)), result4);

        // Test Case 5: Page 0, no change expected
        Pair<Pair<Integer, Integer>, Pair<Integer, Integer>> result5 = PaginationATHelper.getObjectOfStartAndSizeToGetFrom(20, 30, 0, 0);
        assertEquals(Pair.of(Pair.of(0, 0), Pair.of(0, 0)), result5);
    }

    @Test
    void testGetSizeToGetFromEachOnFirstPage() {
        // Test Case 1: Both counts are greater than desiredSize/2
        Pair<Integer, Integer> result1 = ReflectionTestUtils.invokeMethod(PaginationATHelper.class,"getSizeToGetFromEachOnFirstPage",6, 8, 5);
        assertEquals(Pair.of(3, 2), result1);

        // Test Case 2: Default count is less than desiredSize/2
        Pair<Integer, Integer> result2 = ReflectionTestUtils.invokeMethod(PaginationATHelper.class,"getSizeToGetFromEachOnFirstPage",2, 8, 5);
        assertEquals(Pair.of(2, 3), result2);

        // Test Case 3: Temporary count is less than desiredSize/2
        Pair<Integer, Integer> result3 = ReflectionTestUtils.invokeMethod(PaginationATHelper.class,"getSizeToGetFromEachOnFirstPage",6, 2, 5);
        assertEquals(Pair.of(3, 2), result3);

        // Test Case 4: Both counts are less than desiredSize/2
        Pair<Integer, Integer> result4 = ReflectionTestUtils.invokeMethod(PaginationATHelper.class,"getSizeToGetFromEachOnFirstPage",2, 3, 5);
        assertEquals(Pair.of(2, 3), result4);
    }

    @Test
    void testGetPageWithMapping() {
        // Test invalid page size and page number
        assertThrows(IllegalArgumentException.class, () -> PaginationATHelper.getPageWithMapping(null, -1, -1, 10, null));

        // Test null source list
        assertNull(PaginationATHelper.getPageWithMapping(null, 0, 10, 10, null));

        // Test empty source list
        assertEquals(
                PageDto.builder().pageNumber(0).totalElements(0).content(new ArrayList<>()).totalPages(0).build(),
                PaginationATHelper.getPageWithMapping(new ArrayList<>(), 0, 10, 0, null)
        );

        // Test source list size less than fromIndex
        assertNull(PaginationATHelper.getPageWithMapping(Arrays.asList(1, 2, 3), 2, 10, 10, null));

        // Test valid inputs with mapper
        assertEquals(
                PageDto.builder().pageNumber(0).totalPages(2).content(Arrays.asList("1", "2")).totalElements(4).build(),
                PaginationATHelper.getPageWithMapping(Arrays.asList(1, 2, 3, 4), 0, 2, 4, Object::toString)
        );
    }

    @Test
    void testGetPageWithMappingForItemIterable() {
        // Test invalid page size and page number
        assertThrows(IllegalArgumentException.class, () -> PaginationATHelper.getPageWithMappingForItemIterable(null, -1, -1, 10, null));

        // Test null source list or mapper
        assertNull(PaginationATHelper.getPageWithMappingForItemIterable(null, 0, 10, 10, null));
        assertNull(PaginationATHelper.getPageWithMappingForItemIterable(Mockito.mock(ItemIterable.class), 0, 10, 10, null));

        // Test source list total number of items is 0
        assertEquals(
                PageDto.builder().pageNumber(0).totalElements(0).content(new ArrayList<>()).totalPages(0).build(),
                PaginationATHelper.getPageWithMappingForItemIterable(Mockito.mock(ItemIterable.class), 0, 10, 0, Object::toString)
        );

        // Test source list total number of items less than fromIndex
        var itemIterable = Mockito.mock(ItemIterable.class);
        when(itemIterable.getTotalNumItems()).thenReturn(10l);
        assertNull(PaginationATHelper.getPageWithMappingForItemIterable(itemIterable, 2, 10, 10, Object::toString));

        // Test valid inputs with mapper
        // Assuming there is a mock ItemIterable implementation that returns valid data
        itemIterable=Mockito.mock(ItemIterable.class);
        when(itemIterable.getTotalNumItems()).thenReturn(4l);
        when(itemIterable.skipTo(anyLong())).thenReturn(itemIterable);
        when(itemIterable.getPage(anyInt())).thenReturn(itemIterable);

        when(itemIterable.iterator()).thenReturn(Arrays.asList("1", "2").iterator());
        assertEquals(
                PageDto.builder().pageNumber(0).totalPages(2).content(Arrays.asList("1", "2")).totalElements(4).build(),
                PaginationATHelper.getPageWithMappingForItemIterable(itemIterable, 0, 2, 4, Object::toString)
        );
    }
}
