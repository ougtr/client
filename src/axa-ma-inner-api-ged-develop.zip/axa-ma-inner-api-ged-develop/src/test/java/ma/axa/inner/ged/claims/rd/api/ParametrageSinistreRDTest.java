package ma.axa.inner.ged.claims.rd.api;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ma.axa.inner.ged.util.request.RequestFacade;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import ma.axa.inner.ged.api.parametrage.ParametrageClaimsRdAPI;
import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.service.parametrage.ParametrageService;
import ma.axa.inner.ged.util.ClaimParamGenerator;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.constants.PathConstants;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(ParametrageClaimsRdAPI.class)
class ClaimRdParametrageTest {

	private static final String service_path = PathConstants.CLAIM_RD_PARAMS;
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	ParametrageService parametrageService;

	@Autowired
	WebApplicationContext webApplicationContext;
	
	@MockBean
	private DataSourceContextHolder dataSourceContextHolder;
	
	@BeforeEach
	void initMockRepositories() {
		when(parametrageService.getAllBranches()).thenReturn(ClaimParamGenerator.getListBranche());
		when(parametrageService.getEntityByBranche(anyInt())).thenReturn(ClaimParamGenerator.getListEntities());		
		when(parametrageService.getTypeDocumentByEntity(anyInt())).thenReturn(ClaimParamGenerator.getListTypeDocument());
		when(parametrageService.getListRepertoireByIdTypeDocument(anyInt(), anyInt())).thenReturn(ClaimParamGenerator.getListRepertoires());
	}

	@ParameterizedTest
	@ValueSource(strings = {"/branches", "/entities", "/type-documents/1/1/directories", "/entities/1/type-documents", "/type-documents/directories"})
	@WithMockUser(authorities = { GlobalConstants.SCOPE_GED })
	void get_all(String path) throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(service_path + path).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

}
