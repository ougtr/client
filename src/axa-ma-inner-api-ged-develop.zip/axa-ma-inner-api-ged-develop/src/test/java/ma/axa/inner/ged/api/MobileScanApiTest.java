package ma.axa.inner.ged.api;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;

import ma.axa.inner.ged.util.request.RequestFacade;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.multipart.MultipartFile;

import ma.axa.inner.ged.config.datasource.DataSourceContextHolder;
import ma.axa.inner.ged.mobile.scan.dto.OcrDoc;
import ma.axa.inner.ged.mobile.scan.dto.OcrDocDto;
import ma.axa.inner.ged.mobile.scan.dto.ScanResponse;
import ma.axa.inner.ged.mobile.scan.service.MobileScanDocService;
import ma.axa.inner.ged.mobile.scan.service.QrCodeService;

@WebAppConfiguration
@MockBean({Tracer.class})
@Import({RequestFacade.class})
@WebMvcTest(MobileScanApi.class)
@AutoConfigureMockMvc(addFilters = false)
class MobileScanApiTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	QrCodeService qrCodeService;
	@MockBean
	MobileScanDocService mobileScanDocService;
	
	@MockBean
	private DataSourceContextHolder dataSourceContextHolder;

	@Test
	@WithMockUser
	void uploadTemporaryFileTest() throws IOException, Exception {

		MockMultipartFile multiPartFile = new MockMultipartFile("file", "test.pdf", "application/pdf",
				"content".getBytes());
		when(mobileScanDocService.uploadFileTemp(any(MultipartFile.class),any(MultipartFile.class), any(OcrDocDto.class), any(String.class)))
				.thenReturn(new OcrDoc());
		mockMvc.perform(multipart("/v1/dossier-client/scan/dossiers/{token}", "token")
				.file("file1", multiPartFile.getBytes()).file("file2", multiPartFile.getBytes()).param("token", "token").param("typeDocument", "56"))
				.andExpect(status().isCreated());
	}

	@Test
	void indexFileScanTest() throws Exception {
		mobileScanDocService.indexDocument(any(String.class));
		mockMvc.perform(MockMvcRequestBuilders.post("/v1/dossier-client/scan/dossiers/{token}/documents", "token")
				.param("token", "token").accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());

	}

	@Test
	void generateQrCodeTest() throws Exception {
		when(qrCodeService.generateQRCode(any(String.class), any(Integer.class), any(Integer.class)))
				.thenReturn(new ScanResponse());
		mockMvc.perform(MockMvcRequestBuilders.get("/v1/dossier-client/scan/dossiers").param("typeDocument", "typeDocument")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
	@Test
	void getTypeDocumentTest() throws Exception {
		when(qrCodeService.getTypeDocumentByToken(any(String.class))).thenReturn(new ScanResponse());
		mockMvc.perform(MockMvcRequestBuilders.get("/v1/dossier-client/scan/dossiers/type-document").param("token", "token")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
	
	@Test
	void getOcrDocumentByTokenTest() throws Exception {
		when(qrCodeService.getocrDocumentByToken(any(String.class))).thenReturn(new OcrDocDto());
		mockMvc.perform(MockMvcRequestBuilders.get("/v1/dossier-client/scan/dossiers/ocr-document").param("token", "token")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
}
