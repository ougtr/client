package ma.axa.inner.ged.claims.ls.mapper;

import ma.axa.inner.ged.claim.ls.domain.DocumentClaimLsEs;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsReq;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsResp;
import ma.axa.inner.ged.claim.ls.mapper.ClaimLsMapperImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ClaimLsMapperImplTest {

	@Mock
	private DocumentClaimLsEs document;
	
	@Mock
	private DocClaimLsReq documentReq;

	ClaimLsMapperImpl mapper = new ClaimLsMapperImpl();

	@Test
	void testToDtoWithNonNullDocument() {


		when(document.getReference()).thenReturn("ref-20230202-01");
		when(document.getId()).thenReturn("64a7fb0a-c4d3-4487-8e97-8d453c458adb");
		// add other property mocks as needed

		// call the method being tested
		DocClaimLsResp result = mapper.toDto(document);

		// verify that the result is not null
		assertNotNull(result);

		// verify that the properties were set correctly
		assertEquals("ref-20230202-01", result.getReference());
		assertEquals("64a7fb0a-c4d3-4487-8e97-8d453c458adb", result.getId());
		// add other property assertions as needed
	}

	@Test
	void testToDtoWithNullDocument() {
		// call the method being tested with a null parameter
		document = null;
		DocClaimLsResp result = mapper.toDto(document);

		// verify that the result is null
		assertNull(result);
	}

	@Test
	void testToDtoWithNullDocument_list() {
		// call the method being tested with a null parameter
		List<DocumentClaimLsEs> doc = null;
		List<DocClaimLsResp> result = mapper.toDto(doc);

		// verify that the result is null
		assertNull(result);
	}
	
	@Test
	void testToDtoWithNonNullDocument_list() {

		List<DocumentClaimLsEs> doc = new ArrayList<DocumentClaimLsEs>();
		doc.add(document);
		when(document.getReference()).thenReturn("ref-20230202-01");
		when(document.getId()).thenReturn("64a7fb0a-c4d3-4487-8e97-8d453c458adb");
		// add other property mocks as needed

		// call the method being tested
		List<DocClaimLsResp> result = mapper.toDto(doc);

		// verify that the result is not null
		assertNotNull(result);

		
	}


	@Test
	void testFromDtoWithNullDocument_list() {
		// call the method being tested with a null parameter
		List<DocClaimLsReq> doc = null;
		List<DocumentClaimLsEs> result = mapper.fromDto(doc);

		// verify that the result is null
		assertNull(result);
	}

}
