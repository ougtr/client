package ma.axa.inner.ged.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class GzipUtils {

	public static final int BUFFER_SIZE = 1024;

	public static byte[] compress(byte[] bytes) {
		try {
			var outputStream = new ByteArrayOutputStream();
			try (var gzipOutputStream = new GZIPOutputStream(outputStream)) {
				gzipOutputStream.write(bytes);
			}
			return outputStream.toByteArray();
		} catch (IOException e) {
			log.error(e.getMessage(), e);
			return bytes;
		}
	}

	public static byte[] decompress(byte[] inBytes) {
		try {
			var gzipInputStream = new GZIPInputStream(new ByteArrayInputStream(inBytes));
			var outputStream = new ByteArrayOutputStream();
			var buffer = new byte[BUFFER_SIZE];
			int length;
			while ((length = gzipInputStream.read(buffer)) != -1) {
				outputStream.write(buffer, 0, length);
			}
			gzipInputStream.close();
			return outputStream.toByteArray();
		} catch (IOException e) {
			log.error(e.getMessage(), e);
			return inBytes;
		}
	}
}
