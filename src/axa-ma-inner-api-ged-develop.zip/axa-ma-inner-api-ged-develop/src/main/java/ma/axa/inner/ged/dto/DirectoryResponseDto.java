package ma.axa.inner.ged.dto;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DirectoryResponseDto {

    private Integer id;
    private String gedDirectory;
    private String directoryColor;
    private Boolean hasVictim;
    private Boolean withIdProcedure;
}
