package ma.axa.inner.ged.api.parametrage;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.parametrage.EntityResponseDto;
import ma.axa.inner.ged.dto.parametrage.RepertoireResponseDto;
import ma.axa.inner.ged.dto.parametrage.TypeDocumentResponseDto;
import ma.axa.inner.ged.service.parametrage.ParametrageService;
import ma.axa.inner.ged.util.constants.ClaimsConstants;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.constants.PathConstants;

@Slf4j
@RestController
@RequestMapping(PathConstants.CLAIM_TRANSPORT_PARAMS)
@Tag(name = GlobalConstants.TAG_CLAIM_TRANSPORT_APIS, description = GlobalConstants.TAG_DESC_CLAIM_TRANSPORT_APIS)
@RequiredArgsConstructor
public class ParametrageSinistreGEDTransport {

	public final ParametrageService parametrageService;

	@Operation(summary = "Get Transport entity by code branche ")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Entity list fetched", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = EntityResponseDto.class)) }),
			@ApiResponse(responseCode = "500", description = "internal error", content = @Content) })
	@GetMapping(path = "/entities", produces = { "application/json" })
	public List<EntityResponseDto> getListEntitiesTransport() {
		log.info("Start Api ENTITY");
		var listEntity = parametrageService.getEntityByBranche(ClaimsConstants.BRANCH_TRANSPORT_CODE);
		log.info("End Api ENTITY");
		return listEntity;
	}

	@Operation(summary = "Get Transport Type Document by code entity")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Transport Type Document list fetched", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = TypeDocumentResponseDto.class)) }),
			@ApiResponse(responseCode = "500", description = "internal error", content = @Content) })
	@GetMapping(path = "/entities/{entity_code}/type-documents", produces = { "application/json" })
	public List<TypeDocumentResponseDto> getListTypeDocumentByIdEntityTransport(
			@PathVariable(value = "entity_code") int idEntity) {
		log.info("Start Api Type Document");
		var listTypeDocument = parametrageService.getTypeDocumentByEntity(idEntity);
		log.info("End Api Type Document");
		return listTypeDocument;
	}

	@Operation(summary = "Get Transport Repertoire by type document")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Repertoire list fetched", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = RepertoireResponseDto.class)) }),
			@ApiResponse(responseCode = "500", description = "internal error", content = @Content) })
	@GetMapping(path = "/type-documents/{entity_code}/{type_document_code}/directories", produces = { "application/json" })
	public List<RepertoireResponseDto> getListRepertoireByIdTypeDocumentTransport(
			@PathVariable(value = "entity_code") int idEntity, @PathVariable(value = "type_document_code") int idTypeDocument) {
		log.info("Start Api Repertoire");
		var listRepertoire = parametrageService.getListRepertoireByIdTypeDocument(idEntity, idTypeDocument);
		log.info("End Api Repertoire");
		return listRepertoire;
	}
	
	
}
