package ma.axa.inner.ged.repository.cima.auto;

import static ma.axa.inner.ged.util.ElasticSearchUtils.addTermQuery;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.cima.auto.CimaAutoDocumentEs;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoSearchParams;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.repository.ElasticSearchNewRepository;
import ma.axa.inner.ged.util.constants.ElasticConstants;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Repository
@RequiredArgsConstructor
@Slf4j
public class CimaAutoElasticRepository {
	private final BrancheProperties cimaAutoProperties;
	private final ElasticSearchNewRepository elasticRepository;

	public String createNewDocument(final String documentId, final CimaAutoDocumentEs metaData,
			final String countryCode) throws ElasticsearchException, IOException {
		validateDocumentId(documentId);
		validateMetaData(metaData);
		try {
			if (exists(documentId)) {
				throw new ResourceAlreadyExist(GlobalConstants.URI_RECORDE_ALREADY_EXIST,
						"Document with id {0} already exist", new String[] { documentId });
			}
			String esIndex = String.join("-", countryCode.toLowerCase(), cimaAutoProperties.getEsDocIndex());
			var created = elasticRepository.createNewDocument(esIndex, documentId, metaData);
			if (created == null) {
				log.error("[es-repo] Error creating new document for id: {}", documentId);
				throw new GlobalException("Error creating new document for id :  {}", documentId);
			}
			log.info("[es-repo] Successfully created new cima document with id: {}", documentId);
			return created;
		} catch (Exception e) {
			log.error("[es-repo] Error creating new document for id: {}, err: {} ", documentId, e.getMessage());
			throw e;
		}
	}

	public boolean deleteDocument(String documentId) {
		if (StringUtils.isBlank(documentId))
			throw new IllegalArgumentException("documentId must not be blank");
		try {
			var response = elasticRepository.deleteDocument(cimaAutoProperties.getEsDocIndex(), documentId);
			if (response) {
				log.debug("[es-repo]Successfully deleted document claim ls with id: {}", documentId);
				return true;
			}
		} catch (Exception e) {
			log.warn("[es-repo] Error deleting document by id: {}, err: {}", documentId, e.getMessage());
		}
		return false;
	}

	public List<CimaAutoDocumentEs> findByCriteria(CimaAutoSearchParams searchParams, boolean findAll) {
		refreshIndex();
		try {
			var boolQuery = new BoolQuery.Builder();
			var query = getQueryForMultiSearch(searchParams);
			boolQuery.must(query);
			int from = searchParams.getPageNumber() * searchParams.getPageSize();
			var searchRequest = new SearchRequest.Builder();
			String esIndex = String.join("-", searchParams.getCountryCode().name().toLowerCase(),
					cimaAutoProperties.getEsDocIndex());
			searchRequest.index(esIndex).query(q -> q.bool(boolQuery.build()));
			if (!findAll) {
				searchRequest.from(from).size(searchParams.getPageSize());
			}

			SearchResponse<CimaAutoDocumentEs> searchResponse = elasticRepository.search(searchRequest,
					CimaAutoDocumentEs.class);
			return searchResponse.hits().hits().stream().map(Hit::source).collect(Collectors.toList());
		} catch (Exception e) {
			log.error("Error during elastic search", e);
			return Collections.emptyList();
		}
	}

	private Query getQueryForMultiSearch(CimaAutoSearchParams searchParams) {
		var boolQuery = new BoolQuery.Builder();
		addTermQuery(ElasticConstants.CREATED_BY, searchParams.getCreatedBy(), boolQuery);
		addTermQuery(ElasticConstants.CIMA_AUTO_TYPE_DOCUMENT, searchParams.getTypeDocument(), boolQuery);
		addTermQuery(ElasticConstants.CIMA_AUTO_NUM_DECLARATION, searchParams.getNumDeclaration(), boolQuery);
		addTermQuery(ElasticConstants.CIMA_AUTO_UG, searchParams.getUg(), boolQuery);
		addTermQuery(ElasticConstants.CIMA_AUTO_CODE_INTERMEDIAIRE, searchParams.getCodeIntermediaire(), boolQuery);
		return boolQuery.build()._toQuery();
	}

	/**
	 * Refresh Index
	 */
	private void refreshIndex() {
		try {
			elasticRepository.refreshIndex(cimaAutoProperties.getEsDocIndex());
		} catch (Exception e) {
			log.error("[ES] Error during refresh index, err: {}", e.getMessage());
		}
	}

	/*
	 * Helpers
	 */

	private void validateDocumentId(String documentId) {
		if (StringUtils.isBlank(documentId)) {
			throw new IllegalArgumentException("ID Document must not be blank");
		}
	}

	private void validateMetaData(CimaAutoDocumentEs metaData) {
		if (metaData == null) {
			throw new IllegalArgumentException("Document must not be null");
		}
	}

	private boolean exists(String documentId) {
		return elasticRepository.existsDocument(cimaAutoProperties.getEsDocIndex(), documentId);
	}
}
