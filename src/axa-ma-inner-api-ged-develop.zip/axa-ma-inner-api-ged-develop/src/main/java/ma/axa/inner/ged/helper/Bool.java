package ma.axa.inner.ged.helper;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include. NON_NULL)
public class Bool {
	private List<Map<String,Map<String,Object>>> must;
	private List<Map<String,Map<String,Object>>> should;
	@JsonProperty(value = "must_not")
	private List<Map<String,Map<String,Object>>> mustNot;
}
