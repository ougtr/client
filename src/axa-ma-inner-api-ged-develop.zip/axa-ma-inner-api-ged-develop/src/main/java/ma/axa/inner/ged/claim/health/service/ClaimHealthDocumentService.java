package ma.axa.inner.ged.claim.health.service;


import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.health.domain.UploadedDocumentAs400;
import ma.axa.inner.ged.claim.health.dto.*;
import ma.axa.inner.ged.claim.health.mapper.RepoHealthMapper;
import ma.axa.inner.ged.claim.health.repository.HealthDocumentsRepository;
import ma.axa.inner.ged.config.GedHealthProperties;
import ma.axa.inner.ged.dto.CommonResponse;
import ma.axa.inner.ged.exception.DocumentNotFoundException;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.exception.RequestValidationException;
import ma.axa.inner.ged.mapper.DocumentMapper;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.service.ManageDocumentService;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import java.util.List;

@Service
@Slf4j
public class ClaimHealthDocumentService extends ManageDocumentService {


    private final GedHealthProperties gedHealthProperties;
    private final ClaimDocumentRepository claimDocumentRepository;
    private final HealthDocumentsRepository healthDocumentsRepository;
    private final RepoHealthMapper repoHealthMapper;

    public ClaimHealthDocumentService(ClaimDocumentRepository claimDocumentRepository, RepoHealthMapper repoHealthMapper,
                                      GedHealthProperties gedHealthProperties, HealthDocumentsRepository healthDocumentsRepository) {
        super(claimDocumentRepository);
        this.gedHealthProperties = gedHealthProperties;
        this.claimDocumentRepository = claimDocumentRepository;
        this.healthDocumentsRepository = healthDocumentsRepository;
        this.repoHealthMapper = repoHealthMapper;
    }


    public GedHealthFolderProperties indexDossier(MultipartFile file) {
        String filename = file.getOriginalFilename();
        if (filename != null) {
            FileUtil.assertFileNameValid(filename);
        }

        var prefixPath = gedHealthProperties.getOutbox();
        var path = pathFromDateDoc();
        var folder = claimDocumentRepository.createArboFoldersByPath(prefixPath, path);
        log.info("End: creating arborecense in alfresco repository with path '{}'", prefixPath + path);
        if (folder == null) {
            log.error("can not create/open dossier (floder) is null");
            throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
        }
        Map<String, Object> properties = new HashMap<>();
        properties.put(AXADocPropertyIds.IDENTIFIANT_SCANER, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
        properties.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
        return GedHealthFolderProperties.builder().folder(folder).properties(properties).build();

    }

    @SneakyThrows
    public String uploadFilePsi(MultipartFile file, DocProductionHealthReq documentProductionHealth) {
        log.info("Start : uploadFilePsi with data '{}'", documentProductionHealth);
        var listDocument = healthDocumentsRepository.getUploadedDocuments(documentProductionHealth.getCodeProduit(), documentProductionHealth.getCotationId(), documentProductionHealth.getNumOrder());
        Optional<UploadedDocumentAs400> existFile = listDocument.stream()
                .filter(doc -> doc.getColng4().trim().equalsIgnoreCase(documentProductionHealth.getTypeDoc().trim()))
                .findFirst();
        if (existFile.isPresent()) {
            return existFile.get().getIdeged();
        }
        String idAlfresco = null;
        try {

            if (file != null && file.getOriginalFilename() != null && file.getContentType() != null) {
                var folderProperties = indexDossier(file);
                idAlfresco = uploadFile(folderProperties.getProperties(), DocumentMapper.mapFileToGedDocument(file), folderProperties.getFolder()).get("idAlfresco");
                documentProductionHealth.setIdAlfresco(StringUtils.removeStartIgnoreCase(idAlfresco, GlobalConstants.PREFIX_IN_ALFRESCO_ID));
            }
            healthDocumentsRepository.addMetaDataDocumentPsi(repoHealthMapper.toEntityGedpProdHealthAs400(documentProductionHealth));

        } catch (Exception e) {
            log.error("can not upload document or save metadata in as400 error '{}'", e.getMessage());
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
        }
        return idAlfresco;

    }

    @SneakyThrows
    public String uploadFile(MultipartFile file, DocClaimHealthReq documentSinistreHealth) {
        log.info("Start : uploadFile  with data '{}'", documentSinistreHealth);
        if (file != null && file.getOriginalFilename() != null && file.getContentType() != null) {
            var folderProprites = indexDossier(file);
            try {
                var idAlfresco = uploadFile(folderProprites.getProperties(), DocumentMapper.mapFileToGedDocument(file), folderProprites.getFolder()).get("idAlfresco");
                documentSinistreHealth.setIdAlfresco(StringUtils.removeStartIgnoreCase(idAlfresco, GlobalConstants.PREFIX_IN_ALFRESCO_ID));
                healthDocumentsRepository.addMetaDataDocument(repoHealthMapper.toEntityAs400(documentSinistreHealth));
                return idAlfresco;
            } catch (Exception e) {
                log.error("can not upload document or save metadata in as400 error '{}'", e.getMessage());
                throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
            }
        }
        return null;
    }

    public Resource downloadFileFromGed(String idAlfresco) {
        log.info("Start: Downloading file with id '{}'", idAlfresco);
        var document = claimDocumentRepository.getFileDocument(idAlfresco);
        log.debug("File downloaded : '{}'", document);
        log.info("Start: Downloading file with id '{}'", idAlfresco);
        return new ByteArrayResource(document.getFileByte()) {
            @Override
            public String getFilename() {
                return document.getFileName();
            }
        };
    }


    public List<HealthSearchResponseDto> getDocuments(String typeGestion, String nomDoc) {
        log.info("Start service : Search list of documents with type gestion '{}' and nom document '{}'", typeGestion, nomDoc);

        var nomDocIsValid = validationRequest(nomDoc, "{error.health.doc.nom.doc.not-empty}");
        var typeGestionIsValid = validationRequest(typeGestion, "{error.health.type.gestion.not-empty}");

        if ((nomDocIsValid != null && !nomDocIsValid.isSuccess())) {
            throw new RequestValidationException(GlobalConstants.URI_BUSINESS_REQUEST_VALIDATION, nomDocIsValid.getMsgErrors());
        } else if ((typeGestionIsValid != null && !typeGestionIsValid.isSuccess())) {
            throw new RequestValidationException(GlobalConstants.URI_BUSINESS_REQUEST_VALIDATION, typeGestionIsValid.getMsgErrors());
        }
        List<HealthSearchResponseDto> result = null;
        result = repoHealthMapper.toDtoSearch(healthDocumentsRepository.getDocuments(typeGestion, nomDoc));
        log.info("End service : Search list of documents with type gestion '{}' and nom document '{}'", typeGestion, nomDoc);
        return result;
    }


    public String pathFromDateDoc() {
        var date = LocalDate.now();
        return date.getYear() + "/" + date.getMonthValue() + "/" + date.getDayOfMonth();
    }

    public String deleteHealthMetadata(String nomDoc, String typeDoc) {
        log.error("Start : deleting metadata ");

        var nomDocIsValid = validationRequest(nomDoc, "{error.health.doc.nom.doc.not-empty}");
        var typeDocIsValid = validationRequest(typeDoc, "{error.health.type.doc.not-empty}");
        if ((nomDocIsValid != null && !nomDocIsValid.isSuccess())) {
            throw new RequestValidationException(GlobalConstants.URI_BUSINESS_REQUEST_VALIDATION, nomDocIsValid.getMsgErrors());
        } else if ((typeDocIsValid != null && !typeDocIsValid.isSuccess())) {
            throw new RequestValidationException(GlobalConstants.URI_BUSINESS_REQUEST_VALIDATION, typeDocIsValid.getMsgErrors());
        }

        String resp;
        try {
            resp = healthDocumentsRepository.deleteHealthMetadata(nomDoc, typeDoc);
        } catch (Exception e) {
            log.error("can not delete document metadata from as400 we get error '{}'", e.getMessage());
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
        }
        return resp;
    }

    public CommonResponse validationRequest(String param, String msg) {
        var response = CommonResponse.builder();
        var error = new HashMap<String, String>();
        if (StringUtils.isBlank(param)) {
            error.put(param, msg);
        }
        response.msgErrors(error);
        response.success(error.isEmpty());
        return response.build();
    }

    public void updateDocContent(String documentId, MultipartFile file) {
        log.info("Start Service: updating file with id '{}'", documentId);
        var docIdValidate = validationRequest(documentId, "{error.rd.doc.id.not-blank}");
        if ((docIdValidate != null && !docIdValidate.isSuccess())) {
            throw new RequestValidationException(GlobalConstants.URI_BUSINESS_REQUEST_VALIDATION, docIdValidate.getMsgErrors());
        }
        try {
             claimDocumentRepository.updateContent(documentId,file);
        } catch (Exception e) {
            log.error("can not update document contente we get error '{}'", e.getMessage());
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
        }
    }

}
