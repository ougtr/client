package ma.axa.inner.ged.domain.parametrage;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TypeDocumentParametrage {
	
	private BigDecimal code;
	private String libelle;

}
