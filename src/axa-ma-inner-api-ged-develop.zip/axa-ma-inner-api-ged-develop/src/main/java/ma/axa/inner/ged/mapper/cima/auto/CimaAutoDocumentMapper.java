package ma.axa.inner.ged.mapper.cima.auto;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import ma.axa.inner.ged.domain.cima.auto.CimaAutoDocumentEs;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentRequest;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentResponse;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CimaAutoDocumentMapper {

	CimaAutoDocumentEs fromDto(CimaAutoDocumentRequest document);

    @Mapping(source = "createdBy", target = "uploadedBy")
	@Mapping(source = "numPolice", target = "policyNumber")
    CimaAutoDocumentResponse toDto(CimaAutoDocumentEs documentEs);
}
