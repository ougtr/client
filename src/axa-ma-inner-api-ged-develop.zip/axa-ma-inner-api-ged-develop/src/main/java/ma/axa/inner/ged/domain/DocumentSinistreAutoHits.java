package ma.axa.inner.ged.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DocumentSinistreAutoHits {
    private Integer total;
    @JsonProperty("max_score")
    private Double maxScore;
    private List<DocumentSinistreAutoHit> hits;
}
