
package ma.axa.inner.ged.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ESDossierSchema {
    private int took;
    @JsonProperty("timed_out")
    private Boolean timedOut;
    @JsonProperty("_shards")
    private Shards shards;
    private DossierSinistreAutoHits hits;

}