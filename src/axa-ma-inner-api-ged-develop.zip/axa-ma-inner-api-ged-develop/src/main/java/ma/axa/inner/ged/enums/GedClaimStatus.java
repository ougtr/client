package ma.axa.inner.ged.enums;

import lombok.Getter;

@Getter
public enum GedClaimStatus {
	UNKNOWN("Inconnue"),
	EN_INSTANCE("En Instance"),

	IDENTIFIE("Identifie"),

	NON_IDENTIFIE("Non Identifié");
	
	private String label;
	
	private GedClaimStatus(String label) {
		this.label = label;
	}
}
