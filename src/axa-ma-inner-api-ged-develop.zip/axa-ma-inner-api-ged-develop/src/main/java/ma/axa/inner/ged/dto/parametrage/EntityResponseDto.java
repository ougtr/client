package ma.axa.inner.ged.dto.parametrage;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EntityResponseDto {
	
	private int codeEntity;
	private String libelleEntity;

}
