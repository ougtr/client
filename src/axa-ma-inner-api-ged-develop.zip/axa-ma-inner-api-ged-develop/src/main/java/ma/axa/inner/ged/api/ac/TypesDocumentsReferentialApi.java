package ma.axa.inner.ged.api.ac;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.TypeDocResponse;
import ma.axa.inner.ged.service.ac.TypeDocumentsReferentialService;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * This API is being migrated to the Inner Portefeuille.
 *
 * @deprecated This API is marked as deprecated and will be removed in a future release.
 * <p> Please update your integrations to use the new API in the Inner Portefeuille microservice:
 * {@code GET /v1/claims/ac/params/type-documents}, which can be accessed via {TypologyAPI.getTypologiesByParams(DocTypeQuery, Integer, Integer)}.
 *
 * @param queryDto :  the query parameters for filtering document types
 * @param page the page number for pagination
 * @param size the page size for pagination
 * @return a paginated list of document types
 */

@Deprecated(forRemoval = true)
@Tag(name = GlobalConstants.AUTO_GED_APIS_TAG)
@RestController
@RequestMapping("/v1/claims/ac/params/type-documents")
@RequiredArgsConstructor
@Slf4j
public class TypesDocumentsReferentialApi {

    private final TypeDocumentsReferentialService typeDocumentsReferentialService;

    @Operation(summary = "Retrieve the list of document types (typologies)" , deprecated = true)
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "documents type retrieved", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = TypeDocResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "no document type is found", content = @Content),
            @ApiResponse(responseCode = "400", description = "bad request", content = @Content)})
    @GetMapping
    public ResponseEntity<List<TypeDocResponse>> getListTypeDocs() {
        log.info("Start api: get les types de documents");
        ResponseEntity<List<TypeDocResponse>> typesDocs = new ResponseEntity<>(typeDocumentsReferentialService.getListTypeDocs(), HttpStatus.OK);
        log.info("End api: get les types de documents");
        return typesDocs;
    }

    @Operation(summary = "Retrieve list of document types by id" , deprecated = true)
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "documents type retrieved by id", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = TypeDocResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Id invalid", content = @Content),
            @ApiResponse(responseCode = "404", description = "no document type to get", content = @Content) })
    @GetMapping(path = "", produces = { "application/json" })
    public ResponseEntity<List<TypeDocResponse>> getListTypeDocsByEntityId(
            @NotNull(message = "please specify entity id.") @RequestParam(value = "entity_id") int entityId) {
        log.info("Start api: get les types de documents par entityId '{}'", entityId);
        ResponseEntity<List<TypeDocResponse>> typesDocs = new ResponseEntity<>(typeDocumentsReferentialService.getListTypeDocsByEntityId(entityId), HttpStatus.OK);
        log.info("End api: get les types de documents par entityId '{}'", entityId);
        return typesDocs;
    }
}
