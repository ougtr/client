package ma.axa.inner.ged.api.production.fleet;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.production.fleet.DocFleetReq;
import ma.axa.inner.ged.dto.production.fleet.DocFleetResp;
import ma.axa.inner.ged.service.production.fleet.FleetDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/v1/fleet/documents")
@Tag(name = GlobalConstants.TAG_FLOTTE_APIS, description = GlobalConstants.TAG_DESC_FLOTTE_APIS)
@RequiredArgsConstructor
public class FleetDocumentAPI {

    private final FleetDocumentService service;

    /***
     *
     * @param documentId
     * @return
     */
    @Operation(summary = "Download a flotte document by document_id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was downloaded", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = Resource.class, format = "byte"))}),
            @ApiResponse(responseCode = "404", description = "document not found", content = @Content),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
    @GetMapping(value = "/{document_id}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<Resource> downloadFleetDocContent(
            @Parameter(required = true, description = "The document id (Alfresco ID)") @NotBlank(message = "Document id must not be empty") @PathVariable(value = "document_id") String documentId) {
        log.info("[flotte-api] Start download file " + documentId);
        return service.downloadFile(documentId);
    }

    /***
     *
     * @param docFleetReq
     * @param files
     * @return
     */
    @Operation(summary = "Upload new flotte document and index meta-data")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document ID", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = DocFleetReq.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<List<DocFleetResp>> uploadFleetDoc(
            @ParameterObject @ModelAttribute @Valid DocFleetReq docFleetReq,
            @RequestPart(value = "files", required = true) List<MultipartFile> files) {
        log.info("[flotte-api] Start Uploading files:  {}", files.size());
        var createdDocument = service.uploadFleetDocument(docFleetReq, files);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdDocument);
    }

    /***
     *
     * @param documentId
     * @return
     */
    @Operation(summary = "Delete Flotte document by document_id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was deleted", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "404", description = "document not found", content = @Content),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
    @DeleteMapping(value = "/{document_id}")
    public ResponseEntity<String> deleteFleetDoc(
            @NotBlank(message = GlobalConstants.ERROR_MSG_RD_ID_NOT_BLANK) @PathVariable(value = "document_id") String documentId) {
        log.info("[flotte-api] Start delete file {}", documentId);
        return ResponseEntity.ok(service.deleteDocument(documentId));
    }

    /***
     *
     * @param quotationNumber
     * @param simulationNumber
     * @param userName
     * @return
     */
    @Operation(summary = "tag Fleet document by quotationNumber")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was tagged", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "404", description = "document not found", content = @Content),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
    @PutMapping(value = "/tag-by-quotation-number")
    public ResponseEntity tagAllDocumentByQuotationNumber(
            @NotBlank(message = GlobalConstants.ERROR_FLEET_QUOTATION_ID_NOT_EMPTY) @RequestParam(value = "quotation_number") String quotationNumber,
            @NotBlank(message = GlobalConstants.ERROR_FLEET_SIMULATION_NUMBER_NOT_EMPTY) @RequestParam(value = "simulation_number") String simulationNumber,
            @NotBlank(message = GlobalConstants.ERROR_FLEET_USER_NAME_NOT_EMPTY) @RequestParam(value = "user_name") String userName
    ) {
        log.info("[FLEET] Tag documents by QuotationNumber : {}", quotationNumber);
        service.tagAllDocumentsByQuotationNumber(quotationNumber, simulationNumber, userName);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /***
     *
     * @param quotationNumber
     * @param policyNumber
     * @param userName
     * @return
     */
    @Operation(summary = "tag Fleet document by policyNumber")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was tagged", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "404", description = "document not found", content = @Content),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
    @PutMapping(value = "/tag-by-policy-number")
    public ResponseEntity tagAllDocumentByPolicyNumber(
            @NotBlank(message = GlobalConstants.ERROR_FLEET_QUOTATION_ID_NOT_EMPTY) @RequestParam(value = "quotation_number") String quotationNumber,
            @NotBlank(message = GlobalConstants.ERROR_FLEET_POLICY_NUMBER_NOT_EMPTY) @RequestParam(value = "policy_number") String policyNumber,
            @NotBlank(message = GlobalConstants.ERROR_FLEET_USER_NAME_NOT_EMPTY) @RequestParam(value = "user_name") String userName,
            @RequestParam(value = "amendment_number",required = false) String amendmentNumber
    ) {
        log.info("[FLEET] Tag documents by policyNumber : {}", policyNumber);
        service.tagAllDocumentsByPolicyNumber(policyNumber, quotationNumber, userName,amendmentNumber);
        return new ResponseEntity<>(HttpStatus.OK);
    }



}