package ma.axa.inner.ged.dto.transverse.med;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MEDDocumentResponse {
    @JsonProperty(index = 1)
    private String id;
    private String filename;




}
