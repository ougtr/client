package ma.axa.inner.ged.mapper.cima.auto;

import java.util.Collections;
import java.util.Map;

import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentRequest;
import ma.axa.inner.ged.mapper.AlfrescoPropsMapper;

public class CimaAutoAlfrescoMapper extends AlfrescoPropsMapper {
	private CimaAutoAlfrescoMapper() throws InstantiationException {
		throw new InstantiationException("Instances of this type are forbidden");
	}

	public static Map<String, Object> toFolderProperties(CimaAutoDocumentRequest metaData) {
		return toFolderProperties(metaData, null);
	}

	public static Map<String, Object> toFolderProperties(CimaAutoDocumentRequest metaData,
			Map<String, Object> properties) {
		if (metaData == null) {
			return Collections.emptyMap();
		}

		var alfrescoProps = AlfrescoFolderProperties.builder().numeroPoliceDossier(metaData.getNumPolice())
				.intermediareDossier(metaData.getCodeIntermediaire()).codeProduit(metaData.getBranche()).build();
		return toFolderProperties(properties, alfrescoProps);
	}

	public static Map<String, Object> toDocumentProperties(CimaAutoDocumentRequest metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(CimaAutoDocumentRequest metaData,
			Map<String, Object> properties) {
		if (metaData == null) {
			return Collections.emptyMap();
		}
		var alfrescoProps = AlfrescoDocumentProperties.builder().numPolice(metaData.getNumPolice())
				.createdBy(metaData.getCreatedBy()).agentIntermediaire(metaData.getCodeIntermediaire()).build();
		return toDocumentProperties(properties, alfrescoProps);
	}
}
