package ma.axa.inner.ged.claim.common.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public abstract class DocumentClaimEs {
	private String id;
	@JsonProperty("filename")
	private String filename;
	@JsonProperty("path")
	private String path;
	@JsonProperty("reference")
	private String reference;
	@JsonProperty("is_original")
	private boolean original;
	@JsonProperty("is_draft")
	private boolean draft;
	private String status;

	@JsonProperty("branche_code")
	private Integer brancheCode;
	@JsonProperty("branche_label")
	private String brancheLabel;
	@JsonProperty("type_document_code")
	private Integer typeDocumentCode;
	@JsonProperty("type_document_label")
	private String typeDocumentLabel;
	@JsonProperty("entity_code")
	private Integer entityCode;
	@JsonProperty("entity_label")
	private String entityLabel;

	@JsonProperty("application_code")
	private String applicationCode;
	@JsonProperty("date_survenance")
	private LocalDate dateSurvenance;
	@JsonProperty("date_reception")
	private LocalDate dateReception;

	@JsonProperty("date_numerisation")
	private LocalDate dateNumerisation;
	@JsonProperty("sinistre_number")
	private String sinistreNumber;
	@JsonProperty("sinistre_user_creator")
	private String sinistreUserCreator;

	// Police
	@JsonProperty("num_police")
	private String numPolice;
	@JsonProperty("assure_nom")
	private String assureNom;
	@JsonProperty("assure_prenom")
	private String assurePrenom;
	@JsonProperty("produit_code")
	private Integer produitCode;
	@JsonProperty("produit_label")
	private String produitLabel;

	// intermediaire
	@JsonProperty("intermediaire_code")
	private Integer intermediaireCode;
	@JsonProperty("intermediaire_nom")
	private String intermediaireNom;

	@JsonProperty("comment")
	private String comment;

	@JsonProperty("created_by")
	private String createdBy;
	@JsonProperty("created_at")
	private LocalDateTime createdAt;
	@JsonProperty("last_updated_by")
	private String lastUpdatedBy;
	@JsonProperty("last_updated_at")
	private LocalDateTime lastUpdatedAt;
	
	
	@JsonProperty("emetteur")
	private String emetteur;
	@JsonProperty("repertoire")
	private String repertoire;
	@JsonProperty("repertoire_code")
	private String repertoireCode;
	
	@JsonProperty("filesize")
	private String filesize;
	@JsonProperty("filetype")
	private String filetype;
	
	//TODO
	//NEW information
	
	@JsonProperty("valeur_juridiction")
	private String valeur_juridiction;
	
	@JsonProperty("num_tribunal")
	private String num_tribunal;
	
	@JsonProperty("numAdhesion")
	private String numAdhesion;

	@JsonProperty("libBanque")
	private String libBanque;

	@JsonProperty("numDeclaration")
	private String numDeclaration;
	
	@JsonProperty("correspondance_G")
	private String correspondance_G;
}
