package ma.axa.inner.ged.dto.at;

import lombok.*;
import ma.axa.inner.ged.util.jpa_query_filter.QueryFilterCriteria;
import ma.axa.inner.ged.util.jpa_query_filter.annotations.JpaQueryOperation;
import ma.axa.inner.ged.util.jpa_query_filter.enums.JpaQueryOperationEnum;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode
public class MissingDocumentQuery implements QueryFilterCriteria {
    private Integer type;
    @JpaQueryOperation(JpaQueryOperationEnum.IN)
    private List<Integer> group;
}
