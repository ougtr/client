package ma.axa.inner.ged.api.at;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.at.DirectoriesDto;
import ma.axa.inner.ged.service.at.DirectoriesATService;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = GlobalConstants.AT_GED_APIS_TAG)
@RestController
@RequestMapping("/v1/claims/at/params/directories")
@RequiredArgsConstructor
@Slf4j
public class DocumentDirectoryAtApi {

    private final DirectoriesATService directoriesATService;

    @Operation(summary = "Get all directories")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "repositories list fetched", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = DirectoriesDto.class)) }),
    @ApiResponse(responseCode = "500", description = "internal error", content = @Content)})
    @GetMapping(path = "", produces = { "application/json" })
    public List<DirectoriesDto> getListOfRepositories() {
        log.info("Start api : Get all repositories");
        final var repositories = directoriesATService.getAllRepositories();
        log.info("End api : Get all repositories");
        return repositories;
    }
}
