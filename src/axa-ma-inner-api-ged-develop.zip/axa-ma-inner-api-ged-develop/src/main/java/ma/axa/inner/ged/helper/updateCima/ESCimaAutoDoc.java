package ma.axa.inner.ged.helper.updateCima;

import org.springframework.beans.BeanUtils;

import com.fasterxml.jackson.annotation.JsonInclude;

import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentRequest;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ESCimaAutoDoc extends CimaAutoDocumentRequest {
    public ESCimaAutoDoc(CimaAutoDocumentRequest preDeclarationTypeDoc){

        BeanUtils.copyProperties(preDeclarationTypeDoc,this);

    }
}
