package ma.axa.inner.ged.claim.cima.auto.service;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.common.service.DownloadHelper;
import ma.axa.inner.ged.claim.common.service.UploadHelper;
import ma.axa.inner.ged.config.OpenInsurClaimProperties;
import ma.axa.inner.ged.domain.ESResponse;
import ma.axa.inner.ged.dto.CimaRequestDocument;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class AutoDocumentService {

    private final DownloadHelper downloadHelper;

    private final UploadHelper uploadHelper;

    private final OpenInsurClaimProperties openInsurClaimProperties;


    public Resource downloadDocByIdAlfresco(String id) {
        return downloadHelper.downloadFileFromGed(id);
    }

    public String upload(MultipartFile file, String countryCode) {
        log.info("Start upload");
        String idAlfresco = null;
        try {
            if (file != null && file.getOriginalFilename() != null && file.getContentType() != null) {
                idAlfresco = uploadHelper.uploadFile(file, openInsurClaimProperties.getOutbox().concat(countryCode)).get("idAlfresco");
            }
        } catch (Exception e) {
            log.error("can not upload document", e);
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
        }
        return idAlfresco;
    }

    public List<String> uploadFiles(List<MultipartFile> documents, String countryCode) {
        log.info("Start upload files");
        List<String> ids = new ArrayList<>();
        documents.forEach(document -> {
            var id = upload(document, countryCode);
            ids.add(id);
        });
        log.info("End upload files");
        return ids;
    }
    public ESResponse indexDocumentInEs(CimaRequestDocument cimaRequestDocument, String idAlfresco){
        log.info("Start service index cima document in elastic serach with id = {} and metaData = {}", idAlfresco, cimaRequestDocument);
        var esResponse = uploadHelper.createDocumentInEs(cimaRequestDocument, idAlfresco);
        log.info("End service index cima document in elastic serach with id = {} and metaData = {}", idAlfresco, cimaRequestDocument);
        return esResponse;
    }
}
