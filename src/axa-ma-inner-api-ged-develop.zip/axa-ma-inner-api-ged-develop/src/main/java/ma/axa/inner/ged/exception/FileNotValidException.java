package ma.axa.inner.ged.exception;

public class FileNotValidException extends Exception {
	private static final long serialVersionUID = -4010562297124744796L;
	
	public FileNotValidException(String message) {
		super(message);
	}

}
