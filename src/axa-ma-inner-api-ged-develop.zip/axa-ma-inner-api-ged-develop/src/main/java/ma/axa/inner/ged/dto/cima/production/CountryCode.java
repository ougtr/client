package ma.axa.inner.ged.dto.cima.production;

public enum CountryCode {
    SE,
    CI,
    GA,
    CA
}
