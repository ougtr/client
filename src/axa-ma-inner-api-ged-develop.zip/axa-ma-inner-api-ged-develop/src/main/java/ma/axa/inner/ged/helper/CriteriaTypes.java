package ma.axa.inner.ged.helper;

public enum CriteriaTypes {
	TERM("term"),
	FUZZY("fuzzy"),
	MATCH("match"),
	MATCH_PHRASE("match_phrase");
	
	String value;
	
	CriteriaTypes(String value) {
		this.value = value;
	}
	
	public String value() {
		return this.value;
	}
}
