package ma.axa.inner.ged.util;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public interface SigningUtils {

    String HASH_ALGORITHM = "SHA-256";
    String SIGNATURE_ALGORITHM = "HmacSHA256";
    Charset charset = StandardCharsets.UTF_8;

    static String hashAndEncode(String text) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance(HASH_ALGORITHM);
        md.update(text.getBytes(charset));
        byte[] digestBytes = md.digest();
        return Base64.getEncoder().encodeToString(digestBytes);
    }


    static String signAndEncode(String text, String secretKey) throws NoSuchAlgorithmException, InvalidKeyException {
        byte[] bytesToSign = text.getBytes(StandardCharsets.UTF_8);
        Mac mac = Mac.getInstance(SIGNATURE_ALGORITHM);
        mac.init(new SecretKeySpec(charset.encode(secretKey).array(), SIGNATURE_ALGORITHM));
        byte[] signatureBytes = mac.doFinal(bytesToSign);
        return Base64.getEncoder().encodeToString(signatureBytes);
    }

}
