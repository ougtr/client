package ma.axa.inner.ged.dto.production.health.dim;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.inner.ged.util.constants.GlobalConstants;

import javax.validation.constraints.Min;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DocHealthDIMSearchParams {
    private String idQuotation;
    private String policyNumber;
    private String typeDocument;
    @Min(value = 0, message = GlobalConstants.ERROR_MSG_SEARCH_PAGENUMBER_MIN)
    @Builder.Default
    private Integer pageNumber = 0;
    @Min(value = 1, message = GlobalConstants.ERROR_MSG_SEARCH_PAGESIZE_MIN)
    @Builder.Default
    private Integer pageSize = 10;
}