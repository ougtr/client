package ma.axa.inner.ged.util.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class GlobalConstants {

    /**
     * SCOPE
     **/
    public static final String SCOPE_GED = "SCOPE_ged";

    /**
     * OpenApi
     **/
    public static final String TAG_CLAIM_RD_APIS = "RD";
    public static final String TAG_DESC_CLAIM_RD_APIS = "RD Ged APIs";
    public static final String TAG_CLAIM_TRANSPORT_APIS = "Transport";
    public static final String TAG_DESC_CLAIM_TRANSPORT_APIS = "Transport Ged APIs";
    public static final String LS_GED_BRANCHE_LABEL = "LS";
    public static final String TAG_HEALTH_APIS = "HEALTH";
    public static final String TAG_DESC_HEALTH_APIS = "Health Ged APIs";
    public static final String TAG_CLAIM_LS_APIS = "LS";
    public static final String TAG_DESC_CLAIM_LS_APIS = "Ls claim Ged APIs";
    public static final String TAG_SEHASSUR_API = "Sehassur Ged APIs";
    public static final String TAG_HEALTH_AMC_APIS = "AMC";
    public static final String TAG_DESC_HEALTH_AMC_APIS = "Health AMC Ged APIs";
    public static final String HEALTH_AMC_GED_BRANCHE_LABEL = "HEALTH AMC";
    public static final String TAG_HEALTH_DIM_APIS = "DIM";
    public static final String TAG_DESC_HEALTH_DIM_APIS = "Health DIM Ged APIs";
    public static final String HEALTH_DIM_GED_BRANCHE_LABEL = "HEALTH DIM";
    public static final String HEALTH_COMMON_GED_BRANCHE_LABEL = "HEALTH COMMON";
    public static final String FLOTTE_GED_BRANCHE_LABEL = "FLOTTE Ged";
    public static final String RC_PRODUCTION_GED_BRANCHE_LABEL = "PRODUCTION RC";
    public static final String TAG_FLOTTE_APIS = "FLOTTE";
    public static final String TAG_DESC_FLOTTE_APIS = "Flotte Ged APIs";
    public static final String INFO_API_TITLE = "AXA GED API";
    public static final String INFO_API_DESCRIPTION = "Inner Ged Api";
    public static final String AUTO_GED_APIS_TAG = "Auto";
    public static final String AT_GED_APIS_TAG = "AT";
    public static final String RC_GED_APIS_TAG = "RC";
    public static final String LS_GED_APIS_TAG = "LS";
    public static final String MRH_GED_APIS_TAG = "MRH";
    public static final String TAG_MED_APIS = "MED";
    public static final String TAG_DESC_MED_APIS = "MED Ged APIs";

    public static final String TYPE_DOC_APIS_TAG = "Typologie de documents referentiel API";

    /**
     * Parametrage Sinistre GED
     **/
    public static final String INFO_PARAMETRAGE = "GED SINISTRE PARAMETRAGE";

    public static final String REPOSITORIES_APIS_TAG = "Repositories Api";

    /**
     * REQUEST HEADERS
     **/
    public static final String HEADER_BEARER = "Bearer ";
    public static final String HEADER_BASIC = "Basic ";
    public static final String HEADER_GED_CONTENT_ENCODING = "X-Ged-Content-Encoding";
    public static final String HEADER_GED_ACCEPT_ENCODING = "X-Ged-Accept-Encoding";

    /**
     * API ERROR CODES
     **/

    private static final String BASE_URI = "/problem";
    public static final String URI_DEFAULT = BASE_URI + "/error-with-detail";
    public static final String URI_INIT_CONFIGURATION = BASE_URI + "/init-configuration";
    public static final String URI_MISSING_REQUEST_PARAMETER = BASE_URI + "/missing-request-params";
    public static final String URI_METHOD_NOT_ALLOWED = BASE_URI + "/method-not-allowed";
    public static final String URI_INTER_SERVICE_COMMUNICATION = BASE_URI + "/inter-service-communication";
    public static final String URI_VALIDATION_CONSTRAINT_VIOLATION = BASE_URI + "/validation-constraint-violation";
    public static final String URI_BUSINESS_REQUEST_VALIDATION = BASE_URI + "/business-request-validation";
    public static final String URI_HTTP_MESSAGE_NOT_READABLE = BASE_URI + "/http-message-not-readable";
    public static final String URI_METHOD_ARGUMENT_NOT_VALID = BASE_URI + "/method-argument-not-valid";
    public static final String URI_CALL_STORED_PROCEDURE = BASE_URI + "/db/call-stored-procedure";
    public static final String URI_FILE_READ_ERROR = BASE_URI + "/file-read-error";
    public static final String URI_RECORDE_ALREADY_EXIST = BASE_URI + "/record-already-exist";
    public static final String URI_RECORDE_DOC_ID_NOT_FOUND = BASE_URI + "/documents/id-not-found";
    public static final String URI_ALFRESCO_UPLOAD_MAX_RETRY = BASE_URI + "/alfresco/max-retry-exceeded";
    public static final String URI_INTERNAL_ERROR = BASE_URI + "/internal-error";
    public static final String FILE_ES_INDEXING_ERROR = BASE_URI + "/file-es-indexing-error";
    public static final String URI_UNEXPECTED_TECHNICAL_ERROR = BASE_URI + "/unexpected-technical-exception";

    public static final String DIRECTORIES_AT_SORT = "sort";
    /**
     * ERROR MESSAGES
     **/
    public static final String ERROR_MSG_ALFRESCO_MAX_RETRY = "error.alfresco.doc.upload.max-retry";
    public static final String ERROR_MSG_RD_REFERENCE_ALREADY_EXIST = "error.rd.doc.reference.already-exist";
    public static final String ERROR_MSG_RD_IDDOCUMENT_NOT_FOUND = "error.rd.doc.id.not-found";
    public static final String ERROR_MSG_RD_IDDOCUMENT_ALREADY_EXIST = "error.rd.doc.id.already-exist";
    public static final String ERROR_MSG_RD_REFERENCE_NOT_BLANK = "error.rd.doc.reference.not-blank";
    public static final String ERROR_MSG_RD_CREATEDBY_NOT_BLANK = "error.rd.doc.createdBy.not-blank";
    public static final String ERROR_MSG_RD_LASTUPDATEDBY_NOT_BLANK = "error.rd.doc.lastUpdatedBy.not-blank";
    public static final String ERROR_MSG_RD_APPLICATIONCODE_NOT_BLANK = "error.rd.doc.applicationCode.not-blank";
    public static final String ERROR_MSG_RD_ID_NOT_BLANK = "error.rd.doc.id.not-blank";
    public static final String ERROR_MSG_RD_IDS_NOT_EMPTY = "error.rd.doc.ids.not-empty";
    public static final String ERROR_MSG_RD_IDS_SIZE_MAX = "error.rd.doc.ids.size.max";
    public static final String ERROR_MSG_SEARCH_PAGENUMBER_MIN = "error.request.search.page-number.min";
    public static final String ERROR_MSG_SEARCH_PAGESIZE_MIN = "error.request.search.page-size.min";
    public static final String ERROR_MSG_LS_ID_NOT_BLANK = "error.ls.doc.id.not-found";
    public static final String ERROR_HEALTH_QUOTATION_ID_NOT_EMPTY = "error.health.quotation.id.not-empty";
    public static final String ERROR_HEALTH_POLICY_NUMBER_NOT_EMPTY = "error.health.policy.number.not-empty";
    public static final String ERROR_HEALTH_USER_NAME_NOT_EMPTY = "error.health.user.name.not-empty";
    public static final String ERROR_FLEET_QUOTATION_ID_NOT_EMPTY = "error.fleet.quotation.id.not-empty";
    public static final String ERROR_FLEET_POLICY_NUMBER_NOT_EMPTY = "error.fleet.policy.number.not-empty";
    public static final String ERROR_FLEET_SIMULATION_NUMBER_NOT_EMPTY = "error.fleet.simulation.number.not-empty";
    public static final String ERROR_FLEET_USER_NAME_NOT_EMPTY = "error.fleet.user.name.not-empty";
    /**
     * FILE & FOLDER
     **/
    public static final String ALFRESCO_WORKSPACE_PREFIX = "workspace://SpacesStore/";
    public static final String FOLDER_SEPARATOR_SLASH = "/";
    public static final String FOLDER_SEPARATOR = FOLDER_SEPARATOR_SLASH;
    /**
     * APP CONFIG
     **/
    public static final int MAX_RETRY = 100;
    public static final int BULK_MAX_DELETE = 100;
    /**
     * Patterns
     **/
    public static final String DATE_FORMAT_COMMON = "dd-MM-yyyy";
    public static final String DATETIME_FORMAT_COMMON = "dd-MM-yyy HH:mm:ss:SSS";
    public static final String DATE_FORMAT_YYYYMMDD = "yyyy-MM-dd";
    public static final String DATETIME_FORMAT_YYYYMMDD = "dd-MM-yyy HH:mm:ss:SSS";

    public static final String DATE_FORMAT_FOR_FRONT = "yyyyMMdd";
    public static final String DATE_FORMAT_COMMON_FRENCH = "dd/MM/yyyy";
    public static final String DATE_TIME_FORMAT_COMMON_FRENCH = "dd/MM/yyyy HH:mm:ss";
    public static final String LONG_DATE_FORMAT = "EEE MMM dd yyyy HH:mm:ss 'GMT'Z ('GMT'XXX)";
    public static final String DATE_OBJECT_STRING_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
    public static final String DATE_OBJECT_STRING_FORMAT_UTC = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    public static final int PAGE_SIZE_ELASTIC_SEARCH = 20;

    public static final String PREFIX_IN_ALFRESCO_ID = "workspace://SpacesStore/";

    /**
     * API LS
     **/
    public static final String CODE_ACTION = "SO";
    public static final String COUNTRY_CODE = "countryCode";

    public static final Integer MIN_DATE = 19000101;





    public static final String IDALFRESCO = "idalfersco";


}