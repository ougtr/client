package ma.axa.inner.ged.exception;

import ma.axa.inner.ged.util.constants.GlobalConstants;

public class IOFileException extends GlobalException {

	private static final long serialVersionUID = 2222758585380429741L;
	
	public IOFileException(String message) {
		super (GlobalConstants.URI_FILE_READ_ERROR, message);
	}
}
