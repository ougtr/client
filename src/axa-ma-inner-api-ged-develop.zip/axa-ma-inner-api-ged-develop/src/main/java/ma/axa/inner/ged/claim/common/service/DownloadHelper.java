package ma.axa.inner.ged.claim.common.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;


@Component
@Slf4j
@RequiredArgsConstructor
public class DownloadHelper {

    private  final ClaimDocumentRepository claimDocumentRepository;


    public Resource downloadFileFromGed(String idAlfresco) {
        log.info("Start: Downloading file with id '{}'", idAlfresco);
        var document = claimDocumentRepository.getFileDocument(idAlfresco);
        log.debug("File downloaded : '{}'", document);
        log.info("Start: Downloading file with id '{}'", idAlfresco);
        return new ByteArrayResource(document.getFileByte()) {
            @Override
            public String getFilename() {
                return document.getFileName();
            }
        };
    }
}
