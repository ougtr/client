package ma.axa.inner.ged.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Data
public class ESDocMobileScanRequest {
	@JsonProperty("idalfersco")
	String idAlfersco;
	@JsonProperty("nomdocument")
	String nomDocument;
	@JsonProperty("iddoc")
	String identifiantScaner;
	@JsonProperty("dateUpload")
	Date dateUpload;
	@JsonProperty("uploadedby")
	String agentIndexation;
	@JsonProperty("typeDocument")
	String typeDocument;
	@JsonProperty("repertoire")
	private String repertoire;
}
