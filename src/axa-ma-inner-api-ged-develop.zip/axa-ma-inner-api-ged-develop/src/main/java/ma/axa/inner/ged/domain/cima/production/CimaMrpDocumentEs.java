package ma.axa.inner.ged.domain.cima.production;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CimaMrpDocumentEs {
    private String id;
    @JsonProperty("filename")
    private String filename;
    @JsonProperty("path")
    private String path;
    @JsonProperty("document_type_code")
    private String documentTypeCode;
    @JsonProperty("document_type_label")
    private String documentTypeLabel;
    @JsonProperty("policy_number")
    private String policyNumber;
    @JsonProperty("intermediary_code")
    private String agentCode;
    @JsonProperty("created_by")
    private String createdBy;
    @JsonProperty("created_at")
    private LocalDateTime createdAt;
    @JsonProperty("product_code")
    private String productCode;
}
