package ma.axa.inner.ged.mapper.at;

import ma.axa.inner.ged.domain.at.DocumentSinistreATES;
import ma.axa.inner.ged.dto.at.ChangesQueryDto;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import java.util.Date;
import java.util.Objects;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE,imports = {Date.class, StringUtils.class, Objects.class})
public interface DocumentsEsMapper {
    @Mapping(target="idalfersco", source="changes.alfrescoId")
    @Mapping(target="numsinistre", expression="java(StringUtils.isNotBlank(changes.getClaimNumber())  ? changes.getClaimNumber() : original.getNumsinistre())")
    @Mapping(target="nomdocument", source="original.nomdocument")
    @Mapping(target="iddocument", source="original.iddocument")
    @Mapping(target="numpolice", source="original.numpolice")
    @Mapping(target="iddoc", source="original.iddoc")
    @Mapping(target="uploadedby", source="userName")
    @Mapping(target="typeDocument", expression="java(changes.getTypology() != null ? Objects.toString(changes.getTypology()):original.getTypeDocument())")
    @Mapping(target="repertoire", expression="java(changes.getRepository() != null ? Objects.toString(changes.getRepository()):original.getRepertoire())")
    @Mapping(target="dateSurvenance", expression="java(changes.getOccurrenceDate() != null ? Objects.toString(changes.getOccurrenceDate()) : original.getDateSurvenance())")
    @Mapping(target="receptiondate", source="original.receptiondate")
    @Mapping(target="sourceDossier", source="original.sourceDossier")
    @Mapping(target="type", source="original.type")
    @Mapping(target="numDossierBnej", source="original.numDossierBnej")
    @Mapping(target="numDossierTribunal", source="original.numDossierTribunal")
    @Mapping(target="isTemporary", source="original.isTemporary")
    @Mapping(target="size", source="original.size")
    @Mapping(target="tag", source="original.tag")
    @Mapping(target="dateEnvoi", source="original.dateEnvoi")
    @Mapping(target="uploadDateTimeStamp", expression="java((new Date()).getTime())")
    @Mapping(target="isReturnedRO", source="original.isReturnedRO")
    DocumentSinistreATES mergeCopyChangesWithDocumentEs(DocumentSinistreATES original, ChangesQueryDto changes,String userName);
}
