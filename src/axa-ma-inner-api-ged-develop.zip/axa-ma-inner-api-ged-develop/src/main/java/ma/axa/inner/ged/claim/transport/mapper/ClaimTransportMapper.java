package ma.axa.inner.ged.claim.transport.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import ma.axa.inner.ged.claim.transport.domain.DocumentClaimTransportEs;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportAddReq;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportResponse;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportUpdateReq;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ClaimTransportMapper {

	// -> TO DTO

	public DocClaimTransportResponse toDto(DocumentClaimTransportEs document);

	public List<DocClaimTransportResponse> toDto(List<DocumentClaimTransportEs> documents);

	// -> FROM DTO

	public DocumentClaimTransportEs fromDto(DocClaimTransportAddReq documentRes);

	public List<DocumentClaimTransportEs> fromDto(List<DocClaimTransportAddReq> documentRes);

	public DocumentClaimTransportEs fromDto(DocClaimTransportUpdateReq documentReq);

	// -> update
	@BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
	void updateFromDto(DocClaimTransportUpdateReq documentReq, @MappingTarget DocumentClaimTransportEs document);

	// Others
	public static Page<DocumentClaimTransportEs> mapToPage(SearchResponse<DocumentClaimTransportEs> searchResponse,
			int from,
			int size) {
		if (searchResponse == null || searchResponse.hits().hits().isEmpty() || searchResponse.hits().total() == null) {
			return Page.empty();
		} else {
			long totalElements = searchResponse.hits().total().value();
			List<DocumentClaimTransportEs> results = searchResponse.hits().hits().stream()
					.map(Hit::source)
					.collect(Collectors.toList());
			PageRequest pageRequest = PageRequest.of(from, size);
			return new PageImpl<>(results, pageRequest, totalElements);
		}
	}
}
