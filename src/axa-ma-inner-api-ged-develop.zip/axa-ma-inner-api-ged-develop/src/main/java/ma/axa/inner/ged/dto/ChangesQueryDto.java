package ma.axa.inner.ged.dto;

import lombok.*;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode
public class ChangesQueryDto {
    private Long id;
    @NotBlank
    private String alfrescoId;
    private String policeNumber;
    private String predeclarationNumber;
    private String claimNumber;
    private String immatriculation;
    private String tpi;
    private String oldAlfrescoId;
    private Boolean isCopied;
}
