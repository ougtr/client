package ma.axa.inner.ged.exception;

public class DocumentNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 2365302365233461112L;
	
	public DocumentNotFoundException(String message){
		super(message);
	}
}
