package ma.axa.inner.ged.domain.production.fleet;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.domain.production.ProductionDocumentEs;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentFleetEs extends ProductionDocumentEs {
    @JsonProperty("policy_number")
    private String policyNumber;
    @JsonProperty("quotation_id")
    private String quotationId;
    @JsonProperty("simulation_id")
    private String simulationId;
    @JsonProperty("avenant_number")
    private String amendmentNumber;
}