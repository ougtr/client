package ma.axa.inner.ged.mapper.parametrage;

import java.math.BigDecimal;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import ma.axa.inner.ged.domain.parametrage.RepertoireParametrage;
import ma.axa.inner.ged.dto.parametrage.RepertoireResponseDto;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface RepertoireMapper {
	
	
	@Mapping(source = "code", target = "codeRepertoire", qualifiedByName = "convertBigDec")
	@Mapping(source = "libelle", target = "libelleRepertoire")
	public RepertoireResponseDto mapToRepertoireDto(RepertoireParametrage ep);
	public List<RepertoireResponseDto> mapToRepertoireDtoList(List<RepertoireParametrage> eps);
	
	
	@Named("convertBigDec")
	 default int convertBigDec(BigDecimal code){
        return Integer.valueOf(code.toString());
    }

}
