package ma.axa.inner.ged.api.ls;


import java.util.Arrays;
import java.util.List;


import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;


import ma.axa.inner.ged.dto.*;
import ma.axa.inner.ged.exception.BusinessException;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.service.ls.LsDocumentsService;
import ma.axa.inner.ged.service.ls.LsSaveDocument;
import ma.axa.inner.ged.util.constants.GlobalConstants;


@Tag(name = GlobalConstants.LS_GED_APIS_TAG)

@RestController
@RequestMapping("/v1")
@RequiredArgsConstructor
@Slf4j
public class LsDocumentsAPI {

		private final LsDocumentsService lsDocumentService;
		private final LsSaveDocument saveDocument ; 

		@SneakyThrows
		@Operation(summary = "upload a  document")
		@ApiResponses(value = {
				@ApiResponse(responseCode = "201", description = "Document added", content = {
						@Content(mediaType = "application/json", schema = @Schema(implementation = String.class)) }),
				@ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
				@ApiResponse(responseCode = "500", description = "Internal server error while uploading the file", content = @Content)})
		@PostMapping(path = "/ls/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
		public String uploadFile(
				@ParameterObject @Valid @ModelAttribute DocumentRequest documentMetadata, 
				@RequestPart(value = "files") List<MultipartFile> file){
			
			log.info("START LS UPLOAD API - '{}' - '{}'", documentMetadata.getToken(), documentMetadata.getCodeAction());
			
			var idAlfresco = "";
			var i = 0;
			var response = "KO";
			
			List<String> listOfCodeActions = Arrays.asList(documentMetadata.getTypeDoc().split("-"));
			
			for(MultipartFile f : file){
				
				idAlfresco = lsDocumentService.uploadFile(f);
				
				LsDocumentRequest as400Request = LsDocumentRequest.builder()
				.token(documentMetadata.getToken())
				.codeProduct(documentMetadata.getCodeProduct())
				.codeAction(documentMetadata.getCodeAction())
				.typedoc(listOfCodeActions.get(i))
				.urlDocument(idAlfresco.substring(24))
				.libelleDocument(f.getOriginalFilename())
				.build();
				
	          	saveDocument.saveLsMetadataDocument(as400Request);
	          	
		        i++;
		         	
		        response = "OK";
			}
			
			log.info("END LS UPLOAD API - '{}'", response);
			return response ;
		}
		
		@SneakyThrows
		@Operation(summary = "Upload an LS Document")
		@ApiResponses(value = {
				@ApiResponse(responseCode = "201", description = "Document uploaded successfully", content = {
						@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
				@ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
				@ApiResponse(responseCode = "500", description = "Internal server error while uploading the file", content = @Content)})
		@PostMapping(path = "/ls/upload/document", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
		public String uploadFile(
				@ParameterObject @Valid @ModelAttribute DocumentRequest documentMetadata, 
				@RequestPart(value = "file") MultipartFile file){
			
			log.info("START LS UPLOAD API - '{}' - '{}'", documentMetadata.getToken(), documentMetadata.getCodeAction());
			String idAlfresco = lsDocumentService.uploadFile(file);			
			log.info("END LS UPLOAD API - '{}'", idAlfresco);
			return idAlfresco ;
		}

		@Operation(summary = "download a ls document by alfresco id")
		@ApiResponses(value = {
				@ApiResponse(responseCode = "200", description = "document was downloaded", content = {
						@Content(mediaType = "text/plain", schema = @Schema(implementation = Resource.class))}),
				@ApiResponse(responseCode = "404", description = "document not found with id", content = @Content),
				@ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
		@GetMapping(value = "/ls/documents/{id}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
		public ResponseEntity<Resource> downloadFile(@NotNull(message = "{error.alfresco.id}") @PathVariable(value = "id", required = true) String alfrescoIdWithoutPrefix) {
			
			log.info("Start api: Downloading file with id '{}'", alfrescoIdWithoutPrefix);
			var resource =  lsDocumentService.downloadFile(alfrescoIdWithoutPrefix);
			var headers = new HttpHeaders();
			var headerKey = "X-filename";
			var  headerValue = resource.getFilename();
			headers.set(headerKey,headerValue);

			log.info("End api: File downloaded !");
			return ResponseEntity.ok().headers(headers).body(resource);
	}

	/***
	 * Ls prevoyance
	 */

	@Operation(summary = "upload a  document")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Document added", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = String.class)) }),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
			@ApiResponse(responseCode = "500", description = "Internal server error while uploading the file", content = @Content)})
	@PostMapping(path = "/prevoyance/ls/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<LsGedResponse> uploadLsPrevoyanceFile(@ParameterObject @Valid @ModelAttribute DocumentLsPrevoyanceRequest doc,
													  @RequestPart(value = "file") MultipartFile file){

		log.info("Start api: uploading file (document Ls) '{}'", file.getOriginalFilename());
		var id=  lsDocumentService.uploadFile(file);
		if(StringUtils.isBlank(doc.getLibDocument()))
			doc.setLibDocument(FilenameUtils.removeExtension(file.getOriginalFilename()));
		String idAlfresco = StringUtils.removeStartIgnoreCase(id, GlobalConstants.PREFIX_IN_ALFRESCO_ID);
		String  response = saveDocument.saveNewLsPrevoyaneDoc(doc,idAlfresco);
		log.info("response : '{}'" + response);
		LsGedResponse lsGedResponse = LsGedResponse.builder().idAlfresco(idAlfresco).typeDoc(doc.getTypeDocument()).build();
		return new ResponseEntity<>(lsGedResponse, HttpStatus.CREATED);
	}

	@Operation(summary = "search a document by idGestion")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "documents metadata were found", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = SearchLsPrevoyanceResponse.class))}),
			@ApiResponse(responseCode = "400", description = "Request not valid", content = @Content),
			@ApiResponse(responseCode = "404", description = "documents not found with claim number", content = @Content)}
	)
	@GetMapping("/prevoyance/ls/documents/metadatas")
	public ResponseEntity<List<SearchLsPrevoyanceResponse>> searchLsPrevoyanceDocuments(@NotBlank(message = "idGestion est obligatoire") @RequestParam(value = "idGestion",required = true) String idGestion) {
		log.info("Start api: Search list of documents with type gestion '{}' and nom document '{}'", idGestion);
		var listOfLsPrevoyanceDocuments = saveDocument.searchLsPrevoyanceDocuments(idGestion);
		return new ResponseEntity<>(listOfLsPrevoyanceDocuments, HttpStatus.OK);
	}



	@Operation(summary = "delete ls prevoyane using id gestion and row number")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "documents metadata were found", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
			@ApiResponse(responseCode = "400", description = "Request not valid", content = @Content),
			@ApiResponse(responseCode = "404", description = "documents not found with claim number", content = @Content)}
	)
	@DeleteMapping("/prevoyance/ls/documents/{document_id}")
	public ResponseEntity<String> deleteLsPrevoyanceMetadata(
			@NotBlank(message = "{error.id.doc.not-empty}") @PathVariable(value = "document_id",required = true) String documentId
	) {
		log.info("Start api: delete  documents with idGestion '{}' and row number '{}'",documentId);
		String result = saveDocument.deleteLsPrevoyanceMetadata(documentId);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@Operation(summary = "delete ls subscription document using id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "documents metadata were found", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
			@ApiResponse(responseCode = "400", description = "Request not valid", content = @Content),
			@ApiResponse(responseCode = "404", description = "documents not found with claim number", content = @Content)}
	)
	@DeleteMapping("/ls/souscription/{token}/document/{document_id}")
	public ResponseEntity<String> deleteSubscriptionDocument(
			@NotBlank(message = "{error.id.doc.not-empty}")
			@PathVariable(value = "document_id") String documentId,
			@NotBlank(message = "{error.id.doc.token}")
			@PathVariable(value = "token") String token,
			@RequestParam(value = "product_code") String productCode,
			@RequestParam(value = "document_type") String documentType,
			@RequestParam(value = "action_code") String actionCode
	) throws BusinessException {

		String result = saveDocument.deleteLsSubscriptionDocumentMetadata(token, documentId,productCode,documentType,actionCode);
		if ("KO".equals(result)) {
			log.warn("Warning cannot delete metadata of document {} of subscription {}", documentId, token);
			return  new ResponseEntity<>(result, HttpStatus.OK);
		}
		return new ResponseEntity<>(lsDocumentService.deleteDocument(documentId), HttpStatus.OK);
	}

}
