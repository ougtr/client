package ma.axa.inner.ged.dto.parametrage;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BrancheResponseDto {
	
	private int codeBranche;
	private String libelleBranche;

}
