package ma.axa.inner.ged.service.at;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.GedProperties;
import ma.axa.inner.ged.config.properties.GedAtProperties.AtProperties;
import ma.axa.inner.ged.domain.ESDocumentATRequest;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.domain.IndexOrPathToUse;
import ma.axa.inner.ged.domain.TypeDocAs400;
import ma.axa.inner.ged.domain.at.DocumentSinistreATES;
import ma.axa.inner.ged.dto.CommonResponse;
import ma.axa.inner.ged.dto.DocClaimAtReqDto;
import ma.axa.inner.ged.dto.DocumentInfoDto;
import ma.axa.inner.ged.dto.DocumentSinistreAT;
import ma.axa.inner.ged.dto.at.*;
import ma.axa.inner.ged.enums.AutoAtBranchEnum;
import ma.axa.inner.ged.enums.ESOrderEnum;
import ma.axa.inner.ged.exception.BusinessException;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.exception.RequestValidationException;
import ma.axa.inner.ged.helper.ElasticSearchHelper;
import ma.axa.inner.ged.helper.PaginationATHelper;
import ma.axa.inner.ged.mapper.DocumentInfoMapper;
import ma.axa.inner.ged.mapper.DocumentMapper;
import ma.axa.inner.ged.mapper.at.DocumentsAlfrescoMapper;
import ma.axa.inner.ged.mapper.at.DocumentsEsMapper;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.repository.DocumentInfoRepository;
import ma.axa.inner.ged.repository.TypeDocRepository;
import ma.axa.inner.ged.service.ManageDocumentService;
import ma.axa.inner.ged.util.DateUtils;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.ObjectUtils;
import ma.axa.inner.ged.util.StringUtil;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.ItemIterable;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;


@Service
@Slf4j
public class ClaimATDocumentService extends ManageDocumentService {

    private static final String DATE_DELIMITOR = "/";
    private final DocumentInfoRepository documentInfoRepository;
    private final DocumentInfoMapper documentInfoMapper;
    private final GedProperties gedProperties;
    private final AtProperties atProperties;
    private final ElasticSearchHelper elasticSearchHelper;
    private final MessageSource messageSource;
    private final List<String> possibleSearchParamInAlfresco = List.of("claimNumber", "occurenceDate", "temporary", "page", "size", "searchInAlfresco");
    private final DocumentsEsMapper documentsEsMapper;

    private final TypeDocRepository typologiesRepository;

    private final DocumentsAlfrescoMapper documentsAlfrescoMapper;

    public ClaimATDocumentService(ClaimDocumentRepository claimDocumentRepository, AtProperties atProperties, GedProperties gedProperties, ElasticSearchHelper elasticSearchHelper, DocumentsEsMapper documentsEsMapper, TypeDocRepository typologiesRepository, DocumentInfoRepository documentInfoRepository, DocumentInfoMapper documentInfoMapper, DocumentsAlfrescoMapper documentsAlfrescoMapper, MessageSource messageSource) {
        super(claimDocumentRepository);
        this.gedProperties = gedProperties;
        this.atProperties = atProperties;
        this.elasticSearchHelper = elasticSearchHelper;
        this.documentsEsMapper = documentsEsMapper;
        this.typologiesRepository = typologiesRepository;
        this.documentInfoRepository = documentInfoRepository;
        this.documentInfoMapper = documentInfoMapper;
        this.documentsAlfrescoMapper = documentsAlfrescoMapper;
        this.messageSource = messageSource;
    }

    public String uploadFile(DocumentSinistreAT documentSinistreAT, MultipartFile file) {
        if (StringUtils.isBlank(documentSinistreAT.getNumSinistre())
                && StringUtils.isBlank(documentSinistreAT.getNumPolice())) {
            throw new BusinessException("Numéro sinistre ou numéro police obligatoire !");
        }
        FileUtil.assertFileNameValid(file.getOriginalFilename());

        String id = "idAlfresco";
        String idAlfresco = null;
        GedDocument gedDocument = DocumentMapper.mapFileToGedDocument(file, documentSinistreAT.getNomDocument());

        if (StringUtils.isBlank(documentSinistreAT.getNumSinistre())) {
            Map<String, String> metadata = uploadFile(DocumentMapper.documentPropertiesConstructor(documentSinistreAT),
                    gedDocument, claimDocumentRepository.getFolder(gedProperties.getAgentInbox()));
            idAlfresco = metadata.get(id);
        } else {
            Folder folder = createOrUpdateDirectory(documentSinistreAT);

            var esDossierATRequest = DocumentMapper.mapToESDossierATRequest(documentSinistreAT, folder.getId());
            elasticSearchHelper.addIndexDossierAT(esDossierATRequest, documentSinistreAT.getNumSinistre());

            Map<String, String> metadata = uploadFile(DocumentMapper.documentPropertiesConstructor(documentSinistreAT),
                    gedDocument, folder);
            idAlfresco = metadata.get(id);
            if (StringUtils.isNotBlank(idAlfresco)) {
                var esDocumentATRequest = DocumentMapper.mapToESDocumentATRequest(documentSinistreAT,
                        gedDocument.getFileName(), idAlfresco);
                elasticSearchHelper.addIndexDocumentAT(esDocumentATRequest);
            }
        }
        if (StringUtils.isBlank(idAlfresco)) {
            throw new InternalErrorException("Problème lors de l'upload du document !");
        }

        return idAlfresco;
    }

    private Folder createOrUpdateDirectory(DocumentSinistreAT documentSinistreAT) {
        if (documentSinistreAT.getDateSurvenance() == null) {
            throw new BusinessException("Date survenance vide, impossible de construire le chemin Alfresco");
        }
        var folder = claimDocumentRepository.createArboFoldersByPath(gedProperties.getOutbox(),
                constructFolderPath(documentSinistreAT.getDateSurvenance(), documentSinistreAT.getNumSinistre()));
        if (folder == null) {
            throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
        }
        Map<String, Object> properties = DocumentMapper.directoryPropertiesConstructor(folder, documentSinistreAT);
        if (!properties.isEmpty())
            folder.updateProperties(properties);
        return folder;
    }

    private String constructFolderPath(Date date, String numSinistre) {
        String year = new SimpleDateFormat("yyyy").format(date);
        String month = new SimpleDateFormat("MM").format(date);
        String day = new SimpleDateFormat("dd").format(date);

        return year + DATE_DELIMITOR + month + DATE_DELIMITOR + day + DATE_DELIMITOR + numSinistre;
    }


    /***
     *
     * upload tomporary file
     *
     * ***/
    public String uploadFileAt(DocClaimAtReqDto docClaimAtReqDto, MultipartFile file) {

        String idAlfresco = "";
        if (StringUtils.isBlank(docClaimAtReqDto.getNumSinistre())) {
            if (file != null && file.getOriginalFilename() != null && file.getContentType() != null) {

                idAlfresco = uploadDocAt(IndexOrPathToUse.TEMPORARY, docClaimAtReqDto, file);
                return idAlfresco;

            } else {
                throw new BusinessException("File est obligatoire !");
            }

        } else {
            idAlfresco = uploadDocAt(IndexOrPathToUse.DEFAULT, docClaimAtReqDto, file);
            return idAlfresco;
        }
    }

    public String uploadDocAt(IndexOrPathToUse index, DocClaimAtReqDto docClaimAtReqDto, MultipartFile file) {
        log.info("Start : indexing dossier document sinistre in alfresco  with data '{}'", docClaimAtReqDto);
        try {
            String filename = file.getOriginalFilename();
            if (filename != null) {
                FileUtil.assertFileNameValid(filename);
            }
            String idAlfresco = uploadAtFile(index, DocumentMapper.mapFileToGedDocument(file), docClaimAtReqDto);
            docClaimAtReqDto.setNomDocument(filename);
            ESDocumentATRequest esDocumentATRequest = DocumentMapper.mapToESDocumentAtTemporaryRequest(docClaimAtReqDto, idAlfresco, file.getSize(), false);
            if (IndexOrPathToUse.TEMPORARY.equals(index))
                esDocumentATRequest.setIsTemporary(true);
            elasticSearchHelper.addAtDocument(index, esDocumentATRequest, idAlfresco);
            log.info("End Service : Indexing dossier sinistre with idAlfresco '{}'", idAlfresco);
            return idAlfresco;

        } catch (Exception e) {
            log.error("can not upload document or indexing error '{}'", e.getMessage());
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
        }
    }

    public String uploadAtFile(IndexOrPathToUse index, GedDocument gedDocument, DocClaimAtReqDto docClaimAtReqDto) {
        log.info("Start: creating arborecense in alfresco repository");

        String prefixPath = null;
        Folder folder = null;
        if (index.equals(IndexOrPathToUse.TEMPORARY)) {
            prefixPath = atProperties.getAlfrescoSitePath().concat(atProperties.getAlfrescoRootFolder());
            folder = pathFromDateDoc(docClaimAtReqDto, prefixPath, IndexOrPathToUse.TEMPORARY);
        } else {
            prefixPath = gedProperties.getOutbox();
            folder = pathFromDateDoc(docClaimAtReqDto, prefixPath, IndexOrPathToUse.DEFAULT);
        }

        log.info("End: creating arborecense in alfresco repository with path '{}'", prefixPath);
        if (folder == null) {
            log.error("can not create/open dossier (floder) is null");
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, "Erreur lors de la création/ouverture du dossier");
        }
        Map<String, Object> properties = new HashMap<>();
        properties.put(AXADocPropertyIds.IDENTIFIANT_SCANER, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
        properties.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
        var uploadOutput = uploadFile(properties, gedDocument, folder);
        return uploadOutput.get("idAlfresco");
    }

    private String pathFromDateDocForTemporaryFile() {
        var date = LocalDate.now();
        return date.getYear() + "/" + date.getMonthValue() + "/" + date.getDayOfMonth();
    }

    public Folder pathFromDateDoc(DocClaimAtReqDto docClaimAtReqDto, String prefixPath, IndexOrPathToUse index) {
        Folder folder = null;
        if (IndexOrPathToUse.DEFAULT.equals(index))
            folder = claimDocumentRepository.createArboFoldersByPath(prefixPath,
                    constructFolderPath(DateUtils.toDate(docClaimAtReqDto.getDateSurvenance()), docClaimAtReqDto.getNumSinistre()));
        else
            folder = claimDocumentRepository.createArboFoldersByPath(prefixPath, pathFromDateDocForTemporaryFile());

        if (folder == null) {
            throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
        }
        if (Objects.nonNull(docClaimAtReqDto.getDateSurvenance()) ||
                StringUtils.isNotBlank(docClaimAtReqDto.getNumSinistre())
        ) {
            Map<String, Object> properties = DocumentMapper.directoryPropertiesConstructor(folder, DocumentSinistreAT.builder()
                    .dateSurvenance(DateUtils.toDate(docClaimAtReqDto.getDateSurvenance()))
                    .identifiantScanner(docClaimAtReqDto.getUploadedby())
                    .numPolice(Optional.ofNullable(docClaimAtReqDto.getNumPolice())
                            .map(BigDecimal::toString)
                            .orElse(null)
                    )
                    .numSinistre(docClaimAtReqDto.getNumSinistre())
                    .build());
            if (!properties.isEmpty())
                folder.updateProperties(properties);
        }
        return folder;
    }

    public Resource downloadAtFile(String idAlfresco) {
        log.info("Start: Downloading file with id '{}'", idAlfresco);
        var document = claimDocumentRepository.getFileDocument(idAlfresco);
        log.debug("File downloaded : '{}'", document);
        log.info("Start: Downloading file with id '{}'", idAlfresco);
        return new ByteArrayResource(document.getFileByte()) {
            @Override
            public String getFilename() {
                return document.getFileName();
            }
        };
    }

    @SneakyThrows
    public List<DocumentSinistreATES> retriveAtDocumentsList(String claimNumber) {
        log.info("Start service : Search list of documents with '{}'", claimNumber);
        List<DocumentSinistreATES> result;
        var validationClaimNumber = validationRequest(claimNumber);
        if (validationClaimNumber != null && !validationClaimNumber.isSuccess()) {
            throw new RequestValidationException(GlobalConstants.URI_BUSINESS_REQUEST_VALIDATION, validationClaimNumber.getMsgErrors());
        }
        result = elasticSearchHelper.getAtDocumentsList(IndexOrPathToUse.DEFAULT, "numsinistre", claimNumber);

        log.info("End service : Search list of documents with '{}'", claimNumber);
        return result;
    }

    public String modifyAtDocMetadata(String documentId, DocClaimAtReqDto docClaimAtReqDto) {
        log.info("Start service : modify Document with idAlfresco '{}' and metaData '{}'", documentId, docClaimAtReqDto);
        final var idAlfresco = GlobalConstants.PREFIX_IN_ALFRESCO_ID.concat(documentId);

        List<DocumentSinistreATES> docExistInTemporary = elasticSearchHelper.getAtDocumentsList(IndexOrPathToUse.TEMPORARY, GlobalConstants.IDALFRESCO, idAlfresco);
        if (CollectionUtils.isEmpty(docExistInTemporary)) {
            modifyOrSaveAtDocumentMetadataNotInTemporary(documentId, docClaimAtReqDto);
        } else {
            ESDocumentATRequest esDocumentATRequest = DocumentMapper.mapToESDocumentAtTemporaryRequest(docClaimAtReqDto, idAlfresco, docExistInTemporary.get(0).getSize(), true);
            if ((StringUtils.isBlank(esDocumentATRequest.getNumSinistre()) || Objects.isNull(docClaimAtReqDto.getDateSurvenance()))) {
                esDocumentATRequest.setIsTemporary(false);
                elasticSearchHelper.updateAtMetadata(IndexOrPathToUse.TEMPORARY, esDocumentATRequest, documentId);
            }
            if (StringUtils.isNotBlank(docClaimAtReqDto.getNumSinistre()) && Objects.nonNull(docClaimAtReqDto.getDateSurvenance())) {
                claimDocumentRepository.moveDocumentFromSourceToDestination(gedProperties.getOutbox(), constructFolderPath(DateUtils.toDate(docClaimAtReqDto.getDateSurvenance()), docClaimAtReqDto.getNumSinistre()), idAlfresco);
                for (var doc : docExistInTemporary) {
                    DocumentMapper.mapToESDocumentFromAtRequest(esDocumentATRequest, doc, docClaimAtReqDto);
                    esDocumentATRequest.setIsTemporary(false);
                    elasticSearchHelper.addAtDocument(IndexOrPathToUse.DEFAULT, esDocumentATRequest, idAlfresco);
                    elasticSearchHelper.deleteAtMetadata(IndexOrPathToUse.TEMPORARY, documentId);
                }
            }
        }
        log.info("End service : modify Document with output '{}'", idAlfresco);
        return idAlfresco;
    }

    private void modifyOrSaveAtDocumentMetadataNotInTemporary(String documentId, DocClaimAtReqDto metaData) {
        final var idAlfresco = GlobalConstants.PREFIX_IN_ALFRESCO_ID.concat(documentId);
        List<DocumentSinistreATES> docExistInDefault = elasticSearchHelper.getAtDocumentsList(IndexOrPathToUse.DEFAULT, GlobalConstants.IDALFRESCO, idAlfresco);

        if (CollectionUtils.isNotEmpty(docExistInDefault)) {
            ESDocumentATRequest esDocumentATRequest = DocumentMapper.mapToESDocumentAtTemporaryRequest(metaData, idAlfresco, docExistInDefault.get(0).getSize(), true);
            var oldMetadata = searchInDocumentsByQuery(DocumentMetadataQueryDto.builder().id(StringUtil.prettyIdAlfresco(documentId)).build())
                    .getContent().stream().findFirst().orElse(new DocClaimAtReqDto());

            if (Boolean.TRUE.equals(metaData.getIsReturnedRO()) || (oldMetadata.getNumSinistre() != null && metaData.getNumSinistre() == null)) {
                DocumentMapper.mapToESDocumentFromAtRequest(esDocumentATRequest, docExistInDefault.get(0), metaData);
                esDocumentATRequest.setIsTemporary(false);
                claimDocumentRepository.moveDocumentFromSourceToDestination(StringUtils.join(atProperties.getAlfrescoSitePath(), atProperties.getAlfrescoRootFolder()), pathFromDateDocForTemporaryFile(), idAlfresco);
                elasticSearchHelper.addAtDocument(IndexOrPathToUse.TEMPORARY, esDocumentATRequest, idAlfresco);
                elasticSearchHelper.deleteAtMetadata(IndexOrPathToUse.DEFAULT, documentId);
            } else {
                elasticSearchHelper.updateAtMetadata(IndexOrPathToUse.DEFAULT, esDocumentATRequest, documentId);
                if (Objects.nonNull(metaData.getNumSinistre()) && Objects.nonNull(metaData.getDateSurvenance())) {
                    claimDocumentRepository.moveDocumentFromSourceToDestination(gedProperties.getOutbox(), constructFolderPath(DateUtils.toDate(metaData.getDateSurvenance()), metaData.getNumSinistre()), idAlfresco);
                }
            }
        } else {
            var index = metaData.getNumSinistre() == null ? IndexOrPathToUse.TEMPORARY : IndexOrPathToUse.DEFAULT;
            var document = DocumentMapper.mapToESDocumentAtTemporaryRequest(metaData, idAlfresco, metaData.getSize(), false);
            elasticSearchHelper.addAtDocument(index, document, idAlfresco);
        }
    }

    public CommonResponse validationRequest(Object obj) {
        var response = CommonResponse.builder();
        var error = new HashMap<String, String>();
        if (obj instanceof List) {
            if (obj instanceof Collection && ((Collection) obj).isEmpty()) {
                error.put("metadata", "document n'existe pas");
            }
        } else if (obj instanceof String && StringUtils.isBlank((String) obj)) {
            error.put("claim_number", "Numero de sinistre est obligatoire");
        }
        response.msgErrors(error);
        response.success(error.isEmpty());
        return response.build();
    }


    public String deleteAtDocument(String idAlfresco) {
        log.info("Start service : delete Document with idAlfresco '{}'", idAlfresco);
        List<DocumentSinistreATES> docExistInTemporary = elasticSearchHelper.getAtDocumentsList(IndexOrPathToUse.TEMPORARY, "idalfersco", GlobalConstants.PREFIX_IN_ALFRESCO_ID.concat(idAlfresco));
        String result = "";
        if (CollectionUtils.isEmpty(docExistInTemporary)) {
            result = deleteAtDoc(IndexOrPathToUse.DEFAULT, idAlfresco);
        } else {
            result = deleteAtDoc(IndexOrPathToUse.TEMPORARY, idAlfresco);
        }
        log.info("End service : modify Document with output '{}'", result);
        return result;
    }

    @SneakyThrows
    private String deleteAtDoc(IndexOrPathToUse index, String documentId) {
        elasticSearchHelper.deleteAtMetadata(index, documentId);
        return claimDocumentRepository.deleteFile(GlobalConstants.PREFIX_IN_ALFRESCO_ID.concat(documentId));
    }

    public PageDto<DocClaimAtReqDto> searchInDocumentsByQuery(DocumentMetadataQueryDto document) {
        log.info("Start: Search on documents by query '{}'", document);
        final var indexOrPath = Boolean.TRUE.equals(document.getTemporary()) ? IndexOrPathToUse.TEMPORARY : IndexOrPathToUse.DEFAULT;
        PageDto<DocClaimAtReqDto> result = null;
        if (Boolean.TRUE.equals(document.getSearchInAlfresco())) {
            if (StringUtils.isBlank(document.getClaimNumber()) || document.getOccurrenceDate() == null || document.getOccurrenceDate() <= GlobalConstants.MIN_DATE) {
                throw new BusinessException(messageSource.getMessage("error.search.alfresco.needed-param.not-found", null, Locale.FRANCE));
            }
            final var occurrenceDate = document.getOccurrenceDate();
            String path = gedProperties.getOutbox().concat(DATE_DELIMITOR).concat(constructFolderPath(DateUtils.fromBackDateToObjectDate(occurrenceDate), document.getClaimNumber()));
            document.setOccurrenceDate(null);
            document.setIsReturnedRO(null);
            final List<DocumentSinistreATES> allMetadatasFromElastic = elasticSearchHelper.getAllInDocumentsMetadataAt(indexOrPath, document);
            ItemIterable<CmisObject> allMetadataFromAlfresco = null;
            if (new HashSet<>(possibleSearchParamInAlfresco).containsAll(ObjectUtils.extractFieldValues(document).keySet()) || document.getRepository() != null)
                allMetadataFromAlfresco = claimDocumentRepository.getAllChildsFromAlfrescoDirectory(path);

            if (allMetadataFromAlfresco == null || allMetadataFromAlfresco.getTotalNumItems() == 0) {
                result = PaginationATHelper.getPageWithMapping(allMetadatasFromElastic, document.getPage(), document.getSize(), allMetadatasFromElastic.size(), DocumentMapper::mapFromDocumentATESToDocClaimAtReqDto);
            } else if (CollectionUtils.isEmpty(allMetadatasFromElastic)) {
                result = PaginationATHelper.getPageWithMappingForItemIterable(allMetadataFromAlfresco, document.getPage(), document.getSize(), (int) allMetadataFromAlfresco.getTotalNumItems(), cmisObject -> {
                    if (cmisObject instanceof Document)
                        return documentsAlfrescoMapper.mapFromPropertiesToAlfresco(cmisObject.getProperties(), document.getClaimNumber(), document.getOccurrenceDate());
                    else
                        return null;
                });
                if (StringUtils.isNotBlank(document.getRepository()) && result != null && CollectionUtils.isNotEmpty(result.getContent())) {
                    var filteredResult = result.getContent().stream().filter(doc -> Objects.equals(doc.getRepertoire(), document.getRepository())).collect(Collectors.toList());
                    result.setContent(filteredResult);
                    result.setTotalElements(filteredResult.size());
                }
            } else {
                final var hashMap = new HashMap<>(allMetadatasFromElastic.parallelStream().collect(Collectors.toMap(documentSinistreAtEs -> StringUtils.replace(documentSinistreAtEs.getIdalfersco(), GlobalConstants.PREFIX_IN_ALFRESCO_ID, ""), DocumentMapper::mapFromDocumentATESToDocClaimAtReqDto)));

                for (final var alfrescoMetadata : allMetadataFromAlfresco) {
                    if (!(alfrescoMetadata instanceof Document)) {
                        continue;
                    }
                    final var mapedAlfrescoMetadata = documentsAlfrescoMapper.mapFromPropertiesToAlfresco(alfrescoMetadata.getProperties(), document.getClaimNumber(), occurrenceDate);
                    if (mapedAlfrescoMetadata == null)
                        continue;
                    if (document.getRepository() != null && (!Objects.equals(mapedAlfrescoMetadata.getRepertoire(), document.getRepository())))
                        continue;
                    if (hashMap.containsKey(mapedAlfrescoMetadata.getIdAlfresco())) {
                        final var temp = hashMap.get(mapedAlfrescoMetadata.getIdAlfresco());
                        if (Boolean.TRUE.equals(temp.getIsReturnedRO())) {
                            hashMap.remove(mapedAlfrescoMetadata.getIdAlfresco());
                            continue;
                        }
                        if (mapedAlfrescoMetadata.getCreationTimeStamp() != null && temp.getCreationTimeStamp() == null) {
                            temp.setCreationTimeStamp(mapedAlfrescoMetadata.getCreationTimeStamp());
                        }
                        if (mapedAlfrescoMetadata.getReceptionDate() != null && temp.getReceptionDate() == null) {
                            temp.setReceptionDate(mapedAlfrescoMetadata.getReceptionDate());
                        }
                        if (mapedAlfrescoMetadata.getSize() != null && temp.getSize() == null) {
                            temp.setSize(mapedAlfrescoMetadata.getSize());
                        }
                        if (mapedAlfrescoMetadata.getNumPolice() != null && temp.getNumPolice() == null) {
                            temp.setNumPolice(mapedAlfrescoMetadata.getNumPolice());
                        }
                        if (StringUtils.isNotBlank(mapedAlfrescoMetadata.getUploadedby()) && StringUtils.isBlank(temp.getUploadedby())) {
                            temp.setUploadedby(mapedAlfrescoMetadata.getUploadedby());
                        }
                        if (StringUtils.isNotBlank(mapedAlfrescoMetadata.getNomDocument()) && StringUtils.isBlank(temp.getNomDocument())) {
                            temp.setNomDocument(mapedAlfrescoMetadata.getNomDocument());
                        }
                        if (StringUtils.isNotBlank(mapedAlfrescoMetadata.getRepertoire()) && StringUtils.isBlank(temp.getRepertoire())) {
                            temp.setRepertoire(mapedAlfrescoMetadata.getRepertoire());
                        }
                    } else {
                        hashMap.put(mapedAlfrescoMetadata.getIdAlfresco(), mapedAlfrescoMetadata);
                    }
                }

                final var metadatas = hashMap.values().stream().sorted((o1, o2) -> ObjectUtils.comparator(ESOrderEnum.DESC, o1.getCreationTimeStamp(), o2.getCreationTimeStamp())).collect(Collectors.toCollection(ArrayList::new));
                result = PaginationATHelper.getPageWithMapping(metadatas, document.getPage(), document.getSize(), metadatas.size(), (value) -> value);
            }
        } else
            result = elasticSearchHelper.searchInDocumentsListsByQuery(indexOrPath, document, document.getPage(), document.getSize());
        log.info("End: Search on documents by query '{}'", document);
        return result;
    }

    public List<DocumentInfoDto> getMissingDocumentsByQuery(MissingDocumentQuery query) {
        log.info("Start service: Get list of missing documents by type {}", query);
        var missingDocuments = documentInfoRepository.findByQuery(query, 0, Integer.MAX_VALUE)
                .getContent();
        var output = documentInfoMapper.toMissingDocumentDtoList(missingDocuments);
        log.info("End service: Get list of missing documents by type {}", query);
        return output;
    }

    public List<ChangesQueryDto> copyDocumentsByAlfrescoIds(Boolean temporary, CopyDocumentsQueryDto copyDocumentsQueryDto) {
        log.info("Start service : copy files with alfresco's id's '{}' for user '{}'", copyDocumentsQueryDto.getChanges(), copyDocumentsQueryDto.getUserName());
        final var indexOrPathToUse = (temporary == null || !temporary) ? IndexOrPathToUse.DEFAULT : IndexOrPathToUse.TEMPORARY;
        // initializing state variables
        final var queryOfSearchOnAlfrescoIds = new HashMap<Object, String>();
        final var hashMapOfIdAlfrescoByChangesObject = new HashMap<String, ArrayList<ChangesQueryDto>>();
        final var getListOfIdAlfrescosToBeCopied = new HashMap<String, List<String>>();
        final var getOldIdByNewId = new HashMap<String, String>();
        final var listOfTypologies = new ArrayList<TypeDocAs400>();
        var prefixPath = gedProperties.getOutbox();

        if (indexOrPathToUse.equals(IndexOrPathToUse.TEMPORARY)) {
            prefixPath = atProperties.getAlfrescoSitePath().concat(atProperties.getAlfrescoRootFolder());
        }
        for (var copyInformation : copyDocumentsQueryDto.getChanges()) {
            copyInformation.setAlfrescoId(GlobalConstants.PREFIX_IN_ALFRESCO_ID.concat(copyInformation.getAlfrescoId()));
            copyInformation.setIsCopied(false);
            copyInformation.setOldAlfrescoId(copyInformation.getAlfrescoId());
            if (copyInformation.getTypology() != null) {
                if (listOfTypologies.isEmpty())
                    listOfTypologies.addAll(typologiesRepository.findByBranch(AutoAtBranchEnum.SAT));
                final var typology = listOfTypologies.stream().filter((typ) -> Objects.equals(typ.getId(), copyInformation.getTypology())).findFirst().orElse(null);
                if (typology == null)
                    copyInformation.setTypology(null);
                else
                    copyInformation.setRepository(typology.getRepositoryId());
            }
            queryOfSearchOnAlfrescoIds.put(copyInformation.getAlfrescoId(), "idalfersco");
            if (!getListOfIdAlfrescosToBeCopied.containsKey(copyInformation.getAlfrescoId())) {
                getListOfIdAlfrescosToBeCopied.put(copyInformation.getAlfrescoId(), new ArrayList<>());
            }
            getListOfIdAlfrescosToBeCopied.get(copyInformation.getAlfrescoId()).add(
                    pathFromDateDoc(DocClaimAtReqDto.builder()
                            .numSinistre(copyInformation.getClaimNumber())
                            .dateSurvenance(DateUtils.parseDate(Objects.toString(copyInformation.getOccurrenceDate(), null), GlobalConstants.DATE_FORMAT_FOR_FRONT))
                            .build(), prefixPath, indexOrPathToUse).getPath());

            if (!hashMapOfIdAlfrescoByChangesObject.containsKey(copyInformation.getAlfrescoId())) {
                hashMapOfIdAlfrescoByChangesObject.put(copyInformation.getAlfrescoId(), new ArrayList<>());
            }
            hashMapOfIdAlfrescoByChangesObject.get(copyInformation.getAlfrescoId()).add(copyInformation);
        }

        // copy alfresco files and get copy operation state with new ids of files

        final var copiedFilesMap = claimDocumentRepository.copyFileToDestination(getListOfIdAlfrescosToBeCopied);
        for (var idAlfrescoOldNew : copiedFilesMap.entrySet()) {
            if (idAlfrescoOldNew.getKey() == null || !hashMapOfIdAlfrescoByChangesObject.containsKey(idAlfrescoOldNew.getKey())) {
                continue;
            }

            if (CollectionUtils.isNotEmpty(idAlfrescoOldNew.getValue())) {
                var index = 0;

                for (var newAlfrescoId : idAlfrescoOldNew.getValue()) {
                    if (index >= hashMapOfIdAlfrescoByChangesObject.get(idAlfrescoOldNew.getKey()).size()) {
                        break;
                    }
                    if (StringUtils.isBlank(newAlfrescoId)) {
                        queryOfSearchOnAlfrescoIds.remove(idAlfrescoOldNew.getKey());
                        index++;
                        continue;
                    }
                    getOldIdByNewId.put(newAlfrescoId, idAlfrescoOldNew.getKey());
                    hashMapOfIdAlfrescoByChangesObject.get(idAlfrescoOldNew.getKey()).get(index).setAlfrescoId(newAlfrescoId);
                    index++;
                }
            } else {
                queryOfSearchOnAlfrescoIds.remove(idAlfrescoOldNew.getKey());
                hashMapOfIdAlfrescoByChangesObject.get(idAlfrescoOldNew.getKey()).forEach(
                        changesToCopyQueryDto -> changesToCopyQueryDto.setAlfrescoId(null)
                );
            }
        }

        // insert All files metadata-s with provided changes and get state of every copied metadata
        var listOfPredec = elasticSearchHelper.getATUnionOfMetadatasWithFieldQuery(indexOrPathToUse, queryOfSearchOnAlfrescoIds);
        if (CollectionUtils.isNotEmpty(listOfPredec)) {
            Optional<ChangesQueryDto> tempCopieInformation;
            final var arrayListOfPredeclarationToCreate = new ArrayList<DocumentSinistreATES>();
            for (var predec : listOfPredec) {
                if (predec.getIdalfersco() == null || !hashMapOfIdAlfrescoByChangesObject.containsKey(predec.getIdalfersco())) {
                    continue;
                }
                hashMapOfIdAlfrescoByChangesObject.get(predec.getIdalfersco()).forEach(
                        changesToCopyQueryDto -> arrayListOfPredeclarationToCreate.add(documentsEsMapper.mergeCopyChangesWithDocumentEs(predec, changesToCopyQueryDto, copyDocumentsQueryDto.getUserName()))
                );
            }
            final Map<String, Boolean> tempHashMap;
            try {
                tempHashMap = elasticSearchHelper.insertATMultipleMetadatas(indexOrPathToUse, arrayListOfPredeclarationToCreate);
            } catch (JsonProcessingException e) {
                throw new InternalErrorException("une erreur d'insertion dans ES.");
            }
            for (var entry : tempHashMap.entrySet()) {
                if (!getOldIdByNewId.containsKey(entry.getKey()) || !hashMapOfIdAlfrescoByChangesObject.containsKey(getOldIdByNewId.get(entry.getKey()))) {
                    continue;
                }
                tempCopieInformation = hashMapOfIdAlfrescoByChangesObject.get(getOldIdByNewId.get(entry.getKey())).stream().filter(
                        changesToCopyQueryDto -> StringUtils.equals(changesToCopyQueryDto.getAlfrescoId(), entry.getKey())
                ).findFirst();

                tempCopieInformation.ifPresent(changesToCopyQueryDto -> changesToCopyQueryDto.setIsCopied(entry.getValue()));

            }
        }
        ArrayList<ChangesQueryDto> result = new ArrayList<>();
        hashMapOfIdAlfrescoByChangesObject.forEach(
                (key, value) -> result.addAll(value)
        );
        log.info("End service : copy files with alfresco's id's '{}' for user '{}'", copyDocumentsQueryDto.getChanges(), copyDocumentsQueryDto.getUserName());
        return result;
    }
}