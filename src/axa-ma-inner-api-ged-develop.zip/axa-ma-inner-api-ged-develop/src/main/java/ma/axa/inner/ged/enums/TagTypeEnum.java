package ma.axa.inner.ged.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import org.apache.commons.lang3.StringUtils;

import java.util.Objects;

@Getter
@AllArgsConstructor
@FieldDefaults(makeFinal = true , level = AccessLevel.PRIVATE)
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum TagTypeEnum {
    INCOMING("E" , "Entrant") ,
    OUTGOING("S" , "Sortant") ;

    String code ;
    String label ;

    @JsonCreator
    public static TagTypeEnum getByCode(@JsonProperty(value = "code") String code ){
        if(StringUtils.isBlank(code)) return null ;
        for(var o : values()){
            if (Objects.equals(o.getCode() , code)) return o ;
        }
        return  null ; 
    }
}
