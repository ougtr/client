package ma.axa.inner.ged.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ESDossierATRequest {
	@JsonProperty("idalfersco")
	String idAlfersco;
	@JsonProperty("police")
	String numPolice;
	@JsonProperty("datesurvenance")
	Date dateSurvenance;
	@JsonProperty("datenumerisation")
	Date dateScan;
	@JsonProperty("nomvictime")
	String nomVictime;
	@JsonProperty("intermediaire")
	String intermediaire;
	@JsonProperty("codeproduit")
	String codeProduit;
	@JsonProperty("datedeclaration")
	Date dateDeclaration;
	@JsonProperty("classe")
	String classSinistre;
}
