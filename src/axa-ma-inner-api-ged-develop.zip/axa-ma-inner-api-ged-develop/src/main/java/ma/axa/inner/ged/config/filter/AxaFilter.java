package ma.axa.inner.ged.config.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AxaFilter implements Filter {
	private String filterName;

	@Override
	public void init(FilterConfig filterConfig) {
		filterName = filterConfig.getFilterName();
		log.info("Init Filter: {}", filterName);
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// Do nothing
	}

	@Override
	public void destroy() {
		log.info("Destroy Filter: {}", filterName);
	}
}
