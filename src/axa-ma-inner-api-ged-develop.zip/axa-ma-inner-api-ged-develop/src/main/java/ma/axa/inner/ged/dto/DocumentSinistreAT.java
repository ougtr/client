package ma.axa.inner.ged.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DocumentSinistreAT {

    private String numSinistre;
    private String numPolice;
    @NotBlank(message = "Type document obligatoire")
    private String typeDocument;
    @NotBlank(message = "Identifiant scanner obligatoire")
    private String identifiantScanner;
    @NotBlank(message = "Login user obligatoire")
    private String userLogin;
    @NotNull(message = "Code user obligatoire")
    private Integer userCode;
    private String numReglement;
    private String refIntermediaire;
    private String nomDocument;

    private Integer natureCourier;
    @DateTimeFormat(pattern = "yyyyMMdd")
    private Date dateScan;
    private Integer typeCourier;

    private String classeSinistre;
    @DateTimeFormat(pattern = "yyyyMMdd")
    private Date dateDeclaration;
    private String codeIntermediaire;
    private String nomVictime;
    @DateTimeFormat(pattern = "yyyyMMdd")
    private Date dateSurvenance;
    private String codeProduit;
    private String libDocument;
    private String codeDocument;
    private String regulationNumber;
    private String transactionId;
    private String objectHash;
    private String rightHolder;

}
