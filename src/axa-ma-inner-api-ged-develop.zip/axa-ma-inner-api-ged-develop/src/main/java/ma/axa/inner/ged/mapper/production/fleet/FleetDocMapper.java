package ma.axa.inner.ged.mapper.production.fleet;


import ma.axa.inner.ged.domain.production.fleet.DocumentFleetEs;
import ma.axa.inner.ged.dto.production.fleet.DocFleetReq;
import ma.axa.inner.ged.dto.production.fleet.DocFleetResp;
import ma.axa.inner.ged.mapper.MapstructUtil;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = MapstructUtil.class)
public interface FleetDocMapper {

    // -> TO DTO

    @Mapping(source = "simulationId", target = "simulationNumber")
    @Mapping(source = "quotationId", target = "quotationNumber")
    @Mapping(source = "filesize", target = "filesize", qualifiedByName = "mapToFileSize")
    DocFleetResp toDto(DocumentFleetEs document);

    List<DocFleetResp> toDtoList(List<DocumentFleetEs> documents);

    // -> FROM DTO

    DocumentFleetEs fromDto(DocFleetReq documentReq);

    List<DocumentFleetEs> fromDto(List<DocFleetReq> documentReq);

}