package ma.axa.inner.ged.domain.production;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductionDocumentEs {

    private String id;
    @JsonProperty("filename")
    private String filename;
    @JsonProperty("path")
    private String path;
    @JsonProperty("reference")
    private String reference;
    @JsonProperty("branche_label")
    private String brancheLabel;
    @JsonProperty("type_document_code")
    private Integer typedocumentCode;
    @JsonProperty("type_document_label")
    private String typedocumentLabel;
    @JsonProperty("corporate_name")
    private String corporateName;
    private String status;
    @JsonProperty("repertoire")
    private String repertoire;
    @JsonProperty("repertoire_code")
    private String repertoireCode;
    @JsonProperty("intermediary_code")
    private Integer intermediaryCode;
    @JsonProperty("created_by")
    private String createdBy;
    @JsonProperty("created_at")
    private String createdAt;
    @JsonProperty("last_updated_by")
    private String lastUpdatedBy;
    @JsonProperty("last_updated_at")
    private LocalDateTime lastUpdatedAt;
    @JsonProperty("filesize")
    private long filesize;
    @JsonProperty("filetype")
    private String filetype;

}
