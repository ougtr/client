package ma.axa.inner.ged.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DossierProductionTypeDoc {

    @JsonProperty("_index")
    private String index;
    @JsonProperty("_type")
    private String type;
    @JsonProperty("_id")
    private String id;

    private String branche;
    private String codeProduit;
    private String dateEffetPolice;
    private String dateEffetPoliceFormat;
    private String idAlfresco;
    private String intermediaire;
    private String nomSouscripteur;
    private String numPolice;
    private String statutPolice;
}
