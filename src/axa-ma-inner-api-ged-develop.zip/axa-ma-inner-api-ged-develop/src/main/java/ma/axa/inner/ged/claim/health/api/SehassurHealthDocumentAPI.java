package ma.axa.inner.ged.claim.health.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.health.dto.DocumentUploadInvoiceRequest;
import ma.axa.inner.ged.claim.health.service.SehassurHealthDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;

import javax.validation.Valid;

import org.springdoc.api.annotations.ParameterObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


@RestController
@RequestMapping("/v1/sehassur")
@Tag(name = GlobalConstants.TAG_HEALTH_APIS, description = GlobalConstants.TAG_DESC_HEALTH_APIS)
@RequiredArgsConstructor
@Slf4j
public class SehassurHealthDocumentAPI {

    private final SehassurHealthDocumentService sehassurHealthDocumentService;

    @Operation(summary = "upload a  document sehassur dabadoc")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document added", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error while uploading the file", content = @Content)})
    @PostMapping(path = "documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Void> uploadInvoice(@ParameterObject @Valid @ModelAttribute DocumentUploadInvoiceRequest invoiceInformations,
                             @RequestPart(value = "invoice", required = true) MultipartFile file) {

        log.info("Start api: SehassurHealthDocumentAPI uploadInvoice  {} " ,invoiceInformations);
       	sehassurHealthDocumentService.uploadFacture(file, invoiceInformations);
        log.info("End api: SehassurHealthDocumentAPI uploadInvoice ");
        return new ResponseEntity<Void>(HttpStatus.CREATED);
    }

}
