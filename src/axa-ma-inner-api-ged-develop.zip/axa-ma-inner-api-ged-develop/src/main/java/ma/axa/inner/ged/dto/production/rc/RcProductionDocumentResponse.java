package ma.axa.inner.ged.dto.production.rc;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RcProductionDocumentResponse {
    @JsonProperty(index = 1)
    private String id;
    private String policyNumber;
    private String idAlfresco;
    private String filename;
    private String uploadedBy;
    private String repertoire;
    private String repertoireCode;
}
