package ma.axa.inner.ged.mapper.cima.auto;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import ma.axa.inner.ged.domain.cima.auto.CimaAutoDocumentsTypeEs;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentTypeResponse;
import ma.axa.inner.ged.mapper.MapstructUtil;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = MapstructUtil.class)
public interface CimaAutoDocumentsTypeMapper {

	@Mapping(source = "id", target = "id", qualifiedByName = "trim")
	@Mapping(source = "lib", target = "lib", qualifiedByName = "trim")
	@Mapping(source = "directoryName", target = "directoryName", qualifiedByName = "trim")
	@Mapping(source = "entityName", target = "entityName", qualifiedByName = "trim")
	@Mapping(source = "description", target = "desc")
	CimaAutoDocumentTypeResponse toResponse(CimaAutoDocumentsTypeEs itemEs);

	List<CimaAutoDocumentTypeResponse> toResponses(List<CimaAutoDocumentsTypeEs> items);

	CimaAutoDocumentsTypeEs fromDto(CimaAutoDocumentTypeResponse item);
}
