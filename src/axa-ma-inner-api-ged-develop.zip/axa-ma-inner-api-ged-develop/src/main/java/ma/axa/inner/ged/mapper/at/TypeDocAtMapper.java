package ma.axa.inner.ged.mapper.at;

import ma.axa.inner.ged.domain.TypeDocAs400;
import ma.axa.inner.ged.domain.at.DocumentInfo;
import ma.axa.inner.ged.dto.at.IntermediaryTypeDocDto;
import ma.axa.inner.ged.dto.at.TypeDocDto;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface TypeDocAtMapper {

    @Mapping(source = "label", target = "label",qualifiedByName = "trim")
    @Mapping(source = "entityId",target = "familyId")
    public TypeDocDto typeDocToTypeDocAt(TypeDocAs400 typeDocAs400);
    public List<TypeDocDto> typeDocToTypeDocAt(List<TypeDocAs400> typeDocAs400);

    @Named("trim")
    public static String trimValue(String value) {
        return StringUtils.trim(value);
    }

    IntermediaryTypeDocDto mapToIntermediaryTypeDocDto(DocumentInfo doc);
    List<IntermediaryTypeDocDto> mapToIntermediaryTypeDocDto(List<DocumentInfo> docs);
}
