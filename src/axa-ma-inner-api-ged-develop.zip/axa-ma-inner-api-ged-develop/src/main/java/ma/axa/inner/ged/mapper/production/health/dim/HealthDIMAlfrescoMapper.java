package ma.axa.inner.ged.mapper.production.health.dim;

import ma.axa.inner.ged.dto.production.health.dim.DocHealthDIMReq;
import ma.axa.inner.ged.dto.production.health.dim.DocHealthDIMUpdateReq;
import ma.axa.inner.ged.mapper.AlfrescoPropsMapper;

import java.util.Collections;
import java.util.Map;

public class HealthDIMAlfrescoMapper extends AlfrescoPropsMapper {

	private HealthDIMAlfrescoMapper() throws InstantiationException {
		throw new InstantiationException("Instances of this type are forbidden");
	}

	// Folders

	public static Map<String, Object> toFolderProperties(DocHealthDIMReq metaData) {
		return toFolderProperties(metaData, null);
	}

	public static Map<String, Object> toFolderProperties(DocHealthDIMReq metaData, Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();

		var alfrescoProps = AlfrescoFolderProperties.builder()
				.numeroPoliceDossier(metaData.getPolicyNumber())
				.build();

		return toFolderProperties(properties, alfrescoProps);
	}

	// Documents

	public static Map<String, Object> toDocumentProperties(DocHealthDIMReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocHealthDIMReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numPolice(metaData.getPolicyNumber())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}

	public static Map<String, Object> toDocumentProperties(DocHealthDIMUpdateReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocHealthDIMUpdateReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numPolice(metaData.getPolicyNumber())
				//.identifiantScaner(metaData.getReference())
				//.isAuthentique(metaData.isOriginal())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}
}