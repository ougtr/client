package ma.axa.inner.ged.exception;

import ma.axa.inner.ged.util.constants.GlobalConstants;

public class CallStoredProcedureException extends GlobalException {

	private static final long serialVersionUID = 5409824811785548571L;

	public CallStoredProcedureException(String message) {
		super (GlobalConstants.URI_CALL_STORED_PROCEDURE, message);
	}
}
