package ma.axa.inner.ged.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DocumentLsPrevoyanceRequest {
    private String idGestion;
    private String typeDocument;
    private String libDocument;
    private String uploadedBy;
}
