package ma.axa.inner.ged.exception;

import ma.axa.inner.ged.util.constants.GlobalConstants;

public class ESIndexingException extends GlobalException {
	
	private static final long serialVersionUID = 7689661517105498579L;

	public ESIndexingException(String message) {
		super (GlobalConstants.FILE_ES_INDEXING_ERROR, message);
	}
}
