package ma.axa.inner.ged.helper.update;

import com.fasterxml.jackson.annotation.JsonInclude;
import ma.axa.inner.ged.domain.PreDeclarationTypeDoc;
import org.springframework.beans.BeanUtils;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ESDoc extends PreDeclarationTypeDoc {
    public ESDoc(PreDeclarationTypeDoc preDeclarationTypeDoc){

        BeanUtils.copyProperties(preDeclarationTypeDoc,this);

    }
}
