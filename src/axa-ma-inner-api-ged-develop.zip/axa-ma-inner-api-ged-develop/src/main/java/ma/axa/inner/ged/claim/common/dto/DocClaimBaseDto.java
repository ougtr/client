package ma.axa.inner.ged.claim.common.dto;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Getter
@Setter
@ToString
@NoArgsConstructor
@SuperBuilder
public abstract  class DocClaimBaseDto {
	protected String filename;
	protected String comment;
	protected boolean original;

	protected String numPolice;
	protected String sinistreNumber;
	protected String sinistreUserCreator;
	protected String typeDocumentCode;
	protected String typeDocumentLabel;
	protected String entityCode;
	protected String entityLabel;
	protected String assureNom;
	protected String assurePrenom;
	protected Integer produitCode;
	protected String produitLabel;
	protected Integer intermediaireCode;
	protected String intermediaireNom;
	private boolean draft;
	
	
	//TODO
	//NEW information
	protected String valeur_juridiction;
	protected String num_tribunal;
	protected String numAdhesion;
	protected String libBanque;
	protected String numDeclaration;
	protected String correspondance_G;


	@DateTimeFormat(pattern = GlobalConstants.DATE_FORMAT_COMMON, fallbackPatterns = {GlobalConstants.DATE_FORMAT_YYYYMMDD})
	@JsonFormat(pattern = GlobalConstants.DATE_FORMAT_COMMON, shape = JsonFormat.Shape.STRING)
	protected LocalDate dateReception;

	@DateTimeFormat(pattern = GlobalConstants.DATE_FORMAT_COMMON, fallbackPatterns = {GlobalConstants.DATE_FORMAT_YYYYMMDD})
	@JsonFormat(pattern = GlobalConstants.DATE_FORMAT_COMMON, shape = JsonFormat.Shape.STRING)
	protected LocalDate dateNumerisation;

	@DateTimeFormat(pattern = GlobalConstants.DATE_FORMAT_COMMON, fallbackPatterns = {GlobalConstants.DATE_FORMAT_YYYYMMDD})
	@JsonFormat(pattern = GlobalConstants.DATE_FORMAT_COMMON, shape = JsonFormat.Shape.STRING)
	protected LocalDate dateSurvenance;
}
