package ma.axa.inner.ged.domain;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class ProductionTypeDoc {

    @NotNull(message = "Le code produit est obligatoire")
    private String productCode;
	private String idAlfresco;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@NotNull(message = "la date d'effet est obligatoire")
	private LocalDate effectDate;
	@NotNull(message = "le numero de police est obligatoire")
	private String policeNumber;
	@NotNull(message = "Le nom du client est obligatoire")
	private String clientName;
	@NotNull(message = "Le code intermediaire est obligatoire")
	private String codeIntermediaire;
	@DateTimeFormat(pattern = "yyyyMMdd")
	private Date dateDeclaration;
	private Date dateScan;
	private List<String> tagsLabels;
	private List<String> tagsIds;
	private Integer typedocument;
	private String typedocumentLabel;
}
