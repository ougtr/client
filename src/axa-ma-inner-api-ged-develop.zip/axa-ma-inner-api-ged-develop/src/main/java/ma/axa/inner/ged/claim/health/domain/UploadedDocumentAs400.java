package ma.axa.inner.ged.claim.health.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UploadedDocumentAs400 {
    private BigDecimal nulign;

    private String colng4;

    private String libpre;

    private String ideged;

    private String rectyp;


}
