package ma.axa.inner.ged;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class AxaInnerGedApiApplication {
	public static void main(String[] args) {
		SpringApplication.run(AxaInnerGedApiApplication.class, args);
	}
}
