package ma.axa.inner.ged.repository;


import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.domain.SearchLsPrevoyanceAs400;
import ma.axa.inner.ged.dto.DocumentLsPrevoyanceRequest;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import ma.axa.inner.ged.dto.LsDocumentRequest;
import ma.axa.inner.ged.exception.CallStoredProcedureException;

import java.util.List;

@Repository
@RequiredArgsConstructor
@Slf4j
public class LsDocumentsRepository {

	private final JdbcTemplate jdbcTemplate;
	
	@SneakyThrows
	public String  saveLsMetadataDocument(LsDocumentRequest request) {

		try {
            String signature = "";
			log.info("CALL LGRPP.PSLSPASV18('{}','{}','{}','{}','{}','{}','{}')",
					request.getToken(),
					request.getCodeProduct(),
					request.getCodeAction(),
					request.getTypedoc(),
					request.getUrlDocument(),
					request.getLibelleDocument(),
                    signature);
			
			return jdbcTemplate.queryForObject("CALL LGRPP.PSLSPASV18(?,?,?,?,?,?,?)", String.class,
					request.getToken(),
					request.getCodeProduct(),
					request.getCodeAction(),
					request.getTypedoc(),
					request.getUrlDocument(),
					request.getLibelleDocument(),
                    signature
					);

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new CallStoredProcedureException(e.getMessage());
		}
	}

	@SneakyThrows
    public String saveNewLsPrevoyaneDoc(DocumentLsPrevoyanceRequest doc,String idAlfresco) {
		try {
			log.info("Start: save Doc ls by doc '{}'", doc);
			return jdbcTemplate.queryForObject("CALL LGRPP.PSGMISV04(?,?,?,?,?)",String.class,
					doc.getIdGestion(), doc.getTypeDocument(), doc.getLibDocument(),
					idAlfresco,doc.getUploadedBy());

		} catch (Exception e) {
			log.error("cannot call procedure to save ls doc  error happened : '{}'", e.getMessage());
			throw new CallStoredProcedureException(e.getMessage());
		}
    }

    public List<SearchLsPrevoyanceAs400> searchLsPrevoyanceDocuments(String idGestion) {
		try {
			log.info("Start: get Doc ls by '{}'", idGestion);
			var list = jdbcTemplate.query("CALL LGRPP.PSGMISV06(?)",
					BeanPropertyRowMapper.newInstance(SearchLsPrevoyanceAs400.class),
					idGestion);
			log.info("End: Searching ls doc  by idGestion '{}' ", idGestion);
			return list;
		} catch (Exception e) {
			log.error("cannot call procedure to get ls doc by idGestionr : '{}'", e.getMessage());
			throw new CallStoredProcedureException(e.getMessage());
		}
    }

	@SneakyThrows
	public String deleteLsPrevoyanceMetadata(String documentId) {
		try {
			return jdbcTemplate.queryForObject("CALL LGRPP.PSGMISV05(?)",String.class,
					documentId);
		} catch (Exception e) {
			log.error("cannot call procedure to delete metadata '{}'", e.getMessage());
			throw new CallStoredProcedureException(e.getMessage());
		}
	}

	@SneakyThrows
	public String deleteLsSubscriptionMetadata(String token , String documentId, String productCode, String documentType, String actionCode) {
		try {
			return jdbcTemplate.queryForObject("CALL PSLSPASV19(?,?,?,?,?)",String.class,token,
					productCode,actionCode,documentType,documentId);
		} catch (Exception e) {
			log.error("cannot call procedure to delete metadata '{}'", e.getMessage());
			throw new CallStoredProcedureException(e.getMessage());
		}
	}
}
