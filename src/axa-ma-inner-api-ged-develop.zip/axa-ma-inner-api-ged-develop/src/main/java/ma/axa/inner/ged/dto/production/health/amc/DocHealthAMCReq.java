package ma.axa.inner.ged.dto.production.health.amc;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.dto.production.health.common.DocHealthReq;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DocHealthAMCReq extends DocHealthReq {
	@Builder.Default
	private String productCode = "0333";
	@Builder.Default
	private String brancheLabel="Health Production AMC";
}