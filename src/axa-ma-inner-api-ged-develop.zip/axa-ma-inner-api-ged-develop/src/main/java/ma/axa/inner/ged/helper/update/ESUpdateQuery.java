package ma.axa.inner.ged.helper.update;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ESUpdateQuery {
    private ESDoc doc;
}
