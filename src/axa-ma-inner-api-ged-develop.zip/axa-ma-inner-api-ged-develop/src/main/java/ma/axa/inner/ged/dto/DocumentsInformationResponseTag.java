package ma.axa.inner.ged.dto;

public enum DocumentsInformationResponseTag {

    ENTRANT("entrant"),
    SORTANT("sortant");

    String value;

    DocumentsInformationResponseTag(String value) {
        this.value = value;
    }

    public String value() {
        return this.value;
    }
}
