package ma.axa.inner.ged.domain;

import lombok.*;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ESResponseIndex {

    private Boolean acknowledged;

}
