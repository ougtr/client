package ma.axa.inner.ged.dto.at;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;

@Getter
@Setter
@Builder
@EqualsAndHashCode
public class PageDto<T> {
    private Integer pageNumber;
    private Integer totalPages;
    private Integer totalElements;
    private Collection<T> content;
}