package ma.axa.inner.ged.claim.cima.auto.api;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.cima.auto.service.AutoDocumentService;
import ma.axa.inner.ged.domain.ESResponse;
import ma.axa.inner.ged.dto.CimaRequestDocument;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springframework.core.io.Resource;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/v1/cima/claims")
@Tag(name = GlobalConstants.TAG_HEALTH_APIS, description = GlobalConstants.TAG_DESC_HEALTH_APIS)
@RequiredArgsConstructor
@Slf4j
public class AutoDocumentAPI {

    private final AutoDocumentService autoDocumentService;


    @Operation(summary = "download a health document by its alfresco id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was downloaded", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = Resource.class))}),
            @ApiResponse(responseCode = "404", description = "document not found with id", content = @Content),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
    @GetMapping(value = "/documents/{document_Id}/content", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<Resource> download(@NotNull(message = "{error.alfresco.id}") @PathVariable(value = "document_Id", required = true) String documentId) {
        log.info("Start api: Downloading file with id '{}'", documentId);
        var resource = autoDocumentService.downloadDocByIdAlfresco(documentId);

        var headers = new HttpHeaders();
        String headerKey = "X-filename";
        String headerValue = resource.getFilename();
        headers.set(headerKey,headerValue);

        log.info("End api: File downloaded !");
        return ResponseEntity.ok().headers(headers).body(resource);
    }

    @Operation(summary = "upload a  document")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document added", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = String.class)) }),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error while uploading the file", content = @Content)})
    @PostMapping(path = "/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public String upload(@RequestPart(value = "file") MultipartFile document, @RequestParam(value = "country") String countryCode){

        log.info("Start api: uploading file (document Health) '{}'", document.getOriginalFilename());
        String id=  autoDocumentService.upload(document, countryCode);
        log.info("End api: File (document health) uploaded '{}'", document.getOriginalFilename());
        return id;
    }

    @Operation(summary = "upload a documents")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Documents added", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = String.class)) }),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error while uploading the file", content = @Content)})
    @PostMapping(path = "/allDocuments", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public List<String> uploadFiles(@RequestPart(value = "files") List<MultipartFile> documents, @RequestParam(value = "country") String countryCode){
        List<String> filenames = documents.stream().map(MultipartFile::getOriginalFilename).collect(Collectors.toList());
        String filenamesString = String.join(", ", filenames);
        log.info("Start api: uploading files (document Health) '{}'", filenamesString);
        List<String> id=  autoDocumentService.uploadFiles(documents, countryCode);
        log.info("End api: File (document health) uploaded '{}'", filenamesString);
        return id;
    }

    @Operation(summary = "index document")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Documents indexed", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = ESResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error in indexing the file", content = @Content)})
    @PostMapping(value = "/indexFile/{idAlfresco}")
    public ESResponse indexFile(@RequestBody CimaRequestDocument cimaRequestDocument, @PathVariable String idAlfresco){
        log.info("Start resource cima document in elastic serach with id = {} and metaData = {}", idAlfresco, cimaRequestDocument);
        var esResponse = autoDocumentService.indexDocumentInEs(cimaRequestDocument, idAlfresco);
        log.info("End resource cima document in elastic serach with id = {} and metaData = {}", idAlfresco, cimaRequestDocument);
        return esResponse;
    }
}
