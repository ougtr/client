package ma.axa.inner.ged.mobile.scan.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.GedProperties;
import ma.axa.inner.ged.config.properties.GedMobileScanPropreties.MsProperties;
import ma.axa.inner.ged.domain.ESDocMobileScanRequest;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.domain.IndexOrPathToUse;
import ma.axa.inner.ged.exception.BusinessException;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.helper.ElasticSearchHelper;
import ma.axa.inner.ged.mapper.DocumentMapper;
import ma.axa.inner.ged.mobile.scan.dto.OcrDoc;
import ma.axa.inner.ged.mobile.scan.dto.OcrDocDto;
import ma.axa.inner.ged.mobile.scan.repository.OcrDocRepository;
import ma.axa.inner.ged.mobile.scan.service.MobileScanDocService;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.service.ManageDocumentService;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.constants.MobileScanStatutEnum;

@Service
@Slf4j
public class MobileScanDocServiceImpl extends ManageDocumentService implements MobileScanDocService {

	private static final String DATE_DELIMITOR = "/";

	private final GedProperties gedProperties;
	private final MsProperties msProperties;
	private final ElasticSearchHelper elasticSearchHelper;
	private final OcrDocRepository ocrDocRepository;

	public MobileScanDocServiceImpl(ClaimDocumentRepository claimDocumentRepository, MsProperties msProperties,
			GedProperties gedProperties, ElasticSearchHelper elasticSearchHelper, OcrDocRepository ocrDocRepository) {
		super(claimDocumentRepository);
		this.gedProperties = gedProperties;
		this.msProperties = msProperties;
		this.elasticSearchHelper = elasticSearchHelper;
		this.ocrDocRepository = ocrDocRepository;
	}


	@Override
	public OcrDoc uploadFileTemp(MultipartFile file1, MultipartFile file2, OcrDocDto ocrDocumentDto, String token) {

		String idAlfrescoRecto = "";
		String idAlfrescoVerso = "";
		OcrDoc ocrDocument;
		var ocrDocBDD = ocrDocRepository.findByToken(token);
		if (ocrDocBDD != null) {
			if (file1 == null && file2 == null) {
				throw new BusinessException("IL FAUT UPLOAD AU MOINS UN DOCUMENT !");
			}
			if (file1 != null && file1.getOriginalFilename() != null && file1.getContentType() != null) {

				idAlfrescoRecto = uploadMsFile(IndexOrPathToUse.TEMPORARY, DocumentMapper.mapFileToGedDocument(file1));
			}
			if (file2 != null && file2.getOriginalFilename() != null && file2.getContentType() != null) {

				idAlfrescoVerso = uploadMsFile(IndexOrPathToUse.TEMPORARY, DocumentMapper.mapFileToGedDocument(file2));
			}
			ocrDocument = copyProperties(ocrDocBDD, ocrDocumentDto);
			ocrDocument.setIdAlfrescoRecto(idAlfrescoRecto);
			ocrDocument.setIdAlfrescoVerso(idAlfrescoVerso);
			ocrDocRepository.save(ocrDocument);
		} else {
			throw new BusinessException("Token doesn't exist in data base !");
		}
		return ocrDocument;

	}

	public OcrDoc copyProperties(OcrDoc ocrDocExist, OcrDocDto ocrDocumentDto) {
		OcrDoc ocrDocument=new OcrDoc();
		BeanUtils.copyProperties(ocrDocumentDto, ocrDocument);
		ocrDocument.setId(ocrDocExist.getId());
		if (ocrDocExist.getTypeDocument() != null) {
			ocrDocument.setTypeDocument(ocrDocExist.getTypeDocument());
		}
		if (ocrDocExist.getToken() != null) {
			ocrDocument.setToken(ocrDocExist.getToken());
		}
		ocrDocument.setDateMaj(new Date());
		ocrDocument.setStatut(MobileScanStatutEnum.OCIRISER.toString());
		return ocrDocument;
	}

	public String uploadDoc(IndexOrPathToUse index, OcrDoc ocrDocument, MultipartFile file) {
		log.info("Start : indexing dossier document sinistre in alfresco  with data '{}'", ocrDocument);
		try {
			String filename = file.getOriginalFilename();
			if (filename != null) {
				FileUtil.assertFileNameValid(filename);
			}
			String idAlfresco = uploadMsFile(index, DocumentMapper.mapFileToGedDocument(file));
			ocrDocument.setNomDocument(filename);
			log.info("End Service : Indexing dossier sinistre with idAlfresco '{}'", idAlfresco);
			return idAlfresco;

		} catch (Exception e) {
			log.error("can not upload document or indexing error '{}'", e.getMessage());
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
		}
	}

	public String uploadMsFile(IndexOrPathToUse index, GedDocument gedDocument) {
		log.info("Start: creating arborecense in alfresco repository");

		var prefixPath = gedProperties.getOutbox();
		var path = pathFromDateDoc();
		if (index.equals(IndexOrPathToUse.TEMPORARY)) {
			prefixPath = msProperties.getAlfrescoSitePath().concat(msProperties.getAlfrescoRootFolder());
		}
		var folder = claimDocumentRepository.createArboFoldersByPath(prefixPath, path);
		log.info("End: creating arborecense in alfresco repository with path '{}'", prefixPath + path);
		if (folder == null) {
			log.error("can not create/open dossier (floder) is null");
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR,
					"Erreur lors de la création/ouverture du dossier");
		}
		Map<String, Object> properties = new HashMap<>();
		properties.put(AXADocPropertyIds.IDENTIFIANT_SCANER,
				LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
		properties.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
		var uploadOutput = uploadFile(properties, gedDocument, folder);
		return uploadOutput.get("idAlfresco");
	}

	@Override
	public void indexDocument(String token) {
		OcrDoc ocrDocument = ocrDocRepository.findByToken(token);
		if (ocrDocument != null) {
			if (ocrDocument.getIdAlfrescoRecto() != null) {
				indexMetadaDocument(ocrDocument.getIdAlfrescoRecto(), ocrDocument);
			}
			if (ocrDocument.getIdAlfrescoVerso() != null) {
				indexMetadaDocument(ocrDocument.getIdAlfrescoVerso(), ocrDocument);
			}
			ocrDocument.setStatut(MobileScanStatutEnum.INDEXE.toString());
			ocrDocument.setDateMaj(new Date());
			ocrDocRepository.save(ocrDocument);
		} 

	}

	public String indexMetadaDocument(String documentId, OcrDoc ocrDocument) {
		log.info("Start service : modify path Document and index with idAlfresco '{}'", documentId);
		final var idAlfresco = GlobalConstants.PREFIX_IN_ALFRESCO_ID.concat(documentId);
		ESDocMobileScanRequest esDocMobileScanRequest = DocumentMapper.mapToESDocMobileScanRequest(ocrDocument,
				idAlfresco);
		claimDocumentRepository.moveDocumentFromSourceToDestination(gedProperties.getOutbox(), pathFromDateDoc(),
				idAlfresco);
		elasticSearchHelper.addMobileScanDocument(IndexOrPathToUse.DEFAULT, esDocMobileScanRequest, idAlfresco);
		log.info("End service : modify path Document and index with output '{}'", idAlfresco);
		return idAlfresco;

	}

	private String pathFromDateDoc() {
		var date = LocalDate.now();
		return date.getYear() + DATE_DELIMITOR + date.getMonthValue() + DATE_DELIMITOR + date.getDayOfMonth();
	}

}
