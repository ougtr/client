package ma.axa.inner.ged.util.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class PathConstants {


    public static final String CLAIM_RD_DOCUMENTS = "/v1/claims/rd/documents";
    public static final String CLAIM_RD_PARAMS = "/v1/claims/rd/params";
    public static final String CLAIM_TRANSPORT_DOCUMENTS = "/v1/claims/transport/documents";
    public static final String CLAIM_TRANSPORT_PARAMS = "/v1/claims/transport/params";
    public static final String GLOBAL_DOCUMENTS = "/v1/documents";

}
