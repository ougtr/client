package ma.axa.inner.ged.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ESBulkOperationsEnum {
    CREATE("create");
    private String operation;
}
