package ma.axa.inner.ged.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ESDocumentSchema {
    private int took;
    @JsonProperty("timed_out")
    private Boolean timedOut;
    @JsonProperty("_shards")
    private Shards shards;
    private DocumentSinistreAutoHits hits;
}
