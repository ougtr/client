package ma.axa.inner.ged.util.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ClaimsConstants {


	public static final int BRANCH_RD_CODE = 2;
	public static final int BRANCH_TRANSPORT_CODE = 1;
	public static final int BRANCH_LS_CODE = 3;
	public static final int NUMORDER = 0;

}
