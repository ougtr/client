package ma.axa.inner.ged.repository.production.rc;

import static ma.axa.inner.ged.util.ElasticSearchUtils.termQuery;
import static ma.axa.inner.ged.util.ElasticSearchUtils.addTermQuery;

import java.io.IOException;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.production.rc.RcProductionDocumentEs;
import ma.axa.inner.ged.dto.production.rc.ProductionRcSearchParams;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.repository.ElasticSearchNewRepository;
import ma.axa.inner.ged.util.constants.ElasticConstants;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;


@Repository
@RequiredArgsConstructor
@Slf4j
public class ProductionRcElasticRepository {

    private final BrancheProperties rcProperties;
    private final ElasticSearchNewRepository elasticRepository;

    /**
     * Create new Document in ElasticSearch
     */
    public String createNewDocument(final String documentId, final RcProductionDocumentEs metaData)
            throws ElasticsearchException, IOException {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("ID Document must not be blank");
        if (metaData == null)
            throw new NullPointerException("Document Production Rc must not be null");

        try {
            if (exists(documentId)) {
                throw new ResourceAlreadyExist(GlobalConstants.URI_RECORDE_ALREADY_EXIST,
                        "Document with id {0} already exist",
                        new String[] { documentId });
            }

            var created = elasticRepository.createNewDocument(rcProperties.getEsDocIndex(), documentId,
                    metaData);
            if (created != null) {
                log.info("[es-repo] Successfully created new document Production RC with id: {}", documentId);
                return created;
            }
        } catch (Exception e) {
            log.error("[es-repo] Error creating new document for id: {}, err: {} ", documentId, e.getMessage());
            throw e;
        }
        return null;
    }

    public boolean exists(String documentId) {
        return elasticRepository.existsDocument(rcProperties.getEsDocIndex(), documentId);
    }
    
    public RcProductionDocumentEs findOneDocumentByReference(String reference) {
        refreshIndex();
        BoolQuery.Builder boolQuery = new BoolQuery.Builder();
        boolQuery.must(termQuery(ElasticConstants.REFERENCE, reference));
        try {
            var searchRequest = new SearchRequest.Builder();
            searchRequest.index(rcProperties.getEsDocIndex())
                    .query(q -> q.bool(boolQuery.build()));
            var searchResponse = elasticRepository.search(searchRequest, RcProductionDocumentEs.class);
            if (searchResponse != null && !searchResponse.hits().hits().isEmpty()) {
                return searchResponse.hits().hits().get(0).source();
            }
        } catch (Exception e) {
            log.error("[es-repo] Error during search by reference: {} , err: {}", reference, e.getMessage());
        }
        return null;
    }
    /**
     * Refresh Index
     */
    public void refreshIndex() {
        try {
            elasticRepository.refreshIndex(rcProperties.getEsDocIndex());
        } catch (Exception e) {
            log.error("[ES] Error during refresh index, err: {}", e.getMessage());
        }
    }
    
    // Update

    public boolean updateDocument(final String documentId, final RcProductionDocumentEs metaData)
            throws ElasticsearchException, IOException {
        return updateDocument(documentId, metaData, false);
    }


    /**
     * Update Document in ElasticSearch
     */
    private boolean updateDocument(final String documentId, final RcProductionDocumentEs metaData,
                                   boolean isUpsert)
            throws ElasticsearchException, IOException {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("Document ID must not be blank");
        if (metaData == null)
            throw new NullPointerException("Document Health DIM must not be null");

        try {
            var response = elasticRepository.updateDocument(rcProperties.getEsDocIndex(), documentId, metaData,
                    isUpsert,
                    RcProductionDocumentEs.class);
            log.info("[es-repo] Successfully updatd new document Health DIM with id: {}", documentId);
            return response;
        } catch (Exception e) {
            log.error("[es-repo] Error updating  document with id:{}, err: {}", documentId, e.getMessage());
            throw e;
        }
    }
    public Optional<RcProductionDocumentEs> findById(String id) {
        try {
            refreshIndex();
            return Optional.of(elasticRepository.findById(rcProperties.getEsDocIndex(), id, RcProductionDocumentEs.class));
        } catch (Exception e) {
            log.error("[es-repo] Error find document with id:{}, err: {}", id, e.getMessage());
            return Optional.empty();
        }
    }
    
    /**
     * find document by criteria
     *
     * @param searchParams
     */

    public SearchResponse<RcProductionDocumentEs> findByCriteria(ProductionRcSearchParams searchParams) {
        refreshIndex();
        try {
            var boolQuery = new BoolQuery.Builder();
            var query = getQueryForMultiSearch(searchParams);
            boolQuery.must(query);
            int from = searchParams.getPageNumber() * searchParams.getPageSize();

            var searchRequest = new SearchRequest.Builder();
            searchRequest.index(rcProperties.getEsDocIndex())
                    .query(q -> q
                            .bool(boolQuery.build()))
                    .from(from)
                    .size(searchParams.getPageSize());
            return elasticRepository.search(searchRequest, RcProductionDocumentEs.class);
        } catch (Exception e) {
            log.error("Error during elastic search", e);
            return null;
        }
    }
    public static Query getQueryForMultiSearch(ProductionRcSearchParams searchParams) {
        var boolQuery = new BoolQuery.Builder();
        addTermQuery(ElasticConstants.NUM_POLICE, searchParams.getPolicyNumber(), boolQuery);
        return boolQuery.build()._toQuery();
    }
    
    public boolean deleteDocument(String documentId) {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("documentId must not be blank");
        try {
            var response = elasticRepository.deleteDocument(rcProperties.getEsDocIndex(), documentId);
            if (response) {
                log.debug("[es-repo]Successfully deleted document Production RC with id: {}", documentId);
                return true;
            }
        } catch (Exception e) {
            log.warn("[es-repo] Error deleting document by id: {}, err: {}", documentId, e.getMessage());
        }
        return false;
    }
    
    
}
