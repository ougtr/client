package ma.axa.inner.ged.dto;

import lombok.Data;

@Data
public class DocumentResponse {

	private String caseNumber;
	private String idAlfresco;
	
}
