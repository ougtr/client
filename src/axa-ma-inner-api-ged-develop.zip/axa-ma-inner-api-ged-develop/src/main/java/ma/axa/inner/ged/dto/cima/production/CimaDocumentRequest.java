package ma.axa.inner.ged.dto.cima.production;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CimaDocumentRequest {
    @NotNull
    private CountryCode countryCode;
    @NotNull
    private ProductType productType;
    @NotNull
    @NotEmpty
    private String agentCode;
    @NotNull
    @NotEmpty
    private String productCode;
    @NotNull
    @NotEmpty
    private String policyNumber;
    @NotNull
    @NotEmpty
    private String documentTypeCode;
    @NotNull
    @NotEmpty
    private String documentTypeLabel;
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    @NotNull(message = "La date d'effet ne doit pas être null")
    private LocalDate effectDate;
    @NotNull
    @NotEmpty
    private String createdBy;
    @NotNull
    @DateTimeFormat(pattern = "dd/MM/yyyy HH:mm:ss")
    private LocalDateTime createdAt;
}
