package ma.axa.inner.ged.mapper.production.health.dim;

import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;

import ma.axa.inner.ged.domain.production.health.dim.DocumentHealthDIMEs;
import ma.axa.inner.ged.dto.production.health.dim.DocHealthDIMReq;
import ma.axa.inner.ged.dto.production.health.dim.DocHealthDIMResp;
import ma.axa.inner.ged.dto.production.health.dim.DocHealthDIMUpdateReq;
import ma.axa.inner.ged.mapper.MapstructUtil;
import org.mapstruct.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = MapstructUtil.class)
public interface HealthDIMMapper {

	// -> TO DTO

	@Mapping(source = "filesize",target = "filesize",qualifiedByName = "mapToFileSize")
	DocHealthDIMResp toDto(DocumentHealthDIMEs document);

	List<DocHealthDIMResp> toDtoList(List<DocumentHealthDIMEs> documents);

	// -> FROM DTO

	DocumentHealthDIMEs fromDto(DocHealthDIMReq documentRes);

	List<DocumentHealthDIMEs> fromDto(List<DocHealthDIMReq> documentRes);

	DocumentHealthDIMEs fromDto(DocHealthDIMUpdateReq documentReq);

	// -> update
	@BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
	void updateFromDto(DocHealthDIMUpdateReq documentReq, @MappingTarget DocumentHealthDIMEs document);

	// Others
	static Page<DocumentHealthDIMEs> mapToPage(SearchResponse<DocumentHealthDIMEs> searchResponse, int from,
			int size) {
		if (searchResponse == null || searchResponse.hits().hits().isEmpty() || searchResponse.hits().total() == null) {
			return Page.empty();
		} else {
			long totalElements = searchResponse.hits().total().value();
			List<DocumentHealthDIMEs> results = searchResponse.hits().hits().stream()
					.map(Hit::source)
					.collect(Collectors.toList());
			PageRequest pageRequest = PageRequest.of(from, size);
			return new PageImpl<>(results, pageRequest, totalElements);
		}
	}
}