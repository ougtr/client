package ma.axa.inner.ged.util;

import lombok.experimental.UtilityClass;
import ma.axa.inner.ged.dto.cima.auto.CountryCode;

import org.apache.commons.lang3.StringUtils;

@UtilityClass
public class DataSourceUtils {
    public static CountryCode getDataSourceFromHeader(String datasource) {
        return StringUtils.isBlank(datasource) ?
                CountryCode.MA :
                CountryCode.valueOf(datasource);
    }
}
