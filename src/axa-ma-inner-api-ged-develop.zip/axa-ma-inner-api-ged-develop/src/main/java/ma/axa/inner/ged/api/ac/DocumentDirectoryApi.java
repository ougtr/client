package ma.axa.inner.ged.api.ac;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.DirectoryResponseDto;
import ma.axa.inner.ged.service.ac.DirectoriesService;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@Tag(name = GlobalConstants.AUTO_GED_APIS_TAG)
@RestController
@RequestMapping("/v1/claims/ac/params/directories")
@RequiredArgsConstructor
@Slf4j
public class DocumentDirectoryApi {

    private final DirectoriesService directoriesService;

    @Operation(summary = "Get all directories")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "repositories list fetched", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = DirectoryResponseDto.class)) }),
    @ApiResponse(responseCode = "500", description = "internal error", content = @Content)})
    @GetMapping(path = "", produces = { "application/json" })
    public List<DirectoryResponseDto> getListOfRepositories() {
        log.info("Start api : Get all repositories");
        final var repositories = directoriesService.getAllRepositories();
        log.info("End api : Get all repositories");
        return repositories;
    }
}
