package ma.axa.inner.ged.claim.ls.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.inner.ged.util.constants.GlobalConstants;

import javax.validation.constraints.Min;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DocClaimLsSearchParams {
    private String sinistreNumber;
    @Min(value = 0, message = GlobalConstants.ERROR_MSG_SEARCH_PAGENUMBER_MIN)
    @Builder.Default
    private Integer pageNumber = 0;
    @Min(value = 1, message = GlobalConstants.ERROR_MSG_SEARCH_PAGESIZE_MIN)
    @Builder.Default
    private Integer pageSize = 10;
}
