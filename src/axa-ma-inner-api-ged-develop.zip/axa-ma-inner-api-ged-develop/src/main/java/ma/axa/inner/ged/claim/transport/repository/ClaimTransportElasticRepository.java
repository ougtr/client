package ma.axa.inner.ged.claim.transport.repository;

import static ma.axa.inner.ged.util.ElasticSearchUtils.addDateRangeQuery;
import static ma.axa.inner.ged.util.ElasticSearchUtils.addDateTimeRangeQuery;
import static ma.axa.inner.ged.util.ElasticSearchUtils.addTermQuery;
import static ma.axa.inner.ged.util.ElasticSearchUtils.termQuery;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.transport.domain.DocumentClaimTransportEs;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportSearchParams;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.repository.ElasticSearchNewRepository;
import ma.axa.inner.ged.util.constants.ElasticConstants;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Slf4j
@Repository
@RequiredArgsConstructor
public class ClaimTransportElasticRepository {

	private final BrancheProperties transportProperties;
	private final ElasticSearchNewRepository elasticRepository;

	// ========== Delete actions ==========

	/**
	 * Delete Document from ElasticSearch by ID
	 * 
	 * @param id The id of document
	 * @return
	 */
	public boolean deleteDocument(String documentId) {
		if (StringUtils.isBlank(documentId))
			throw new IllegalArgumentException("documentId must not be blank");
		try {
			var response = elasticRepository.deleteDocument(transportProperties.getEsDocIndex(), documentId);
			if (response) {
				log.info("Hello ");
				log.debug("[es-repo]Successfully deleted document claim rd with id: {}", documentId);
				return true;
			}
		} catch (Exception e) {
			log.warn("[es-repo] Error deleting document by id: {}, err: {}", documentId, e.getMessage());
		}
		return false;
	}

	public boolean deleteBulk(List<String> ids) throws ElasticsearchException, IOException {
		if (ids == null || ids.isEmpty())
			throw new IllegalArgumentException("Documents ids must not be null or empty");
		try {
			return elasticRepository.bulkDeleteDocument(transportProperties.getEsDocIndex(), ids);
		} catch (ElasticsearchException | IOException e) {
			log.warn("[es-repo] Error deleting documents by ids: {}, err: {}", ids, e.getMessage());
			throw e;
		}
	}

	/** ========== Create actions ========== **/

	/**
	 * Create new Document in ElasticSearch
	 */
	public String createNewDocument(final String documentId, final DocumentClaimTransportEs metaData)
			throws ElasticsearchException, IOException {
		if (StringUtils.isBlank(documentId))
			throw new IllegalArgumentException("ID Document must not be blank");
		if (metaData == null)
			throw new NullPointerException("Document Claim RD must not be null");

		try {
			if (exists(documentId)) {
				throw new ResourceAlreadyExist(GlobalConstants.URI_RECORDE_ALREADY_EXIST,
						GlobalConstants.ERROR_MSG_RD_IDDOCUMENT_ALREADY_EXIST,
						new String[] { documentId });
			}
			var created = elasticRepository.createNewDocument(transportProperties.getEsDocIndex(), documentId,
					metaData);
			if (created != null) {
				log.info("[es-repo] Successfully created new document claim rd with id: {}", documentId);
				return created;
			}
		} catch (Exception e) {
			log.error("[es-repo] Error creating new document for id: {}, err: {} ", documentId, e.getMessage());
			throw e;
		}
		return null;
	}

	// ========== Update actions ==========

	public boolean updateDocument(final String documentId, final DocumentClaimTransportEs metaData)
			throws ElasticsearchException, IOException {
		return updateDocument(documentId, metaData, false);
	}

	public boolean upsertDocument(final String documentId, final DocumentClaimTransportEs metaData)
			throws ElasticsearchException, IOException {
		return updateDocument(documentId, metaData, true);
	}

	/**
	 * Update Document in ElasticSearch
	 */
	private boolean updateDocument(final String documentId, final DocumentClaimTransportEs metaData,
			boolean isUpsert)
			throws ElasticsearchException, IOException {
		if (StringUtils.isBlank(documentId))
			throw new IllegalArgumentException("Document ID must not be blank");
		if (metaData == null)
			throw new NullPointerException("Document Claim RD must not be null");

		try {
			var response = elasticRepository.updateDocument(transportProperties.getEsDocIndex(), documentId, metaData,
					isUpsert,
					DocumentClaimTransportEs.class);
			log.info("[es-repo] Successfully updatd new document claim rd with id: {}", documentId);
			return response;
		} catch (Exception e) {
			log.error("[es-repo] Error updating  document with id:{}, err: {}", documentId, e.getMessage());
			throw e;
		}
	}

	// ========== Finders ==========

	public Optional<DocumentClaimTransportEs> findById(String id) {
		try {
			refreshIndex();
			return Optional.of(elasticRepository.findById(transportProperties.getEsDocIndex(), id,
					DocumentClaimTransportEs.class));
		} catch (Exception e) {
			log.error("[es-repo] Error find document with id:{}, err: {}", id, e.getMessage());
			return Optional.empty();
		}
	}

	/**
	 * 
	 * @param reference
	 * @return The first found document
	 */
	public DocumentClaimTransportEs findOneDocumentByReference(String reference) {
		refreshIndex();
		BoolQuery.Builder boolQuery = new BoolQuery.Builder();
		boolQuery.must(termQuery(ElasticConstants.REFERENCE, reference));
		try {
			var searchRequest = new SearchRequest.Builder();
			searchRequest.index(transportProperties.getEsDocIndex())
					.query(q -> q.bool(boolQuery.build()));
			var searchResponse = elasticRepository.search(searchRequest, DocumentClaimTransportEs.class);
			if (searchResponse != null && !searchResponse.hits().hits().isEmpty()) {
				return searchResponse.hits().hits().get(0).source();
			}
		} catch (Exception e) {
			log.error("[es-repo] Error during search by reference: {} , err: {}", reference, e.getMessage());
		}
		return null;
	}

	public SearchResponse<DocumentClaimTransportEs> findByCriteria(DocClaimTransportSearchParams searchParams) {
		refreshIndex();
		try {
			var boolQuery = new BoolQuery.Builder();
			var query = getQueryForMultiSearch(searchParams);
			boolQuery.must(query);
			int from = searchParams.getPageNumber() * searchParams.getPageSize();

			var searchRequest = new SearchRequest.Builder();
			searchRequest.index(transportProperties.getEsDocIndex())
					.query(q -> q
							.bool(boolQuery.build()))
					.from(from)
					.size(searchParams.getPageSize());
			return elasticRepository.search(searchRequest, DocumentClaimTransportEs.class);
		} catch (Exception e) {
			log.error("Error during elastic search", e);
			return null;
		}
	}

	// ========== Finders ==========

	/**
	 * Check if document id exist
	 * 
	 * @param documentId
	 */
	public boolean exists(String documentId) {
		return elasticRepository.existsDocument(transportProperties.getEsDocIndex(), documentId);
	}

	/**
	 * Refresh Index
	 */
	public void refreshIndex() {
		try {
			elasticRepository.refreshIndex(transportProperties.getEsDocIndex());
		} catch (Exception e) {
			log.error("[ES] Error during refresh index, err: {}", e.getMessage());
		}
	}

	// =========== Utils ===========

	public static Query getQueryForMultiSearch(DocClaimTransportSearchParams searchParams) {
		var boolQuery = new BoolQuery.Builder();
		addTermQuery(ElasticConstants.NUM_POLICE, searchParams.getNumPolice(), boolQuery);
		addTermQuery(ElasticConstants.SINISTRE_NUMBER, searchParams.getSinistreNumber(), boolQuery);
		addTermQuery(ElasticConstants.CREATED_BY, searchParams.getCreatedBy(), boolQuery);
		addTermQuery(ElasticConstants.INTERMEDIAIRE_CODE, searchParams.getIntermediaireCode(), boolQuery);
		addTermQuery(ElasticConstants.BRANCHE_CODE, searchParams.getBrancheCode(), boolQuery);
		addTermQuery(ElasticConstants.BRANCHE_LABEL, searchParams.getBrancheLabel(), boolQuery);
		addTermQuery(ElasticConstants.PRODUIT_CODE, searchParams.getProduitCode(), boolQuery);
		addTermQuery(ElasticConstants.PRODUIT_LABEL, searchParams.getProduitLabel(), boolQuery);
		addTermQuery(ElasticConstants.IS_DRAFT, searchParams.getIsDraft(), boolQuery);
		addTermQuery(ElasticConstants.REFERENCE, searchParams.getReference(), boolQuery);
		addTermQuery(ElasticConstants.ASSURE_NOM, searchParams.getAssureNom(), boolQuery);
		addTermQuery(ElasticConstants.ASSURE_PRENOM, searchParams.getAssurePrenom(), boolQuery);
		addTermQuery(ElasticConstants.STATUS, searchParams.getStatus(), boolQuery);
		addTermQuery(ElasticConstants.LAST_UPDATED_BY, searchParams.getLastUpdatedBy(), boolQuery);
		
		addTermQuery(ElasticConstants.ENTITYCODE, searchParams.getEntityCode(), boolQuery);
		addTermQuery(ElasticConstants.TYPEDOCUMENTCODE, searchParams.getTypeDocumentCode(), boolQuery);
		addTermQuery(ElasticConstants.REPERTOIRE, searchParams.getRepertoire(), boolQuery);
		
		addDateRangeQuery(ElasticConstants.DATE_NUMERISATION, searchParams.getDateNumerisationFrom(),
				searchParams.getDateNumerisationTo(), boolQuery);
		addDateRangeQuery(ElasticConstants.DATE_RECEPTION, searchParams.getDateReceptionFrom(),
				searchParams.getDateReceptionTo(), boolQuery);
		addDateRangeQuery(ElasticConstants.DATE_SURVENANCE, searchParams.getDateSurvenanceFrom(),
				searchParams.getDateSurvenanceTo(), boolQuery);
		addDateTimeRangeQuery(ElasticConstants.CREATED_AT, searchParams.getCreatedAtFrom(),
				searchParams.getCreatedAtTo(), boolQuery);
		addDateTimeRangeQuery(ElasticConstants.LAST_UPDATED_AT, searchParams.getLastUpdateAtFrom(),
				searchParams.getLastUpdateAtTo(), boolQuery);
		return boolQuery.build()._toQuery();
	}
}
