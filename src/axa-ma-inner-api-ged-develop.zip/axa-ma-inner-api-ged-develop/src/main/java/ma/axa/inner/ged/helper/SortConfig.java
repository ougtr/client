package ma.axa.inner.ged.helper;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SortConfig {
 private String order;
}
