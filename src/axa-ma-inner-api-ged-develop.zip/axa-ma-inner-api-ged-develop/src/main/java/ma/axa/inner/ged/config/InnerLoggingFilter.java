package ma.axa.inner.ged.config;

import ma.axa.inner.ged.util.request.RequestFacade;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Component
class InnerLoggingFilter implements Filter {

    private static final String USER_NAME = "username";
    private static final String OUTER_ID = "outer-id";

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        MDC.put(USER_NAME, req.getHeader(RequestFacade.USER_NAME));
        MDC.put(OUTER_ID, req.getHeader(RequestFacade.OUTER_ID));

        try {
            chain.doFilter(request, response);
        } finally {
            cleanMDC();
        }
    }

    private void cleanMDC() {
        MDC.remove(USER_NAME);
        MDC.remove(OUTER_ID);
    }
}
