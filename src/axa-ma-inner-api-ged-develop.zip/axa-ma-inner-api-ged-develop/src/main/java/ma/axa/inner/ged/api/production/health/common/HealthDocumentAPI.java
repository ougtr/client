package ma.axa.inner.ged.api.production.health.common;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCReq;
import ma.axa.inner.ged.dto.production.health.common.DocHealthCommonReq;
import ma.axa.inner.ged.dto.production.health.common.DocHealthCommonResp;
import ma.axa.inner.ged.dto.production.health.common.DocHealthSearchParams;
import ma.axa.inner.ged.service.production.health.common.HealthDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/v1/health/documents")
@Tag(name = GlobalConstants.TAG_HEALTH_AMC_APIS, description = GlobalConstants.TAG_DESC_HEALTH_AMC_APIS)
@RequiredArgsConstructor
public class HealthDocumentAPI {

	private final HealthDocumentService service;

	@Operation(summary = "Download a health document by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was downloaded", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = Resource.class, format = "byte")) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping(value = "/{document_id}/content", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<Resource> downloadHealthDocContent(
			@Parameter(required = true, description = "The document id (Alfresco ID)") @NotBlank(message = "Document id must not be empty") @PathVariable(value = "document_id") String documentId) {
		log.info("[health-common-api] Start download file " + documentId);
		return service.downloadFile(documentId);
	}

	@Operation(summary = "Upload new health document and index meta-data")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Document ID", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = DocHealthAMCReq.class))}),
			@ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
	@PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<List<DocHealthCommonResp>> uploadHealthDoc(
			@ParameterObject @ModelAttribute @Valid DocHealthCommonReq docHealthReq,
			@RequestPart(value = "files", required = true) List<MultipartFile> files) {
		log.info("[health-common-api] Start Uploading files:  {}", files.size());
		var createdDocument = service.uploadHealthDocument(docHealthReq, files);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdDocument);
	}

	@Operation(summary = "Delete Health document by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was deleted", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = String.class))}),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
	@DeleteMapping(value = "/{document_id}")
	public ResponseEntity<String> deleteHealthDoc(
			@NotBlank(message = GlobalConstants.ERROR_MSG_RD_ID_NOT_BLANK) @PathVariable(value = "document_id") String documentId) {
		log.info("[health-common-api] Start delete file " + documentId);
		return ResponseEntity.ok(service.deleteDocument(documentId));
	}

	@Operation(summary = "Search Health Documents by policy number and integration id ")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was downloaded", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = Page.class))}),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
	@GetMapping
	public ResponseEntity<Page<DocHealthCommonResp>> searchHealthDoc(@Valid DocHealthSearchParams params) {
		log.info("[API] Multi Searching documents ...");
		var pageResult = service.search(params);
		return ResponseEntity.ok(pageResult);
	}


}