package ma.axa.inner.ged.claim.rd.mapper;

import java.util.Collections;
import java.util.Map;

import ma.axa.inner.ged.claim.rd.dto.DocClaimRdAddReq;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdUpdateReq;
import ma.axa.inner.ged.mapper.AlfrescoPropsMapper;
import ma.axa.inner.ged.util.StringUtil;

public class ClaimRdAlfrescoMapper extends AlfrescoPropsMapper {

	private ClaimRdAlfrescoMapper() throws InstantiationException {
		throw new InstantiationException("Instances of this type are forbidden");
	}

	/** ======= Folders ======= **/

	public static Map<String, Object> toFolderProperties(DocClaimRdAddReq metaData) {
		return toFolderProperties(metaData, null);
	}

	public static Map<String, Object> toFolderProperties(DocClaimRdAddReq metaData, Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();

		var alfrescoProps = AlfrescoFolderProperties.builder()
				.intermediareDossier(StringUtil.toString(metaData.getIntermediaireCode()))
				.numeroPoliceDossier(metaData.getNumPolice())
				.numeroSinistreDossier(metaData.getSinistreNumber())
				.codeProduit(StringUtil.toString(metaData.getProduitCode()))
				// .classeSinistre(StringUtil.toString(metaData.getBrancheCode()))
				.dateSurvenanaceDossier(metaData.getDateSurvenance())
				.nomVictimeDossier(metaData.getAssureNom())
				
				//TODO
				//NEW information
				.valeur_juridictionDossier(metaData.getValeur_juridiction())
				.num_tribunalDossier(metaData.getNum_tribunal())
				.LibBanqueDossier(metaData.getLibBanque())
				.numAdhesionDossier(metaData.getNumAdhesion())
				.numDeclarationDossier(metaData.getNumDeclaration())
				.correspondance_GDossier(metaData.getCorrespondance_G())
				.build();

		return toFolderProperties(properties, alfrescoProps);
	}

	/** ======= Documents ======= **/

	public static Map<String, Object> toDocumentProperties(DocClaimRdAddReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocClaimRdAddReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numPolice(metaData.getNumPolice())
				.numSinistre(metaData.getSinistreNumber())
				.identifiantScaner(metaData.getReference())
				.agentIntermediaire(StringUtil.toString(metaData.getIntermediaireCode()))
				.isAuthentique(metaData.isOriginal())
				
				//TODO
				//NEW information
				.valeur_juridiction(metaData.getValeur_juridiction())
				.num_tribunal(metaData.getNum_tribunal())
				.libBanque(metaData.getLibBanque())
				.numAdhesion(metaData.getNumAdhesion())
				.numDeclaration(metaData.getNumDeclaration())
				.correspondance_G(metaData.getCorrespondance_G())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}

	public static Map<String, Object> toDocumentProperties(DocClaimRdUpdateReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocClaimRdUpdateReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numPolice(metaData.getNumPolice())
				.numSinistre(metaData.getSinistreNumber())
				.identifiantScaner(metaData.getReference())
				.agentIntermediaire(StringUtil.toString(metaData.getIntermediaireCode()))
				.isAuthentique(metaData.isOriginal())
				
				//TODO
				//NEW information
				.valeur_juridiction(metaData.getValeur_juridiction())
				.num_tribunal(metaData.getNum_tribunal())
				.libBanque(metaData.getLibBanque())
				.numAdhesion(metaData.getNumAdhesion())
				.numDeclaration(metaData.getNumDeclaration())
				.correspondance_G(metaData.getCorrespondance_G())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}
}
