package ma.axa.inner.ged.domain.production.health.amc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.domain.production.ProductionDocumentEs;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentHealthAMCEs extends ProductionDocumentEs {
    @JsonProperty("quotation_id")
    private String quotationNumber;
    @JsonProperty("policy_number")
    private String policyNumber;
    @JsonProperty("product_code")
    private String productCode;
    @JsonProperty("demand_reference")
    private String demandReference;
}