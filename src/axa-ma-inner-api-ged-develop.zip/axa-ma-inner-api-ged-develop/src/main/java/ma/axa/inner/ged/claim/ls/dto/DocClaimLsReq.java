package ma.axa.inner.ged.claim.ls.dto;

import lombok.*;

import javax.validation.constraints.NotBlank;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocClaimLsReq  {
	@NotBlank(message = "reference est requis")
	private String reference;
	private String sinistreNumber;
	private String typeDocumentCode;
	private String filename;
	private boolean isOriginal;
	private String status ;

	private String uploadedBy;
	private String repertoire;
	private String repertoireCode;

}
