package ma.axa.inner.ged.repository.parametrage;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.domain.parametrage.BrancheParametrage;
import ma.axa.inner.ged.domain.parametrage.EntityParametrage;
import ma.axa.inner.ged.domain.parametrage.RepertoireParametrage;
import ma.axa.inner.ged.domain.parametrage.TypeDocumentParametrage;

@Repository
@Transactional
@RequiredArgsConstructor
@Slf4j
public class ParametrageRepository {
	
	private final JdbcTemplate jdbcTemplate;
	
	@SneakyThrows
	public List<BrancheParametrage> getAll(){
		List<BrancheParametrage> list;
		log.info("#################### Start calling for all branches  #######################");
		list = jdbcTemplate.query("SELECT * FROM ASADONNE.GEDBRAN", BeanPropertyRowMapper.newInstance(BrancheParametrage.class));
		log.info("#################### End calling for all branches  #######################");
		
		return list;
	}
	
	@SneakyThrows
	public List<EntityParametrage> getListEntityByIdBranche(int id){
		List<EntityParametrage> list;
		log.info("#################### Start calling for entity by branche  #######################");
		list = jdbcTemplate.query("SELECT * FROM ASADONNE.GEDENTI WHERE CODBRAN = ?", 
				BeanPropertyRowMapper.newInstance(EntityParametrage.class), id);
		log.info("#################### End calling for entity by branche  #######################");
		return list;
	}
	
	public List<TypeDocumentParametrage> getListTypeDocumentByIdEntity(int id){
		
		List<TypeDocumentParametrage> list;
		log.info("#################### Start calling for type document by entity  #######################");
		list = jdbcTemplate.query("SELECT * FROM ASADONNE.GEDTYPD WHERE CODE IN (SELECT CODTYPD FROM ASADONNE.LENTTYPD WHERE CODENTI = ? )", 
				BeanPropertyRowMapper.newInstance(TypeDocumentParametrage.class), id);
		log.info("#################### End calling for type document by entity  #######################");
		return list;
	}

	public List<RepertoireParametrage> getListRepertoireByIdDocument(int id, int idEntity){
		
		List<RepertoireParametrage> list;
		log.info("#################### Start calling for repertoire by type document #######################");
		list = jdbcTemplate.query("SELECT * FROM ASADONNE.GEDREPER WHERE CODE IN (SELECT CODREPER FROM ASADONNE.LREPERT WHERE CODTYPD = ? AND CODENTI = ?)", 
				BeanPropertyRowMapper.newInstance(RepertoireParametrage.class), id, idEntity);
		log.info("#################### End calling for repertoire by type document #######################");	
		return list;
		
	}

	public List<RepertoireParametrage> getListRepertoire() {
		List<RepertoireParametrage> list;
		log.info("#################### Start calling for repertoire #######################");
		list = jdbcTemplate.query("SELECT * FROM ASADONNE.GEDREPER",
				BeanPropertyRowMapper.newInstance(RepertoireParametrage.class));
		log.info("#################### End calling for repertoire #######################");
		return list;
	}
	
}
