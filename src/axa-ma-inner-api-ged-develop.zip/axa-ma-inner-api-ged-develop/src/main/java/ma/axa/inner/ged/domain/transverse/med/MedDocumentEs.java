package ma.axa.inner.ged.domain.transverse.med;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MedDocumentEs {

	private String id;
	String typeQuittance;
	String typeAnnotation;
	@JsonProperty("file_name")
	private String filename;
	@JsonProperty("path")
	private String path;

}
