package ma.axa.inner.ged.mapper.production.health.amc;

import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import ma.axa.inner.ged.domain.production.health.amc.DocumentHealthAMCEs;

import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCReq;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCResp;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCUpdateReq;
import ma.axa.inner.ged.mapper.MapstructUtil;
import org.mapstruct.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE,uses = MapstructUtil.class)
public interface HealthAMCMapper {

	// -> TO DTO
	DocHealthAMCUpdateReq toUpdateDto(DocumentHealthAMCEs documentEs);

	@Mapping(source = "filesize",target = "filesize",qualifiedByName = "mapToFileSize")
	DocHealthAMCResp toDto(DocumentHealthAMCEs document);

	List<DocHealthAMCResp> toDtoList(List<DocumentHealthAMCEs> documents);

	// -> FROM DTO

	DocumentHealthAMCEs fromDto(DocHealthAMCReq documentRes);

	List<DocumentHealthAMCEs> fromDto(List<DocHealthAMCReq> documentRes);

	DocumentHealthAMCEs fromDto(DocHealthAMCUpdateReq documentReq);

	// -> update
	@BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
	void updateFromDto(DocHealthAMCUpdateReq documentReq, @MappingTarget DocumentHealthAMCEs document);

	// Others
	static Page<DocumentHealthAMCEs> mapToPage(SearchResponse<DocumentHealthAMCEs> searchResponse, int from,
											   int size) {
		if (searchResponse == null || searchResponse.hits().hits().isEmpty() || searchResponse.hits().total() == null) {
			return Page.empty();
		} else {
			long totalElements = searchResponse.hits().total().value();
			List<DocumentHealthAMCEs> results = searchResponse.hits().hits().stream()
					.map(Hit::source)
					.collect(Collectors.toList());
			PageRequest pageRequest = PageRequest.of(from, size);
			return new PageImpl<>(results, pageRequest, totalElements);
		}
	}
}