package ma.axa.inner.ged.helper;

import lombok.RequiredArgsConstructor;
import ma.axa.inner.ged.dto.at.PageDto;
import org.apache.chemistry.opencmis.client.api.ItemIterable;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;


@Component
@RequiredArgsConstructor
public class PaginationATHelper {

    public static Pair<Pair<Integer, Integer>, Pair<Integer, Integer>> getObjectOfStartAndSizeToGetFrom(Integer countFromDefault, Integer countFromTemporary, Integer desiredSize, Integer page) {
        var fromDefault = 0;
        var fromTemporary = 0;
        Pair<Integer, Integer> pair = null;
        for (int i = 0; i <= page; i++) {
            pair = getSizeToGetFromEachOnFirstPage(countFromDefault - fromDefault, countFromTemporary - fromTemporary, desiredSize);
            if (pair.getKey() > 0 && i != page)
                fromDefault = fromDefault + pair.getKey();
            if (pair.getValue() > 0 && i != page)
                fromTemporary = fromTemporary + pair.getValue();
        }
        return Pair.of(Pair.of(fromDefault, fromTemporary), pair);
    }

    private static Pair<Integer, Integer> getSizeToGetFromEachOnFirstPage(Integer countFromDefault, Integer countFromTemporary, Integer desiredSize) {
        final var desiredSizesHalf = Math.round((float) desiredSize / 2);
        if (countFromDefault >= desiredSizesHalf && countFromTemporary >= desiredSizesHalf) {
            return Pair.of(desiredSizesHalf, desiredSize -desiredSizesHalf);
        } else if (countFromDefault < desiredSizesHalf) {
            if (desiredSize - countFromDefault <= countFromTemporary)
                return Pair.of(countFromDefault, desiredSize - countFromDefault);
            else
                return Pair.of(countFromDefault, countFromTemporary);
        } else {
            if (desiredSize - countFromTemporary <= countFromDefault)
                return Pair.of(desiredSize - countFromTemporary, countFromTemporary);
            else
                return Pair.of(countFromDefault, countFromTemporary);
        }
    }

    public static <T,R> PageDto<R> getPageWithMapping(List<T> sourceList, int page, int pageSize, int contentSize, Function<T,  R> mapper) {
        if (pageSize < 0 || page < 0) {
            throw new IllegalArgumentException("invalid page size: " + pageSize);
        }
        List<R> result = new ArrayList<>();
        var fromIndex = page * pageSize;
        if (sourceList == null) {
            return null;
        }
        else if(sourceList.isEmpty()){
            return PageDto.<R>builder().pageNumber(0).totalElements(0).content(result).totalPages(0).build();
        }
        else if( sourceList.size() <= fromIndex){
            return null;
        }
        var totalPages = (int) Math.ceil((double) contentSize / (double) pageSize);
        sourceList = sourceList.subList(fromIndex, Math.min(fromIndex + pageSize, sourceList.size()));
        if(mapper != null){
            result = sourceList.stream().map(mapper).collect(Collectors.toList());
        }
        return PageDto.<R>builder().pageNumber(page).totalPages(totalPages).content(result).totalElements(contentSize).build();
    }

    public static <T,R> PageDto<R> getPageWithMappingForItemIterable(ItemIterable<T> sourceList, int page, int pageSize, int contentSize, Function<T,  R> mapper) {
        if (pageSize < 0 || page < 0) {
            throw new IllegalArgumentException("invalid page size: " + pageSize);
        }
        final List<R> result = new ArrayList<>();
        var fromIndex = page * pageSize;
        if (sourceList == null || mapper == null) {
            return null;
        }
        else if(sourceList.getTotalNumItems() ==0){
            return PageDto.<R>builder().pageNumber(0).totalElements(0).content(result).totalPages(0).build();
        }
        else if( sourceList.getTotalNumItems() <= fromIndex){
            return null;
        }
        var totalPages = (int) Math.ceil((double) contentSize / (double) pageSize);
        sourceList=sourceList.skipTo(fromIndex).getPage(pageSize);

        sourceList.iterator().forEachRemaining(cmisObject->
                Optional.ofNullable(mapper.apply(cmisObject)).ifPresent(result::add)
        );

        return PageDto.<R>builder().pageNumber(page).totalPages(totalPages).content(result).totalElements(contentSize).build();
    }
}
