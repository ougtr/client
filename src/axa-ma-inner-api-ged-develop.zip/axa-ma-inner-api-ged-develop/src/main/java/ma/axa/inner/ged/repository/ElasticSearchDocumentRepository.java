package ma.axa.inner.ged.repository;

import feign.FeignException;
import ma.axa.inner.ged.domain.*;
import ma.axa.inner.ged.domain.at.ESDocumentAtSchema;
import ma.axa.inner.ged.domain.at.EsDocumentAtCountSchema;
import ma.axa.inner.ged.dto.CimaRequestDocument;
import ma.axa.inner.ged.helper.RequestQuery;
import ma.axa.inner.ged.helper.update.ESUpdateQuery;
import ma.axa.inner.ged.helper.updateAt.ESAtUpdateQuery;
import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.*;

@FeignClient(url = "${axa.es.host}:${axa.es.port}", name = "ES-CLIENT")
public interface ElasticSearchDocumentRepository {

	@PostMapping("/{indexToUse}/_search")
	ESDocumentSchema getDocuments(@PathVariable String indexToUse,@RequestBody RequestQuery query);
	
	@PostMapping("/${axa.es.auto.dossier.index}/_search")
	ESDossierSchema getDossiers(@RequestBody RequestQuery query);
	
	@PostMapping(value="${axa.es.auto.dossier.index}/${axa.es.auto.dossier.type}/{id}")
	ESResponse addIndexDossierSinAuto(@RequestBody DossierSinistreAuto dossierSinistreAuto, @PathVariable String id);
	
	@PostMapping("/{indexToUse}/${axa.es.auto.document.type}/{idAlfresco}")
	ESResponse addIndex(@RequestBody PreDeclarationTypeDoc preDeclarationTypeDoc,@PathVariable String indexToUse, @PathVariable String idAlfresco);
	
	@PostMapping("/${axa.es.production.document.index}/${axa.es.production.document.type}/{idAlfresco}")
	ESResponse addIndexProduction(@RequestBody ESDocumentProductionRequest esDocumentProductionRequest, @PathVariable String idAlfresco);
	
	@PostMapping("/${axa.es.production.dossier.index}/${axa.es.production.dossier.type}/{idAlfresco}")
    ESResponse addIndexDossierProduction(@RequestBody ESDossierProductionRequest esDossierProductionRequest, @PathVariable String idAlfresco);

	@PostMapping("/${axa.es.production.health.dossier.index}/${axa.es.production.health.dossier.type}/{idAlfresco}")
    ESResponse addIndexDossierProductionHealth(@RequestBody ESDossierProductionRequest esDossierProductionRequest, @PathVariable String idAlfresco);


	@PostMapping(value = "/_bulk",produces = "application/json")
	EsMultipleResponses multipleActionRequests(@RequestBody String bulkQuery);
	// auto
	@PostMapping("/{indexToUse}/${axa.es.auto.document.type}/{idAlfresco}/_update")
	ESResponse updateMetadata(@RequestBody ESUpdateQuery updateQuery, @PathVariable String idAlfresco ,@PathVariable String indexToUse);

	@GetMapping("/{index}")
	void checkIndexExistence(@PathVariable String index) throws FeignException;

	@PutMapping("/${axa.es.auto.document.temp-index}")
	ESResponseIndex createTemporaryIndex() throws FeignException;

	@PostMapping("/${axa.es.auto.document.temp-index}/${axa.es.auto.document.type}/{idAlfresco}")
	ESResponse addIndexToTemporary(@RequestBody PreDeclarationTypeDoc preDeclarationTypeDoc, @PathVariable String idAlfresco);

	@DeleteMapping("/{indexToUse}/${axa.es.auto.document.type}/{idAlfresco}?refresh=true")
	ESResponse deleteDocumentsMetadata(@PathVariable String indexToUse,@PathVariable String idAlfresco);



	// at
	@PostMapping("/${axa.es.at.dossier.index}/${axa.es.at.dossier.type}/{numSinistre}")
	ESResponse addIndexDossierAT(@RequestBody ESDossierATRequest esDossierAT, @PathVariable String numSinistre) throws FeignException;

	@PostMapping("/${axa.es.at.document.index}/${axa.es.at.document.type}")
	ESResponse addIndexDocumentAT(@RequestBody ESDocumentATRequest esDocumentAT) throws FeignException;

	@PutMapping("/{temp_index}/${axa.es.at.document.type}")
	ESResponseIndex createAtTemporaryIndex(@PathVariable(name = "temp_index") String tempIndex) throws FeignException;

	@PostMapping("/{indexAt}/${axa.es.at.document.type}/{idAlfresco}")
	ESResponse addAtIndex(@PathVariable String indexAt,@RequestBody ESDocumentATRequest esDocumentATRequest,  @PathVariable String idAlfresco);

	@DeleteMapping("/{indexAt}/${axa.es.at.document.type}/{idAlfresco}")
	ESResponse deleteAtDocumentsMetadata(@PathVariable String indexAt,@PathVariable String idAlfresco);

	@PostMapping("/{indexAt}/_search")
	ESDocumentAtSchema getAtDocuments(@PathVariable String indexAt,@RequestBody RequestQuery query);

	@PostMapping("/{indexAt}/_count")
	EsDocumentAtCountSchema countAtDocumentsByQuery(@PathVariable String indexAt, @RequestBody RequestQuery query);

	@PostMapping("/{indexAt}/${axa.es.at.document.type}/{idAlfresco}/_update")
	ESResponse updateAtMetadata(@RequestBody ESAtUpdateQuery updateQuery, @PathVariable String idAlfresco,@PathVariable String indexAt);

	@PostMapping("/{indexAt}/${axa.es.at.document.type}/{idAlfresco}")
	ESResponse addMobileScanIndex(@PathVariable String indexAt,@RequestBody ESDocMobileScanRequest esDocMobileScanRequest,  @PathVariable String idAlfresco);

	@PostMapping("/${axa.es.cima.document.index}/${axa.es.cima.document.type}/{idAlfresco}")
	ESResponse addDocumentCima(@RequestBody CimaRequestDocument esDocumentATRequest, @PathVariable String idAlfresco);

	@PutMapping("/${axa.es.cima.document.index}")
	ESResponseIndex createCimaIndex() throws FeignException;
}
