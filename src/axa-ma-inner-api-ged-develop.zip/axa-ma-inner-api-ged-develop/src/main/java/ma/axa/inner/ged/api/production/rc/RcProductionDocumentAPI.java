package ma.axa.inner.ged.api.production.rc;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.domain.ProductionTypeDoc;
import ma.axa.inner.ged.domain.production.ProductionDemandDoc;
import ma.axa.inner.ged.dto.DemandUploadResponseDto;
import ma.axa.inner.ged.dto.production.rc.RcProductionDocumentRequest;
import ma.axa.inner.ged.service.production.ProductionDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Tag(name = GlobalConstants.RC_GED_APIS_TAG)
@RestController
@RequestMapping("/v1/production/rc/documents")
@RequiredArgsConstructor
@Slf4j
public class RcProductionDocumentAPI {

    private final ProductionDocumentService rcProductionDocumentService;

    @Operation(summary = "Upload new production rc document and index meta-data")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document ID", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = RcProductionDocumentRequest.class)) }),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content) })
    @PostMapping(path="/upload",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> uploadRcProductionDocuments(
            @ParameterObject @ModelAttribute @Valid ProductionTypeDoc documentMeta,
            @RequestParam(value = "file", required = true) MultipartFile file) {
        var createdDocument = rcProductionDocumentService.uploadFile(file,documentMeta);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdDocument);
    }
   
    @Operation(summary = "download a production document by alfresco_id ")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was downloaded", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = Resource.class))}),
            @ApiResponse(responseCode = "404", description = "document not found with id", content = @Content),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<Resource> downloadFile(@NotNull(message = "{error.alfresco.id}") @PathVariable(value = "id", required = true) String alfrescoIdWithoutPrefix) {
        log.info("Start api: Downloading file with id '{}'", alfrescoIdWithoutPrefix);
        var resource = rcProductionDocumentService.downloadFile(alfrescoIdWithoutPrefix);

        var headers = new HttpHeaders();
        String headerKey = "X-filename";
        String headerValue = resource.getFilename();
        headers.set(headerKey,headerValue);
        log.info("End api: File downloaded !");
        return ResponseEntity.ok().headers(headers).body(resource);
    }

    @SneakyThrows
    @Operation(summary = "uploader un document production pour une demand")
    @PostMapping(path="/demands/upload",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public List<DemandUploadResponseDto> uploadRcDemandFile(@ParameterObject @ModelAttribute @Valid ProductionDemandDoc productionDemandDoc,
            @RequestPart(value = "files", required = true) List<MultipartFile> files){
        log.info("Start: Uploading file (document demand production)");
        var ids = rcProductionDocumentService.uploadDemandFiles(files, productionDemandDoc);
        return ids;
    }
}
