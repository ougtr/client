package ma.axa.inner.ged.dto.at;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode
public class TypeDocDto {
    private Integer id;
    private Integer familyId;
    private String label;
    private Integer repositoryId;
    private Integer cellId;
}
