package ma.axa.inner.ged.service.production.health.amc;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch.core.search.Hit;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.alfresco.DocumentAlfresco;
import ma.axa.inner.ged.domain.production.health.amc.DocumentHealthAMCEs;
import ma.axa.inner.ged.dto.CommonResponse;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCReq;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCResp;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCSearchParams;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCUpdateReq;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.RequestValidationException;
import ma.axa.inner.ged.exception.ResourceNotFoundException;
import ma.axa.inner.ged.mapper.production.health.amc.HealthAMCAlfrescoMapper;
import ma.axa.inner.ged.mapper.production.health.amc.HealthAMCMapper;
import ma.axa.inner.ged.repository.production.health.amc.HealthAMCElasticRepository;
import ma.axa.inner.ged.service.AlfrescoGedService;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Slf4j
@Service
@RequiredArgsConstructor
public class HealthAMCDocumentService {

    private final BrancheProperties healthAMCProperties;
    private final HealthAMCMapper amcMapper;

    private final AlfrescoGedService alfrescoService;
    private final HealthAMCElasticRepository elasticHealthAMCRepository;

    /**
     * Searching documents in elasticSearch
     *
     * @param searchParams
     * @return {@link Page} of founded documents
     */
    public Page<DocHealthAMCResp> search(@NotNull DocHealthAMCSearchParams searchParams) {
        log.info("[health-amc-api] start multi search");
        var response = elasticHealthAMCRepository.findByCriteria(searchParams,false);
        var page = HealthAMCMapper.mapToPage(response, searchParams.getPageNumber(), searchParams.getPageSize());
        return page.map(amcMapper::toDto);
    }

    /**
     * Upload new document to Alfresco and index meta-data in ES
     *
     * @param metaData Meta data of document
     * @param files    Documents Content
     * @return
     * @throws Exception
     */
    public List<DocHealthAMCResp> uploadDocWithMetaData(DocHealthAMCReq metaData, List<MultipartFile> files) {
        log.info("[health-amc-api] upload document ");
        try {
            List<DocumentHealthAMCEs> esDocuments = new ArrayList<>();
            for (MultipartFile file : files) {
                var documentEs = amcMapper.fromDto(metaData);
                documentEs.setFilesize(file.getSize());
                if (FileUtil.isValidFile(file)) {
                    String filename = file.getOriginalFilename();
                    if (filename != null) {
                        FileUtil.assertFileNameValid(filename);
                    }
                    var folderProperties = HealthAMCAlfrescoMapper.toFolderProperties(metaData);
                    var targetFolder = alfrescoService.prepareDocumentFolder(healthAMCProperties.getAlfrescoRootFolder(),healthAMCProperties.getAlfrescoSitePath(),folderProperties,!StringUtils.isEmpty(metaData.getPolicyNumber())? metaData.getPolicyNumber() : metaData.getDemandReference());

                    // Upload Document to alfresco
                    DocumentAlfresco createdDocument = null;
                    Map<String, Object> properties = HealthAMCAlfrescoMapper.toDocumentProperties(metaData);
                    createdDocument = alfrescoService.createDocument(targetFolder, filename, file, properties, true);
                    if (createdDocument == null) {
                        return null;
                    }
                    // Indexing document in ES
                    alfrescoService.indexDocument(createdDocument,documentEs,GlobalConstants.HEALTH_AMC_GED_BRANCHE_LABEL);
                    elasticHealthAMCRepository.createNewDocument(documentEs.getId(), documentEs);
                    esDocuments.add(documentEs);
                }
            }
            return amcMapper.toDtoList(esDocuments);
        } catch (ElasticsearchException | IOException e) {
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
        }
    }

    public CommonResponse validationUpdateRequest(DocumentHealthAMCEs documentEs) {
        var response = CommonResponse.builder();
        var error = new HashMap<String, String>();
        if (!validStatus(documentEs.getStatus(), documentEs.getPolicyNumber())) {
            error.put("status", "Must fill policy Number number to update status = CLOTURE");
        }

        response.msgErrors(error);
        response.success(error.isEmpty());
        return response.build();
    }

    public static boolean validStatus(String status, String policyNumber) {
        if (null != status && status.equals("CLOTURE")) {
            return StringUtils.isNotBlank(policyNumber);
        }
        return true;
    }

    /**
     * @throws IOException
     * @throws ElasticsearchException
     * @throws ResourceNotFoundException
     **/
    public DocHealthAMCResp updateDocument(String documentId, DocHealthAMCUpdateReq metaData) {
        log.info("[health-amc-api] update document ");
        if (metaData == null)
            throw new NullPointerException("Document meta-data to be updated must no be null");
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("documentId must not be null");

        var isExistInElastic = elasticHealthAMCRepository.exists(documentId);
        if (!isExistInElastic)
            throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
                    "Document with id '{0}' not found", new String[]{documentId});
        var documentEs = elasticHealthAMCRepository.findById(documentId)
                .orElseThrow(() -> new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
                        "Document Not Found"));
        amcMapper.updateFromDto(metaData, documentEs);
        // validation
        var isValid = validationUpdateRequest(documentEs);
        if (isValid != null && !isValid.isSuccess()) {
            throw new RequestValidationException("Error validation", isValid.getMsgErrors());
        }
        try {
            // Update Alfresco meta-data, is optional
            updateDocumentAlfrescoProps(documentId, metaData);
            log.debug("[health-amc-service] start update elastic document properties...");
            elasticHealthAMCRepository.updateDocument(documentId, documentEs);
            var updated = elasticHealthAMCRepository.findById(documentId).orElse(null);
            return amcMapper.toDto(updated);
        } catch (Exception e) {
            var err = " when update Document, err: " + e.getMessage();
            log.error(err);
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, err);
        }
    }

    public void updateDocumentAlfrescoProps(String documentId, DocHealthAMCUpdateReq metaData) {
        try {
            log.info("[health-amc-service] start update alfresco document properties...");
            Map<String, Object> properties = HealthAMCAlfrescoMapper.toDocumentProperties(metaData);
            alfrescoService.updateDocumentProperties(documentId, properties);
        } catch (Exception e) {
            log.warn("[health-amc-service] Error during update alfresco meta-data for id: {}, err: {} ", documentId,
                    e.getMessage());
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
        }
    }

    public String deleteDocument(String id) {

        log.debug("[health-amc-api] delete document " + id);
        // Delete doc from alfresco and ES
        try {
            alfrescoService.deleteDocument(id);
            elasticHealthAMCRepository.deleteDocument(id);
        } catch (Exception e) {
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR,
                    e.getMessage());
        }

        return id;
    }

    public void tagAllDocumentsByPolicyNumber(String policyNumber,String idQuotation,String userName) {
        log.info("[health-amc-api] tag documents by policyNumber " + policyNumber);
        DocHealthAMCSearchParams params = DocHealthAMCSearchParams.builder().idQuotation(idQuotation).build();
        var response = elasticHealthAMCRepository.findByCriteria(params,true);
        List<DocumentHealthAMCEs> results = response.hits().hits().stream()
                .map(Hit::source)
                .collect(Collectors.toList());
        for (DocumentHealthAMCEs doc :results) {
            indexDocByPolicyNumber(doc,policyNumber,userName);
        }
    }

    private void indexDocByPolicyNumber(DocumentHealthAMCEs doc, String policyNumber,String userName) {
        var documentEs = elasticHealthAMCRepository.findById(doc.getId())
                .orElseThrow(() -> new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
                        "Document Not Found"));
        documentEs.setPolicyNumber(policyNumber);
        documentEs.setLastUpdatedBy(userName);
        try {
            elasticHealthAMCRepository.updateDocument(doc.getId(), documentEs);
        } catch (Exception e) {
            var err = " when update Document, err: " + e.getMessage();
            log.error(err);
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, err);
        }
    }

}