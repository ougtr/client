package ma.axa.inner.ged.dto.cima.auto;

public enum CountryCode {
	MA,
    SN,
    CI,
    GA,
    CA
}
