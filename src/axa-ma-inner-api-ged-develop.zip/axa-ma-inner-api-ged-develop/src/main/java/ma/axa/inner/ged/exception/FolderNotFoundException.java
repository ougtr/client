package ma.axa.inner.ged.exception;

public class FolderNotFoundException extends Exception{

	private static final long serialVersionUID = 6833729042012371043L;
	
	public FolderNotFoundException(String message) {
		super(message);
	}

}
