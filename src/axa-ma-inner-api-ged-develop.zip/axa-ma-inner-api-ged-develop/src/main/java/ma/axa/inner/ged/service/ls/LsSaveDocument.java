package ma.axa.inner.ged.service.ls;

import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.CommonResponse;
import ma.axa.inner.ged.dto.DocumentLsPrevoyanceRequest;
import ma.axa.inner.ged.dto.SearchLsPrevoyanceResponse;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.RequestValidationException;
import ma.axa.inner.ged.mapper.LsPrevoyanceMapper;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;
import ma.axa.inner.ged.dto.LsDocumentRequest;
import ma.axa.inner.ged.exception.CallStoredProcedureException;
import ma.axa.inner.ged.repository.LsDocumentsRepository;

import java.util.HashMap;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
@Slf4j
public class LsSaveDocument {

	private final LsPrevoyanceMapper lsPrevoyanceMapper;
	private final LsDocumentsRepository documentRepository;

	public String saveLsMetadataDocument(LsDocumentRequest  documentRequest) {
		log.info("Start saveLsMetadataDocument service : '{}'", documentRequest.toString());
		try {
			
			String response = documentRepository.saveLsMetadataDocument(documentRequest);

			log.info("End saveLsMetadataDocument service - '{}'", response);
			return response;
			
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new CallStoredProcedureException(e.getMessage());
		}
	}

	public String saveNewLsPrevoyaneDoc(DocumentLsPrevoyanceRequest doc,String idAlfresco) {
		log.info("Start service : Saving ls prevoyane document with metadata '{}' and idAlfresco'{}", doc,idAlfresco);
		return  documentRepository.saveNewLsPrevoyaneDoc(doc,idAlfresco);
	}

	public List<SearchLsPrevoyanceResponse> searchLsPrevoyanceDocuments(String idGestion) {
		log.info("Start service : Search list of documents with id gestion '{}' ", idGestion);

		var idGestionIsValid = validationRequest(idGestion, "{error.ls.id.gestion.not-empty}");
		if( (idGestionIsValid != null && !idGestionIsValid.isSuccess())){
			throw new RequestValidationException(GlobalConstants.URI_BUSINESS_REQUEST_VALIDATION, idGestionIsValid.getMsgErrors());
		}
		List<SearchLsPrevoyanceResponse> result = null;
		result = lsPrevoyanceMapper.toDto(documentRepository.searchLsPrevoyanceDocuments(idGestion));
		log.info("End service : Search list of documents with id gestion '{}'", idGestion);
		return result;
	}

	public CommonResponse validationRequest(String param, String msg) {
		var response = CommonResponse.builder();
		var error = new HashMap<String, String>();
		if (StringUtils.isBlank(param)) {
			error.put(param, msg);
		}
		response.msgErrors(error);
		response.success(error.isEmpty());
		return response.build();
	}

	public String deleteLsPrevoyanceMetadata(String documentId) {
		log.error("Start : deleting metadata ");

		var idDocIsValid = validationRequest(documentId,"{error.id.doc.not-empty}");
		if((idDocIsValid != null && !idDocIsValid.isSuccess())) {
			throw new RequestValidationException(GlobalConstants.URI_BUSINESS_REQUEST_VALIDATION, idDocIsValid.getMsgErrors());
		}

		String resp;
		try {
			resp = documentRepository.deleteLsPrevoyanceMetadata(documentId);
		}catch (Exception e){
			log.error("can not delete document metadata from as400 we get error '{}'",e.getMessage());
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR,e.getMessage());
		}
		return resp;
	}

	public String deleteLsSubscriptionDocumentMetadata(String token , String documentId, String productCode, String documentType, String actionCode) {

		try {
			log.info("Start deleting metadata document {} for subscription {}",documentId,token);
			return documentRepository.deleteLsSubscriptionMetadata(token,documentId,productCode,documentType,actionCode);
		}catch (Exception e){
			log.error("Error while trying deleting metadata document {} of subscription {}",documentId,token);
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR,e.getMessage());
		}
	}
}

