package ma.axa.inner.ged.service.ac;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.GedProperties;
import ma.axa.inner.ged.domain.*;
import ma.axa.inner.ged.dto.ChangesQueryDto;
import ma.axa.inner.ged.dto.CopyDocumentsQueryDto;
import ma.axa.inner.ged.exception.DocumentNotFoundException;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.helper.ElasticSearchHelper;
import ma.axa.inner.ged.mapper.DocumentMapper;
import ma.axa.inner.ged.mapper.PredeclarationTypeDocMapper;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.service.ManageDocumentService;
import ma.axa.inner.ged.util.DateUtils;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.ObjectUtils;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;


@Service
@Slf4j
public class ClaimAutoDocumentService extends ManageDocumentService {

    private final GedProperties gedProperties;
    private final ElasticSearchHelper elasticSearchHelper;

    private final PredeclarationTypeDocMapper predeclarationTypeDocMapper;

    public ClaimAutoDocumentService(ClaimDocumentRepository claimDocumentRepository, GedProperties gedProperties,
                                    ElasticSearchHelper elasticSearchHelper, PredeclarationTypeDocMapper predeclarationTypeDocMapper) {
        super(claimDocumentRepository);
        this.gedProperties = gedProperties;
        this.elasticSearchHelper = elasticSearchHelper;
        this.predeclarationTypeDocMapper = predeclarationTypeDocMapper;
    }

    private String pathFromDateDoc() {
        var date = LocalDate.now();
        return date.getYear() + "/" + date.getMonthValue() + "/" + date.getDayOfMonth();
    }


    @SneakyThrows

    public String uploadFile(MultipartFile file) {
        var idAlfresco = "";

        log.info("          " + gedProperties.toString());

        if (file != null && file.getOriginalFilename() != null && file.getContentType() != null) {
            String filename = file.getOriginalFilename();
            if (filename != null) {
                FileUtil.assertFileNameValid(filename);
            }
            idAlfresco = uploadFile(DocumentMapper.mapFileToGedDocument(file));

        }
        return idAlfresco;
    }

    @SneakyThrows
    public String uploadFile(MultipartFile file, PreDeclarationTypeDoc documentSinistreAuto, IndexOrPathToUse indexOrPathToUse) {
        log.info("Start : indexing dossier sinistre with data '{}'", documentSinistreAuto);
        if (file != null && file.getOriginalFilename() != null && file.getContentType() != null) {
            String filename = file.getOriginalFilename();
            if (filename != null) {
                FileUtil.assertFileNameValid(filename);
            }

            var idAlfresco = uploadFile(indexOrPathToUse, DocumentMapper.mapFileToGedDocument(file));
            if (documentSinistreAuto != null && documentSinistreAuto.getFormaDoc() != null) {
                documentSinistreAuto.setFormaDoc(FileUtil.replaceMimeTypeWithReadableFormDoc(documentSinistreAuto.getFormaDoc()));
            }
            var esoutput = elasticSearchHelper.addDocumentSinistre(documentSinistreAuto, idAlfresco, indexOrPathToUse);

            indexingConnexeSinistre(file, indexOrPathToUse, esoutput, documentSinistreAuto);

            log.info("End Service : Indexing dossier sinistre with output '{}'", esoutput);
            return idAlfresco;
        }
        log.info("End Service : indexing dossier sinistre terminated");
        return null;
    }

    @SneakyThrows
    public String uploadTestFile(MultipartFile file, PreDeclarationTypeDoc documentSinistreAuto, IndexOrPathToUse indexOrPathToUse) {
        log.info("Start : indexing dossier sinistre with data '{}'", documentSinistreAuto);
        if (file != null && file.getOriginalFilename() != null && file.getContentType() != null) {
            String filename = file.getOriginalFilename();
            if (filename != null) {
                FileUtil.assertFileNameValid(filename);
            }

            var idAlfresco = uploadTestFile(indexOrPathToUse, DocumentMapper.mapFileToGedDocument(file));
            if (documentSinistreAuto != null && documentSinistreAuto.getFormaDoc() != null) {
                documentSinistreAuto.setFormaDoc(FileUtil.replaceMimeTypeWithReadableFormDoc(documentSinistreAuto.getFormaDoc()));
            }
            var esoutput = elasticSearchHelper.addDocumentSinistre(documentSinistreAuto, idAlfresco, indexOrPathToUse);

            indexingConnexeSinistre(file, indexOrPathToUse, esoutput, documentSinistreAuto);

            log.info("End Service : Indexing dossier sinistre with output '{}'", esoutput);
            return idAlfresco;
        }
        log.info("End Service : indexing dossier sinistre terminated");
        return null;
    }

    public <T> void indexingConnexeSinistre(T file, IndexOrPathToUse indexOrPathToUse, ESResponse esoutput, PreDeclarationTypeDoc documentSinistreAuto) {
        if (IndexOrPathToUse.DEFAULT.equals(indexOrPathToUse) && Objects.nonNull(esoutput) && Boolean.TRUE.equals(esoutput.getCreated()) && Objects.nonNull(documentSinistreAuto) && CollectionUtils.isNotEmpty(documentSinistreAuto.getConnexeSinistres())) {
            if (file == null || (!MultipartFile.class.isAssignableFrom(file.getClass()) && !Objects.equals(file.getClass(), GedDocument.class))) {
                return;
            }
            final var gedDocument = (Objects.equals(file.getClass(), GedDocument.class)) ? file : DocumentMapper.mapFileToGedDocument((MultipartFile) file);
            var idAlfresco = "";

            for (var connexe : documentSinistreAuto.getConnexeSinistres()) {
                documentSinistreAuto.setNSin(connexe);
                idAlfresco = uploadFile(IndexOrPathToUse.DEFAULT, (GedDocument) gedDocument);
                elasticSearchHelper.addDocumentSinistre(documentSinistreAuto, idAlfresco, IndexOrPathToUse.DEFAULT);
            }
        }
    }

    public String uploadFile(IndexOrPathToUse indexOrPathToUse, GedDocument gedDocument) {
        log.info("Start: creating arborecense in alfresco repository");

        var prefixPath = gedProperties.getSearchdoc();
        var path = pathFromDateDoc();
        if (indexOrPathToUse.equals(IndexOrPathToUse.TEMPORARY)) {
            prefixPath = gedProperties.getOutbox();
        }
        var folder = claimDocumentRepository.createArboFoldersByPath(prefixPath, path);
        log.info("End: creating arborecense in alfresco repository with path '{}'", prefixPath + path);
        if (folder == null) {
            log.error("can not create/open dossier (floder) is null");
            throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
        }
        Map<String, Object> properties = new HashMap<>();
        properties.put(AXADocPropertyIds.IDENTIFIANT_SCANER, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
        properties.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
        var uploadOutput = uploadFile(properties, gedDocument, folder);
        return uploadOutput.get("idAlfresco");
    }

    public String uploadTestFile(IndexOrPathToUse indexOrPathToUse, GedDocument gedDocument) {
        log.info("Start: creating arborecense in alfresco repository");

        var prefixPath = gedProperties.getSearchdoc();
        var path = pathFromDateDoc();
        if (indexOrPathToUse.equals(IndexOrPathToUse.TEMPORARY)) {
            prefixPath = gedProperties.getOutbox();


        }
        var folder = claimDocumentRepository.createArboFoldersByPath(prefixPath, path);
        log.info("End: creating arborecense in alfresco repository with path '{}'", prefixPath + path);
        if (folder == null) {
            log.error("can not create/open dossier (floder) is null");
            throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
        }
        Map<String, Object> properties = new HashMap<>();
        properties.put(AXADocPropertyIds.IDENTIFIANT_SCANER, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
        properties.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
        var uploadOutput = uploadTestFile(properties, gedDocument, folder);
        return uploadOutput.get("idAlfresco");
    }

    public Resource downloadFile(String id) {
        log.info("Start: Downloading file with id '{}'", id);
        var document = claimDocumentRepository.getFileDocument(id);
        log.debug("File downloaded : '{}'", document);
        log.info("Start: Downloading file with id '{}'", id);
        return new ByteArrayResource(document.getFileByte()) {
            @Override
            public String getFilename() {
                return document.getFileName();
            }
        };
    }

    public List<PreDeclarationTypeDoc> searchInDocumentsByQuery(IndexOrPathToUse indexOrPathToUse, PreDeclarationTypeDoc preDeclarationTypeDoc) {
        log.info("Start: Search on documents by query '{}'", preDeclarationTypeDoc);
        final var finalQuery = ObjectUtils.cleanNullValues(preDeclarationTypeDoc);
        log.info("Search on documents by final query '{}'", finalQuery);
        var result = elasticSearchHelper.searchInDocumentsListsByQuery(indexOrPathToUse, finalQuery);
        if (CollectionUtils.isNotEmpty(result) && Optional.ofNullable(preDeclarationTypeDoc.getNumeroDossier()).isPresent()) {
            var splitNumeroDossier = preDeclarationTypeDoc.getNumeroDossier().split("/", -1);
            var regexNumbers = "[0-9]+";
            if (splitNumeroDossier.length == 3) {
                String regex = String.format("^%s/%s/%s$",
                        StringUtils.isNotBlank(splitNumeroDossier[0]) ? splitNumeroDossier[0] : regexNumbers,
                        StringUtils.isNotBlank(splitNumeroDossier[1]) ? splitNumeroDossier[1] : regexNumbers,
                        StringUtils.isNotBlank(splitNumeroDossier[2]) ? splitNumeroDossier[2] : regexNumbers);
                Pattern pattern = Pattern.compile(regex);

                result = result.stream()
                        .filter(type -> pattern.matcher(type.getNumeroDossier()).find())
                        .collect(Collectors.toList());
            }
        }
        log.info("End: Search on documents by query '{}'", preDeclarationTypeDoc);
        return result;
    }

    public List<DossierSinistreAuto> getDossierSinAutoList(DossierSinistreAuto dossierSinistreAuto) {
        log.info("Start: Search list of dossier sinistre with metadata '{}'", dossierSinistreAuto);
        var result = elasticSearchHelper.getDossierSinAutoList(dossierSinistreAuto);
        log.info("End: Search list of dossier sinistre with metadata '{}'", dossierSinistreAuto);
        return result;
    }

    @SneakyThrows
    public List<PreDeclarationTypeDoc> getDocumentsList(IndexOrPathToUse indexOrPathToUse, String claimNumber, String uploadedBy) {
        log.info("Start service : Search list of documents with '{}'", (uploadedBy != null) ? uploadedBy : claimNumber);
        List<PreDeclarationTypeDoc> result = List.of();

        if (IndexOrPathToUse.DEFAULT.equals(indexOrPathToUse)) {
            if (StringUtils.isBlank(claimNumber)) {
                throw new MissingServletRequestParameterException("claim_number", "String");
            }
            result = elasticSearchHelper.getDocumentsList(IndexOrPathToUse.DEFAULT, "nSin", claimNumber);
        } else if (IndexOrPathToUse.TEMPORARY.equals(indexOrPathToUse)) {
            if (StringUtils.isBlank(uploadedBy)) {
                throw new MissingServletRequestParameterException("uploaded_by", "String");
            }
            result = elasticSearchHelper.getDocumentsList(IndexOrPathToUse.TEMPORARY, "userC", uploadedBy).stream().filter(Objects::nonNull).sorted(
                    (o1, o2) -> {
                        final var comparator = -1 * Long.compare(DateUtils.getMillisFromDate(o1.getDateHeureC(), GlobalConstants.DATE_TIME_FORMAT_COMMON_FRENCH), DateUtils.getMillisFromDate(o2.getDateHeureC(), GlobalConstants.DATE_TIME_FORMAT_COMMON_FRENCH));
                        return comparator == 0 ? StringUtils.compare(o1.getLibDocument(), o2.getLibDocument()) : comparator;
                    }
            ).collect(Collectors.toList());
        }

        log.info("End service : Search list of documents with '{}'", (uploadedBy != null) ? uploadedBy : claimNumber);
        return result;
    }

    public String modifyDocumentsMetadata(IndexOrPathToUse indexOrPathToUse, String idAlfresco, PreDeclarationTypeDoc preDeclarationTypeDoc) {
        log.info("Start service : modify Document with idAlfresco '{}' and metaData '{}'", idAlfresco, preDeclarationTypeDoc);
        var result = elasticSearchHelper.updateMetadata(indexOrPathToUse, preDeclarationTypeDoc, idAlfresco);
        log.info("End service : modify Document with output '{}'", result.getId());
        return result.getId();

    }


    public String uploadFile(GedDocument gedDocument) {
        var path = pathFromDateDoc();
        log.info("Start: creating arborecense in alfresco repository with path '{}'", gedProperties.getSearchdoc() + path);
        var folder = claimDocumentRepository.createArboFoldersByPath(gedProperties.getSearchdoc(), path);
        log.info("End: creating arborecense in alfresco repository with path '{}'", gedProperties.getSearchdoc() + path);
        if (folder == null) {
            log.error("can not create/open dossier (floder) is null");
            throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
        }
        Map<String, Object> properties = new HashMap<>();
        properties.put(AXADocPropertyIds.IDENTIFIANT_SCANER, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
        properties.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
        var uploadOutput = uploadFile(properties, gedDocument, folder);
        return uploadOutput.get("idAlfresco");
    }


    @SneakyThrows
    public String validateTempFile(String idAlfresco, PreDeclarationTypeDoc documentMetadata) {
        log.info("Start service : save document to default part '{}'", idAlfresco);
        final var id = GlobalConstants.PREFIX_IN_ALFRESCO_ID.concat(idAlfresco);
        claimDocumentRepository.moveDocumentFromSourceToDestination(gedProperties.getSearchdoc(), pathFromDateDoc(), id);
        elasticSearchHelper.deleteMetadata(idAlfresco, IndexOrPathToUse.TEMPORARY);
        if (documentMetadata.getFormaDoc() != null) {

            documentMetadata.setFormaDoc(FileUtil.replaceMimeTypeWithReadableFormDoc(documentMetadata.getFormaDoc()));

        }
        final var result = elasticSearchHelper.addDocumentSinistre(documentMetadata, id, IndexOrPathToUse.DEFAULT);

        indexingConnexeSinistre(claimDocumentRepository.getFileDocument(id), IndexOrPathToUse.DEFAULT, result, documentMetadata);

        log.info("End service : document saved to default part successful '{}'", result.getId());
        return result.getId();
    }

    @SneakyThrows
    public String deleteDocument(IndexOrPathToUse indexOrPathToUse, String idAlfresco, Boolean metadataOnly) {
        log.info("Start service : delete Document with idAlfresco '{}'", idAlfresco);

        final var fullDocumentId = GlobalConstants.PREFIX_IN_ALFRESCO_ID.concat(idAlfresco);
        var result = elasticSearchHelper.deleteMetadata(idAlfresco, indexOrPathToUse);

        if (!Boolean.TRUE.equals(result.getFound())) {
            final var alternativeIndex = getAlternativeIndex(indexOrPathToUse);
            result = elasticSearchHelper.deleteMetadata(idAlfresco, alternativeIndex);
            if (!Boolean.TRUE.equals(result.getFound())) {
                throw new DocumentNotFoundException("Document wasn't found by id: " + idAlfresco);
            }
        }

        if (Boolean.FALSE.equals(metadataOnly)) {
            final var deletedFileId = claimDocumentRepository.deleteFile(fullDocumentId);
            result.setId(deletedFileId);
        }

        log.info("End service : delete Document with output '{}'", result.getId());
        return result.getId();
    }

    private IndexOrPathToUse getAlternativeIndex(IndexOrPathToUse currentIndex) {
        return IndexOrPathToUse.DEFAULT.equals(currentIndex) ? IndexOrPathToUse.TEMPORARY : IndexOrPathToUse.DEFAULT;
    }

    @SneakyThrows
    public List<ChangesQueryDto> copyDocumentsByAlfrescoIds(Boolean temporary, CopyDocumentsQueryDto copyDocumentsQueryDto) {
        log.info("Start service : copy files with alfresco's id's '{}' for user '{}'", copyDocumentsQueryDto.getChanges(), copyDocumentsQueryDto.getUserName());
        final var indexOrPathToUse = (temporary == null || !temporary) ? IndexOrPathToUse.DEFAULT : IndexOrPathToUse.TEMPORARY;
        // initializing state variables
        final var queryOfSearchOnAlfrescoIds = new HashMap<Object, String>();
        final var hashMapOfIdAlfrescoByChangesObject = new HashMap<String, ArrayList<ChangesQueryDto>>();
        final HashMap<String, List<String>> getListOfIdAlfrescosToBeCopied = new HashMap<>();
        final var getOldIdByNewId = new HashMap<String, String>();

        var prefixPath = gedProperties.getSearchdoc();
        var path = pathFromDateDoc();
        if (indexOrPathToUse.equals(IndexOrPathToUse.TEMPORARY)) {
            prefixPath = gedProperties.getOutbox();
        }

        for (var copyInformation : copyDocumentsQueryDto.getChanges()) {
            copyInformation.setAlfrescoId(GlobalConstants.PREFIX_IN_ALFRESCO_ID.concat(copyInformation.getAlfrescoId()));
            copyInformation.setIsCopied(false);
            copyInformation.setOldAlfrescoId(copyInformation.getAlfrescoId());

            queryOfSearchOnAlfrescoIds.put(copyInformation.getAlfrescoId(), "idAlfresco");
            if (!getListOfIdAlfrescosToBeCopied.containsKey(copyInformation.getAlfrescoId())) {
                getListOfIdAlfrescosToBeCopied.put(copyInformation.getAlfrescoId(), new ArrayList<>());
            }
            getListOfIdAlfrescosToBeCopied.get(copyInformation.getAlfrescoId()).add(
                    claimDocumentRepository.createArboFoldersByPath(prefixPath, path).getPath()
            );

            if (!hashMapOfIdAlfrescoByChangesObject.containsKey(copyInformation.getAlfrescoId())) {
                hashMapOfIdAlfrescoByChangesObject.put(copyInformation.getAlfrescoId(), new ArrayList<>());
            }
            hashMapOfIdAlfrescoByChangesObject.get(copyInformation.getAlfrescoId()).add(copyInformation);
        }

        // copy alfresco files and get copy operation state with new ids of files

        final var copiedFilesMap = claimDocumentRepository.copyFileToDestination(getListOfIdAlfrescosToBeCopied);
        for (var idAlfrescoOldNew : copiedFilesMap.entrySet()) {
            if (idAlfrescoOldNew.getKey() == null || !hashMapOfIdAlfrescoByChangesObject.containsKey(idAlfrescoOldNew.getKey())) {
                continue;
            }

            if (CollectionUtils.isNotEmpty(idAlfrescoOldNew.getValue())) {
                var index = 0;

                for (var newAlfrescoId : idAlfrescoOldNew.getValue()) {
                    if (index >= hashMapOfIdAlfrescoByChangesObject.get(idAlfrescoOldNew.getKey()).size()) {
                        break;
                    }
                    if (StringUtils.isBlank(newAlfrescoId)) {
                        queryOfSearchOnAlfrescoIds.remove(idAlfrescoOldNew.getKey());
                        index++;
                        continue;
                    }
                    getOldIdByNewId.put(newAlfrescoId, idAlfrescoOldNew.getKey());
                    hashMapOfIdAlfrescoByChangesObject.get(idAlfrescoOldNew.getKey()).get(index).setAlfrescoId(newAlfrescoId);
                    index++;
                }
            } else {
                queryOfSearchOnAlfrescoIds.remove(idAlfrescoOldNew.getKey());
                hashMapOfIdAlfrescoByChangesObject.get(idAlfrescoOldNew.getKey()).forEach(
                        changesToCopyQueryDto -> changesToCopyQueryDto.setAlfrescoId(null)
                );
            }
        }

        // insert All files metadata-s with provided changes and get state of every copied metadata
        var listOfPredec = elasticSearchHelper.getUnionOfMetadatasWithFieldQuery(indexOrPathToUse, queryOfSearchOnAlfrescoIds);
        if (CollectionUtils.isNotEmpty(listOfPredec)) {
            Optional<ChangesQueryDto> tempCopieInformation;
            final var arrayListOfPredeclarationToCreate = new ArrayList<PreDeclarationTypeDoc>();
            for (var predec : listOfPredec) {
                if (predec.getIdAlfresco() == null || !hashMapOfIdAlfrescoByChangesObject.containsKey(predec.getIdAlfresco())) {
                    continue;
                }
                hashMapOfIdAlfrescoByChangesObject.get(predec.getIdAlfresco()).forEach(
                        changesToCopyQueryDto -> arrayListOfPredeclarationToCreate.add(predeclarationTypeDocMapper.getPredeclarationsModifiedInformation(
                                predec,
                                changesToCopyQueryDto,
                                copyDocumentsQueryDto.getUserName()
                        ))
                );
            }
            final var tempHashMap = elasticSearchHelper.insertMultipleMetadatas(indexOrPathToUse, arrayListOfPredeclarationToCreate);
            for (var entry : tempHashMap.entrySet()) {
                if (!getOldIdByNewId.containsKey(entry.getKey()) || !hashMapOfIdAlfrescoByChangesObject.containsKey(getOldIdByNewId.get(entry.getKey()))) {
                    continue;
                }
                tempCopieInformation = hashMapOfIdAlfrescoByChangesObject.get(getOldIdByNewId.get(entry.getKey())).stream().filter(
                        changesToCopyQueryDto -> StringUtils.equals(changesToCopyQueryDto.getAlfrescoId(), entry.getKey())
                ).findFirst();

                tempCopieInformation.ifPresent(changesToCopyQueryDto -> changesToCopyQueryDto.setIsCopied(entry.getValue()));

            }
        }
        ArrayList<ChangesQueryDto> result = new ArrayList<>();
        hashMapOfIdAlfrescoByChangesObject.forEach(
                (key, value) -> result.addAll(value)
        );
        log.info("End service : copy files with alfresco's id's '{}' for user '{}'", copyDocumentsQueryDto.getChanges(), copyDocumentsQueryDto.getUserName());
        return result;
    }

}
