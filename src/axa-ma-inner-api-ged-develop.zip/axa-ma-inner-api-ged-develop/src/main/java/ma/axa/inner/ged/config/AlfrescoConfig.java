package ma.axa.inner.ged.config;

import ma.axa.inner.ged.exception.GlobalException;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.client.api.SessionFactory;
import org.apache.chemistry.opencmis.client.runtime.SessionFactoryImpl;
import org.apache.chemistry.opencmis.commons.SessionParameter;
import org.apache.chemistry.opencmis.commons.enums.BindingType;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class AlfrescoConfig {
	@Bean
	Session createSession(AlfrescoProperties properties) {
    	if(StringUtils.isEmpty(properties.getHostname()) || StringUtils.isEmpty(properties.getUser())
    			|| StringUtils.isEmpty(properties.getPassword()))
    		throw new GlobalException("TECHNICAL_ALFRESCO_ERROR", "alfresco credentials are not provided");
    	
    	var baseUrl = "http://" + properties.getHostname() + (!properties.getPort().equals("") ? ":" : "") +
    			properties.getPort() + properties.getCmisPath();
    	Map<String, String> parameters = new HashMap<>();
    	parameters.put(SessionParameter.USER,properties.getUser());
    	parameters.put(SessionParameter.PASSWORD,properties.getPassword());
    	parameters.put(SessionParameter.ATOMPUB_URL,baseUrl);
    	parameters.put(SessionParameter.REPOSITORY_ID,"Main Repository");
    	parameters.put(SessionParameter.BINDING_TYPE,BindingType.ATOMPUB.value());
    	
    	SessionFactory sessionFactory = SessionFactoryImpl.newInstance();
    	var repositories = sessionFactory.getRepositories(parameters);
    	if(CollectionUtils.isEmpty(repositories))
    		throw new GlobalException("TECHNICAL_ALFRESCO_ERROR", "server has no repositories");
    	return repositories.get(0).createSession();
	}

}
