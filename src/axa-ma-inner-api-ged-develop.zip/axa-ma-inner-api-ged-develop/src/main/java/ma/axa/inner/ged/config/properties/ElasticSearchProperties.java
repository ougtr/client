package ma.axa.inner.ged.config.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

@Data
@ConfigurationProperties(prefix = "axa.elasticsearch")
public class ElasticSearchProperties {
	private String host;
	private int port;
	private String schema;
	private String username;
	private String password;
	private String fingerprint;
}