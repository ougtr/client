package ma.axa.inner.ged.api;

import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;

import java.io.IOException;

import javax.validation.Valid;

import org.springdoc.api.annotations.ParameterObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.zxing.WriterException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.mobile.scan.dto.OcrDoc;
import ma.axa.inner.ged.mobile.scan.dto.OcrDocDto;
import ma.axa.inner.ged.mobile.scan.dto.ScanResponse;
import ma.axa.inner.ged.mobile.scan.service.MobileScanDocService;
import ma.axa.inner.ged.mobile.scan.service.QrCodeService;

@RestController
@Slf4j
@RequestMapping("v1/dossier-client/scan/dossiers")
public class MobileScanApi {
	@Autowired
	QrCodeService qrCodeService;
	@Autowired
	MobileScanDocService mobileScanDocService;

	@Operation(summary = "upload document agent mobile scan temp")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Document added", content = {
					@Content(mediaType = "multipart/form-data", schema = @Schema(implementation = OcrDoc.class)) }),
			@ApiResponse(responseCode = "400", description = "request not valid", content = @Content) })
	@PostMapping(value = "/{token}", consumes = MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<OcrDoc> uploadTemporaryFile(@ParameterObject @Valid @ModelAttribute OcrDocDto ocrDocument,
			@Parameter(description = "Content of the document") @PathVariable(value = "token", required = true) String token,
			@RequestPart(value = "file1", required = true) MultipartFile file1,
			@RequestPart(value = "file2", required = false) MultipartFile file2) {
		log.info("Start: Uploading file mobile scan '{}' and stocke data after ocr '{}'", file1.getOriginalFilename(),
				ocrDocument);
		var ocrDocuement = mobileScanDocService.uploadFileTemp(file1, file2, ocrDocument, ocrDocument.getToken());
		log.info("End: File mobile scan uploaded '{}'", file1.getOriginalFilename());
		return new ResponseEntity<>(ocrDocuement, HttpStatus.CREATED);
	}

	@Operation(summary = "index document agent mobile scan")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Document indexed", content = {
					@Content(mediaType = "multipart/form-data", schema = @Schema(implementation = String.class)) }),
			@ApiResponse(responseCode = "400", description = "request not valid", content = @Content) })
	@PostMapping(value = "/{token}/documents", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> indexFileScan(@ParameterObject @Valid @ModelAttribute OcrDocDto ocrDocument,
			@Parameter(description = "Content of the document") @PathVariable(value = "token", required = true) String token) {
		log.info("Start: indexing metadata for file with token '{}'", token);
		mobileScanDocService.indexDocument(token);
		log.info("End: indexing metadata for file with token '{}'", token);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "generate qr code", content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ScanResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "invalid request", content = @Content) })
	@GetMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ScanResponse> generateQrCode(
			@RequestParam(name = "typeDocument", required = true) String typeDocument)
			throws IOException, WriterException {
		log.info("Start api: get token qr code");
		ScanResponse scanResponse = qrCodeService.generateQRCode(typeDocument, 200, 200);
		return new ResponseEntity<>(scanResponse, HttpStatus.OK);

	}

	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "retrieve type document by token", content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ScanResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "invalid request", content = @Content) })
	@GetMapping(path = "/type-document", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ScanResponse> getTypeDocument(@RequestParam(name = "token", required = true) String token)
			throws IOException, WriterException {
		log.info("Start api: return type document by token ");
		ScanResponse scanResponse = qrCodeService.getTypeDocumentByToken(token);
		return new ResponseEntity<>(scanResponse, HttpStatus.OK);

	}

	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "retrieve type document by token", content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = OcrDocDto.class)) }),
			@ApiResponse(responseCode = "400", description = "invalid request", content = @Content) })
	@GetMapping(path = "/ocr-document", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OcrDocDto> getOcrDocumentByToken(@RequestParam(name = "token", required = true) String token)
			throws IOException, WriterException {
		log.info("Start api: return info document ociriser");
		OcrDocDto ocrDocumentDto = qrCodeService.getocrDocumentByToken(token);
		return new ResponseEntity<>(ocrDocumentDto, HttpStatus.OK);

	}

}
