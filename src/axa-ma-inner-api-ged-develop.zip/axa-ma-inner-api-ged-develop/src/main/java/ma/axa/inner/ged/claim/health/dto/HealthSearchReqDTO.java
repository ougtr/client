package ma.axa.inner.ged.claim.health.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HealthSearchReqDTO {
    private String typeGestion;
    private String nomDoc;
}
