package ma.axa.inner.ged.mapper.at;

import ma.axa.inner.ged.domain.at.DirectoriesATGed;
import ma.axa.inner.ged.dto.at.DirectoriesDto;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface DirectoryATMapper {

    DirectoriesDto directoryAtToDto(DirectoriesATGed directories);

    List<DirectoriesDto> directoriesAtToDto(List<DirectoriesATGed> directories);
}
