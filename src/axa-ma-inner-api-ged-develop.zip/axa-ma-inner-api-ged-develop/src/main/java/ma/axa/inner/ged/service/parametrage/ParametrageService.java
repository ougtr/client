package ma.axa.inner.ged.service.parametrage;

import java.util.List;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.parametrage.BrancheResponseDto;
import ma.axa.inner.ged.dto.parametrage.EntityResponseDto;
import ma.axa.inner.ged.dto.parametrage.RepertoireResponseDto;
import ma.axa.inner.ged.dto.parametrage.TypeDocumentResponseDto;
import ma.axa.inner.ged.mapper.parametrage.BrancheParametrageMapper;
import ma.axa.inner.ged.mapper.parametrage.EntityParametrageMapper;
import ma.axa.inner.ged.mapper.parametrage.RepertoireMapper;
import ma.axa.inner.ged.mapper.parametrage.TypeDocumentParametrageMapper;
import ma.axa.inner.ged.repository.parametrage.ParametrageRepository;

@Service
@Slf4j
@RequiredArgsConstructor
public class ParametrageService {
	
	public final ParametrageRepository parametrageRepository;
	public final BrancheParametrageMapper mapperBranche;
	public final EntityParametrageMapper mapperEntity;
	public final TypeDocumentParametrageMapper mapperTypeDocument;
	public final RepertoireMapper mapperRepertoire;
	
	
	@SneakyThrows
	public List<BrancheResponseDto> getAllBranches(){
		
		List<BrancheResponseDto> listBranche;
		log.info("Start getting branche info service");
		listBranche = mapperBranche.mapToBrancheDtoList(parametrageRepository.getAll());
		log.info("End getting branche info service");
		return listBranche;
	}
	
	public List<EntityResponseDto> getEntityByBranche(int id){
		
		List<EntityResponseDto> list;
		log.info("Start getting Entity info service");
		list = mapperEntity.mapToEntityDtoList(parametrageRepository.getListEntityByIdBranche(id));
		log.info("End getting Entity info service");
		return list;
		
	}
	
	public List<TypeDocumentResponseDto> getTypeDocumentByEntity(int id){
		
		List<TypeDocumentResponseDto> list;
		log.info("Start getting type document info service");
		list = mapperTypeDocument.mapToEntityDtoList(parametrageRepository.getListTypeDocumentByIdEntity(id));
		log.info("Start getting type document info service");
		return list;
	}
	
	public List<RepertoireResponseDto> getListRepertoireByIdTypeDocument(int idEntity,int id){
		
		List<RepertoireResponseDto> list;
		log.info("Start getting repertoire info service");
		list = mapperRepertoire.mapToRepertoireDtoList(parametrageRepository.getListRepertoireByIdDocument(id, idEntity));
		log.info("End getting repertoire info service");
		return list;
	}

	public List<RepertoireResponseDto> getListRepertoire() {
		List<RepertoireResponseDto> list;
		log.info("Start getting repertoire info service");
		list = mapperRepertoire.mapToRepertoireDtoList(parametrageRepository.getListRepertoire());
		log.info("End getting repertoire info service");
		return list;
	}
}
