package ma.axa.inner.ged.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DemandUploadResponseDto {

    private String fileName;
    private String idAlfresco;
	
}
