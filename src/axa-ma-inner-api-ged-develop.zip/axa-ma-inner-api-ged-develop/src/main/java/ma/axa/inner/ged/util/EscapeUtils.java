package ma.axa.inner.ged.util;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;

public class EscapeUtils {

	private final static String[] TO_REPLACE = new String[]{"\n", "\r"};
	private final static String[] REPLACE_WITH = new String[]{"_", "_"};

	public static String escapeHtml(String s) {
		return (s == null) ? null : StringEscapeUtils.escapeHtml4(crlf(s));
	}

	public static String escapeJson(String s) {
		return (s == null) ? null : StringEscapeUtils.escapeJson(crlf(s));
	}

	private static String crlf(String s) {
		return (s == null) ? null : StringUtils.replaceEach(s, TO_REPLACE, REPLACE_WITH);
	}
}
