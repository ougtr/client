package ma.axa.inner.ged.util;

import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class MessageUtils {

	public static String getMessage(MessageSource messageSource, String code, Object[] args) {
		try {
			return messageSource.getMessage(code, args, LocaleContextHolder.getLocale());
		} catch (NoSuchMessageException e) {
			log.warn("[ERROR_HANDLING] No message found under code [{}]", code);
			return code;
		}
	}
}
