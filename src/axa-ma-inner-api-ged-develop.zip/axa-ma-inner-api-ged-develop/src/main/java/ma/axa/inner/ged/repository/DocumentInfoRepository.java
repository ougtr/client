package ma.axa.inner.ged.repository;

import ma.axa.inner.ged.domain.at.DocumentInfo;
import ma.axa.inner.ged.util.jpa_query_filter.JpaQueryFilter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DocumentInfoRepository extends JpaRepository<DocumentInfo,Integer>, JpaQueryFilter<DocumentInfo> {
    List<DocumentInfo> findByGroup(Integer group);
}
