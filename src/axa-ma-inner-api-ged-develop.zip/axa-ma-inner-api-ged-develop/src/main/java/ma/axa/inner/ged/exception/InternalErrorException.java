package ma.axa.inner.ged.exception;

import ma.axa.inner.ged.util.constants.GlobalConstants;

public class InternalErrorException extends GlobalException {

	private static final long serialVersionUID = 2222758585380429741L;
	
	public InternalErrorException(String message) {
		super (GlobalConstants.URI_DEFAULT, message);
	}
}
