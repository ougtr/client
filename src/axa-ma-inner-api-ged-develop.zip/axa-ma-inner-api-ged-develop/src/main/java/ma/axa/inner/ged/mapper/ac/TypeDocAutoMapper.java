package ma.axa.inner.ged.mapper.ac;

import ma.axa.inner.ged.domain.TypeDocAs400;
import ma.axa.inner.ged.dto.TypeDocResponse;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface TypeDocAutoMapper {

    @Mapping(source = "label", target = "label",qualifiedByName = "trim")
    TypeDocResponse typeDocToTypeDocResponse(TypeDocAs400 typeDocAs400);

    List<TypeDocResponse> typeDocListToTypeDocResponseList(List<TypeDocAs400> typeDocAs400List);

    @Named("trim")
    static String trimValue(String value) {
        return StringUtils.trim(value);
    }
}
