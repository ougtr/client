package ma.axa.inner.ged.claim.ls.mapper;

import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import ma.axa.inner.ged.claim.ls.domain.DocumentClaimLsEs;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsReq;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsResp;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsUpdateReq;
import org.mapstruct.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ClaimLsMapper {

	// -> TO DTO

	public DocClaimLsResp toDto(DocumentClaimLsEs document);

	public List<DocClaimLsResp> toDto(List<DocumentClaimLsEs> documents);

	// -> FROM DTO

	public DocumentClaimLsEs fromDto(DocClaimLsReq documentRes);

	public List<DocumentClaimLsEs> fromDto(List<DocClaimLsReq> documentRes);

	public DocumentClaimLsEs fromDto(DocClaimLsUpdateReq documentReq);

	// -> update
	@BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
	void updateFromDto(DocClaimLsUpdateReq documentReq, @MappingTarget DocumentClaimLsEs document);

	// Others
	public static Page<DocumentClaimLsEs> mapToPage(SearchResponse<DocumentClaimLsEs> searchResponse, int from,
			int size) {
		if (searchResponse == null || searchResponse.hits().hits().isEmpty() || searchResponse.hits().total() == null) {
			return Page.empty();
		} else {
			long totalElements = searchResponse.hits().total().value();
			List<DocumentClaimLsEs> results = searchResponse.hits().hits().stream()
					.map(Hit::source)
					.collect(Collectors.toList());
			PageRequest pageRequest = PageRequest.of(from, size);
			return new PageImpl<>(results, pageRequest, totalElements);
		}
	}
}
