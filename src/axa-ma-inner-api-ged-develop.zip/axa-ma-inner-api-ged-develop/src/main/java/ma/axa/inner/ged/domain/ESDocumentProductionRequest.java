package ma.axa.inner.ged.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ESDocumentProductionRequest {
    @JsonProperty("idalfersco")
    private String idAlfersco;
    @JsonProperty("nomdocument")
    private String nomDocument;
    @JsonProperty("numpolice")
    private String numPolice;
    @JsonProperty("typeDocument")
    private String documentType;
    @JsonProperty("typeDocumentLabel")
    private String documentTypeLabel;
    @JsonProperty("dateCreation")
    private String dateCreation;
    private String sourceDocument;
    private String visibleToIntermediate;
    private String exercice;
    private List<String> tagsLabels;
    private List<String> tagsIds;
    private Integer typedocument;
	private String typedocumentLabel;

}
