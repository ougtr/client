package ma.axa.inner.ged.claim.health.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GedProductionHealthEntityAS400 {
    private BigDecimal ideamc;
    private String codpro;
    private String ideged;
    private String ponpo1;
    private String ponpo2;
    private String bdlusr;
    private Integer menuor;
    private String rectype;
    private String colng4;


}
