package ma.axa.inner.ged.claim.health.domain;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GedHealthEntityRes {
    private String TYPDOC;
    private String IDEGED;
}
