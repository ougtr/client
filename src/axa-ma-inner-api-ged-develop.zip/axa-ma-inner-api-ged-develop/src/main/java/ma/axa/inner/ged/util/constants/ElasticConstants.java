package ma.axa.inner.ged.util.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ElasticConstants {

    public static final String IDX_PRODUCTION_FLOTTE_SCHEMA = "es_index/production-flotte.json";
    public static final String IDX_CLAIM_RD_SCHEMA = "es_index/claim-rd.json";
    public static final String IDX_CLAIM_TRANSPORT_SCHEMA = "es_index/claim-transport.json";
    public static final String IDX_CLAIM_LS_SCHEMA = "es_index/claim-ls.json";
    public static final String IDX_PRODUCTION_RC_SCHEMA = "es_index/production-rc.json";
    public static final String IDX_PRODUCTION_HEALTH_AMC_SCHEMA = "es_index/production-health-amc.json";
    public static final String IDX_PRODUCTION_HEALTH_DIM_SCHEMA = "es_index/production-health-dim.json";
    public static final String IDX_PRODUCTION_HEALTH_COMMON_SCHEMA = "es_index/production-health-common.json";
    public static final String IDX_CIMA_MRP_SCHEMA = "es_index/cima.json";
    public static final String IDX_CIMA_AUTO_SCHEMA = "es_index/cima-auto.json";
    public static final String IDX_POSTE_LS_SCHEMA = "es_index/poste-ls.json";

    public static final String IDX_TRANSVERSE_MED_SCHEMA = "es_index/transverse-med.json";


    public static final String ID = "id";
    public static final String FILENAME = "filename";
    public static final String REFERENCE = "reference";
    public static final String IS_ORIGINAL = "is_original";

    public static final String IS_DRAFT = "is_draft";
    public static final String STATUS = "status";
    public static final String BRANCHE_CODE = "branche_code";
    public static final String BRANCHE_LABEL = "branche_label";
    public static final String TYPE_DOCUMENT_LABEL = "type_document_label";
    public static final String TYPE_DOCUMENT_CODE = "type_document_code";
    public static final String APP_SOURCE = "app_source";
    public static final String DATE_SURVENANCE = "date_survenance";
    public static final String DATE_RECEPTION = "date_reception";
    public static final String DATE_NUMERISATION = "date_numerisation";
    public static final String SINISTRE_NUMBER = "sinistre_number";
    public static final String SINISTRE_USER_CREATOR = "sinistre_user_creator";
    public static final String NUM_CERTIFICAT = "num_certificat";
    public static final String NUM_ORDER = "num_order";
    public static final String NUM_POLICE = "num_police";
    public static final String NUM_PREDECLARATION = "predeclaration_number";
    public static final String ASSURE_NOM = "assure_nom";
    public static final String ASSURE_PRENOM = "assure_prenom";
    public static final String PRODUIT_CODE = "produit_code";
    public static final String PRODUIT_LABEL = "produit_label";
    public static final String INTERMEDIAIRE_CODE = "intermediaire_code";
    public static final String INTERMEDIAIRE_NOM = "intermediaire_nom";
    public static final String CREATED_BY = "created_by";
    public static final String CREATED_AT = "created_at";
    public static final String LAST_UPDATED_BY = "last_updated_by";
    public static final String LAST_UPDATED_AT = "last_updated_at";
    public static final String ENTITYCODE = "entity_code";
    public static final String TYPEDOCUMENTCODE = "type_document_code";
    public static final String REPERTOIRE = "repertoire";
    public static final String REPERTOIRECODE = "repertoire_code";
    public static final String QUOTATION_NUMBER = "quotation_id";
    public static final String SIMULATION_NUMBER = "simulation_id";
    public static final String POLICY_NUMBER = "policy_number";
    public static final String INTEGRATION_ID = "integration_id";

    // TODO
    // NEW information
    public static final String VALEUR_JURIDIQUE = "valeur_juridiction";
    public static final String NUM_TRIBUNAL = "num_tribunal";

    public static final String NUM_ADHESION = "numAdhesion";
    public static final String LIB_BANQUE = "libBanque";

    public static final String NUM_DECLARATION = "numDeclaration";

    public static final String CORRESPONDANCE_G = "correspondance_G";

    // CIMA AUTO
    public static final String CIMA_AUTO_TYPE_DOCUMENT = "type_document";
    public static final String CIMA_AUTO_NUM_DECLARATION = "num_declaration";
    public static final String CIMA_AUTO_COUNTRY_CODE = "country_code";
    public static final String CIMA_AUTO_NUM_SINISTRE = "num_sinistre";
    public static final String CIMA_AUTO_NUM_POLICE = "num_police";
    public static final String CIMA_AUTO_IMMATRICULATION = "immatriculation";
    public static final String CIMA_AUTO_DATE_SURVENACE = "date_survenace";
    public static final String CIMA_AUTO_DATE_EFFET = "date_effet";
    public static final String CIMA_AUTO_CODE_INTERMEDIAIRE = "code_intermediaire";
    public static final String CIMA_AUTO_NOM_INTERMEDIAIRE = "nom_intermediaire";
    public static final String CIMA_AUTO_DATE_RECEPTION = "date_reception";
    public static final String CIMA_AUTO_DATE_NUMERISATION = "date_numerisation";
    public static final String CIMA_AUTO_ENTITE_EMETTEUR = "entite_emetteur";
    public static final String CIMA_AUTO_STATUT = "statut";
    public static final String CIMA_AUTO_CREATED_BY = "created_by";
    public static final String CIMA_AUTO_CREATED_AT = "created_at";
    public static final String CIMA_AUTO_UG = "ug";
    public static final String CIMA_AUTO_REF_PRESTATAIRE = "ref_prestataire";
    public static final String CIMA_AUTO_REF_MOYEN_PIEMENT = "ref_moyena_piement";
}