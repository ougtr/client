package ma.axa.inner.ged.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ESOrderEnum {
    DESC("desc"),ASC("asc");
    private final String code;
}
