package ma.axa.inner.ged.postels.mapper;

import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import ma.axa.inner.ged.postels.domain.DocPosteLsEs;
import ma.axa.inner.ged.postels.dto.DocPosteLsReq;
import ma.axa.inner.ged.postels.dto.DocPosteLsResp;
import ma.axa.inner.ged.postels.dto.DocPosteLsUpdateReq;
import org.mapstruct.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface IDocPosteLsMapper {

	// -> TO DTO

	public DocPosteLsResp toDto(DocPosteLsEs document);

	public List<DocPosteLsResp> toDto(List<DocPosteLsEs> documents);

	// -> FROM DTO

	public DocPosteLsEs fromDto(DocPosteLsReq documentRes);

	public List<DocPosteLsEs> fromDto(List<DocPosteLsReq> documentRes);

	public DocPosteLsEs fromDto(DocPosteLsUpdateReq documentReq);

	// -> update
	@BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
	void updateFromDto(DocPosteLsUpdateReq documentReq, @MappingTarget DocPosteLsEs document);

	// Others
	public static Page<DocPosteLsEs> mapToPage(SearchResponse<DocPosteLsEs> searchResponse, int from,
											   int size) {
		if (searchResponse == null || searchResponse.hits().hits().isEmpty() || searchResponse.hits().total() == null) {
			return Page.empty();
		} else {
			long totalElements = searchResponse.hits().total().value();
			List<DocPosteLsEs> results = searchResponse.hits().hits().stream()
					.map(Hit::source)
					.collect(Collectors.toList());
			PageRequest pageRequest = PageRequest.of(from, size);
			return new PageImpl<>(results, pageRequest, totalElements);
		}
	}
}
