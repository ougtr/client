package ma.axa.inner.ged.dto.error;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class ViolationErrorResponse extends ApiError {

	private List<ApiErrorItem> errors;
}
