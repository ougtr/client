package ma.axa.inner.ged.config.filter.wrapper;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.Part;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.StreamUtils;

import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.util.GzipUtils;

@Slf4j
public class GzipRequestWrapper extends HttpServletRequestWrapper {

	public GzipRequestWrapper(final HttpServletRequest request) {
		super(request);
	}

	@Override
	public Collection<Part> getParts() throws IOException,
			ServletException {
		var compressedParts = super.getParts();
		return compressedParts.stream()
				.map(GzipRequestWrapper::decompress)
				.collect(Collectors.toList());
	}

	@Override
	public Part getPart(String name) throws IOException,
			ServletException {
		return getParts()
				.stream()
				.filter(e -> StringUtils.equals(name, e.getName()))
				.findFirst()
				.orElse(null);
	}

	public static Part decompress(Part origin) {
		try {
			var outBytes = GzipUtils.decompress(StreamUtils.copyToByteArray(origin.getInputStream()));
			var inputStream = new ByteArrayInputStream(outBytes);
			return new GzipDecompressedPart(origin, outBytes.length, inputStream);
		} catch (IOException e) {
			log.error(e.getMessage(), e);
			return origin;
		}
	}

}