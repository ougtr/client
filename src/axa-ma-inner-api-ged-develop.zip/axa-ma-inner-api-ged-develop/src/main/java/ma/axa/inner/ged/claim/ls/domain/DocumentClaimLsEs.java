package ma.axa.inner.ged.claim.ls.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentClaimLsEs  {
    private String id;
    @JsonProperty("filename")
    private String filename;
    @JsonProperty("path")
    private String path;
    @JsonProperty("reference")
    private String reference;
    @JsonProperty("is_original")
    private boolean original;
    @JsonProperty("branche_label")
    private String brancheLabel;
    @JsonProperty("type_document_code")
    private Integer typeDocumentCode;
    @JsonProperty("type_document_label")
    private String typeDocumentLabel;
    @JsonProperty("sinistre_number")
    private String sinistreNumber;
    private String status;

    @JsonProperty("uploaded_by")
    private String uploadedBy;
    @JsonProperty("repertoire")
    private String repertoire;
    @JsonProperty("repertoire_code")
    private String repertoireCode;

}
