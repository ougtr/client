package ma.axa.inner.ged.util;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class FormatterUtils {
	
	private final SimpleDateFormat formatterDate= new SimpleDateFormat("yyyyMMdd");

	
	public BigDecimal toBigDecimal(Date date) {
		BigDecimal converted = BigDecimal.ZERO;
		if (date != null) {
			String formattedDate = formatterDate.format(date);
			converted = new BigDecimal(formattedDate);
		}
		return converted;
	}

}
