package ma.axa.inner.ged.mapper.parametrage;

import java.math.BigDecimal;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import ma.axa.inner.ged.domain.parametrage.EntityParametrage;
import ma.axa.inner.ged.dto.parametrage.EntityResponseDto;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface EntityParametrageMapper {

	
	@Mapping(source = "code", target = "codeEntity", qualifiedByName = "convertBigDec")
	@Mapping(source = "libelle", target = "libelleEntity")
	public EntityResponseDto mapToEntityDto(EntityParametrage ep);
	public List<EntityResponseDto> mapToEntityDtoList(List<EntityParametrage> eps);
	
	
	@Named("convertBigDec")
	 default int convertBigDec(BigDecimal code){
        return Integer.valueOf(code.toString());
    }
}
