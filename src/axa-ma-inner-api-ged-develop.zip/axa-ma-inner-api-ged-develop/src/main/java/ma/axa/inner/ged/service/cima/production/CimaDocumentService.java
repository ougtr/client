package ma.axa.inner.ged.service.cima.production;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.alfresco.DocumentAlfresco;
import ma.axa.inner.ged.dto.cima.production.CimaDocumentRequest;
import ma.axa.inner.ged.dto.cima.production.CimaDocumentResponse;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.mapper.cima.production.CimaMrpAlfrescoMapper;
import ma.axa.inner.ged.mapper.cima.production.CimaMrpDocumentMapper;
import ma.axa.inner.ged.repository.cima.production.CimaMrpElasticRepository;
import ma.axa.inner.ged.service.AlfrescoGedService;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

import static ma.axa.inner.ged.util.CommonUtils.getPath;
import static ma.axa.inner.ged.util.DateUtils.getDatePath;

@Service
@Slf4j
@RequiredArgsConstructor
public class CimaDocumentService {
    private final CimaMrpElasticRepository repository;
    private final CimaMrpDocumentMapper mapper;
    private final BrancheProperties cimaProperties;
    private final AlfrescoGedService alfrescoService;

    public CimaDocumentResponse uploadFile(CimaDocumentRequest metaData, MultipartFile file) {
        try {
            var documentEs = mapper.fromDto(metaData);
            String filename = file.getOriginalFilename();
            var folderProperties = CimaMrpAlfrescoMapper.toFolderProperties(metaData);
            var targetFolder = prepareDocumentFolder(folderProperties, metaData);
            Map<String, Object> properties = CimaMrpAlfrescoMapper.toDocumentProperties(metaData);
            DocumentAlfresco createdDocument = alfrescoService.createDocument(targetFolder, filename, file, properties, true);
            if (createdDocument == null) {
                return null;
            }
            documentEs.setId(createdDocument.getId());
            documentEs.setFilename(createdDocument.getFilename());
            documentEs.setPath(createdDocument.getPath());
            repository.createNewDocument(documentEs.getId(), documentEs, metaData.getCountryCode().name());
            return mapper.toDto(documentEs);
        } catch (IOException e) {
            log.error("Error uploading document with meta-data: {}", metaData, e);
            throw new InternalErrorException("Erreur lors de l'upload du document");
        }
    }

    private Folder prepareDocumentFolder(Map<String, Object> properties, CimaDocumentRequest metaData) {
        var sitePath = cimaProperties.getAlfrescoSitePath();
        var folderPath = getFolderPath(metaData);
        var createdFolder = alfrescoService.createTreeFolder(folderPath, sitePath, properties);
        if (createdFolder == null) {
            throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
        }
        return createdFolder;
    }

    private String getFolderPath(CimaDocumentRequest metaData) {
        var rootFolderPath = "/".concat(metaData.getCountryCode().name().concat(cimaProperties.getAlfrescoRootFolder()).concat( metaData.getProductType().name().toLowerCase()));
        return appendEffectDateAndReference(rootFolderPath, metaData);
    }

    private String appendEffectDateAndReference(final String path, CimaDocumentRequest metaData) {
        String policyNumber = metaData.getPolicyNumber();
        var customPath = getPath(path);
        var datePath = getDatePath(metaData.getEffectDate());
        return String.join("/", customPath, datePath, policyNumber);
    }

}
