package ma.axa.inner.ged.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DocumentSinistreAutoHit {
    @JsonProperty("_index")
    private String index;
    @JsonProperty("_type")
    private String type;
    @JsonProperty("_id")
    private String id;
    @JsonProperty("_score")
    private Double score;
    @JsonProperty("_source")
    private PreDeclarationTypeDoc source;
}
