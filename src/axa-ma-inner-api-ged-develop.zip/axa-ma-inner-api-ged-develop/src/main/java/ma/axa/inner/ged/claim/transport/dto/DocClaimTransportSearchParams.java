package ma.axa.inner.ged.claim.transport.dto;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.claim.common.dto.DocClaimSearchParams;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class DocClaimTransportSearchParams extends DocClaimSearchParams {
}
