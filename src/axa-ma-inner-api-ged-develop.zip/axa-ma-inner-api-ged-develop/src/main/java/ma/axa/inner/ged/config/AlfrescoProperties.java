package ma.axa.inner.ged.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Configuration
@EnableConfigurationProperties
@Data
@ConfigurationProperties("axa.alfresco")
public class AlfrescoProperties {
	private String hostname;
	private String port;
	private String password;
	private String user;
	private String cmisPath;

}
