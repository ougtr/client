package ma.axa.inner.ged.domain;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DossierSinistreAuto{
	private String id;
	private String predec;
	private BigDecimal numSinistre;
	@JsonProperty("natureSin")
	private String natureSinistre;
	private BigDecimal polnum;
	private int codeAgent;
	private String nomAssure;
	private List<String> nomVictimes;
	private List<String> numJuridiction;
	private String matricule;
	private BigDecimal dateSinistre;
	private String objectHash;
	private String typologies;
}
