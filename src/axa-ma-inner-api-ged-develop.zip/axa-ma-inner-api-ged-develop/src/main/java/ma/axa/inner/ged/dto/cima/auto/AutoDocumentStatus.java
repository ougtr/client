package ma.axa.inner.ged.dto.cima.auto;

public enum AutoDocumentStatus {
	IDENTIFIER,
	NON_IDENTIFIER
}
