package ma.axa.inner.ged.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Configuration
public class OpenApiConfig {

	@Bean
	public OpenAPI springShopOpenAPI(@Value("${axa.docs.version}") String version) {
		return new OpenAPI().info(apiInfo(version));
	}

	private static Info apiInfo(String version) {
		return new Info().title(GlobalConstants.INFO_API_TITLE)
				.description(GlobalConstants.INFO_API_DESCRIPTION)
				.version(version)
				.termsOfService("https://www.axa.ma/mentions-legales");
	}
}
