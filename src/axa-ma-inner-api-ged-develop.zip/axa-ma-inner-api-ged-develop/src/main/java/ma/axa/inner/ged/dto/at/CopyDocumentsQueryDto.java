package ma.axa.inner.ged.dto.at;

import lombok.*;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode
public class CopyDocumentsQueryDto {
    private String userName;
    @NotEmpty
    private List<@Valid ChangesQueryDto> changes;
}