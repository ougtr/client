package ma.axa.inner.ged.exception;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Thrown whenever a record not exist on database.
 */
@Data
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RequestValidationException extends RuntimeException {
	private static final long serialVersionUID = 4786368668233461454L;

	private final Map<String, String> errors;

	public RequestValidationException(String detail, Map<String, String> errors) {
		super(detail);
		this.errors = errors;
	}
}
