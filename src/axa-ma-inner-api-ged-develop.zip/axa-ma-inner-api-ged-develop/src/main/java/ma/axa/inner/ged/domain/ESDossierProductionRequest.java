package ma.axa.inner.ged.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ESDossierProductionRequest {
    @JsonProperty("idalfersco")
    private String idAlfersco;
    @JsonProperty("police")
    private String numPolice;
    @JsonProperty("datenumerisation")
    private Date dateScan;
    @JsonProperty("intermediaire")
    private String intermediaire;
    @JsonProperty("statutpolice")
    private String statutPolice;
    @JsonProperty("codeproduit")
    private String productCode;
    @JsonProperty("dateEffetPolice")
    private Date dateEffetPolice;
    @JsonProperty("dateEffetPoliceFormat")
    private String dateEffetPoliceFormat;

}
