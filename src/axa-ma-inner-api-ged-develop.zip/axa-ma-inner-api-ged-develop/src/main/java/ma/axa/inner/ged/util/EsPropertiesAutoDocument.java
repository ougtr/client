package ma.axa.inner.ged.util;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@Setter
@Getter
@ConfigurationProperties("axa.es.auto.document")
public class EsPropertiesAutoDocument {
    private String index;
    private String type;
    private String tempIndex;
}
