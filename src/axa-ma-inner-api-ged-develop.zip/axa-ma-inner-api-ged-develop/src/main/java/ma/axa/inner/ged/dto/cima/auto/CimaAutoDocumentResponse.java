package ma.axa.inner.ged.dto.cima.auto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CimaAutoDocumentResponse {
    @JsonProperty(index = 1)
    private String id;
    private String policyNumber;
    private String filename;
    private String uploadedBy;



}
