package ma.axa.inner.ged.dto.production.health.dim;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.dto.production.health.common.DocHealthReq;



@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DocHealthDIMReq extends DocHealthReq {
	@Builder.Default
	private String productCode = "0110";
	@Builder.Default
	private String brancheLabel="Health Production DIM";

}