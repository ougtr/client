package ma.axa.inner.ged.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.enums.AutoAtBranchEnum;
import ma.axa.inner.ged.enums.TagTypeEnum;
import ma.axa.inner.ged.util.converter.TagTypeEnumConverter;

import javax.persistence.*;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "DOCTYPE")
public class TypeDocAs400 {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;
    @Column(name = "ENTITE_IDEN")
    private Integer entityId;
    @Column(name = "LABEL")
    private String label;
    @Column(name="SINREPGEDID")
    private Integer repositoryId;
    @Column(name = "TAGTYPE")
    @Convert(converter = TagTypeEnumConverter.class)
    private TagTypeEnum tagType;
    @Column(name = "SORTPER")
    private String outgoingPerimeter;
    @Column(name="BRANCH")
    @Enumerated(EnumType.STRING)
    private AutoAtBranchEnum branch;
    @Column(name="CELL")
    private Integer cellId;
}
