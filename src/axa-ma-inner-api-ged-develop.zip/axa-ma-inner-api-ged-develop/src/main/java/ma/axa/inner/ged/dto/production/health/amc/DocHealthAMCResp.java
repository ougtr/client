package ma.axa.inner.ged.dto.production.health.amc;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.dto.production.health.common.DocHealthResp;


@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DocHealthAMCResp extends DocHealthResp {
	@JsonProperty(index = 1)
	private String id;

}