package ma.axa.inner.ged.dto.production.health.dim;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class DocHealthDIMUpdateReq {
	private String policyNumber;
	private Integer typedocument;
	private String typedocumentLabel;
	private String idAlfresco;
	private String status ;
}