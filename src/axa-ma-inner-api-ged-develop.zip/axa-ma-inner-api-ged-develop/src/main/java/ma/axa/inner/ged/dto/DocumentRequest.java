package ma.axa.inner.ged.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocumentRequest {
	private String token;	
	private String codeProduct;
	private String typeDoc;

	private String codeAction;
	private String uploadedBy;



}
