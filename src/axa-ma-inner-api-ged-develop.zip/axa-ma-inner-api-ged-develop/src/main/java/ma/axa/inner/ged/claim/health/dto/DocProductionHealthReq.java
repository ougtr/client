package ma.axa.inner.ged.claim.health.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DocProductionHealthReq {
    private BigDecimal cotationId;
    private String police1;
    private String police2;
    private String codeProduit;
    private Integer numOrder;
    private String idAlfresco;
    @NotBlank(message = "Type document obligatoire")
    private String typeDoc;
    private String typeCode;
    private String user;

}
