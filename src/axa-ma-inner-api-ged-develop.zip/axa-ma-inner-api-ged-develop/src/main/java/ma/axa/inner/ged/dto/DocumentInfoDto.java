package ma.axa.inner.ged.dto;

import lombok.*;
import lombok.experimental.SuperBuilder;


@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class DocumentInfoDto {
    private Integer id;
    private String label;
    private Integer type;
    private Integer typology;
    private Integer secondTypology;
}
