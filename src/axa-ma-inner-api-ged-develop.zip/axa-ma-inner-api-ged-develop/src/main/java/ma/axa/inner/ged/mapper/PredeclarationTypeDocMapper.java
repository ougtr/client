package ma.axa.inner.ged.mapper;

import ma.axa.inner.ged.domain.PreDeclarationTypeDoc;
import ma.axa.inner.ged.dto.ChangesQueryDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface PredeclarationTypeDocMapper {
    @Mapping(target = "idAlfresco",source = "copyQuery.alfrescoId")
    @Mapping(target = "polnum",source = "copyQuery.policeNumber")
    @Mapping(target = "numPreDeclaration",source = "copyQuery.predeclarationNumber")
    @Mapping(target = "nSin",source = "copyQuery.claimNumber")
    @Mapping(target = "immatriculation",source = "copyQuery.immatriculation")
    @Mapping(target = "tpi",source = "copyQuery.tpi")
    @Mapping(target = "statutBordereau",source = "predec.statutBordereau")
    @Mapping(target = "typeDocument",source = "predec.typeDocument")
    @Mapping(target = "libDocument",source = "predec.libDocument")
    @Mapping(target = "codeExp",source = "predec.codeExp")
    @Mapping(target = "userC",source = "predec.userC")
    @Mapping(target = "dateC",source = "predec.dateC")
    @Mapping(target = "dateA",source = "predec.dateA")
    @Mapping(target = "heureC",source = "predec.heureC")
    @Mapping(target = "dateM",source = "predec.dateM")
    @Mapping(target = "heureM",source = "predec.heureM")
    @Mapping(target = "formaDoc",source = "predec.formaDoc")
    @Mapping(target = "nomVictime",source = "predec.nomVictime")
    @Mapping(target = "emplacement",source = "predec.emplacement")
    @Mapping(target = "aclasser",source = "predec.aclasser")
    @Mapping(target = "aclasserPar",source = "predec.aclasserPar")
    @Mapping(target = "aclasserLe",source = "predec.aclasserLe")
    @Mapping(target = "dateHeureC",source = "predec.dateHeureC")
    @Mapping(target = "numeroDossier",source = "predec.numeroDossier")
    @Mapping(target = "documentOriginal",source = "predec.documentOriginal")
    @Mapping(target = "commentaire",source = "predec.commentaire")
    @Mapping(target = "entiteEnregistrement",source = "predec.entiteEnregistrement")
    @Mapping(target = "intermediaire",source = "predec.intermediaire")
    @Mapping(target = "idDocument",source = "predec.idDocument")
    @Mapping(target = "receptionDate",source = "predec.receptionDate")
    @Mapping(target = "survenanceDate",source = "predec.survenanceDate")
    @Mapping(target = "typeDocLabel",source = "predec.typeDocLabel")
    @Mapping(target = "tagLabel",source = "predec.tagLabel")
    @Mapping(target = "type",source = "predec.type")
    @Mapping(target = "sendingDate",source = "predec.sendingDate")
    @Mapping(target = "size",source = "predec.size")
    @Mapping(target = "connexeSinistres",source = "predec.connexeSinistres")
    @Mapping(target = "repositoryId",source = "predec.repositoryId")
    @Mapping(target = "userM",source = "userName")
    public PreDeclarationTypeDoc getPredeclarationsModifiedInformation(PreDeclarationTypeDoc predec, ChangesQueryDto copyQuery, String userName);

}
