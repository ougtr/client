package ma.axa.inner.ged.claim.common.service;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.common.domain.GedFolderProperties;
import ma.axa.inner.ged.claim.health.dto.GedHealthFolderProperties;
import ma.axa.inner.ged.domain.ESResponse;
import ma.axa.inner.ged.dto.CimaRequestDocument;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.helper.ElasticSearchHelper;
import ma.axa.inner.ged.mapper.DocumentMapper;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.StringUtil;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;
import org.apache.chemistry.opencmis.commons.exceptions.CmisContentAlreadyExistsException;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
@RequiredArgsConstructor
public class UploadHelper {

    private final ClaimDocumentRepository claimDocumentRepository;
    private final ElasticSearchHelper elasticSearchHelper;

    public GedFolderProperties indexDossier(MultipartFile file, String prefixPath) {
        String originalFilename = file.getOriginalFilename();
        if (originalFilename != null) {
            FileUtil.assertFileNameValid(originalFilename);
        }
        var filePath = pathFromDateDoc();
        var folderFile = claimDocumentRepository.createArboFoldersByPath(prefixPath, filePath);
        log.info("End: creating arborecense in alfresco repository with filePath '{}'", prefixPath + filePath);
        if (folderFile == null) {
            log.error("can not create/open dossier (floder) is null");
            throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
        }
        Map<String, Object> meta = new HashMap<>();
        meta.put(AXADocPropertyIds.IDENTIFIANT_SCANER, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
        meta.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
        return GedFolderProperties.builder().folder(folderFile).properties(meta).build();

    }

    public String pathFromDateDoc() {
        var date = LocalDate.now();
        return date.getYear() + "/" + date.getMonthValue() + "/" + date.getDayOfMonth();
    }

    public Map<String,String> uploadFile( MultipartFile file, String outBox) {
        log.info("Start: Uploading file");
        var properties = indexDossier(file,outBox);
        Map<String, Object> metadata = properties.getProperties();
        var folder = properties.getFolder();
        String idAlfresco = null;
        var gedDocument = DocumentMapper.mapFileToGedDocument(file);
        var output = new HashMap<String,String>();
        var filename = gedDocument.getFileName();
        var changeOriginalName = false;
        var i = 1;
        do {
            if (changeOriginalName) {
                filename = StringUtil.incrementExistingFilename(filename, i);
                changeOriginalName = false;
                i++;
                gedDocument.setFileName(filename);
            }
            try {
                log.debug("Start: create document '{}' in repository ",gedDocument.getFileName());
                var uploadedDocument = claimDocumentRepository.createDocument(folder, gedDocument);
                if (uploadedDocument == null) {
                    log.error("can not create document '{}' in repository ",gedDocument.getFileName());
                    throw new InternalErrorException("Erreur lors de l'upload du document");
                }
                log.debug("End: create document '{}' in repository ",gedDocument.getFileName());
                uploadedDocument.updateProperties(metadata);
                idAlfresco = uploadedDocument.getVersionSeriesId();
            } catch (CmisContentAlreadyExistsException e) {
                changeOriginalName = true;
            }
        } while (changeOriginalName);
        output.put("idAlfresco",idAlfresco);
        output.put("filename", filename);
        log.info("End: File uploaded '{}' with output '{}' and '{}'", gedDocument.getFileName(),output,gedDocument.getMimeType());
        return output;
    }

    public ESResponse createDocumentInEs(CimaRequestDocument cimaRequestDocument, String idAlfresco){
        log.info("Start index cima document in elastic serach with id = {} and metaData = {}", idAlfresco, cimaRequestDocument);
        var esResponse = elasticSearchHelper.addCimaDocument(cimaRequestDocument, idAlfresco);
        log.info("End index cima document in elastic serach with id = {} and metaData = {}", idAlfresco, cimaRequestDocument);
        return esResponse;
    }
}
