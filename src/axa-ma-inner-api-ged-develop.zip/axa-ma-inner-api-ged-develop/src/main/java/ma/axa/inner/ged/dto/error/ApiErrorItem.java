package ma.axa.inner.ged.dto.error;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@Builder
public class ApiErrorItem implements Serializable {
	private static final long serialVersionUID = -6102582467291948000L;

	private String target;
	private String message;
	private String[] params;
}
