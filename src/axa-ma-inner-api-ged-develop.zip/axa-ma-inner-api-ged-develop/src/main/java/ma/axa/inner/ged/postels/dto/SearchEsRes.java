package ma.axa.inner.ged.postels.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import javax.validation.constraints.*;

import lombok.*;

import javax.validation.constraints.NotBlank;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = false)
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class SearchEsRes {
    private String idAlfresco;
    private String filename;
    private String numPolice;
    private String numQuotation;
    @NotBlank(message = "Reference est requis")
    private String reference;
    private String brancheLabel;
    @NotBlank(message = "CreatedBy est requis")
    private String createdBy;
    private String updatedBy;
    private String createdAt;
    private String updatedAt;
    private String applicationCode;
    private String comment;
    private boolean original;
    private String typeDocumentCode;
    private String path;
}