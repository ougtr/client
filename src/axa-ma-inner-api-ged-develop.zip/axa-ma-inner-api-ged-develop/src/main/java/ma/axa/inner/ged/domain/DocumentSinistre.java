package ma.axa.inner.ged.domain;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "DOCSINAUTO")
public class DocumentSinistre {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String idalfresco;
	private String nsin;
	private BigDecimal polnum;
	private String typedocument;
	private String nomdocument;
	private String userc;
	private BigDecimal datec;
	private String numpredeclaration;
	private String formadoc;
	private String nomvictime;
	private String emplacement;
} 
