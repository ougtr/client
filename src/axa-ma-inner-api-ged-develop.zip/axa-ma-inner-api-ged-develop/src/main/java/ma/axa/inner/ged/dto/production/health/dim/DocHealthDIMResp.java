package ma.axa.inner.ged.dto.production.health.dim;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.dto.production.health.common.DocHealthResp;


@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DocHealthDIMResp extends DocHealthResp {
	@JsonProperty(index = 1)
	private String id;

}