package ma.axa.inner.ged.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.domain.alfresco.DocumentAlfresco;
import ma.axa.inner.ged.domain.production.ProductionDocumentEs;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.FolderUtils;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.apache.chemistry.opencmis.commons.enums.VersioningState;
import org.apache.chemistry.opencmis.commons.exceptions.CmisContentAlreadyExistsException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisObjectNotFoundException;
import org.apache.chemistry.opencmis.commons.impl.dataobjects.ContentStreamImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.webjars.NotFoundException;

import java.io.IOException;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class AlfrescoGedService {

	private final Session session;
	private static final int MAX_RETRY = GlobalConstants.MAX_RETRY;

	/** ========================= **/
	/** ======== Folders ======== **/
	/** ========================= **/

	/**
	 * Retrieve folder by path
	 * 
	 * @param folderPath The full folder path
	 * @return
	 */
	public Folder getFolder(final String folderPath) {
		if (StringUtils.isBlank(folderPath))
			throw new IllegalArgumentException("folderPath is required");
		if (!session.existsPath(folderPath))
			throw new NotFoundException(String.format("Folder %s not found", folderPath));

		return (Folder) session.getObjectByPath(folderPath);
	}

	/**
	 * 
	 * @param folderPath
	 * @param sitePath
	 * @return
	 */
	public Folder createTreeFolder(final String folderPath, final String sitePath) {
		return createTreeFolder(folderPath, sitePath, null);
	}

	/**
	 * Create a all folders in tree path, without any meta data
	 * 
	 * @param fullTreePath full path to be create
	 *                     {@code /site/path/and/child/folder/path}
	 * @return {@link Folder} last child folder
	 */
	public Folder createFullTreeFolder(final String fullTreePath) {
		return createFullTreeFolder(fullTreePath, null);
	}

	/**
	 * Create a all folders in tree path
	 * 
	 * @param fullTreePath full path to be create
	 *                     {@code /site/path/and/child/folder/path}
	 * @param properties   Meta Data of the folder
	 * @return {@link Folder} last child folder
	 */
	public Folder createFullTreeFolder(final String fullTreePath, final Map<String, Object> properties) {
		if (StringUtils.isBlank(fullTreePath))
			throw new IllegalArgumentException("fullTreePath is required");
		return createTreeFolder(fullTreePath, GlobalConstants.FOLDER_SEPARATOR, properties); // Start from root folder
	}

	/**
	 * Create a all folders in tree path
	 * 
	 * @param fullTreePath full path to be create
	 *                     {@code /site/path/and/child/folder/path}
	 * @param properties   Meta Data of the folder
	 * @return {@link Folder} last child folder
	 */
	public Folder createTreeFolder(final String folderPath, final String targetParentPath,
			final Map<String, Object> properties) {
		if (StringUtils.isBlank(folderPath) || StringUtils.isBlank(targetParentPath))
			throw new IllegalArgumentException("folderPpath or targetParentPath is required");
		if (!session.existsPath(targetParentPath))
			throw new NotFoundException(String.format("Parent folder %s not found.", targetParentPath));

		log.info("[Alfresco] creating tree folder: [{}], inside site: [{}]", folderPath, targetParentPath);
		var folders = StringUtils.split(folderPath, GlobalConstants.FOLDER_SEPARATOR);
		Folder currentFolder = null;
		var currentParentPath = targetParentPath;
		for (var i = 0; i < folders.length; i++) {
			currentFolder = createOneFolder(folders[i], currentParentPath, properties);
			currentParentPath = currentFolder.getPath();
		}
		return currentFolder;
	}


	public Folder prepareDocumentFolder(String branchPath,String sitePath,Map<String, Object> properties,String data) {
		var brancheFolderPath = FolderUtils.constructBranchFolderPath(branchPath,data);
		var createdFolder = createTreeFolder(brancheFolderPath, sitePath, properties);
		if (createdFolder == null) {
			throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
		}
		return createdFolder;
	}

	/**
	 * Create Folder inside parentFolderPath, without metadata
	 * 
	 * @param folderName       The name of folder to be created, ex:
	 *                         {@code myfoldername}
	 * @param parentFolderPath The full path of target parent folder, ex:
	 *                         {@code /site/to/folder/parent}
	 * @return {@link Folder} created folder
	 */
	public Folder createOneFolder(final String folderName, final String parentFolderPath) {
		return createOneFolder(folderName, parentFolderPath, null);
	}

	/**
	 * Create Folder inside parentFolderPath, without metadata
	 * 
	 * @param folderName       The name of folder to be created, ex:
	 *                         {@code myfoldername}
	 * @param parentFolderPath The full path of target parent folder, ex:
	 *                         {@code /site/to/folder/parent}
	 * @param properties       Metadata
	 * @return {@link Folder} created folder
	 */
	public Folder createOneFolder(final String folderName, final String parentFolderPath,
			final Map<String, Object> properties) {
		if (StringUtils.isBlank(folderName) || StringUtils.isBlank(parentFolderPath))
			throw new IllegalArgumentException("folder Name or parent folder is required");

		if (!session.existsPath(parentFolderPath))
			throw new NotFoundException(String.format("Parent folder %s not found", parentFolderPath));

		var parent = FileUtil.getPath(parentFolderPath, true, false);
		var addedFolderName = FileUtil.getPath(folderName, false, false);
		var fullPath = String.format("%s/%s", parent, addedFolderName);
		log.debug("[Alfresco] Start creating foler [{}] ....", fullPath);
		try {
			var pFolder = ((Folder) session.getObjectByPath(parent));
			if (session.existsPath(fullPath)) {
				log.debug("[Alfresco] Folder [{}] already exist", fullPath);
				return (Folder) session.getObjectByPath(fullPath);
			} else {
				Map<String, Object> props = new HashMap<>();
				if (properties != null)
					props.putAll(properties);
				props.put(PropertyIds.NAME, folderName);
				props.put(PropertyIds.OBJECT_TYPE_ID, AXADocPropertyIds.AXA_DOSSIER_TYPE);
				var createdFolder = pFolder.createFolder(props);
				log.info("[Alfresco] Create Folder: [{}] has been created successfully", fullPath);
				return createdFolder;
			}
		} catch (CmisObjectNotFoundException e) {
			log.error("[Alfresco] Error during create Folder: [{}], err: {}", fullPath, e.getMessage());
			throw e;
		}
	}

	/** =========================== **/
	/** ======== Documents ======== **/
	/** =========================== **/

	public boolean exists(String id) {
		try {
			return session.exists(id);
		} catch (Exception e) {
			log.error("[ALFRESCO] Error during check if document exist, id: " + id);
			return false;
		}
	}

	/**
	 * Retrieve Document by ID
	 * 
	 * @param id The id alfresco of document
	 * @return {@link Document} object
	 */
	public Document getDocument(String id) {
		if (StringUtils.isBlank(id))
			throw new IllegalArgumentException("document id is required");
		if (!session.exists(id))
			throw new CmisObjectNotFoundException(String.format("Document with ID: %s not found", id));

		var document = session.getObject(id);
		if (document instanceof Document) {
			return (Document) document;
		} else {
			throw new IllegalArgumentException("Object is not a document!");
		}
	}

	/**
	 * Create new Document on alfresco
	 * 
	 * @param withFileNameIncremental should rename document if already exist
	 * @see #createDocument(Folder, String, MultipartFile, Map)
	 */
	public DocumentAlfresco createDocument(final Folder folder, String fileName, MultipartFile content,
			Map<String, Object> properties, boolean withFileNameIncremental) throws IOException {

		if (!withFileNameIncremental)
			return createDocument(folder, fileName, content, properties);
		var i = 0;
		fileName = StringUtils.trimToEmpty(fileName);
		var nextFileName = fileName;
		do {
			if (MAX_RETRY <= i) {
				log.warn("Max retry upload document exceeded, max: {}", MAX_RETRY);
				throw new GlobalException(GlobalConstants.URI_ALFRESCO_UPLOAD_MAX_RETRY,
						GlobalConstants.ERROR_MSG_ALFRESCO_MAX_RETRY);
			}

			try {
				nextFileName = FileUtil.nextFileName(fileName, i);
				log.info("Trying upload document to alfresco, filename: {}", nextFileName);
				return createDocument(folder, nextFileName, content, properties);
			} catch (CmisContentAlreadyExistsException e) {
				log.warn("Document [{}] already exist in alfresco, err: {}", nextFileName, e.getMessage());
				i++;
			} catch (Exception e) {
				log.warn("Error during upload document [{}] to alfresco, err: {}", nextFileName, e.getMessage());
				throw e;
			}
		} while (i <= MAX_RETRY);
		return null;
	}

	/**
	 * Create new Document on alfresco
	 * 
	 * @param folder     The target folder to save the document
	 * @param fileName   filename of document
	 * @param content    The Content of document
	 * @param properties The meta data of document
	 * @return {@link Document} The created document, Call
	 *         {@link AlfrescoUtils#getAlfrescoId(String)} to get ID without store
	 *         or version
	 * @throws IOException
	 */
	public DocumentAlfresco createDocument(Folder folder, String filenName, MultipartFile content,
			Map<String, Object> properties) throws IOException {

		if (properties == null)
			properties = new HashMap<>();
		properties.put(PropertyIds.OBJECT_TYPE_ID, AXADocPropertyIds.AXA_DOC_TYPE);
		properties.put(PropertyIds.NAME, filenName);
		properties.put(PropertyIds.CONTENT_STREAM_MIME_TYPE, content.getContentType());

		var contentStream = new ContentStreamImpl(
				filenName,
				BigInteger.valueOf(content.getSize()),
				content.getContentType(),
				content.getInputStream());

		var createdDoc = folder.createDocument(properties, contentStream, VersioningState.MAJOR);
		var id = getAlfrescoId(createdDoc.getId());
		return DocumentAlfresco.builder()
				.id(id)
				.filename(createdDoc.getName())
				.path(folder.getPath())
				.contentStream(createdDoc.getContentStream().getStream())
				.contentLength(createdDoc.getContentStreamLength())
				.mimeType(createdDoc.getContentStreamMimeType())
				.build();
	}

	/**
	 * Update document properties by ID
	 */
	public String updateDocumentProperties(final String id, Map<String, Object> properties) {
		var doc = getDocument(id);
		return updateDocumentProperties(doc, properties);
	}

	/**
	 * Update Document properties
	 */
	public String updateDocumentProperties(Document document, Map<String, Object> properties) {
		if (document == null)
			throw new IllegalArgumentException("Document must not be null");

		var updatedDoc = document.updateProperties(properties);
		return getAlfrescoId(updatedDoc.getId());
	}

	/**
	 * Delete document from Alfresco
	 * 
	 * @param id The id Alfresco of the document to be delete
	 * @return {@code true} if success delete or throw exception
	 */
	public boolean deleteDocument(String id) {
		if (StringUtils.isBlank(id))
			throw new IllegalArgumentException("Document ID is required");

		var document = getDocument(id);
		log.info("[ALFRESCO] Delete document by id: [{}], name: [{}] ", id, document.getName());
		document.delete();
		return true;
	}

	/**
	 * Remove {@code workspace://SpacesStore/} and veriosn from ObjectId
	 * 
	 * @param objectId The ObjectId or Version series id
	 * @return Id
	 */
	private static final String getAlfrescoId(final String objectId) {
		if (StringUtils.isBlank(objectId))
			return null;
		var id = StringUtils.substringBeforeLast(objectId, ";");
		return StringUtils.removeStartIgnoreCase(id, GlobalConstants.ALFRESCO_WORKSPACE_PREFIX);
	}

	public void indexDocument(DocumentAlfresco createdDocument, ProductionDocumentEs documentEs, String branchLabel){
		documentEs.setId(createdDocument.getId());
		documentEs.setFilename(createdDocument.getFilename());
		documentEs.setPath(createdDocument.getPath());
		documentEs.setBrancheLabel(branchLabel);
	}

}
