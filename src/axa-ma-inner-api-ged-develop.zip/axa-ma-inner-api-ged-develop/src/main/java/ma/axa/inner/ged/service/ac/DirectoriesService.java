package ma.axa.inner.ged.service.ac;


import java.util.List;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.DirectoryResponseDto;
import ma.axa.inner.ged.mapper.RepositoryAutoMapper;
import ma.axa.inner.ged.repository.ac.DirectoriesRepository;


@Service
@RequiredArgsConstructor
@Slf4j
public class DirectoriesService {

    private final DirectoriesRepository directoriesRepository;
    private final RepositoryAutoMapper autoMapper;
    
    public List<DirectoryResponseDto> getAllRepositories(){
        log.info("\n####################### Start: get all repositories  #######################\n");
        final var repositoriesData = autoMapper.toGedRepositoryResponseList(directoriesRepository.findAll());
        log.info("\n####################### End: get all repositories  #######################\n");

        return repositoriesData;
    }
}
