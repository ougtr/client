package ma.axa.inner.ged.service.cima.auto;

import static ma.axa.inner.ged.util.CommonUtils.getPath;
import static ma.axa.inner.ged.util.DateUtils.getDatePath;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.validation.Valid;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.common.service.DownloadHelper;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.alfresco.DocumentAlfresco;
import ma.axa.inner.ged.domain.cima.auto.CimaAutoDocumentEs;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentRequest;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentResponse;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentTypeResponse;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoItemResponse;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoSearchParams;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.mapper.cima.auto.CimaAutoAlfrescoMapper;
import ma.axa.inner.ged.mapper.cima.auto.CimaAutoDocumentMapper;
import ma.axa.inner.ged.mapper.cima.auto.CimaAutoDocumentsTypeMapper;
import ma.axa.inner.ged.repository.cima.auto.CimaAutoElasticRepository;
import ma.axa.inner.ged.repository.parametrage.CimaParametrageRepository;
import ma.axa.inner.ged.service.AlfrescoGedService;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Service
@Slf4j
@RequiredArgsConstructor
public class CimaAutoDocumentService {
	private final CimaAutoElasticRepository cimaAutoElasticRepository;
	private final CimaAutoDocumentMapper mapper;
	private final BrancheProperties cimaAutoProperties;
	private final AlfrescoGedService alfrescoService;
	private final CimaParametrageRepository cimaParametrageRepository;
	private final ma.axa.inner.ged.mapper.cima.auto.CimaAutoItemMapper cimaAutoItemMapper;
	private final CimaAutoDocumentsTypeMapper cimaAutoDocumentsTypeMapper;

	private final ObjectMapper objectMapper;

	private final DownloadHelper downloadHelper;

	@SneakyThrows
	public Resource downloadDocByIdAlfresco(String id) {
		log.info("Start service: downloadDocByIdAlfresco by id:'{}'", id);
		return downloadHelper.downloadFileFromGed(id);
	}

	@SneakyThrows
	public CimaAutoDocumentResponse uploadFile(@Valid CimaAutoDocumentRequest metaData, MultipartFile file) {
		log.info("Start service: CimaAutoDocumentResponse metaData:'{}' , File name:{} ", metaData, file.getName());
		try {
			var document = mapper.fromDto(metaData);
			String filename = file.getOriginalFilename();
			var folderProperties = CimaAutoAlfrescoMapper.toFolderProperties(metaData);
			var targetFolder = prepareDocumentFolder(folderProperties, metaData);
			Map<String, Object> properties = CimaAutoAlfrescoMapper.toDocumentProperties(metaData);
			DocumentAlfresco createdDocument = alfrescoService.createDocument(targetFolder, filename, file, properties,
					true);
			log.info("AlfrescoService createDocument: {} ", createdDocument);
			if (createdDocument == null) {
				return null;
			}
			document.setId(createdDocument.getId());
			document.setFilename(createdDocument.getFilename());
			document.setPath(createdDocument.getPath());

			cimaAutoElasticRepository.createNewDocument(document.getId(), document, metaData.getCountryCode().name());
			return mapper.toDto(document);
		} catch (IOException e) {
			log.error("Error uploading document with meta-data: {}", metaData, e);
			throw new InternalErrorException("Erreur lors de l'upload du document");
		}
	}

	@SneakyThrows
	public String deleteDocument(String id) {
		log.info("Start service: deleteDocument by id:'{}'", id);
		try {
			alfrescoService.deleteDocument(id);
			cimaAutoElasticRepository.deleteDocument(id);
		} catch (Exception e) {
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
		}
		return id;
	}

	@SneakyThrows
	public CimaAutoDocumentResponse updateAutoDocuments(String documentId, CimaAutoDocumentRequest document,
			MultipartFile file) {
		log.info("Start service: updateAutoDocuments documentId:'{}', document:'{}', file:'{}'", documentId, document,
				file.getName());
		deleteDocument(documentId);
		return uploadFile(document, file);
	}

	@SneakyThrows
	public List<CimaAutoItemResponse> findBranches() {
		log.info("Start service: findBranches");
		return cimaAutoItemMapper.toResponses(cimaParametrageRepository.findBranches());
	}

	@SneakyThrows
	public List<CimaAutoItemResponse> findEntities(Long brancheId) {
		log.info("Start service: findEntities by countryCode:'{}' and brancheId: '{}'", brancheId);
		return cimaAutoItemMapper.toResponses(cimaParametrageRepository.findEntities(brancheId));
	}

	@SneakyThrows
	public List<CimaAutoItemResponse> findDirectories() {
		log.info("Start service: findDirectories");
		return cimaAutoItemMapper.toResponses(cimaParametrageRepository.findDirectories());
	}

	@SneakyThrows
	public List<CimaAutoItemResponse> findDocumentTypes(Long entityId, Long directoryId) {
		log.info("Start service: findDocumentTypes by and entityId:'{}' and directoryId:'{}'",
				 entityId, directoryId);
		return cimaAutoItemMapper
				.toResponses(cimaParametrageRepository.findDocumentTypes(entityId, directoryId));
	}
	
	 public List<CimaAutoDocumentEs>findByCriteria(CimaAutoSearchParams searchParams) {
		 log.info("Start service: findByCriteria :'{}'", searchParams);
		 return cimaAutoElasticRepository.findByCriteria(searchParams, true);
	 }
	 
	 public List<CimaAutoDocumentTypeResponse> findAllDocumentTypes() {
		 log.info("Start service: findAllDocumentTypes");
			return cimaAutoDocumentsTypeMapper.toResponses(cimaParametrageRepository.findAllDocumentTypes());
		}

	/*
	 * helpers
	 */
	private Folder prepareDocumentFolder(Map<String, Object> properties, CimaAutoDocumentRequest metaData) {
		var sitePath = cimaAutoProperties.getAlfrescoSitePath();
		var folderPath = getFolderPath(metaData);
		var createdFolder = alfrescoService.createTreeFolder(folderPath, sitePath, properties);
		if (createdFolder == null) {
			throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
		}
		return createdFolder;
	}

	private String getFolderPath(CimaAutoDocumentRequest metaData) {
		var rootFolderPath = "/"
				.concat(metaData.getCountryCode().name().concat(cimaAutoProperties.getAlfrescoRootFolder())
						.concat(metaData.getTypeDocument().toLowerCase()));
		return appendDateNumerisationAndReference(rootFolderPath, metaData);
	}

	private String appendDateNumerisationAndReference(final String path, CimaAutoDocumentRequest metaData) {
		String policyNumber = metaData.getNumPolice();
		var customPath = getPath(path);
		var datePath = getDatePath(metaData.getDateNumerisation());
		return String.join("/", customPath, datePath, policyNumber);
	}


/*
	documents.zip
	 ├── e5ff379a-b366-4191-803e-771266855bf2/
	 │   ├── metadata.json
	 │   └── file1.pdf
	 ├── bbb9caaa-70ea-4cae-87fb-ad8b5bb81a0b/
	 │   ├── metadata.json
	 │   └── file2.png
	 └── ffdca3e4-cedc-4f6a-83ce-4e8fa4145a54/
		 ├── metadata.json
		 └── file3.pdf
	*/
	public byte[] streamDocumentsZip(CimaAutoSearchParams searchParams) throws IOException {
		long startTime = System.currentTimeMillis();
		log.info("Start service: buildDocumentsZip | params={}", searchParams);

		List<CimaAutoDocumentEs> documents = findByCriteria(searchParams);
		log.info("Found {} documents to process", documents.size());

		int successCount = 0;
		int errorCount = 0;

		try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
			 ZipOutputStream zipOut = new ZipOutputStream(baos)) {

			for (CimaAutoDocumentEs doc : documents) {
				String docId = doc.getId();
				log.info("Start processing document id={}", docId);

				try {
					Document document = alfrescoService.getDocument(docId);

					String folderName = docId + "/";

					zipOut.putNextEntry(new ZipEntry(folderName + "metadata.json"));
					zipOut.write(objectMapper.writeValueAsBytes(doc));
					zipOut.closeEntry();

					String fileName = folderName + doc.getFilename();
					zipOut.putNextEntry(new ZipEntry(fileName));
					try (InputStream is = document.getContentStream().getStream()) {
						StreamUtils.copy(is, zipOut);
					}
					zipOut.closeEntry();

					successCount++;
					log.info("Finished document id={}", docId);

				} catch (Exception e) {
					errorCount++;
					log.error("Error processing document id={}", docId, e);
				}
			}

			zipOut.finish();
			zipOut.flush();

			long totalTime = System.currentTimeMillis() - startTime;
			log.info("End service: buildDocumentsZip | totalDocs={} success={} errors={} duration={} ms",
					documents.size(), successCount, errorCount, totalTime);

			return baos.toByteArray();
		}
	}

}
