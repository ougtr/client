package ma.axa.inner.ged.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CaseATRequest {

	private int codeUser;
	private String numSinistre;
	private String numPolice;
	private String numReglement;
	private List<Integer> childCellules;
	private int celluleCode;
	private String familleDocument;
	private String idDocument;
	private String nomDocument;
	private String refIntermediaire;
	private String typeDocument;

}

