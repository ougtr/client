package ma.axa.inner.ged.util.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class MedConstants {

    public static final String MED_BASE_URL = "/v1/transverse/med/documents";
}
