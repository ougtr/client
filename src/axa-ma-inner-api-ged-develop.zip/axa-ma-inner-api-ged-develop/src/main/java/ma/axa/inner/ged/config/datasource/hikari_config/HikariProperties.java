package ma.axa.inner.ged.config.datasource.hikari_config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HikariProperties {
    private String poolName;
    private int maximumPoolSize;
    private int minimumIdle;
    private long maxLifetime;
    private long idleTimeout;
    private boolean autoCommit;
}
