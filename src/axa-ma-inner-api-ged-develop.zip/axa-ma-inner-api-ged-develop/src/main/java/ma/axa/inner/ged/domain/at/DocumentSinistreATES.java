package ma.axa.inner.ged.domain.at;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DocumentSinistreATES {
    private String idalfersco;
    private String numsinistre;
    private String preDeclarationNumber;
    private String nomdocument;
    private String iddocument;
    private BigDecimal numpolice;
    private String iddoc;
    private String uploadedby;
    private String dateUpload;
    private String typeDocument;
    private String repertoire;
    private String dateSurvenance;
    private String receptiondate;
    private String sourceDossier; // SourceFilesATEnum
    private String type; // DocumentTypeATEnum
    private String numDossierBnej;
    private String numDossierTribunal;
    private Boolean isTemporary;
    private Integer intermediaryCode;
    private Long size;
    private String tag;
    private String dateEnvoi;
    private Long uploadDateTimeStamp;
    private Boolean isReturnedRO;
    private String intermediaryReference;
    private Integer sentToIntermediaryDate;
    private String userSenderToIntermediary;
    private String numReglement;
    private String codeDocument;
    private String rightHolderId;
}