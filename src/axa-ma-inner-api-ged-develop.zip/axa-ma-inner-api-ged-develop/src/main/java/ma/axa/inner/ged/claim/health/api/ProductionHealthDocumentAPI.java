package ma.axa.inner.ged.claim.health.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.health.dto.DocProductionHealthReq;
import ma.axa.inner.ged.claim.health.service.ClaimHealthDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;


@RestController
@RequestMapping("v1/production/health")
@Tag(name = GlobalConstants.TAG_HEALTH_APIS, description = GlobalConstants.TAG_DESC_HEALTH_APIS)
@RequiredArgsConstructor
@Slf4j
public class ProductionHealthDocumentAPI {

    private final ClaimHealthDocumentService claimHealthDocumentService;

    @Operation(summary = "upload a  document")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document added", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error while uploading the file", content = @Content)})
    @PostMapping(path = "/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public String uploadFile(@ParameterObject @Valid @ModelAttribute DocProductionHealthReq doc,
                             @RequestPart(value = "file", required = false) MultipartFile file) {

        log.info("Start api: uploadFile  (document Health)");
        String id = claimHealthDocumentService.uploadFilePsi(file, doc);
        log.info("End api: File (document health) uploaded");
        return id;
    }

}
