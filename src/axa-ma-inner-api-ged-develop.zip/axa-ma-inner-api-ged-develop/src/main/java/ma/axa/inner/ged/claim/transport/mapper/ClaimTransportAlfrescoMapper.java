package ma.axa.inner.ged.claim.transport.mapper;

import java.util.Collections;
import java.util.Map;

import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportAddReq;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportUpdateReq;
import ma.axa.inner.ged.mapper.AlfrescoPropsMapper;
import ma.axa.inner.ged.util.StringUtil;

public class ClaimTransportAlfrescoMapper extends AlfrescoPropsMapper {

	private ClaimTransportAlfrescoMapper() throws InstantiationException {
		throw new InstantiationException("Instances of this type are forbidden");
	}

	/** ======= Folders ======= **/

	public static Map<String, Object> toFolderProperties(DocClaimTransportAddReq metaData) {
		return toFolderProperties(metaData, null);
	}

	public static Map<String, Object> toFolderProperties(DocClaimTransportAddReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();

		var alfrescoProps = AlfrescoFolderProperties.builder()
				.intermediareDossier(StringUtil.toString(metaData.getIntermediaireCode()))
				.numeroPoliceDossier(metaData.getNumPolice())
				.numeroSinistreDossier(metaData.getSinistreNumber())
				.codeProduit(StringUtil.toString(metaData.getProduitCode()))
				//.classeSinistre(StringUtil.toString(metaData.getBrancheCode()))
				.dateSurvenanaceDossier(metaData.getDateSurvenance())
				.nomVictimeDossier(metaData.getAssureNom())
				.build();

		return toFolderProperties(properties, alfrescoProps);
	}

	/** ======= Documents ======= **/

	public static Map<String, Object> toDocumentProperties(DocClaimTransportAddReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocClaimTransportAddReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numPolice(metaData.getNumPolice())
				.numSinistre(metaData.getSinistreNumber())
				.identifiantScaner(metaData.getReference())
				.agentIntermediaire(StringUtil.toString(metaData.getIntermediaireCode()))
				.isAuthentique(metaData.isOriginal())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}

	public static Map<String, Object> toDocumentProperties(DocClaimTransportUpdateReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocClaimTransportUpdateReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numPolice(metaData.getNumPolice())
				.numSinistre(metaData.getSinistreNumber())
				.identifiantScaner(metaData.getReference())
				.agentIntermediaire(StringUtil.toString(metaData.getIntermediaireCode()))
				.isAuthentique(metaData.isOriginal())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}
}
