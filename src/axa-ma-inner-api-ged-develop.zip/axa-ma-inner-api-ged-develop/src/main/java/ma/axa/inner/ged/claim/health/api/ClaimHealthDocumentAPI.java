package ma.axa.inner.ged.claim.health.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.health.domain.GedHealthEntityRes;
import ma.axa.inner.ged.claim.health.dto.DocClaimHealthReq;
import ma.axa.inner.ged.claim.health.dto.HealthSearchResponseDto;
import ma.axa.inner.ged.claim.health.dto.ResponseDto;
import ma.axa.inner.ged.claim.health.service.ClaimHealthDocumentService;
import ma.axa.inner.ged.exception.DocumentNotFoundException;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.List;






@RestController
@RequestMapping("/v1/claims/health")
@Tag(name = GlobalConstants.TAG_HEALTH_APIS, description = GlobalConstants.TAG_DESC_HEALTH_APIS)
@RequiredArgsConstructor
@Slf4j
public class ClaimHealthDocumentAPI {

    private final ClaimHealthDocumentService claimHealthDocumentService;

    @Operation(summary = "upload a  document")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document added", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = String.class)) }),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error while uploading the file", content = @Content)})
    @PostMapping(path = "/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public String uploadFile(@ParameterObject @Valid @ModelAttribute DocClaimHealthReq doc,
                             @RequestPart(value = "file") MultipartFile file){

        log.info("Start api: uploading file (document Health) '{}'", file.getOriginalFilename());
        String id=  claimHealthDocumentService.uploadFile(file,doc);
        log.info("End api: File (document health) uploaded '{}'", file.getOriginalFilename());
        return id;
    }

    @Operation(summary = "download a health document by its alfresco id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was downloaded", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = Resource.class))}),
            @ApiResponse(responseCode = "404", description = "document not found with id", content = @Content),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
    @GetMapping(value = "/documents/{document_Id}/content", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<Resource> downloadFile(@NotNull(message = "{error.alfresco.id}") @PathVariable(value = "document_Id", required = true) String documentId) {
        log.info("Start api: Downloading file with id '{}'", documentId);
        var resource = claimHealthDocumentService.downloadFileFromGed(documentId);

        var headers = new HttpHeaders();
        String headerKey = "X-filename";
        String headerValue = resource.getFilename();
        headers.set(headerKey,headerValue);

        log.info("End api: File downloaded !");
        return ResponseEntity.ok().headers(headers).body(resource);
    }


    @Operation(summary = "search a claim using type gestion and document name")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "documents metadata were found", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = GedHealthEntityRes.class))}),
            @ApiResponse(responseCode = "400", description = "Request not valid", content = @Content),
            @ApiResponse(responseCode = "404", description = "documents not found with claim number", content = @Content)}
    )
    @GetMapping("/documents/metadatas")
    public ResponseEntity<List<HealthSearchResponseDto>> searchInDocuments(@NotBlank(message = "type gestion est obligatoire") @RequestParam(value = "typeGestion",required = true) String typeGestion, @NotBlank(message = "Nom document est obligatoire") @RequestParam(value = "nomDoc",required = true) String nomDoc) {
        log.info("Start api: Search list of documents with type gestion '{}' and nom document '{}'", typeGestion,nomDoc);
        var listOfDocuments = claimHealthDocumentService.getDocuments(typeGestion,nomDoc);
        return new ResponseEntity<>(listOfDocuments, HttpStatus.OK);
    }



    @Operation(summary = "delete a claim using type gestio, document name and type of document")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "documents metadata were found", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "400", description = "Request not valid", content = @Content),
            @ApiResponse(responseCode = "404", description = "documents not found with claim number", content = @Content)}
    )
    @DeleteMapping("/documents")
    public ResponseEntity<String> deleteHealthMetadata(
                                                       @NotBlank(message = "{error.health.doc.nom.doc.not-empty}") @RequestParam(value = "nomDoc",required = true) String nomDoc,
                                                       @NotBlank(message = "{error.health.doc.type.gestion.not-empty}") @RequestParam(value = "typeDoc",required = true) String typeDoc
    ) {
        log.info("Start api: delete  documents with   document name'{}' and type document '{}'",nomDoc,typeDoc);
        String result = claimHealthDocumentService.deleteHealthMetadata(nomDoc,typeDoc);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    /***
     * Update doc content
     *
     * */

    @Operation(summary = "update doc content")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "documents metadata were found", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = boolean.class))}),
            @ApiResponse(responseCode = "400", description = "Request not valid", content = @Content),
            @ApiResponse(responseCode = "404", description = "documents not found with claim number", content = @Content)}
    )
    @PutMapping("/documents/{document_Id}/content")
    public ResponseEntity<Void> updateDocContent(@PathVariable(value = "document_Id",required = true) String documentId,
                                                   @RequestPart(value = "file") MultipartFile file
    ){
        log.info("Start api: update documents contente with documentId '{}'",documentId);
        claimHealthDocumentService.updateDocContent(documentId,file);
        return ResponseEntity.noContent().build();
    }


}
