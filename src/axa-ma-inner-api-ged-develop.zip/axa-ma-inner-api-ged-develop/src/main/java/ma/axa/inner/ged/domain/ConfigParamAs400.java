package ma.axa.inner.ged.domain;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class ConfigParamAs400 {
	private String FICH;
	private String LIBCODE;
	private String LIBCOU;
	private String LIBELLE;
	private BigDecimal UPDATE_IDENT;
	private String VARCODE;

}
