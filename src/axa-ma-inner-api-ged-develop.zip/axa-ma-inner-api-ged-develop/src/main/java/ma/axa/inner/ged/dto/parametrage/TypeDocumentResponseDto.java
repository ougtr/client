package ma.axa.inner.ged.dto.parametrage;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TypeDocumentResponseDto {
	
	private int codeTypeDocument;
	private String libelleTypeDocument;


}
