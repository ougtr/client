package ma.axa.inner.ged.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.util.WebUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Slf4j
@Component
public class TimeLogging implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        long time = System.currentTimeMillis();

        try {
            chain.doFilter(request, response);
        } finally {
            time = System.currentTimeMillis() - time;
            HttpServletRequest httpServlet = ((HttpServletRequest) request);
            log.info("{} {}{} took {} ms", httpServlet.getMethod(), getRequestUri(httpServlet), getRequestQuery(httpServlet), time);
        }
    }

    private static String getRequestUri(HttpServletRequest request) {
        String uri = (String) request.getAttribute(WebUtils.INCLUDE_REQUEST_URI_ATTRIBUTE);
        if (uri == null) {
            uri = request.getRequestURI();
        }
        return uri;
    }

    private static String getRequestQuery(HttpServletRequest request) {
        String queryString = request.getQueryString();
        return (StringUtils.hasLength(queryString) ? "?" + queryString : "");
    }
}
