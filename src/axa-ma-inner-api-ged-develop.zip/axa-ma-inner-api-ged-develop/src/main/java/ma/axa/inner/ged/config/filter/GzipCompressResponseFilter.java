package ma.axa.inner.ged.config.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.cloud.openfeign.encoding.HttpEncoding;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.filter.wrapper.GZipResponseWrapper;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Slf4j
@Component
@Order(Ordered.LOWEST_PRECEDENCE)
public class GzipCompressResponseFilter extends AxaFilter {

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		log.debug("[gzip-response-filter] check if header client accept copress response");
		var httpServletRequest = (HttpServletRequest) request;
		var httpServletResponse = (HttpServletResponse) response;

		var gedAcceptEncoding = httpServletRequest.getHeader(GlobalConstants.HEADER_GED_ACCEPT_ENCODING);
		var isCompressAccepted = StringUtils.isNotBlank(gedAcceptEncoding)
				&& gedAcceptEncoding.toLowerCase().indexOf(HttpEncoding.GZIP_ENCODING) != -1;
		if (isCompressAccepted) {
			log.debug("[gzip-response-filter] Compresse response is Accepted, Header[{}] = {}",
					GlobalConstants.HEADER_GED_ACCEPT_ENCODING, gedAcceptEncoding);
			var gzipResponse = new GZipResponseWrapper(httpServletResponse);
			gzipResponse.addHeader(GlobalConstants.HEADER_GED_CONTENT_ENCODING, HttpEncoding.GZIP_ENCODING);
			chain.doFilter(httpServletRequest, gzipResponse);
			gzipResponse.finishResponse();
		} else {
			log.debug("[gzip-response-filter] Compresse response is Not Accepted");
			chain.doFilter(httpServletRequest, httpServletResponse);
		}
	}
}