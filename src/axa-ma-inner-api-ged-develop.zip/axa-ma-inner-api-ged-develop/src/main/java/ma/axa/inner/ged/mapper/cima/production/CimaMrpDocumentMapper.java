package ma.axa.inner.ged.mapper.cima.production;

import ma.axa.inner.ged.domain.cima.production.CimaMrpDocumentEs;
import ma.axa.inner.ged.dto.cima.production.CimaDocumentRequest;
import ma.axa.inner.ged.dto.cima.production.CimaDocumentResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CimaMrpDocumentMapper {

    CimaMrpDocumentEs fromDto(CimaDocumentRequest documentRes);

    @Mapping(source = "createdBy", target = "uploadedBy")
    CimaDocumentResponse toDto(CimaMrpDocumentEs documentEs);
}
