package ma.axa.inner.ged.mapper.at;

import ma.axa.inner.ged.dto.DocClaimAtReqDto;
import ma.axa.inner.ged.enums.OldGedRepositoryEnum;
import ma.axa.inner.ged.util.DateUtils;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.chemistry.opencmis.client.api.Property;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE,imports = {Date.class, StringUtils.class, Objects.class})
public interface DocumentsAlfrescoMapper {
    default DocClaimAtReqDto mapFromAlfrescoMetadata(Map<String,Object> map,String claimNumber,Integer occurenceDate){
        if(CollectionUtils.isEmpty(map)){
            return null;
        }
        final var docClaimAtReq = DocClaimAtReqDto.builder();
        if(map.containsKey(PropertyIds.OBJECT_ID) && StringUtils.isNotBlank(Objects.toString(map.get(PropertyIds.OBJECT_ID),null))){
            docClaimAtReq.idAlfresco(StringUtils.substringBefore(StringUtils.replace(Objects.toString(map.get(PropertyIds.OBJECT_ID),null),GlobalConstants.PREFIX_IN_ALFRESCO_ID,""),";"));
        }
        else {
            return null;
        }
        docClaimAtReq.numSinistre(claimNumber);

        docClaimAtReq.dateSurvenance(DateUtils.parseDate(Objects.toString(occurenceDate,null), GlobalConstants.DATE_FORMAT_FOR_FRONT));
        final var receptionDate = getReceptionDate(map);
        if(receptionDate != null) {
            docClaimAtReq.receptionDate(LocalDate.of(receptionDate.get(Calendar.YEAR), receptionDate.get(Calendar.MONTH) + 1, receptionDate.get(Calendar.DAY_OF_MONTH)));
            docClaimAtReq.creationTimeStamp(receptionDate.getTimeInMillis());
        }
        docClaimAtReq.uploadedby(getUploadedBy(map));
        docClaimAtReq.size(getSize(map));
        docClaimAtReq.nomDocument(getFileName(map));
        docClaimAtReq.numPolice(getPoliceNumber(map));
        docClaimAtReq.repertoire(getRepertoire(map));
        return docClaimAtReq.build();
    }
    default Map<String,Object> mapFromPropertyToHashMap(List<Property<?>> listOfProperties){
        return listOfProperties.stream().map(this::mapFromProperty).filter(Objects::nonNull).collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));
    }
    default Map.Entry<String,Object> mapFromProperty(Property<?> property){
        if(property.getId() != null && property.getValue() != null)
            return Map.entry(property.getId(), property.getValue());
        else
            return null;
    }

    default DocClaimAtReqDto mapFromPropertiesToAlfresco(List<Property<?>> listOfProperties, String claimNumber, Integer occurrenceDate){

        return mapFromAlfrescoMetadata(mapFromPropertyToHashMap(listOfProperties),claimNumber,occurrenceDate);
    }


    default GregorianCalendar getReceptionDate(Map<String,Object> map){
        if(map.containsKey(AXADocPropertyIds.DATE_ARRIVEE) && map.get(AXADocPropertyIds.DATE_ARRIVEE) != null){
            return (GregorianCalendar)  map.get(AXADocPropertyIds.DATE_ARRIVEE);
        }
        else if(map.containsKey(PropertyIds.CREATION_DATE) && map.get(PropertyIds.CREATION_DATE) != null){
            return (GregorianCalendar)  map.get(PropertyIds.CREATION_DATE);
        }
        return null;
    }

    default String getUploadedBy(Map<String,Object> map){
        if(map.containsKey(AXADocPropertyIds.AGENT_INDEXATION) && StringUtils.isNotBlank(Objects.toString(map.get(AXADocPropertyIds.AGENT_INDEXATION),null))){
            return Objects.toString(map.get(AXADocPropertyIds.AGENT_INDEXATION),null);
        }
        else if(map.containsKey(AXADocPropertyIds.AGENT_NUMERISATION) && StringUtils.isNotBlank(Objects.toString(map.get(AXADocPropertyIds.AGENT_NUMERISATION),null))){
            return Objects.toString(map.get(AXADocPropertyIds.AGENT_NUMERISATION),null);
        }
        return null;
    }

    default String getFileName(Map<String,Object> map){
        if(map.containsKey(PropertyIds.CONTENT_STREAM_FILE_NAME) && StringUtils.isNotBlank(Objects.toString(map.get(PropertyIds.CONTENT_STREAM_FILE_NAME),null))){
            return Objects.toString(map.get(PropertyIds.CONTENT_STREAM_FILE_NAME),null);
        }
        else if(map.containsKey(PropertyIds.NAME) && StringUtils.isNotBlank(Objects.toString(map.get(PropertyIds.NAME),null))){
            return Objects.toString(map.get(PropertyIds.NAME),null);
        }
        return null;

    }

    default BigDecimal getPoliceNumber(Map<String,Object> map){
        if(map.containsKey(AXADocPropertyIds.NUMERO_POLICE) && StringUtils.isNumeric(StringUtils.trim(Objects.toString(map.get(AXADocPropertyIds.NUMERO_POLICE),null)))){
            return new BigDecimal(Objects.toString(map.get(AXADocPropertyIds.NUMERO_POLICE),null));
        }
        return null;
    }

    default Long getSize(Map<String,Object> map){
        if(map.containsKey(PropertyIds.CONTENT_STREAM_LENGTH) && map.get(PropertyIds.CONTENT_STREAM_LENGTH)!= null && map.get(PropertyIds.CONTENT_STREAM_LENGTH) instanceof BigInteger){
            return ((BigInteger)map.get(PropertyIds.CONTENT_STREAM_LENGTH)).longValue();
        }
        return null;
    }

    default String getRepertoire(Map<String, Object> map) {
        if (map.containsKey(AXADocPropertyIds.TYPE_COURRIER) && StringUtils.isNotBlank(Objects.toString(map.get(AXADocPropertyIds.TYPE_COURRIER), null))) {
            return Optional.ofNullable(OldGedRepositoryEnum.getByCode(Objects.toString(map.get(AXADocPropertyIds.TYPE_COURRIER), null)))
                    .map(OldGedRepositoryEnum::getCorrespondingNewGedId)
                    .orElse(null);
        }
        return null;
    }

}
