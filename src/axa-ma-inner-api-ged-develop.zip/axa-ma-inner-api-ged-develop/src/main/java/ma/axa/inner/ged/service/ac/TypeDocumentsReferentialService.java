package ma.axa.inner.ged.service.ac;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.domain.TypeDocAs400;
import ma.axa.inner.ged.dto.TypeDocResponse;
import ma.axa.inner.ged.enums.AutoAtBranchEnum;
import ma.axa.inner.ged.mapper.ac.TypeDocAutoMapper;
import ma.axa.inner.ged.repository.TypeDocRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class TypeDocumentsReferentialService {

    private final TypeDocRepository typeDocRepository;
    private final TypeDocAutoMapper autoMapper;

    public List<TypeDocResponse> getListTypeDocs() {
        log.info("Start service: get documents types");
        List<TypeDocAs400> typeDocAs400List = typeDocRepository.findByBranch(AutoAtBranchEnum.SAC);
        List<TypeDocResponse> typeDocResponseList = autoMapper.typeDocListToTypeDocResponseList(typeDocAs400List);
        log.info("End service: get documents types size {}", typeDocResponseList.size());
        return typeDocResponseList;
    }
    public List<TypeDocResponse> getListTypeDocsByEntityId(int entityId) {
        log.info("Start service: get documents types by entityId '{}'", entityId);
        List<TypeDocAs400> typeDocAs400List = typeDocRepository.findByBranchAndEntityId(AutoAtBranchEnum.SAC,entityId);
        List<TypeDocResponse> typeDocResponseList = autoMapper.typeDocListToTypeDocResponseList(typeDocAs400List);
        log.info("End service: get documents types by entityId '{}' size {}", entityId, typeDocResponseList.size());
        return typeDocResponseList;
    }


}
