package ma.axa.inner.ged.mapper;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import ma.axa.inner.ged.util.DateUtils;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;


public class AlfrescoPropsMapper {

	protected AlfrescoPropsMapper() throws InstantiationException {
	   throw new InstantiationException("Instances of this type are forbidden");
	}
		
	protected static final Map<String, Object> toFolderProperties(
			Map<String, Object> properties,
			AlfrescoFolderProperties metaData) {

		if (properties == null)
			properties = new HashMap<>();

		addStringProperty(AXADocPropertyIds.NUMERO_SINISTRE_DOSSIER, metaData.getNumeroSinistreDossier(), properties);
		addStringProperty(AXADocPropertyIds.NUMERO_POLICE_DOSSIER, metaData.getNumeroPoliceDossier(), properties);
		addStringProperty(AXADocPropertyIds.CODE_PRODUIT, metaData.getCodeProduit(), properties);
		addStringProperty(AXADocPropertyIds.CLASSE_SINISTRE, metaData.getClasseSinistre(), properties);
		addStringProperty(AXADocPropertyIds.INTERMEDIARE_DOSSIER, metaData.getIntermediareDossier(), properties);
		addDateProperty(AXADocPropertyIds.DATE_SURVENANACE_DOSSIER, metaData.getDateSurvenanaceDossier(), properties);
		addDateProperty(AXADocPropertyIds.DATE_DECLARATION_DOSSIER, metaData.getDateDeclarationDossier(), properties);
		addStringProperty(AXADocPropertyIds.NOM_VICTIME_DOSSIER, metaData.getNomVictimeDossier(), properties);

		//TODO
		//NEW information
		addStringProperty(AXADocPropertyIds.VALEUR_JURIDIQUE_DOSSIER, metaData.getValeur_juridictionDossier(), properties);
		addStringProperty(AXADocPropertyIds.NUM_TRIBUNAL_DOSSIER, metaData.getNum_tribunalDossier(), properties);
		addStringProperty(AXADocPropertyIds.NUMERO_ADHESION_DOSSIER, metaData.getNumAdhesionDossier(), properties);
		addStringProperty(AXADocPropertyIds.LIB_BANQUE_DOSSIER, metaData.getLibBanqueDossier(), properties);
		addStringProperty(AXADocPropertyIds.NUM_DECLARATION_DOSSIER, metaData.getNumDeclarationDossier(), properties);

		addStringProperty(AXADocPropertyIds.CORRESPONDANCE_G_DOSSIER, metaData.getCorrespondance_GDossier(), properties);
		
		return properties;
	}

	protected static final Map<String, Object> toDocumentProperties(
			Map<String, Object> properties,
			AlfrescoDocumentProperties metaData) {

		if (properties == null)
			properties = new HashMap<>();

		addStringProperty(AXADocPropertyIds.NUMERO_POLICE, metaData.getNumPolice(), properties);
		addStringProperty(AXADocPropertyIds.NUMERO_SINISTRE, metaData.getNumSinistre(), properties);
		addStringProperty(AXADocPropertyIds.IDENTIFIANT_SCANER, metaData.getIdentifiantScaner(), properties);
		addStringProperty(AXADocPropertyIds.AGENT_INDEXATION, metaData.getAgentIndexation(), properties);
		addStringProperty(AXADocPropertyIds.AGENT_NUMERISATION, metaData.getAgentNumerisation(), properties);
		addStringProperty(AXADocPropertyIds.CREATED_BY, metaData.getCreatedBy(), properties);
		addStringProperty(AXADocPropertyIds.AGENT_INTERMEDIAIRE, metaData.getAgentIntermediaire(), properties);
		properties.put(AXADocPropertyIds.AUTHENTIQUE, metaData.isAuthentique);
		return properties;
	}

	@Getter
	@Setter
	@Builder
	protected static final class AlfrescoFolderProperties {
		private String numeroSinistreDossier;
		private String numeroPoliceDossier;
		private String codeProduit;
		private String classeSinistre;
		private String intermediareDossier;
		private LocalDate dateSurvenanaceDossier;
		private LocalDate dateDeclarationDossier;
		private String nomVictimeDossier;
		private String typeQuittanceDossier;
		//TODO
		//NEW information
		private String valeur_juridictionDossier;
		private String num_tribunalDossier;
		private String numAdhesionDossier;
		private String LibBanqueDossier;
		private String numDeclarationDossier;
		private String correspondance_GDossier;
		
	}

	@Getter
	@Setter
	@Builder
	protected static final class AlfrescoDocumentProperties {
		private String numPolice;
		private String numQuittance;
		private String numSinistre;
		private String identifiantScaner;
		private String agentIndexation;
		private String agentNumerisation;
		private String agentIntermediaire;
		private String createdBy;
		private boolean isAuthentique;
		private String typeQuittance;
		
		//TODO
		//NEW information
		private String valeur_juridiction;
		private String num_tribunal;
		private String numAdhesion;
		private String libBanque;
		private String numDeclaration;
		private String correspondance_G;
	}

	private static final void addStringProperty(String key, String value, Map<String, Object> map) {
		if (StringUtils.isNotBlank(value))
			map.put(key, value);
	}

	private static final void addDateProperty(String key, LocalDate value, Map<String, Object> map) {
		if (value != null)
			map.put(key, DateUtils.toDate(value));
	}

}
