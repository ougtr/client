package ma.axa.inner.ged.api.transverse.med;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.transverse.med.MEDDocumentRequest;
import ma.axa.inner.ged.dto.transverse.med.MEDDocumentResponse;
import ma.axa.inner.ged.service.transverse.med.MedDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;

import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;

import static ma.axa.inner.ged.util.constants.MedConstants.MED_BASE_URL;

@RestController
@RequestMapping("/v1/transverse/med/documents")
@Tag(name = GlobalConstants.TAG_MED_APIS, description = GlobalConstants.TAG_DESC_MED_APIS)
@RequiredArgsConstructor
@Slf4j
public class MedDocumentAPI {
	private final MedDocumentService medDocumentService;

	@Operation(summary = "Upload new document and indexing metadata")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Document ID", content = {
			@Content(mediaType = "multipart/form-data", schema = @Schema(implementation = MEDDocumentRequest.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid request", content = @Content) })
	@PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<MEDDocumentResponse> uploadAutoDocuments(
			@ParameterObject @ModelAttribute MEDDocumentRequest document,
			@RequestPart(value = "file") MultipartFile file) {
		log.info("Uploading new MED {} document and index meta-data {}, filename {}", document,
				file.getOriginalFilename());

		log.info("MEDDocumentRequest {}", document);
		var createdDocument = medDocumentService.uploadFile(document, file);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdDocument);

	}

	@Operation(summary = "download a med document by its alfresco id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was downloaded", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = Resource.class))}),
			@ApiResponse(responseCode = "404", description = "document not found with id", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})

	@GetMapping(value = "/{document_id}/content", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<Resource> downloadFile(@NotNull(message = "{error.alfresco.id}") @PathVariable(value = "document_id", required = true) String alfrescoIdWithoutPrefix) {
		log.info("Start api: Downloading file with id '{}'", alfrescoIdWithoutPrefix);
		var resource = medDocumentService.downloadFile(alfrescoIdWithoutPrefix);

		var headers = new HttpHeaders();
		String headerKey = "X-filename";
		String headerValue = resource.getFilename();
		headers.set(headerKey,headerValue);

		log.info("End api: File downloaded !");
		return ResponseEntity.ok().headers(headers).body(resource);
	}

}
