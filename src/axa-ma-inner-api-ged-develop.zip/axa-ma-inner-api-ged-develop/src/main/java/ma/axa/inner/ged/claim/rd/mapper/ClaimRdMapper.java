package ma.axa.inner.ged.claim.rd.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import ma.axa.inner.ged.claim.rd.domain.DocumentClaimRdEs;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdAddReq;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdResponse;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdUpdateReq;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ClaimRdMapper {

	// -> TO DTO

	public DocClaimRdResponse toDto(DocumentClaimRdEs document);

	public List<DocClaimRdResponse> toDto(List<DocumentClaimRdEs> documents);

	// -> FROM DTO

	public DocumentClaimRdEs fromDto(DocClaimRdAddReq documentRes);

	public List<DocumentClaimRdEs> fromDto(List<DocClaimRdAddReq> documentRes);

	public DocumentClaimRdEs fromDto(DocClaimRdUpdateReq documentReq);

	// -> update
	@BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
	void updateFromDto(DocClaimRdUpdateReq documentReq, @MappingTarget DocumentClaimRdEs document);

	// Others
	public static Page<DocumentClaimRdEs> mapToPage(SearchResponse<DocumentClaimRdEs> searchResponse, int from,
			int size) {
		PageRequest pageRequest = PageRequest.of(from, size);
		if (searchResponse == null || searchResponse.hits().hits().isEmpty() || searchResponse.hits().total() == null) {
			return Page.empty(pageRequest);
		} else {
			long totalElements = searchResponse.hits().total().value();
			List<DocumentClaimRdEs> results = searchResponse.hits().hits().stream()
					.map(Hit::source)
					.collect(Collectors.toList());
			return new PageImpl<>(results, pageRequest, totalElements);
		}
	}
}
