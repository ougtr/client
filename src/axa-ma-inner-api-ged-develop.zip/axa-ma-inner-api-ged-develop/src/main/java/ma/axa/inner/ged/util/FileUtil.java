package ma.axa.inner.ged.util;

import java.net.URLConnection;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import ma.axa.inner.ged.dto.production.rc.RcProductionDocumentRequest;
import org.apache.commons.lang3.StringUtils;

import lombok.experimental.UtilityClass;
import ma.axa.inner.ged.exception.FileNameNotValidException;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springframework.web.multipart.MultipartFile;

@UtilityClass
public class FileUtil {


	public static String getMimeType(String fileName) {
		// 1. first use java's built-in utils
		var mimeTypes = URLConnection.getFileNameMap();
		var contentType = mimeTypes.getContentTypeFor(fileName);

		// 2. nothing found -> lookup our in extension map to find types like ".doc" or
		// ".docx"
		if (contentType == null) {
			var extension = fileName.substring(fileName.lastIndexOf('.') + 1, fileName.length());
			contentType = fileExtensionMap.get(extension);
		}
		return contentType;
	}

	/**
	 * Append current date to folder path,<br>
	 * 
	 * @return generated path like: {@code  <path>/yyyy/MM/dd}
	 */
	public static String appendDateAsSubFolders(final String path) {
		if (StringUtils.isBlank(path))
			return null;
		var customPath = getPath(path, false, false);
		var current = LocalDate.now();
		return String.format("/%s/%tY/%2$tm/%2$td", customPath, current);
	}

	public static String appendStringToFolderPath(final String path, String string) {
		var customPath = getPath(path);
		return String.join("/", customPath, string);
	}

	/**
	 * Clean up folder path
	 * 
	 * @param folderPath         The folder path
	 * @param withStartSeparator if {@code true} check & add / at start
	 * @param withEndSeparator   if {@code true} check & add / at the end
	 * @return
	 */
	public static String getPath(final String folderPath, final boolean withStartSeparator,
			final boolean withEndSeparator) {
		if (folderPath == null)
			return null;
		var sb = new StringBuilder(folderPath);
		if (withStartSeparator && !folderPath.startsWith(GlobalConstants.FOLDER_SEPARATOR)) {
			sb.insert(0, GlobalConstants.FOLDER_SEPARATOR);
		} else if (!withStartSeparator && folderPath.startsWith(GlobalConstants.FOLDER_SEPARATOR)) {
			sb.deleteCharAt(0);
		}
		if (withEndSeparator && !folderPath.endsWith(GlobalConstants.FOLDER_SEPARATOR)) {
			sb.append(GlobalConstants.FOLDER_SEPARATOR);
		} else if (!withEndSeparator && folderPath.endsWith(GlobalConstants.FOLDER_SEPARATOR)) {
			sb.deleteCharAt(sb.length() - 1);
		}
		return sb.toString();
	}

	public static String removeExtension(final String fileName) {
		if (StringUtils.isBlank(fileName))
			return "";
		final int index = fileName.lastIndexOf('.');
		if (index == -1) {
			return fileName;
		}
		return fileName.substring(0, index);
	}

	public static String getExtension(final String fileName) {
		final int index = fileName.lastIndexOf('.');
		if (index == -1) {
			return "";
		}
		return fileName.substring(index + 1, fileName.length());
	}

	public static String nextFileName(String filename, int suffix) {
		var tempFilename = removeExtension(filename);
		var extension = getExtension(filename);
		var sb = new StringBuilder(tempFilename);
		if(suffix > 0)
			sb.append(String.format("_%d_%d", suffix, DateUtils.getCurrenNanoDateTime()));
		if(StringUtils.isNotBlank(extension))
			sb.append(".").append(extension);
		return sb.toString();
	}

	private static final Map<String, String> fileExtensionMap;

	static {
		fileExtensionMap = new HashMap<>();
		// MS Office
		fileExtensionMap.put("doc", "application/msword");
		fileExtensionMap.put("dot", "application/msword");
		fileExtensionMap.put("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
		fileExtensionMap.put("dotx", "application/vnd.openxmlformats-officedocument.wordprocessingml.template");
		fileExtensionMap.put("docm", "application/vnd.ms-word.document.macroEnabled.12");
		fileExtensionMap.put("dotm", "application/vnd.ms-word.template.macroEnabled.12");
		fileExtensionMap.put("xls", "application/vnd.ms-excel");
		fileExtensionMap.put("xlt", "application/vnd.ms-excel");
		fileExtensionMap.put("xla", "application/vnd.ms-excel");
		fileExtensionMap.put("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		fileExtensionMap.put("xltx", "application/vnd.openxmlformats-officedocument.spreadsheetml.template");
		fileExtensionMap.put("xlsm", "application/vnd.ms-excel.sheet.macroEnabled.12");
		fileExtensionMap.put("xltm", "application/vnd.ms-excel.template.macroEnabled.12");
		fileExtensionMap.put("xlam", "application/vnd.ms-excel.addin.macroEnabled.12");
		fileExtensionMap.put("xlsb", "application/vnd.ms-excel.sheet.binary.macroEnabled.12");
		fileExtensionMap.put("ppt", "application/vnd.ms-powerpoint");
		fileExtensionMap.put("pot", "application/vnd.ms-powerpoint");
		fileExtensionMap.put("pps", "application/vnd.ms-powerpoint");
		fileExtensionMap.put("ppa", "application/vnd.ms-powerpoint");
		fileExtensionMap.put("pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation");
		fileExtensionMap.put("potx", "application/vnd.openxmlformats-officedocument.presentationml.template");
		fileExtensionMap.put("ppsx", "application/vnd.openxmlformats-officedocument.presentationml.slideshow");
		fileExtensionMap.put("ppam", "application/vnd.ms-powerpoint.addin.macroEnabled.12");
		fileExtensionMap.put("pptm", "application/vnd.ms-powerpoint.presentation.macroEnabled.12");
		fileExtensionMap.put("potm", "application/vnd.ms-powerpoint.presentation.macroEnabled.12");
		fileExtensionMap.put("ppsm", "application/vnd.ms-powerpoint.slideshow.macroEnabled.12");
		// Open Office
		fileExtensionMap.put("odt", "application/vnd.oasis.opendocument.text");
		fileExtensionMap.put("ott", "application/vnd.oasis.opendocument.text-template");
		fileExtensionMap.put("oth", "application/vnd.oasis.opendocument.text-web");
		fileExtensionMap.put("odm", "application/vnd.oasis.opendocument.text-master");
		fileExtensionMap.put("odg", "application/vnd.oasis.opendocument.graphics");
		fileExtensionMap.put("otg", "application/vnd.oasis.opendocument.graphics-template");
		fileExtensionMap.put("odp", "application/vnd.oasis.opendocument.presentation");
		fileExtensionMap.put("otp", "application/vnd.oasis.opendocument.presentation-template");
		fileExtensionMap.put("ods", "application/vnd.oasis.opendocument.spreadsheet");
		fileExtensionMap.put("ots", "application/vnd.oasis.opendocument.spreadsheet-template");
		fileExtensionMap.put("odc", "application/vnd.oasis.opendocument.chart");
		fileExtensionMap.put("odf", "application/vnd.oasis.opendocument.formula");
		fileExtensionMap.put("odb", "application/vnd.oasis.opendocument.database");
		fileExtensionMap.put("odi", "application/vnd.oasis.opendocument.image");
		fileExtensionMap.put("oxt", "application/vnd.openofficeorg.extension");
		// Other
		fileExtensionMap.put("txt", "text/plain");
		fileExtensionMap.put("rtf", "application/rtf");
		fileExtensionMap.put("pdf", "application/pdf");
	}

	public static void assertFileNameValid(String filename) throws FileNameNotValidException {
		if (StringUtils.isBlank(filename)) {
			throw new FileNameNotValidException("file name is blank");
		}
		if (!filename.contains(".")) {
			throw new FileNameNotValidException(
					"file name (" + filename + ") is invalid (should contain an extension)");
		}
	}

	public static String replaceMimeTypeWithReadableFormDoc(String mimeType) {
		if (StringUtils.isEmpty(mimeType)) {
			return null;
		}
		String str = null;
		for (final var entry : fileExtensionMap.entrySet()) {
			if (StringUtils.equals(entry.getValue(), mimeType)) {
				str = entry.getKey();
				break;
			}
		}
		return str;
	}

	public static String getFolderPathFromDocumentPath(String path) {

		return path.substring(0, path.lastIndexOf("/"));
	}

	public static boolean isValidFile(MultipartFile file) {
		return file != null && file.getOriginalFilename() != null && file.getContentType() != null;
	}

	public static String getPath(String path) {
		if (path == null)
			return null;
		var sb = new StringBuilder(path);
		if (path.endsWith(GlobalConstants.FOLDER_SEPARATOR)) {
			sb.deleteCharAt(sb.length() - 1);
		}
		return sb.toString();
	}

    public static String constructFileSize(long fileSizeInOc) {
		double fileSizeInKiloBytes = Math.round((double) fileSizeInOc / 1024);
		double fileSizeInMegaBytes = Math.round(fileSizeInKiloBytes / 1024);
		if (fileSizeInMegaBytes >= 1) return (int) fileSizeInMegaBytes + " Mo";
		else return (int) fileSizeInKiloBytes + " ko";
    }
}
