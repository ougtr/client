package ma.axa.inner.ged.domain.cima.auto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CimaAutoDocumentsTypeEs {
	private String id;
	private String lib;
	private String directoryName;
	private String entityName;
	private String desc;
	private String description;
}
