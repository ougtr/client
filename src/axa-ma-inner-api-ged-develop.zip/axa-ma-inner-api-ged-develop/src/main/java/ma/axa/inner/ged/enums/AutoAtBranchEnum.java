package ma.axa.inner.ged.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum AutoAtBranchEnum {
    SAT(Values.SAT),SAC(Values.SAC);
    private final String value;
    public static class Values{
        public final static String SAT = "SAT";
        public final static String SAC = "SAC";
    }
}