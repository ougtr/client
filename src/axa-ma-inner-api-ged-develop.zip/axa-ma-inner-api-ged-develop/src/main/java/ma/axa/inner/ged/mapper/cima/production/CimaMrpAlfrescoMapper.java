package ma.axa.inner.ged.mapper.cima.production;

import ma.axa.inner.ged.dto.cima.production.CimaDocumentRequest;
import ma.axa.inner.ged.mapper.AlfrescoPropsMapper;

import java.util.Collections;
import java.util.Map;

public class CimaMrpAlfrescoMapper extends AlfrescoPropsMapper {
    private CimaMrpAlfrescoMapper() throws InstantiationException {
        throw new InstantiationException("Instances of this type are forbidden");
    }

    public static Map<String, Object> toFolderProperties(CimaDocumentRequest metaData) {
        return toFolderProperties(metaData, null);
    }

    public static Map<String, Object> toFolderProperties(CimaDocumentRequest metaData, Map<String, Object> properties) {
        if (metaData == null) {
            return Collections.emptyMap();
        }

        var alfrescoProps = AlfrescoFolderProperties.builder()
                .numeroPoliceDossier(metaData.getPolicyNumber())
                .intermediareDossier(metaData.getAgentCode())
                .codeProduit(metaData.getProductCode())
                .build();
        return toFolderProperties(properties, alfrescoProps);
    }

    public static Map<String, Object> toDocumentProperties(CimaDocumentRequest metaData) {
        return toDocumentProperties(metaData, null);
    }

    public static Map<String, Object> toDocumentProperties(CimaDocumentRequest metaData, Map<String, Object> properties) {
        if (metaData == null) {
            return Collections.emptyMap();
        }
        var alfrescoProps = AlfrescoDocumentProperties.builder()
                .numPolice(metaData.getPolicyNumber())
                .createdBy(metaData.getCreatedBy())
                .agentIntermediaire(metaData.getAgentCode())
                .build();
        return toDocumentProperties(properties, alfrescoProps);
    }
}
