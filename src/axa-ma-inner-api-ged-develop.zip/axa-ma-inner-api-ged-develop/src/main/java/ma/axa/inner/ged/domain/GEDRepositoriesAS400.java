package ma.axa.inner.ged.domain;


import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@Table(name = "SINREPGED")
@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@DiscriminatorColumn(name = "branch", discriminatorType = DiscriminatorType.STRING)
public class GEDRepositoriesAS400 {
    @Id
    @Column(name = "ID")
    private Integer id;
    @Column(name = "GED_DIR")
    private String gedDirectory;
    @Column(name = "DIR_COLOR")
    private String directoryColor;
}
