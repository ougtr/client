package ma.axa.inner.ged.mapper;

import ma.axa.inner.ged.util.FileUtil;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Named;
import org.springframework.stereotype.Component;

@Component
public class MapstructUtil {

    @Named("mapToFileSize")
    public static String fileSize(long fileSize) {
        return FileUtil.constructFileSize(fileSize);
    }
    @Named("trim")
	public static String trimValue(String value) {
		return StringUtils.trim(value);
	}

}
