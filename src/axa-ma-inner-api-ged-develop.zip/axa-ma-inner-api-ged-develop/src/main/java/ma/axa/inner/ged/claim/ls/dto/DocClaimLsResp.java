package ma.axa.inner.ged.claim.ls.dto;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class DocClaimLsResp {
	@JsonProperty(index = 1)
	private String id;
	private String sinistreNumber;
	private String filename;
	private String path;
	private String brancheLabel;
	private String reference;

	private String uploadedBy;
	private String repertoire;
	private String repertoireCode;
}
