package ma.axa.inner.ged.claim.transport.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.claim.common.domain.DocumentClaimEs;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentClaimTransportEs extends DocumentClaimEs {
	// Add specific properties CLAIMS TRANSPORT if u need
	@JsonProperty("num_certificat")
	private String numCertificat;
	@JsonProperty("num_order")
	private String numOrder;
	
}
