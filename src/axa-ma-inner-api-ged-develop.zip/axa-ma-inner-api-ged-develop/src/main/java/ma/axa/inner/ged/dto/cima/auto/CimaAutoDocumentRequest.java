package ma.axa.inner.ged.dto.cima.auto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.inner.ged.enums.Nature;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CimaAutoDocumentRequest {
	@NotNull(message = "Param can not be Null")
	private CountryCode countryCode;

	@NotNull(message = "Param can not be Null")
	@NotEmpty(message = "Param can not be empty")
	private String typeDocument;
	private String numDeclaration;
	private String numSinistre;
	@NotNull(message = "Param can not be Null")
	@NotEmpty(message = "Param can not be empty")
	private String numPolice;
	private String immatriculation;
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate dateSurvenace;
	private String compagnieAdverse;
	private String codeIntermediaire;
	private String nomIntermediaire;
	private String refPrestataire;
	private String refMoyenPaiement;
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate dateReception;
	@NotNull(message = "Param can not be Null")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate dateNumerisation;
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate dateEffet;
	private String entiteEmetteur;
	private AutoDocumentStatus statut;
	@Builder.Default
	private String branche = "AUTO";
	private Nature nature;

	@NotNull(message = "Param can not be Null")
	@NotEmpty(message = "Param can not be empty")
	private String createdBy;
	@NotNull(message = "Param can not be Null")
	@DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime createdAt;
}