package ma.axa.inner.ged.domain.ac;

import lombok.*;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.domain.GEDRepositoriesAS400;
import ma.axa.inner.ged.enums.AutoAtBranchEnum;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;


@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@DiscriminatorValue(value= AutoAtBranchEnum.Values.SAC)
public class GedDirectory extends GEDRepositoriesAS400 {
    @Column(name = "HAS_VICTIM")
    private Boolean hasVictim;
    @Column(name = "HASIDPRC")
    private Boolean withIdProcedure;
}
