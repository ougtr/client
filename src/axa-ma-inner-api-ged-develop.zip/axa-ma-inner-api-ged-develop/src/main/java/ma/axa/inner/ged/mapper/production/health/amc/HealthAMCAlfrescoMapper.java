package ma.axa.inner.ged.mapper.production.health.amc;

import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCReq;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCUpdateReq;
import ma.axa.inner.ged.mapper.AlfrescoPropsMapper;


import java.util.Collections;
import java.util.Map;

public class HealthAMCAlfrescoMapper extends AlfrescoPropsMapper {

	private HealthAMCAlfrescoMapper() throws InstantiationException {
		throw new InstantiationException("Instances of this type are forbidden");
	}

	// Folders

	public static Map<String, Object> toFolderProperties(DocHealthAMCReq metaData) {
		return toFolderProperties(metaData, null);
	}

	public static Map<String, Object> toFolderProperties(DocHealthAMCReq metaData, Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();

		var alfrescoProps = AlfrescoFolderProperties.builder()
				.numeroPoliceDossier(metaData.getPolicyNumber())
				.build();

		return toFolderProperties(properties, alfrescoProps);
	}

	// Documents

	public static Map<String, Object> toDocumentProperties(DocHealthAMCReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocHealthAMCReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numPolice(metaData.getPolicyNumber())
				.identifiantScaner(metaData.getReference())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}

	public static Map<String, Object> toDocumentProperties(DocHealthAMCUpdateReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocHealthAMCUpdateReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numPolice(metaData.getPolicyNumber())
				.identifiantScaner(metaData.getReference())
				.isAuthentique(metaData.isOriginal())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}
}