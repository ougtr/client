package ma.axa.inner.ged.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class InfoSinistre {
	private BigDecimal SNNSIN;
	private BigDecimal POLNUM;
	private BigDecimal PRCPRD;
	private String COUSRC;
	private BigDecimal CODTCR;
	private BigDecimal SNDSUR;
	private BigDecimal SNDDEC;
	private BigDecimal COAPPO;
	private BigDecimal CLASIN;
	private String PERNOM;
	private String PERPRE;
}
