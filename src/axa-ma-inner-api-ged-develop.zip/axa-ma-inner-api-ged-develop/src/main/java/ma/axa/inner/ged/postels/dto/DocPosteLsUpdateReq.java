package ma.axa.inner.ged.postels.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
public class DocPosteLsUpdateReq {
	private String numPolice;
	private String typeDocumentCode;
	private boolean original;
	private String numQuotation;
	private String comment;
}
