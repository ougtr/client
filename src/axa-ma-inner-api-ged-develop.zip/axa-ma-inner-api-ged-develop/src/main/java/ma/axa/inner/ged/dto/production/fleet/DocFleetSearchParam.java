package ma.axa.inner.ged.dto.production.fleet;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ma.axa.inner.ged.util.constants.GlobalConstants;

import javax.validation.constraints.Min;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DocFleetSearchParam {
    private String policyNumber;
    private String idQuotation;
    private String idSimulation;
    private String typeDocument;
    @Min(value = 0, message = GlobalConstants.ERROR_MSG_SEARCH_PAGENUMBER_MIN)
    @Builder.Default
    private Integer pageNumber = 0;
    @Min(value = 1, message = GlobalConstants.ERROR_MSG_SEARCH_PAGESIZE_MIN)
    @Builder.Default
    private Integer pageSize = 10;
}
