package ma.axa.inner.ged.mapper.parametrage;

import java.math.BigDecimal;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import ma.axa.inner.ged.domain.parametrage.TypeDocumentParametrage;
import ma.axa.inner.ged.dto.parametrage.TypeDocumentResponseDto;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface TypeDocumentParametrageMapper {

	@Mapping(source = "code", target = "codeTypeDocument", qualifiedByName = "convertBigDec")
	@Mapping(source = "libelle", target = "libelleTypeDocument")
	public TypeDocumentResponseDto mapToEntityDto(TypeDocumentParametrage ep);
	public List<TypeDocumentResponseDto> mapToEntityDtoList(List<TypeDocumentParametrage> eps);
	
	
	@Named("convertBigDec")
	 default int convertBigDec(BigDecimal code){
        return Integer.valueOf(code.toString());
    }
	
}
