package ma.axa.inner.ged.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.function.Supplier;

@Component
@Slf4j
@RequiredArgsConstructor
public class ConcurrentCompletableFuture<T> extends CompletableFuture<T> implements AsyncUncaughtExceptionHandler {
    private static Executor executor;

    private static Integer poolSize;

    @Value("200")
    public void setPoolSize(Integer size) {
        poolSize = size;
    }

    @Override
    public Executor defaultExecutor() {
        if (executor == null) {
            executor = Executors.newFixedThreadPool(poolSize);
        }
        return executor;
    }

    @Override
    public <U> CompletableFuture<U> newIncompleteFuture() {
        return new ConcurrentCompletableFuture<>();
    }

    public static CompletableFuture<Void> runAsync(Runnable runnable) {
        Objects.requireNonNull(runnable);
        return supplyAsync(() -> {
            runnable.run();
            return null;
        });
    }

    public static <U> CompletableFuture<U> supplyAsync(Supplier<U> supplier) {
        return new ConcurrentCompletableFuture<U>().completeAsync(supplier);
    }

    @Override
    public void handleUncaughtException(Throwable ex, Method method, Object... params) {
        log.error("Exception happen in method {}", method.getName());
        log.error("with error : ", ex);
    }
}
