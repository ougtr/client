package ma.axa.inner.ged.claim.health.mapper;

import ma.axa.inner.ged.claim.health.domain.GedHealthEntityAS400;
import ma.axa.inner.ged.claim.health.domain.GedHealthEntityRes;
import ma.axa.inner.ged.claim.health.domain.GedProductionHealthEntityAS400;
import ma.axa.inner.ged.claim.health.dto.DocClaimHealthReq;
import ma.axa.inner.ged.claim.health.dto.DocProductionHealthReq;
import ma.axa.inner.ged.claim.health.dto.HealthSearchResponseDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import java.util.List;


@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface RepoHealthMapper {
    @Mapping(source = "typeDoc", target = "typedoc")
    @Mapping(source = "nomDoc" , target = "nomdoc")
    @Mapping(source = "idAlfresco" , target = "ideged")
    @Mapping(source = "typeGestion" , target = "typges")
    @Mapping(source = "uploadedBy" , target = "usercr")
    public GedHealthEntityAS400 toEntityAs400(DocClaimHealthReq docClaimHealthReq);
    @Mapping(source = "typeDoc", target = "colng4")
    @Mapping(source = "user" , target = "bdlusr")
    @Mapping(source = "idAlfresco" , target = "ideged")
    @Mapping(source = "police1" , target = "ponpo1")
    @Mapping(source = "police2" , target = "ponpo2")
    @Mapping(source = "codeProduit" , target = "codpro")
    @Mapping(source = "cotationId" , target = "ideamc")
    @Mapping(source = "typeCode" , target = "rectype")
    @Mapping(source = "numOrder" , target = "menuor")
    public GedProductionHealthEntityAS400 toEntityGedpProdHealthAs400(DocProductionHealthReq docProductionHealthReq);

    @Mapping(source = "typedoc", target = "typeDoc")
    @Mapping(source = "nomdoc" , target = "nomDoc")
    @Mapping(source = "ideged" , target = "idAlfresco")
    @Mapping(source = "typges" , target = "typeGestion")
    public DocClaimHealthReq toDto(GedHealthEntityAS400 gedHealthEntityAS400);


    @Mapping(source = "TYPDOC", target = "typeDocument")
    @Mapping(source = "IDEGED" , target = "idAlfresco")
    public HealthSearchResponseDto toDtoSearch(GedHealthEntityRes gedHealthEntityRes);

    @Mapping(source = "TYPDOC", target = "typeDocument")
    @Mapping(source = "IDEGED" , target = "idAlfresco")
    public List<HealthSearchResponseDto> toDtoSearch(List<GedHealthEntityRes> gedHealthEntityRes);

}