package ma.axa.inner.ged.repository;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.dto.DocClaimAtReqDto;
import ma.axa.inner.ged.exception.DocumentNotFoundException;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.IOFileException;
import ma.axa.inner.ged.mapper.at.DocumentsAlfrescoMapper;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.StringUtil;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.chemistry.opencmis.client.api.*;
import org.apache.chemistry.opencmis.client.runtime.OperationContextImpl;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.chemistry.opencmis.commons.enums.Action;
import org.apache.chemistry.opencmis.commons.enums.CapabilityContentStreamUpdates;
import org.apache.chemistry.opencmis.commons.enums.IncludeRelationships;
import org.apache.chemistry.opencmis.commons.enums.VersioningState;
import org.apache.chemistry.opencmis.commons.exceptions.CmisContentAlreadyExistsException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisObjectNotFoundException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisPermissionDeniedException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisServiceUnavailableException;
import org.apache.chemistry.opencmis.commons.impl.dataobjects.ContentStreamImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.math.BigInteger;
import java.nio.file.FileAlreadyExistsException;
import java.util.*;
import java.util.stream.Stream;


@AllArgsConstructor
@Data
@Repository
@Slf4j
public class ClaimDocumentRepository { 
	private final Session session;

	public Folder createOrUpdateFolder(String parentFolderPath,Map<String, Object> properties) {
		log.info("Start: createOrUpdateFolder in repository with parentFolderPath '{}' and properties '{}'", parentFolderPath,properties);
		Folder targetFolder = null;
		try {
			targetFolder = (Folder) session.getObjectByPath(parentFolderPath+"/"+properties.get(PropertyIds.NAME));
			
		} catch (CmisObjectNotFoundException child){
			targetFolder =  ((Folder) session.getObjectByPath(parentFolderPath)).createFolder(properties);
		}
		log.info("End: createOrUpdateFolder");
		return targetFolder;
	}

	public Folder createArboFoldersByPath(String parentFolderPath, String path){
		log.info("Start: createArboFoldersByPath in repository with parentFolderPath '{}' and path '{}'", parentFolderPath,path);
		String[] paths = path.split("/"); 
		Folder currentFolder = null;
		for (var i = 0; i < paths.length; i++) {
			Map<String, Object> folderProperties = new HashMap<>(2);
			folderProperties.put(PropertyIds.NAME, paths[i]);
			folderProperties.put(PropertyIds.OBJECT_TYPE_ID, "cmis:folder");
			currentFolder = createOrUpdateFolder(parentFolderPath, folderProperties);
			parentFolderPath = currentFolder.getPath();
		}
		log.info("End: createArboFoldersByPath");
		return currentFolder;
	}
	 
	@SneakyThrows
	public Document  getFileObject(String id) {
		log.info("Start: getting document from repo by id : '{}' ",id);
		if(StringUtils.isNotBlank(id)) {
			Document cmisDocument = null;
			try {
				var cmisObject = session.getObject(id);
				cmisDocument = (Document) cmisObject;
			} catch (CmisObjectNotFoundException e) {
				log.error(" document with id '{}' not found",id);
				throw new DocumentNotFoundException("document with id " + id + " not found ");
			}
			log.info("End: getting document from repo by id : '{}'",id);
			return cmisDocument;
		}
		return null;
	} 
	
	public Document createDocument(Folder folder, GedDocument data) {
		log.info("Start: create Document with name : '{}' ",data.getFileName());
		Map<String, Object> properties = new HashMap<>();
		properties.put(PropertyIds.OBJECT_TYPE_ID, AXADocPropertyIds.AXA_DOC_TYPE);
		properties.put(PropertyIds.NAME, data.getFileName());
		properties.put(PropertyIds.CONTENT_STREAM_MIME_TYPE,data.getMimeType());
		log.info("End: create Document  with name : '{}'",data.getFileName());
		return folder.createDocument(properties
				,new ContentStreamImpl(
					data.getFileName(),
					BigInteger.valueOf(data.getFileByte().length),
					data.getMimeType(),
					new ByteArrayInputStream(data.getFileByte()))
				,VersioningState.MAJOR).getObjectOfLatestVersion(false);
	}
	
	
	@SneakyThrows
	public GedDocument getFileDocument(String alfrescoId) {
		log.info("Start: Get Document : '{}' ", alfrescoId);
		var document = getFileObject(alfrescoId);	

		var gedDocument = new GedDocument();
		if(document.getContentStream() != null && document.getContentStream().getStream() != null)
			gedDocument.setFileByte(document.getContentStream().getStream().readAllBytes());
		if(StringUtils.isNotBlank(document.getName())){
			gedDocument.setFileName(document.getName());
			gedDocument.setMimeType(FileUtil.getMimeType(document.getName()));
		}
		log.info("End: Get Document : '{}' ", alfrescoId);
		return gedDocument;
	}


	public Folder getFolder(String folderPath)  {
		log.info("Start: Get Folder : '{}' ", folderPath);
		Folder targetFolder = null;
		try {
			targetFolder = (Folder) session.getObjectByPath(folderPath);
			
		} catch (CmisObjectNotFoundException e) {
			throw new IOFileException("Dossier " + folderPath + " non trouvé");
		}
		log.info("End: Get Folder : '{}' ", folderPath);
		return targetFolder;
	}

	@SneakyThrows
	public void moveDocumentFromSourceToDestination(String destinationFolderPrefixPath,String destinationPath,String id){

		log.info("Start : move document to destination '{}'",destinationFolderPrefixPath+'/'+destinationPath);
		Folder destination = createArboFoldersByPath(destinationFolderPrefixPath, destinationPath);
		Document doc = getFileObject(id);
		final var alteredOriginalName = StringUtil.replaceExistingFileNameTemporaryIterations(doc.getName());
		Folder source = getFolder(FileUtil.getFolderPathFromDocumentPath(doc.getPaths().get(0)));
		Map<String, Object> properties = new HashMap<>();
		final String newFileName = StringUtil.addTimestampToExistingFileName(alteredOriginalName);
		try {
			properties.put(PropertyIds.NAME, newFileName);
			doc.updateProperties(properties);

			doc.move(source, destination);
		}catch (CmisContentAlreadyExistsException e){
			log.error("file with the same name already exists in destination");
			throw new IOFileException("file with the same name already exists in destination");
		}

		log.info("End : move document to destination '{}' was successful",destinationFolderPrefixPath+'/'+destinationPath);
	}

	// input should be in this manner
	// {
	// 	"idAlfresco" : [
	//		"full-Path",
	//
	// 	]
	// }
	@SneakyThrows
	public Map<String, List<String>> copyFileToDestination(Map<String,List<String>> alfrescoIdsWithPaths){
		log.info("Start : copy document to destination");
		final var hashMap = new HashMap<String,List<String>>();
		Document doc = null;
		Map<String, Object> documentProperties =
				new HashMap<>(1);
		Folder destination;
		for(final var idAlfrescosWithPath : alfrescoIdsWithPaths.entrySet()){
			try {
				if(StringUtils.isBlank(idAlfrescosWithPath.getKey())){continue;}

				for (var path : idAlfrescosWithPath.getValue()) {
					destination = getFolder(path);
					doc = getFileObject(idAlfrescosWithPath.getKey());
					documentProperties.put(PropertyIds.NAME, StringUtil.addTimestampToExistingFileNameWithoutFileNameAlteration(doc.getName()));
					doc = doc.copy(destination, documentProperties, null, null, null, null, new OperationContextImpl());

					final var docId = doc != null && doc.getId() != null ? StringUtils.replace(
							doc.getId(),
							StringUtils.substring(doc.getId(), StringUtils.indexOf(doc.getId(), ";")), "")
							: null;
					if (!hashMap.containsKey(idAlfrescosWithPath.getKey())) {
						hashMap.put(
								idAlfrescosWithPath.getKey(), new ArrayList<>());
					}

					hashMap.get(idAlfrescosWithPath.getKey()).add(docId);

				}

			}catch (Exception ex){
				log.error("can not copy index : {}", ex.getMessage());
				hashMap.put(idAlfrescosWithPath.getKey(),null);
			}
		}

		log.info("End : copy document to destination ");
		return hashMap;
	}


	public String deleteFile(String id){
		log.info("Start : delete document with id '{}'",id);
		Document doc = getFileObject(id);
		if(doc.getAllowableActions().getAllowableActions().contains(Action.CAN_DELETE_OBJECT)) {
			doc.delete(true);
		}
		else {
			log.error("End : can't delete document with id '{}' delete isn't allowed for this account.",id);
			throw new CmisPermissionDeniedException();
		}
		log.info("End : deleted document with id '{}'",id);
		return id;
	}

	public void updateContent(String id, MultipartFile newContentFile) {
		log.info("Start: Getting document from repo by id: '{}'", id);
		Document document = getFileObject(id);
		checkContentStreamUpdatesCapability();
		try {
			ContentStream newContentStream = createContentStream(newContentFile);
			document.setContentStream(newContentStream, true, true);
			log.info("Document updated successfully: {}", document.getName());
		} catch (Exception e) {
			log.error("Error updating document: {}", document.getName(), e);
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
		}
	}

	public void checkContentStreamUpdatesCapability() {
		if (!session.getRepositoryInfo().getCapabilities().getContentStreamUpdatesCapability()
				.equals(CapabilityContentStreamUpdates.ANYTIME)) {
			log.info("Update without checkout is not supported in this repository");
			throw new CmisServiceUnavailableException();
		}
	}

	public ContentStream createContentStream(MultipartFile newContentFile) throws IOException {
		return new ContentStreamImpl(
				newContentFile.getName(),
				BigInteger.valueOf(newContentFile.getSize()),
				newContentFile.getContentType(),
				new ByteArrayInputStream(newContentFile.getBytes())
		);
	}

	public ItemIterable<CmisObject> getAllChildsFromAlfrescoDirectory(String folderPath) {
		Folder folder = null;
		try {
			folder = getFolder(folderPath);
		} catch (IOFileException ex) {
			log.error("file not found by folder path {}", folderPath);
			return null;
		}
		var properties = Set.of(PropertyIds.OBJECT_ID,
				AXADocPropertyIds.NUMERO_SINISTRE,
				AXADocPropertyIds.DATE_ARRIVEE,
				PropertyIds.CONTENT_STREAM_LENGTH,
				PropertyIds.CONTENT_STREAM_FILE_NAME,
				PropertyIds.CREATION_DATE,
				PropertyIds.CONTENT_STREAM_MIME_TYPE,
				AXADocPropertyIds.NUMERO_POLICE, AXADocPropertyIds.AGENT_INDEXATION,
				AXADocPropertyIds.AGENT_NUMERISATION,
				PropertyIds.NAME,
				AXADocPropertyIds.TYPE_COURRIER,
				AXADocPropertyIds.NATURE_COURRIER);

		OperationContext operationContext = session.createOperationContext();
		operationContext.setFilter(properties);
		operationContext.setOrderBy(AXADocPropertyIds.DATE_ARRIVEE.concat(" DESC, ").concat(PropertyIds.CREATION_DATE).concat(" DESC"));
		operationContext.setMaxItemsPerPage(50);
		operationContext.setIncludeRelationships(IncludeRelationships.NONE);
		operationContext.setIncludeAllowableActions(false);
		operationContext.setRenditionFilterString("cmis:none");
		return folder.getChildren(operationContext);
	}

}
