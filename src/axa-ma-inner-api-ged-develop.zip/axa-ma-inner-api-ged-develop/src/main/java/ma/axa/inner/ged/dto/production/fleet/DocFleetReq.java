package ma.axa.inner.ged.dto.production.fleet;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DocFleetReq {
    @Builder.Default
    private String brancheLabel = "Flotte Production Doc";
    private String idAlfresco;
    private String filename;
    private Integer typedocumentCode;
    private String typedocumentLabel;
    private String policyNumber;
    private String createdBy;
    private String createdAt;
    private String lastUpdatedBy;
    private LocalDateTime lastUpdatedAt;
    private String filesize;
    private String filetype;
    private String quotationId;
    private String simulationId;
}