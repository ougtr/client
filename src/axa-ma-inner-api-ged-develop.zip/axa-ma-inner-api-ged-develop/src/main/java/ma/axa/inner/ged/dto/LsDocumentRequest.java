package ma.axa.inner.ged.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LsDocumentRequest {
	private String token;	
	private String codeProduct;
	private String codeAction;
	private String typedoc;
	private String urlDocument;
	private String libelleDocument;
}
