package ma.axa.inner.ged.config.security;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.web.util.UrlPathHelper;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.error.ApiError;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Slf4j
public class SecurityAuthEntryPoint implements AuthenticationEntryPoint {

	private final UrlPathHelper urlPathHelper = new UrlPathHelper();

	@Override
	public void commence(HttpServletRequest request,
			HttpServletResponse response, AuthenticationException authException)
			throws IOException, ServletException {
		String message;
		if (authException.getCause() != null) {
			message = authException.getCause().getMessage();
		} else {
			message = authException.getMessage();
		}
		log.warn(message + ": " + request.getMethod() + " "
				+ request.getRequestURI());
		response.setStatus(HttpServletResponse.SC_FORBIDDEN);
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		ApiError apiError = ApiError.builder().type(GlobalConstants.URI_DEFAULT)
				.title(HttpStatus.FORBIDDEN.getReasonPhrase())
				.status(HttpStatus.FORBIDDEN.value())
				.detail("Access to this resource is denied")
				.instance(urlPathHelper.getPathWithinApplication(request))
				.build();
		var jsonRes = new ObjectMapper().writeValueAsString(apiError);
		out.print(jsonRes);
		out.flush();
	}

}
