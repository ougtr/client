package ma.axa.inner.ged.dto.production.health.common;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DocHealthCommonResp extends DocHealthResp {
	@JsonProperty(index = 1)
	private String id;
}