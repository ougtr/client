package ma.axa.inner.ged.claim.rd.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.claim.common.domain.DocumentClaimEs;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentClaimRdEs extends DocumentClaimEs {
	// Add specific properties CLAIMS RD if u need
    @JsonProperty("predeclaration_number")
    private String predeclarationNumber;
}
