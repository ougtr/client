package ma.axa.inner.ged.dto.at;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class IntermediaryTypeDocDto {
    private Integer id;
    private TypeDocDto typology;
    private TypeDocDto secondTypology;
}
