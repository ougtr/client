package ma.axa.inner.ged.domain;

import java.io.Serializable;
import java.util.Optional;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.logging.log4j.util.Strings;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GedDocument implements Serializable{
	private static final long serialVersionUID = -3177057496353904598L;
	private byte[] fileByte;
	private String mimeType;
	private String fileName;

	public String getFileName() {
		return Optional.ofNullable(fileName)
				.map(name -> name.replaceFirst("^ac/", Strings.EMPTY))
				.orElse(null);
	}
}
