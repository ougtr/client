package ma.axa.inner.ged.service.transverse.med;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties;
import ma.axa.inner.ged.domain.alfresco.DocumentAlfresco;
import ma.axa.inner.ged.domain.transverse.med.MedDocumentEs;
import ma.axa.inner.ged.dto.transverse.med.MEDDocumentRequest;
import ma.axa.inner.ged.dto.transverse.med.MEDDocumentResponse;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.mapper.transverse.med.MedAlfrescoMapper;
import ma.axa.inner.ged.mapper.transverse.med.MedDocumentMapper;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.repository.transverse.med.MedElasticRepository;
import ma.axa.inner.ged.service.AlfrescoGedService;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import static ma.axa.inner.ged.util.CommonUtils.getPath;

@Service
@Slf4j
@RequiredArgsConstructor
public class MedDocumentService {
	private final MedElasticRepository medElasticRepository;
	private final MedDocumentMapper mapper;
	private final AxaGedProperties.BrancheProperties medProperties;
	private final AlfrescoGedService alfrescoService;

	private final ClaimDocumentRepository claimDocumentRepository;

	@SneakyThrows
	public MEDDocumentResponse uploadFile(MEDDocumentRequest metaData, MultipartFile file) {
		log.info("Start service: MEDDocumentResponse metaData:'{}' , File name:{} ", metaData, file.getName());
		try {
			MedDocumentEs document = mapper.fromDto(metaData);
			document.setFilename(file.getOriginalFilename());
			var folderProperties = MedAlfrescoMapper.toFolderProperties(metaData);
			var targetFolder = prepareDocumentFolder(folderProperties, metaData);
			Map<String, Object> properties = MedAlfrescoMapper.toDocumentProperties(metaData);
			DocumentAlfresco createdDocument = alfrescoService.createDocument(targetFolder, document.getFilename(),
					file, properties, true);
			log.info("AlfrescoService createDocument: {} ", createdDocument);
			if (createdDocument == null) {
				return null;
			}
			document.setId(createdDocument.getId());
			document.setFilename(createdDocument.getFilename());
			document.setPath(createdDocument.getPath());

			medElasticRepository.createNewDocument(document.getId(), document);
			return mapper.toDto(document);
		} catch (IOException e) {
			log.error("Error uploading document with meta-data: {}", metaData, e);
			throw new InternalErrorException("Erreur lors de l'upload du document");
		}
	}

	private Folder prepareDocumentFolder(Map<String, Object> properties, MEDDocumentRequest metaData) {
		var sitePath = medProperties.getAlfrescoSitePath();
		var folderPath = getFolderPath(metaData);
		var createdFolder = alfrescoService.createTreeFolder(folderPath, sitePath, properties);
		if (createdFolder == null) {
			throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
		}
		return createdFolder;
	}

	private String getFolderPath(MEDDocumentRequest metaData) {
		var rootFolderPath = "/".concat(medProperties.getAlfrescoRootFolder());
		var folderPathWithDate = appendEffectDate(rootFolderPath, metaData);
		return folderPathWithDate + "/" + metaData.getTypeAnnotation();
	}

	private String appendEffectDate(final String path, MEDDocumentRequest metaData) {
		var customPath = getPath(path);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String datePath = dateFormat.format(new Date());
		return String.join("/", customPath, datePath);
	}


	public Resource downloadFile(String id) {
		log.info("Start: Downloading file with id '{}'", id);
		var document = claimDocumentRepository.getFileDocument(id);
		log.debug("File downloaded : '{}'", document);
		log.info("Start: Downloading file with id '{}'", id);
		return new ByteArrayResource(document.getFileByte()){
			@Override
			public String getFilename(){
				return document.getFileName();
			}
		};
	}

}
