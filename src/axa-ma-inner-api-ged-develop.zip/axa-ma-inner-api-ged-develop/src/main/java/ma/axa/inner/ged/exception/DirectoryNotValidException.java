package ma.axa.inner.ged.exception;

public class DirectoryNotValidException extends Exception {

	private static final long serialVersionUID = 2222758585380429741L;
	
	public DirectoryNotValidException(String message) {
		super(message);
	}

}
