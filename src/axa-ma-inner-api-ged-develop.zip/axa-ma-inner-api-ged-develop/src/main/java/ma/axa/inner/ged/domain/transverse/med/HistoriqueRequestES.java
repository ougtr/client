package ma.axa.inner.ged.domain.transverse.med;

import lombok.Builder;

import java.util.Date;

@Builder
public class HistoriqueRequestES {

    String idQuittance;
    Long idTypeAnnotation;
    String idGestionnaireAccepte;
    Date dateEffet;
    int acceptation;
    String idProfilAnnote;
    String userAjouteAudit;
    Date dateAjoutAudit;
    String timeAjout;
    String userModifAudit;
    Date dateModifAudit;
    String timeModifAudit;
}

