package ma.axa.inner.ged.domain;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class SearchLsPrevoyanceAs400 {
    //id gestion
    private String idgest;
    // N ligne
    private String cplglg;
    //type document
    private String typdoc;
    //lib document
    private String nomdoc;
    //id ged
    private String ideged;
    //uploadedBy
    private String usercr;
    // date creation
    private String acdcre;

}
