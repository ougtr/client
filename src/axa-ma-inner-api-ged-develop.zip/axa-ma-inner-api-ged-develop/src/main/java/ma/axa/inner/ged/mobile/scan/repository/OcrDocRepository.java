package ma.axa.inner.ged.mobile.scan.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ma.axa.inner.ged.mobile.scan.dto.OcrDoc;


@Repository
public interface OcrDocRepository extends JpaRepository<OcrDoc, Integer> {
	 OcrDoc findByToken(String token);
}
