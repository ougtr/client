package ma.axa.inner.ged.domain.cima.auto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CimaAutoItemEs {
    private String id;
    private String lib;
    private String description;
}
