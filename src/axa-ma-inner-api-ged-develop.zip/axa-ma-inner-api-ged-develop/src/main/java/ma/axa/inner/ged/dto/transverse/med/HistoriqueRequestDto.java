package ma.axa.inner.ged.dto.transverse.med;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HistoriqueRequestDto {
    //@NotNull(message = ErrorConstants.ERR_CODE_Historique_NOTBLANK) Long idHistorique;

    @NotNull
    String idQuittance;
    @NotNull
    Long idTypeAnnotation;
    String idGestionnaireAccepte;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    Date dateEffet;
    @NotNull
    int acceptation;
    @NotNull
    String idProfilAnnote;
    String userAjouteAudit;
    Date dateAjoutAudit;
    String timeAjout;
    String userModifAudit;
    Date dateModifAudit;
    String timeModifAudit;

}
