package ma.axa.inner.ged.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SearchLsPrevoyanceResponse {
    private String idAlfresco;
    private String idGestion;
    private String ligneNumber;
    private String typeDocument;
    private String libDocument;
    private String uploadedBy;
    private String CreationDate;

}
