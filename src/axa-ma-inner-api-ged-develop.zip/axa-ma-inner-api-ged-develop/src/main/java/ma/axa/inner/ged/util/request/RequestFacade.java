package ma.axa.inner.ged.util.request;

import lombok.AllArgsConstructor;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Optional;

@Component
@AllArgsConstructor
public class RequestFacade {

    public static final String TRACE_ID = "X-TraceId";
    public static final String USER_NAME = "x-user-name";
    public static final String OUTER_ID = "x-outer-id";

    private final Tracer tracer;

    public String getTraceId() {
        return Optional.ofNullable(get(TRACE_ID))
                .orElse(Optional.ofNullable(tracer.currentSpan())
                        .map(e -> e.context().traceId())
                        .orElse(null)
                );
    }

    public static String get(String header) {
        return currentRequest()
                .map(request -> request.getHeader(header))
                .orElse(null);
    }

    static Optional<HttpServletRequest> currentRequest() {
        return
                Optional.ofNullable(
                                RequestContextHolder.getRequestAttributes()
                        )
                        .filter(ServletRequestAttributes.class::isInstance)
                        .map(ServletRequestAttributes.class::cast)
                        .map(ServletRequestAttributes::getRequest);
    }
}
