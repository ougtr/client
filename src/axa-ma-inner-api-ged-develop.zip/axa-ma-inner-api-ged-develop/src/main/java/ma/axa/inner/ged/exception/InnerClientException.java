package ma.axa.inner.ged.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;
import ma.axa.inner.ged.dto.error.ApiError;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Data
@EqualsAndHashCode(callSuper = true)
public class InnerClientException extends GlobalException {
	private static final long serialVersionUID = 606130691394610424L;

	private final ApiError apiError;

	public InnerClientException(String message, ApiError apiError) {
		super(GlobalConstants.URI_INTER_SERVICE_COMMUNICATION, message);
		this.apiError = apiError;
	}
}
