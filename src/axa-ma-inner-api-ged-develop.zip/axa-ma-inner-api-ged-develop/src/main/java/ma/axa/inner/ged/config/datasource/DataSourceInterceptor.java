package ma.axa.inner.ged.config.datasource;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.cima.auto.CountryCode;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.DataSourceUtils;



@Component
@AllArgsConstructor
@Slf4j
public class DataSourceInterceptor implements HandlerInterceptor {

    private DataSourceContextHolder dataSourceContextHolder;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String datasource = request.getHeader(GlobalConstants.COUNTRY_CODE);
        log.info("Getting datasource from header {}", datasource);
        CountryCode countryCode = DataSourceUtils.getDataSourceFromHeader(datasource);
        log.info("Setting datasource to {}", countryCode);
        dataSourceContextHolder.setCountryContext(countryCode);
        return HandlerInterceptor.super.preHandle(request, response, handler);
    }
}
