package ma.axa.inner.ged.mapper.transverse.med;


import ma.axa.inner.ged.dto.transverse.med.HistoriqueRequestDto;
import ma.axa.inner.ged.dto.transverse.med.MEDDocumentRequest;
import ma.axa.inner.ged.mapper.AlfrescoPropsMapper;

import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;

public class MedAlfrescoMapper extends AlfrescoPropsMapper {

    private MedAlfrescoMapper() throws InstantiationException {
        throw new InstantiationException("Instances of this type are forbidden");
    }

    public static Map<String, Object> toFolderProperties(MEDDocumentRequest metaData) {
        return toFolderProperties(metaData, null);
    }

	public static Map<String, Object> toFolderProperties(MEDDocumentRequest metaData, Map<String, Object> properties) {
        if (metaData == null) {
            return Collections.emptyMap();
        }

        var alfrescoProps = AlfrescoFolderProperties.builder().typeQuittanceDossier(metaData.getTypeQuittance()).build();
        return toFolderProperties(properties, alfrescoProps);
    }

    public static Map<String, Object> toDocumentProperties(MEDDocumentRequest metaData) {
        return toDocumentProperties(metaData, null);
    }

    public static Map<String, Object> toDocumentProperties(MEDDocumentRequest metaData,
                                                           Map<String, Object> properties) {
        if (metaData == null) {
            return Collections.emptyMap();
        }


        var alfrescoProps = AlfrescoDocumentProperties.builder()
                .typeQuittance(metaData.getTypeQuittance()
                )
                .build();
        return toDocumentProperties(properties, alfrescoProps);
    }
}
