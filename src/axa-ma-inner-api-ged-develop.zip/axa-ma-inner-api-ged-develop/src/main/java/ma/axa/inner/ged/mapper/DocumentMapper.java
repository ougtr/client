package ma.axa.inner.ged.mapper;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

import ma.axa.inner.ged.dto.at.DocumentMetadataOrQueryDto;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import ma.axa.inner.ged.domain.DocumentSinistre;
import ma.axa.inner.ged.domain.ESDocMobileScanRequest;
import ma.axa.inner.ged.domain.ESDocumentATRequest;
import ma.axa.inner.ged.domain.ESDocumentProductionRequest;
import ma.axa.inner.ged.domain.ESDossierATRequest;
import ma.axa.inner.ged.domain.ESDossierProductionRequest;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.domain.PreDeclarationTypeDoc;
import ma.axa.inner.ged.domain.ProductionTypeDoc;
import ma.axa.inner.ged.domain.at.DocumentSinistreATES;
import ma.axa.inner.ged.dto.DocClaimAtReqDto;
import ma.axa.inner.ged.dto.DocumentSinistreAT;
import ma.axa.inner.ged.dto.at.DocumentMetadataQueryDto;
import ma.axa.inner.ged.exception.BusinessException;
import ma.axa.inner.ged.exception.IOFileException;
import ma.axa.inner.ged.mobile.scan.dto.OcrDoc;
import ma.axa.inner.ged.util.DateUtils;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;
import ma.axa.inner.ged.util.constants.GlobalConstants;


public final class DocumentMapper {
	private DocumentMapper() {
		throw new IllegalStateException("Utility class");
	}

	public static Map<String, Object> documentPropertiesConstructor(DocumentSinistreAT documentAxa) {

		Map<String, Object> properties = new HashMap<>();
		if (documentAxa.getNumPolice() != null) {
			properties.put(AXADocPropertyIds.NUMERO_POLICE, documentAxa.getNumPolice());
		}
		if (StringUtils.isNotBlank(documentAxa.getNumSinistre())) {
			properties.put(AXADocPropertyIds.NUMERO_SINISTRE, documentAxa.getNumSinistre());
		}
		if (documentAxa.getIdentifiantScanner() != null) {
			properties.put(AXADocPropertyIds.IDENTIFIANT_SCANER, documentAxa.getIdentifiantScanner());
		}
		if (documentAxa.getNatureCourier() != null) {
			properties.put(AXADocPropertyIds.NATURE_COURRIER, documentAxa.getNatureCourier());
		}
		if (documentAxa.getTypeCourier() != null) {
			properties.put(AXADocPropertyIds.TYPE_COURRIER, documentAxa.getTypeCourier());
		}
		if (documentAxa.getUserLogin() != null) {
			properties.put(AXADocPropertyIds.AGENT_INDEXATION, documentAxa.getUserLogin());
		}
		return properties;

	}

	public static Map<String, Object> directoryPropertiesConstructor(Folder folder, DocumentSinistreAT documentAxa) {
		Map<String, Object> properties = new HashMap<>();

		if (documentAxa.getNumPolice() != null) {
			mapDirectoryProperty(folder, AXADocPropertyIds.NUMERO_POLICE_DOSSIER, documentAxa.getNumPolice(), properties);
		}
		if (StringUtils.isNotBlank(documentAxa.getNumSinistre())) {
			mapDirectoryProperty(folder, AXADocPropertyIds.NUMERO_SINISTRE_DOSSIER, documentAxa.getNumSinistre(), properties);
		}
		if (documentAxa.getCodeProduit() != null) {
			mapDirectoryProperty(folder, AXADocPropertyIds.CODE_PRODUIT, documentAxa.getCodeProduit(), properties);
		}
		if (documentAxa.getClasseSinistre() != null) {
			mapDirectoryProperty(folder, AXADocPropertyIds.CLASSE_SINISTRE, documentAxa.getClasseSinistre(), properties);
		}
		if (documentAxa.getCodeIntermediaire() != null) {
			mapDirectoryProperty(folder, AXADocPropertyIds.INTERMEDIARE_DOSSIER, documentAxa.getCodeIntermediaire(), properties);
		}
		if (documentAxa.getDateSurvenance() != null) {
			mapDirectoryProperty(folder, AXADocPropertyIds.DATE_SURVENANACE_DOSSIER, documentAxa.getDateSurvenance(), properties);
		}
		if (documentAxa.getDateDeclaration() != null) {
			mapDirectoryProperty(folder, AXADocPropertyIds.DATE_DECLARATION_DOSSIER, documentAxa.getDateDeclaration(), properties);
		}
		if (documentAxa.getNomVictime() != null) {
			mapDirectoryProperty(folder, AXADocPropertyIds.NOM_VICTIME_DOSSIER, documentAxa.getNomVictime(), properties);
		}
		return properties;
	}

	public static void mapDirectoryProperty(Folder folder, String property, Object value, Map<String, Object> mappedProperties) {
		if(folder.getProperties().stream().anyMatch(e -> StringUtils.equals(property, e.getId())))
			mappedProperties.put(property, value);
	}

	public static Map<String, Object> directoryProductionPropertiesConstructor(ProductionTypeDoc documentAxa) {
		Map<String, Object> properties = new HashMap<>();
		Date effectDate = Date.from(documentAxa.getEffectDate().atStartOfDay(ZoneId.systemDefault()).toInstant());
		properties.put(AXADocPropertyIds.PRODUCTION_PRODUCT_CODE, documentAxa.getProductCode());
		properties.put(AXADocPropertyIds.PRODUCTION_INTERMEDIARY_CODE, documentAxa.getCodeIntermediaire());
		properties.put(AXADocPropertyIds.PRODUCTION_EFFECT_DATE, effectDate);
		properties.put(AXADocPropertyIds.PRODUCTION_CLIENT_NAME, documentAxa.getClientName());
		properties.put(AXADocPropertyIds.PRODUCTION_POLICY_CREATION_DATE, new Date());
		properties.put(AXADocPropertyIds.PRODUCTION_POLICE_NUMBER, documentAxa.getPoliceNumber());

		return properties;
	}

	public static ESDossierATRequest mapToESDossierATRequest(DocumentSinistreAT documentSinistreAT, String idAlfersco) {
		var esDossierATRequest = new ESDossierATRequest();
		esDossierATRequest.setIdAlfersco(idAlfersco);
		esDossierATRequest.setNumPolice(documentSinistreAT.getNumPolice());
		esDossierATRequest.setDateSurvenance(documentSinistreAT.getDateSurvenance());
		esDossierATRequest.setDateScan(new Date());
		esDossierATRequest.setNomVictime(documentSinistreAT.getNomVictime());
		esDossierATRequest.setIntermediaire(documentSinistreAT.getCodeIntermediaire());
		esDossierATRequest.setCodeProduit(documentSinistreAT.getCodeProduit());
		esDossierATRequest.setDateDeclaration(documentSinistreAT.getDateDeclaration());
		esDossierATRequest.setClassSinistre(documentSinistreAT.getClasseSinistre());

		return esDossierATRequest;
	}



	public static ESDossierProductionRequest mapToESDossierProductionRequest(ProductionTypeDoc productionTypeDoc,
																			   String idAlfersco) {
		var esDossierProductionATRequest = new ESDossierProductionRequest();
		esDossierProductionATRequest.setIdAlfersco(idAlfersco);
		esDossierProductionATRequest.setDateScan(new Date());
		esDossierProductionATRequest.setNumPolice(productionTypeDoc.getPoliceNumber());
		esDossierProductionATRequest.setIntermediaire(productionTypeDoc.getCodeIntermediaire());
		esDossierProductionATRequest.setStatutPolice("1");
		esDossierProductionATRequest.setProductCode(productionTypeDoc.getProductCode());
		esDossierProductionATRequest.setDateEffetPolice(convertLocalDateToDate(productionTypeDoc.getEffectDate()));
		esDossierProductionATRequest.setDateEffetPolice(convertLocalDateToDate(productionTypeDoc.getEffectDate()));
		esDossierProductionATRequest.setDateEffetPoliceFormat(convertLocalDateToStringFormated(productionTypeDoc.getEffectDate()));
		return esDossierProductionATRequest;
	}

	public static ESDossierProductionRequest mapToESDossierProductionHealthRequest(ProductionTypeDoc productionTypeDoc,
																				   String idAlfersco) {
		var esDossierProductionHealthRequest = new ESDossierProductionRequest();
		esDossierProductionHealthRequest.setIdAlfersco(idAlfersco);
		esDossierProductionHealthRequest.setDateScan(new Date());
		esDossierProductionHealthRequest.setNumPolice(productionTypeDoc.getPoliceNumber());
		esDossierProductionHealthRequest.setIntermediaire(productionTypeDoc.getCodeIntermediaire());
		esDossierProductionHealthRequest.setStatutPolice("1");
		esDossierProductionHealthRequest.setProductCode(productionTypeDoc.getProductCode());
		esDossierProductionHealthRequest.setDateEffetPolice(convertLocalDateToDate(productionTypeDoc.getEffectDate()));
		esDossierProductionHealthRequest.setDateEffetPolice(convertLocalDateToDate(productionTypeDoc.getEffectDate()));
		esDossierProductionHealthRequest.setDateEffetPoliceFormat(convertLocalDateToStringFormated(productionTypeDoc.getEffectDate()));
		return esDossierProductionHealthRequest;
	}

	private static String convertLocalDateToStringFormated(LocalDate effectDate) {
		return effectDate.getYear()+""+effectDate.getMonthValue()+""+effectDate.getDayOfYear();
	}

	public static ESDocumentATRequest mapToESDocumentATRequest(DocumentSinistreAT documentSinistreAT,
															   String nomDocument, String idAlfersco) {
		var esDocumentATRequest = new ESDocumentATRequest();

		esDocumentATRequest.setIdAlfersco(idAlfersco);
		esDocumentATRequest.setNomDocument(nomDocument);
		esDocumentATRequest.setNumSinistre(documentSinistreAT.getNumSinistre());
		esDocumentATRequest.setTypeDocument(documentSinistreAT.getTypeDocument());
		esDocumentATRequest.setIdentifiantScaner(documentSinistreAT.getIdentifiantScanner());
		esDocumentATRequest.setDateUpload(documentSinistreAT.getDateScan());
		esDocumentATRequest.setAgentIndexation(documentSinistreAT.getUserLogin());
		esDocumentATRequest.setCodeDocument(documentSinistreAT.getCodeDocument());
		esDocumentATRequest.setRightHolderId(documentSinistreAT.getRightHolder());
		return esDocumentATRequest;
	}

	public static DocumentSinistre mapPreDeclarationtoDocumentSinistre(PreDeclarationTypeDoc preDeclarationTypeDoc) {
		var doc = new DocumentSinistre();

		doc.setIdalfresco(preDeclarationTypeDoc.getIdAlfresco());
		doc.setNsin(preDeclarationTypeDoc.getNSin());
		doc.setPolnum(new BigDecimal(preDeclarationTypeDoc.getPolnum()));
		doc.setTypedocument(preDeclarationTypeDoc.getTypeDocument());
		doc.setNomdocument(preDeclarationTypeDoc.getLibDocument());
		doc.setUserc(preDeclarationTypeDoc.getUserC());
		doc.setDatec(preDeclarationTypeDoc.getDateC());
		doc.setNumpredeclaration(preDeclarationTypeDoc.getNumPreDeclaration());
		doc.setFormadoc(preDeclarationTypeDoc.getFormaDoc());
		doc.setNomvictime(preDeclarationTypeDoc.getNomVictime());
		doc.setEmplacement(preDeclarationTypeDoc.getEmplacement());

		return doc;
	}

	public static GedDocument mapFileToGedDocument(MultipartFile file) {
		var gedDocument = new GedDocument();
		try {
			gedDocument.setFileByte(file.getBytes());
			gedDocument.setMimeType(file.getContentType());
			gedDocument.setFileName(file.getOriginalFilename());
			return gedDocument;
		} catch (IOException e) {
			throw new IOFileException(e.getMessage());
		}
	}

	public static GedDocument mapFileToGedDocument(MultipartFile file, String newFileName) {
		if (file == null) {
			throw new BusinessException("Document obligatoire");
		}
		var gedDocument = new GedDocument();
		try {
			var originalFileName = file.getOriginalFilename();
			if (StringUtils.isNotBlank(newFileName) && StringUtils.isNotBlank(originalFileName)) {
				var extension = originalFileName.substring(originalFileName.lastIndexOf('.') + 1);
				gedDocument.setFileName(newFileName.trim() + "." + extension);
			} else {
				gedDocument.setFileName(originalFileName);
			}
			gedDocument.setFileByte(file.getBytes());
			gedDocument.setMimeType(file.getContentType());

			return gedDocument;
		} catch (Exception e) {
			throw new IOFileException(e.getMessage());
		}
	}

	/**
	 * @param documentProductionAT
	 * @param fileName
	 * @param idAlfresco
	 * @return
	 */
	public static ESDocumentProductionRequest mapToESDocumentProductionRequest(ProductionTypeDoc documentProductionAT,
																			   String fileName,
																			   String idAlfresco) {
		var esDocumentProductionRequest = new ESDocumentProductionRequest();

		esDocumentProductionRequest.setIdAlfersco(idAlfresco);
		esDocumentProductionRequest.setNomDocument(fileName);
		esDocumentProductionRequest.setNumPolice(documentProductionAT.getPoliceNumber());
		esDocumentProductionRequest.setDocumentType("2");
		esDocumentProductionRequest.setDocumentTypeLabel("affaire nouvelle");
		esDocumentProductionRequest.setDateCreation(convertLocalDateToString(documentProductionAT.getEffectDate()));
		esDocumentProductionRequest.setSourceDocument("intermediaire");
		esDocumentProductionRequest.setVisibleToIntermediate("true");
		esDocumentProductionRequest.setExercice(documentProductionAT.getEffectDate().getYear()+"");
		esDocumentProductionRequest.setTagsLabels(documentProductionAT.getTagsLabels());
		esDocumentProductionRequest.setTagsIds(documentProductionAT.getTagsIds());
		esDocumentProductionRequest.setTypedocument(documentProductionAT.getTypedocument());
		esDocumentProductionRequest.setTypedocumentLabel(documentProductionAT.getTypedocumentLabel());

		//  .field("idalfersco", doc.getDocumentID())
		//  .field("nomdocument", doc.getNomDocument())
		//  .field("numpolice", doc.getNumPolice())
		//  .field("iddoc", doc.getIdentifiantScaner())

		//  .field("typeDocument = 2", doc.getTypeCourier())
		//  .field("typeDocumentLabel =  affaire nouvelle", doc.getTypeDocumentLabel())
		//  .field("dateCreation", date_formatDateToString(doc.getDateCreation(),"yyyyMMddHHmmss"))
		//  .field("sourceDocument  = intermediaire", doc.getSource())
		//  .field("visibleToIntermediate", doc.isVisibleToIntermediate())
		//  .field("exercice = Year effect date",doc.getExercice())

		return esDocumentProductionRequest;
	}
	public static Date convertLocalDateToDate(LocalDate localDate) {
		return  Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
	}
	public static String convertLocalDateToString(LocalDate localDate) {
		return  localDate.getYear()+""+localDate.getMonthValue()+""+localDate.getDayOfMonth();
	}

	public static DocClaimAtReqDto mapFromDocumentATESToDocClaimAtReqDto(DocumentSinistreATES documentSinistreATES){
		LocalDate receptionDate=null;
		Long creationTimeStamp = null;
		if(StringUtils.isNotBlank(documentSinistreATES.getReceptiondate())){
			receptionDate = DateUtils.parseDateStrToLocalDate(documentSinistreATES.getReceptiondate());
		} else if (StringUtils.isNotBlank(documentSinistreATES.getDateUpload() )) {
			receptionDate=DateUtils.parseDateStrToLocalDate(documentSinistreATES.getDateUpload());
		}
		if(documentSinistreATES.getUploadDateTimeStamp() != null){
			creationTimeStamp = documentSinistreATES.getUploadDateTimeStamp();
		}
		else if(StringUtils.isNotBlank(documentSinistreATES.getDateUpload() ) &&  DateUtils.parseDateStrToDate(documentSinistreATES.getDateUpload()) != null){

			creationTimeStamp =  DateUtils.parseDateStrToDate(documentSinistreATES.getDateUpload()).getTime();
		}
		return DocClaimAtReqDto.builder()
				.idAlfresco(StringUtils.replace(documentSinistreATES.getIdalfersco(),GlobalConstants.PREFIX_IN_ALFRESCO_ID,""))
				.numSinistre(documentSinistreATES.getNumsinistre())
				.preDeclarationNumber(documentSinistreATES.getPreDeclarationNumber())
				.nomDocument(documentSinistreATES.getNomdocument())
				.idDocument(documentSinistreATES.getIddocument())
				.numPolice(documentSinistreATES.getNumpolice())
				.uploadedby(documentSinistreATES.getUploadedby())
				.typeDocument(documentSinistreATES.getTypeDocument())
				.repertoire(documentSinistreATES.getRepertoire())
				.dateSurvenance(DateUtils.parseDateStrToLocalDate(documentSinistreATES.getDateSurvenance()))
				.receptionDate(receptionDate)
				.sendingDate(DateUtils.parseDateStrToLocalDate(documentSinistreATES.getDateEnvoi()))
				.creationTimeStamp(creationTimeStamp)
				.sourceDossier(documentSinistreATES.getSourceDossier())
				.type(documentSinistreATES.getType())
				.tag(documentSinistreATES.getTag())
				.numDossierBnej(documentSinistreATES.getNumDossierBnej())
				.numReglement(documentSinistreATES.getNumReglement())
				.numDossierTribunal(documentSinistreATES.getNumDossierTribunal())
				.intermediaryCode(documentSinistreATES.getIntermediaryCode())
				.size(documentSinistreATES.getSize())
				.isReturnedRO(documentSinistreATES.getIsReturnedRO())
				.intermediaryReference(documentSinistreATES.getIntermediaryReference())
				.userSenderToIntermediary(documentSinistreATES.getUserSenderToIntermediary())
				.sentToIntermediaryDate(documentSinistreATES.getSentToIntermediaryDate())
                .codeDocument(documentSinistreATES.getCodeDocument())
				.rightHolderId(documentSinistreATES.getRightHolderId())
				.build();
	}

	public static ESDocumentATRequest mapToESDocumentAtTemporaryRequest(DocClaimAtReqDto docClaimAtReqDto,String idAlfersco,Long size,Boolean isUpdate) {
		var esDocumentATRequest = new ESDocumentATRequest();
		esDocumentATRequest.setIdAlfersco(idAlfersco);
		esDocumentATRequest.setNumPolice(docClaimAtReqDto.getNumPolice());
		esDocumentATRequest.setNumSinistre(docClaimAtReqDto.getNumSinistre());
		esDocumentATRequest.setNomDocument(docClaimAtReqDto.getNomDocument());
		esDocumentATRequest.setIdDocument(docClaimAtReqDto.getIdDocument());
		esDocumentATRequest.setTypeDocument(docClaimAtReqDto.getTypeDocument());
		esDocumentATRequest.setAgentIndexation(docClaimAtReqDto.getUploadedby());
		esDocumentATRequest.setRepertoire(docClaimAtReqDto.getRepertoire());
		if(Boolean.FALSE.equals(isUpdate)) {
			esDocumentATRequest.setDateUpload(new Date());
			esDocumentATRequest.setUploadDateTimeStamp(new Date().getTime());
		}
		esDocumentATRequest.setSourceDossier(docClaimAtReqDto.getSourceDossier());
		esDocumentATRequest.setType(docClaimAtReqDto.getType());
		esDocumentATRequest.setNumDossierBnej(docClaimAtReqDto.getNumDossierBnej());
		esDocumentATRequest.setNumDossierTribunal(docClaimAtReqDto.getNumDossierTribunal());
		esDocumentATRequest.setIntermediaryCode(docClaimAtReqDto.getIntermediaryCode());
		esDocumentATRequest.setSize(size);
		esDocumentATRequest.setTag(docClaimAtReqDto.getTag());
		esDocumentATRequest.setIsReturnedRO(docClaimAtReqDto.getIsReturnedRO());
		esDocumentATRequest.setIsTemporary(docClaimAtReqDto.getIsTemporary());
		esDocumentATRequest.setPreDeclarationNumber(docClaimAtReqDto.getPreDeclarationNumber());
		esDocumentATRequest.setSentToIntermediaryDate(docClaimAtReqDto.getSentToIntermediaryDate());
		esDocumentATRequest.setUserSenderToIntermediary(docClaimAtReqDto.getUserSenderToIntermediary());
		esDocumentATRequest.setIntermediaryReference(docClaimAtReqDto.getIntermediaryReference());
		esDocumentATRequest.setNumReglement(docClaimAtReqDto.getNumReglement());
		esDocumentATRequest.setCodeDocument(docClaimAtReqDto.getCodeDocument());
		esDocumentATRequest.setRightHolderId(docClaimAtReqDto.getRightHolderId());
		if(Objects.nonNull(docClaimAtReqDto.getSendingDate()))
			esDocumentATRequest.setSendingDate(DateUtils.dateFormatter(DateUtils.toDate(docClaimAtReqDto.getSendingDate()),GlobalConstants.DATE_FORMAT_FOR_FRONT));
		if(Objects.nonNull(docClaimAtReqDto.getReceptionDate()))
			esDocumentATRequest.setReceptionDate(DateUtils.dateFormatter(DateUtils.toDate(docClaimAtReqDto.getReceptionDate()),GlobalConstants.DATE_FORMAT_FOR_FRONT));
		if(StringUtils.isNotBlank(docClaimAtReqDto.getNumSinistre()))
			esDocumentATRequest.setDateSurvenance(DateUtils.dateFormatter(DateUtils.toDate(docClaimAtReqDto.getDateSurvenance()),GlobalConstants.DATE_FORMAT_FOR_FRONT));
		return esDocumentATRequest;
	}

	public static ESDocumentATRequest mapFromMetadataQueryToATES(DocumentMetadataQueryDto metadata){
		return ESDocumentATRequest.builder()
				.idAlfersco(StringUtils.isNotBlank(metadata.getId()) ? GlobalConstants.PREFIX_IN_ALFRESCO_ID+metadata.getId():null)
				.idDocument(metadata.getDocumentId())
				.numSinistre(metadata.getClaimNumber())
				.typeDocument(metadata.getTypology())
				.nomDocument(metadata.getFileName())
				.agentIndexation(metadata.getUploadedBy())
				.repertoire(metadata.getRepository())
				.receptionDate(Objects.toString(metadata.getReceptionDate(),null))
				.dateSurvenance(Objects.toString(metadata.getOccurrenceDate(),null))
				.sendingDate(Objects.toString(metadata.getSendingDate(),null))
				.dateUpload(DateUtils.fromBackDateToObjectDate(metadata.getUploadedAt()))
				.numPolice(metadata.getPoliceNumber())
				.sourceDossier(metadata.getFileSource())
				.type(metadata.getDocumentType())
				.numDossierBnej(metadata.getBnejFileNumber())
				.numDossierTribunal(metadata.getTribunalFileNumber())
				.isTemporary(metadata.getTemporary())
				.tag(metadata.getTagCode())
				.isReturnedRO(metadata.getIsReturnedRO())
				.preDeclarationNumber(metadata.getPreDeclarationNumber())
				.intermediaryCode(metadata.getIntermediaryCode())
				.intermediaryReference(metadata.getIntermediaryReference())
                .codeDocument(metadata.getCodeDocument())
				.rightHolderId(metadata.getRightHolderId())
				.build();
	}

	public static DocumentMetadataOrQueryDto mapMetadataOrQuery(DocumentMetadataQueryDto metadata){
		return DocumentMetadataOrQueryDto.builder()
				.typeDocument(metadata.getTypologiesOr())
				.intermediaryCode(metadata.getIntermediaryCodeOr())
				.repertoire(metadata.getRepositoryOr())
				.build();
	}

	public static void mapToESDocumentFromAtRequest(ESDocumentATRequest esDocumentATRequest, DocumentSinistreATES doc, DocClaimAtReqDto docClaimAtReqDto){
		esDocumentATRequest.setTypeDocument(Optional.ofNullable(docClaimAtReqDto.getTypeDocument()).orElse(doc.getTypeDocument()));
		esDocumentATRequest.setNomDocument(doc.getNomdocument());
		esDocumentATRequest.setAgentIndexation(doc.getUploadedby());
		esDocumentATRequest.setRepertoire(doc.getRepertoire());
		esDocumentATRequest.setDateUpload(new Date());
		esDocumentATRequest.setUploadDateTimeStamp(new Date().getTime());
		esDocumentATRequest.setSourceDossier(docClaimAtReqDto.getSourceDossier());
		esDocumentATRequest.setType(docClaimAtReqDto.getType());
		esDocumentATRequest.setNumDossierBnej(docClaimAtReqDto.getNumDossierBnej());
		esDocumentATRequest.setNumDossierTribunal(docClaimAtReqDto.getNumDossierTribunal());
		esDocumentATRequest.setIsTemporary(null);
		esDocumentATRequest.setSize(doc.getSize());
		esDocumentATRequest.setIsReturnedRO(docClaimAtReqDto.getIsReturnedRO());
		esDocumentATRequest.setIntermediaryReference(doc.getIntermediaryReference());
		esDocumentATRequest.setIntermediaryCode(doc.getIntermediaryCode());
		esDocumentATRequest.setSentToIntermediaryDate(doc.getSentToIntermediaryDate());
		esDocumentATRequest.setUserSenderToIntermediary(doc.getUserSenderToIntermediary());
		if(docClaimAtReqDto.getTag() != null)
			esDocumentATRequest.setTag(docClaimAtReqDto.getTag());
		else if (doc.getTag() != null) {
			esDocumentATRequest.setTag(doc.getTag());
		}

		if(Objects.nonNull(docClaimAtReqDto.getReceptionDate()))
			esDocumentATRequest.setReceptionDate(DateUtils.dateFormatter(DateUtils.toDate(docClaimAtReqDto.getReceptionDate()),GlobalConstants.DATE_FORMAT_FOR_FRONT));
		else if(StringUtils.isNotBlank(doc.getReceptiondate()))
			esDocumentATRequest.setReceptionDate(doc.getReceptiondate());

		if(Objects.nonNull(docClaimAtReqDto.getDateSurvenance()))
			esDocumentATRequest.setDateSurvenance(DateUtils.dateFormatter(DateUtils.toDate(docClaimAtReqDto.getDateSurvenance()),GlobalConstants.DATE_FORMAT_FOR_FRONT));
		else if (StringUtils.isNotBlank(doc.getDateSurvenance())) {
			esDocumentATRequest.setDateSurvenance(doc.getDateSurvenance());
		}

		if(Objects.nonNull(docClaimAtReqDto.getSendingDate()))
			esDocumentATRequest.setSendingDate(DateUtils.dateFormatter(DateUtils.toDate(docClaimAtReqDto.getSendingDate()),GlobalConstants.DATE_FORMAT_FOR_FRONT));
		else if(Objects.nonNull(doc.getDateEnvoi()))
			esDocumentATRequest.setDateSurvenance(doc.getDateEnvoi());
	}

	public static ESDocMobileScanRequest mapToESDocMobileScanRequest(OcrDoc ocrDocument, String idAlfersco) {
		var esDocMobileScanRequest = new ESDocMobileScanRequest();
		esDocMobileScanRequest.setIdAlfersco(idAlfersco);
		esDocMobileScanRequest.setNomDocument(ocrDocument.getNomDocument());
		esDocMobileScanRequest.setTypeDocument(ocrDocument.getTypeDocument());
		esDocMobileScanRequest.setAgentIndexation(ocrDocument.getUser());

		return esDocMobileScanRequest;
	}
}