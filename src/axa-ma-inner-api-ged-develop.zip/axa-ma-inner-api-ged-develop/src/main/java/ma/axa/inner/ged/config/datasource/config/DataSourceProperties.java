package ma.axa.inner.ged.config.datasource.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataSourceProperties {
	
	@Bean
    @ConfigurationProperties(prefix = "spring.datasource.ma")
    public DataSourceConfig maDatasourceConfig() {
        return new DataSourceConfig();
    }
	
    @Bean
    @ConfigurationProperties(prefix = "spring.datasource.ca")
    public DataSourceConfig caDatasourceConfig() {
        return new DataSourceConfig();
    }

    @Bean
    @ConfigurationProperties(prefix = "spring.datasource.ci")
    public DataSourceConfig ciDatasourceConfig() {
        return new DataSourceConfig();
    }

    @Bean
    @ConfigurationProperties(prefix = "spring.datasource.ga")
    public DataSourceConfig gaDatasourceConfig() {
        return new DataSourceConfig();
    }

    @Bean
    @ConfigurationProperties(prefix = "spring.datasource.sn")
    public DataSourceConfig snDatasourceConfig() {
        return new DataSourceConfig();
    }

}
