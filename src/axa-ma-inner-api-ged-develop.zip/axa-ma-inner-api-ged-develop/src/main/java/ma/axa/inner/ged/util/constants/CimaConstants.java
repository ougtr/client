package ma.axa.inner.ged.util.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class CimaConstants {

    public static final String CIMA_PROD_BASE_URL = "/v1/cima/production/documents";
    public static final String TAG_CIMA_PROD_GED_APIS = "CIMA PROD GED APIs";
    
    public static final String CIMA_AUTO_BASE_URL = "/v1/cima/auto/documents";
    public static final String TAG_CIMA_AUTO_GED_APIS = "CIMA AUTO GED APIs";

}
