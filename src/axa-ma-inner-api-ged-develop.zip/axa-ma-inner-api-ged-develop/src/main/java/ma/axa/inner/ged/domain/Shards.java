
package ma.axa.inner.ged.domain;

import lombok.Data;

@Data
public class Shards {
    private Integer total;
    private Integer successful;
    private Integer failed;
}
