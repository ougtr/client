package ma.axa.inner.ged.dto.at;

import lombok.*;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class DocumentMetadataQueryDto {
    private String id;
    private String documentId;
    private String claimNumber;
    private String preDeclarationNumber;
    private BigDecimal policeNumber;
    private String typology;
    private String fileName;
    private String uploadedBy;
    private String repository;
    private Integer uploadedAt;
    private Integer receptionDate;
    private Integer occurrenceDate;
    private Integer sendingDate;
    private String fileSource; // SourceFilesATEnum
    private String documentType; // DocumentTypeATEnum
    private String bnejFileNumber;
    private String tribunalFileNumber;
    private String tagCode;
    @Builder.Default
    private Boolean temporary=false;
    @Builder.Default
    private Integer page=0;
    @Builder.Default
    private Integer size=200;
    @Builder.Default
    private Boolean isReturnedRO = false;
    @Builder.Default
    private Boolean searchInAlfresco = false;
    private Integer intermediaryCode;
    private String intermediaryReference;
    private Integer intermediaryCodeOr;
    private List<String> typologiesOr;
    private String repositoryOr;
    private String codeDocument;
    private String rightHolderId;
}
