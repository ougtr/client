package ma.axa.inner.ged.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;



@Getter
@AllArgsConstructor
public enum Branche {

	TRANSPORT(1, "TRANSPORT", "Transport", true),
	RD(2, "RD", "Risques Divers", true),
	UNKNOWN(-1, "UNKNOWN", "Inconnue", false);

	private int code;
	private String label;
	private String description;
	private boolean isActive;
}
