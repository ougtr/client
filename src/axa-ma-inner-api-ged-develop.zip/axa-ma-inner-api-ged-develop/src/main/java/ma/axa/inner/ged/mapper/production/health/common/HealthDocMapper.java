package ma.axa.inner.ged.mapper.production.health.common;


import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import ma.axa.inner.ged.domain.production.health.common.DocumentHealthEs;
import ma.axa.inner.ged.dto.production.health.common.DocHealthCommonReq;
import ma.axa.inner.ged.dto.production.health.common.DocHealthCommonResp;
import ma.axa.inner.ged.mapper.MapstructUtil;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE,uses = MapstructUtil.class)
public interface HealthDocMapper {

	// -> TO DTO

	@Mapping(source = "filesize",target = "filesize",qualifiedByName = "mapToFileSize")
	DocHealthCommonResp toDto(DocumentHealthEs document);

	List<DocHealthCommonResp> toDtoList(List<DocumentHealthEs> documents);

	// -> FROM DTO

	DocumentHealthEs fromDto(DocHealthCommonReq documentReq);

	List<DocumentHealthEs> fromDto(List<DocHealthCommonReq> documentReq);


	// Others
	static Page<DocumentHealthEs> mapToPage(SearchResponse<DocumentHealthEs> searchResponse, int from,
											   int size) {
		if (searchResponse == null || searchResponse.hits().hits().isEmpty() || searchResponse.hits().total() == null) {
			return Page.empty();
		} else {
			long totalElements = searchResponse.hits().total().value();
			List<DocumentHealthEs> results = searchResponse.hits().hits().stream()
					.map(Hit::source)
					.collect(Collectors.toList());
			PageRequest pageRequest = PageRequest.of(from, size);
			return new PageImpl<>(results, pageRequest, totalElements);
		}
	}

}