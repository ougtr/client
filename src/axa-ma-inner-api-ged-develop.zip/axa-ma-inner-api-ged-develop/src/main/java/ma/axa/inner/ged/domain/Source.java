
package ma.axa.inner.ged.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Source {
    private String idPredeclaration;
    private String idAlfresco;
    @JsonProperty("nSin")
    private String nSin;
    private Double polnum;
    private String typeDocLabel;
    private String typeDoc;
    private String nomFile;
    private String nomVictime;
    private String emplacement;
    private String userC;
    private Double dateC;
    private String dateHeureC;
    private Double dateA;
    @JsonProperty("Aclasser")
    private Integer aclasser;
    @JsonProperty("AclasserPar")
    private String aclasserPar;
    @JsonProperty("AclasserLe")
    private Double aclasserLe;
    private String formDoc;
}
