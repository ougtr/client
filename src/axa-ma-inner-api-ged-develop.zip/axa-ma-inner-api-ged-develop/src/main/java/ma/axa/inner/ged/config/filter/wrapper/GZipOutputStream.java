package ma.axa.inner.ged.config.filter.wrapper;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.WriteListener;
import javax.servlet.http.HttpServletResponse;

public class GZipOutputStream extends ServletOutputStream {
	private HttpServletResponse response;
	private GZIPOutputStream gzipStream;
	private ByteArrayOutputStream byteArrayOutputStream;

	public GZipOutputStream(HttpServletResponse response) throws IOException {
		this.response = response;
		byteArrayOutputStream = new ByteArrayOutputStream();
		gzipStream = new GZIPOutputStream(byteArrayOutputStream);
	}

	public void write(int b) throws IOException {
		gzipStream.write(b);
	}

	@Override
	public void close() throws IOException {
		gzipStream.finish();
		var content = byteArrayOutputStream.toByteArray();
		response.addHeader("Content-Length", Integer.toString(content.length));
		var out = response.getOutputStream();
		out.write(content);
		out.close();
	}

	@Override
	public void flush() throws IOException {
		gzipStream.flush();
	}

	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		gzipStream.write(b, off, len);
	}

	@Override
	public void write(byte[] b) throws IOException {
		gzipStream.write(b);
	}

	@Override
	public boolean isReady() {
		return false;
	}

	@Override
	public void setWriteListener(WriteListener writeListener) {
		// Do nothing 
	}

}
