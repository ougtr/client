package ma.axa.inner.ged.helper;

import lombok.Data;

@Data
public class Query {
	private Bool bool;
}
