package ma.axa.inner.ged.repository.production.health.amc;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.production.health.amc.DocumentHealthAMCEs;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCSearchParams;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.repository.ElasticSearchNewRepository;
import ma.axa.inner.ged.util.ElasticSearchUtils;
import ma.axa.inner.ged.util.constants.ElasticConstants;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static ma.axa.inner.ged.util.ElasticSearchUtils.termQuery;

@Repository
@RequiredArgsConstructor
@Slf4j
public class HealthAMCElasticRepository {
    private final BrancheProperties healthAMCProperties;
    private final ElasticSearchNewRepository elasticRepository;


    /**
     * Create new Document in ElasticSearch
     */
    public String createNewDocument(final String documentId, final DocumentHealthAMCEs metaData)
            throws ElasticsearchException, IOException {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("ID Document must not be blank");
        if (metaData == null)
            throw new NullPointerException("Document Health AMC must not be null");

        try {
            if (exists(documentId)) {
                throw new ResourceAlreadyExist(GlobalConstants.URI_RECORDE_ALREADY_EXIST,
                        "Document with id {0} already exist",
                        new String[]{documentId});
            }

            var created = elasticRepository.createNewDocument(healthAMCProperties.getEsDocIndex(), documentId, metaData);
            if (created != null) {
                log.info("[es-repo] Successfully created new document Health AMC with id: {}", documentId);
                return created;
            }
        } catch (Exception e) {
            log.error("[es-repo] Error creating new document for id: {}, err: {} ", documentId, e.getMessage());
            throw e;
        }
        return null;
    }

    // Update

    public boolean updateDocument(final String documentId, final DocumentHealthAMCEs metaData)
            throws ElasticsearchException, IOException {
        return updateDocument(documentId, metaData, false);
    }


    /**
     * Update Document in ElasticSearch
     */
    private boolean updateDocument(final String documentId, final DocumentHealthAMCEs metaData,
                                   boolean isUpsert)
            throws ElasticsearchException, IOException {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("Document ID must not be blank");
        if (metaData == null)
            throw new NullPointerException("Document Health AMC must not be null");

        try {
            var response = elasticRepository.updateDocument(healthAMCProperties.getEsDocIndex(), documentId, metaData,
                    isUpsert,
                    DocumentHealthAMCEs.class);
            log.info("[es-repo] Successfully updatd new document Health AMC with id: {}", documentId);
            return response;
        } catch (Exception e) {
            log.error("[es-repo] Error updating  document with id:{}, err: {}", documentId, e.getMessage());
            throw e;
        }
    }

    /**
     * find document by criteria
     *
     * @param searchParams
     */

    public SearchResponse<DocumentHealthAMCEs> findByCriteria(DocHealthAMCSearchParams searchParams, boolean findAll) {
        elasticRepository.refreshIndex(healthAMCProperties.getEsDocIndex());
        try {
            var boolQuery = new BoolQuery.Builder();
            var query = ElasticSearchUtils.getQueryForMultiSearch(constructSearchMap(searchParams));
            boolQuery.must(query);
            int from = searchParams.getPageNumber() * searchParams.getPageSize();
            var searchRequest = new SearchRequest.Builder();
            searchRequest.index(healthAMCProperties.getEsDocIndex())
                    .query(q -> q
                            .bool(boolQuery.build()));
            if (!findAll) {
                searchRequest.from(from).size(searchParams.getPageSize());
            }
            return elasticRepository.search(searchRequest, DocumentHealthAMCEs.class);
        } catch (Exception e) {
            log.error("Error during elastic search", e);
            return null;
        }
    }

    private Map<String, String> constructSearchMap(DocHealthAMCSearchParams searchParams) {
        Map<String,String> searchMap= new HashMap<>();
        searchMap.put(ElasticConstants.POLICY_NUMBER,searchParams.getPolicyNumber());
        searchMap.put(ElasticConstants.TYPE_DOCUMENT_LABEL,searchParams.getTypeDocument());
        searchMap.put(ElasticConstants.QUOTATION_NUMBER,searchParams.getIdQuotation());
        return searchMap;
    }


    /**
     * Check if document id exist
     *
     * @param documentId
     */
    public boolean exists(String documentId) {
        return elasticRepository.existsDocument(healthAMCProperties.getEsDocIndex(), documentId);
    }

    public Optional<DocumentHealthAMCEs> findById(String id) {
        try {
            elasticRepository.refreshIndex(healthAMCProperties.getEsDocIndex());
            return Optional.of(elasticRepository.findById(healthAMCProperties.getEsDocIndex(), id, DocumentHealthAMCEs.class));
        } catch (Exception e) {
            log.error("[es-repo] Error find document with id:{}, err: {}", id, e.getMessage());
            return Optional.empty();
        }
    }

    public DocumentHealthAMCEs findOneDocumentByReference(String reference) {
        elasticRepository.refreshIndex(healthAMCProperties.getEsDocIndex());
        BoolQuery.Builder boolQuery = new BoolQuery.Builder();
        boolQuery.must(termQuery(ElasticConstants.REFERENCE, reference));
        try {
            var searchRequest = new SearchRequest.Builder();
            searchRequest.index(healthAMCProperties.getEsDocIndex())
                    .query(q -> q.bool(boolQuery.build()));
            var searchResponse = elasticRepository.search(searchRequest, DocumentHealthAMCEs.class);
            if (searchResponse != null && !searchResponse.hits().hits().isEmpty()) {
                return searchResponse.hits().hits().get(0).source();
            }
        } catch (Exception e) {
            log.error("[es-repo] Error during search by reference: {} , err: {}", reference, e.getMessage());
        }
        return null;
    }

    public boolean deleteDocument(String documentId) {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("documentId must not be blank");
        try {
            var response = elasticRepository.deleteDocument(healthAMCProperties.getEsDocIndex(), documentId);
            if (response) {
                log.debug("[es-repo]Successfully deleted document Health AMC with id: {}", documentId);
                return true;
            }
        } catch (Exception e) {
            log.warn("[es-repo] Error deleting document by id: {}, err: {}", documentId, e.getMessage());
        }
        return false;
    }
}