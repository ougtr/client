package ma.axa.inner.ged.claim.ls.api;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import io.swagger.v3.oas.annotations.tags.Tag;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsResp;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsSearchParams;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsUpdateReq;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsReq;
import ma.axa.inner.ged.claim.ls.service.ClaimLsDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Slf4j
@RestController
@RequestMapping("/v1/claims/ls/documents")
@Tag(name = GlobalConstants.TAG_CLAIM_LS_APIS, description = GlobalConstants.TAG_DESC_CLAIM_LS_APIS)
@RequiredArgsConstructor
public class ClaimLsDocumentAPI {


	private final ClaimLsDocumentService service;


	@Operation(summary = "Upload new claim LS document and index meta-data")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Document ID", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = DocClaimLsReq.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid request", content = @Content) })
	@PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<DocClaimLsResp> uploadClaimLsDoc(
			@ParameterObject @ModelAttribute @Valid DocClaimLsReq documentLsReq,
			@Parameter(description = "Content of the document") @RequestPart(value = "file") MultipartFile file) {
		log.debug("[claim-ls-api] Start Uploading file:  {}", file.getName());
		var createdDocument = service.uploadDocWithMetaData(documentLsReq, file);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdDocument);
	}


	@Operation(summary = "Download a claim LS document by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was downloaded", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = Resource.class, format = "byte")) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping(value = "/{document_id}/content", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<Resource> downloadClaimLsDocContent(
			@Parameter(required = true, description = "The document id (Alfresco ID)") @NotBlank(message = "Document id must not be empty") @PathVariable(value = "document_id") String documentId) {
		return service.downloadFile(documentId);
	}


	@Operation(summary = "Update claim LS document by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was updated", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = DocClaimLsResp.class)) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@PutMapping(value = "/{document_id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DocClaimLsResp> updateClaimLsDoc(
			@NotBlank(message = "Document id must not be empty") @PathVariable(value = "document_id") String documentId,
			@Valid @RequestBody DocClaimLsUpdateReq documentReq) {
		var updatedDoc = service.updateDocument(documentId, documentReq);
		return ResponseEntity.ok(updatedDoc);
	}


	@Operation(summary = "Search claim Ls Documents by sinistre number")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was downloaded", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = Page.class)) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping
	public ResponseEntity<Page<DocClaimLsResp>> searchClaimLsDocByClaimNumber(@Valid DocClaimLsSearchParams searchParams) {
		log.debug("[API] Multi Searching documents...");
		var pageResult = service.search(searchParams);
		return ResponseEntity.ok(pageResult);
	}
	@Operation(summary = "Delete claim Ls document by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was deleted", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = String.class)) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@DeleteMapping(value = "/{document_id}")
	public ResponseEntity<String> deleteDocument(
			@NotBlank(message = GlobalConstants.ERROR_MSG_RD_ID_NOT_BLANK) @PathVariable(value = "document_id") String documentId) {
		return ResponseEntity.ok(service.deleteDocument(documentId));
	}



}
