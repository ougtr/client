package ma.axa.inner.ged.mobile.scan.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.webjars.NotFoundException;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageConfig;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.mobile.scan.dto.OcrDoc;
import ma.axa.inner.ged.mobile.scan.dto.OcrDocDto;
import ma.axa.inner.ged.mobile.scan.dto.QrCode;
import ma.axa.inner.ged.mobile.scan.dto.ScanResponse;
import ma.axa.inner.ged.mobile.scan.repository.OcrDocRepository;
import ma.axa.inner.ged.mobile.scan.repository.QrCodeRepository;
import ma.axa.inner.ged.mobile.scan.service.QrCodeService;
import ma.axa.inner.ged.util.TypeDocumentEnum;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import net.bytebuddy.implementation.bytecode.Throw;
@Service
@Slf4j
public class QrCodeServiceImpl implements QrCodeService {
	@Autowired
	OcrDocRepository ocrDocRepository;
	@Autowired
	QrCodeRepository qrCodeRepository;
	@Value("${axa.front-mobile-scan.url}")
	String url;

	@Override
	public ScanResponse generateQRCode(String typeDocument, int width, int height) throws WriterException, IOException {
		log.info("start service : generate qr code ");
		if(EnumUtils.isValidEnum(TypeDocumentEnum.class, typeDocument)) {
		QRCodeWriter qrCodeWriter = new QRCodeWriter();
		ScanResponse scanResonse = new ScanResponse();
		QrCode qrCode = new QrCode();
		OcrDoc ocrDocument = new OcrDoc();
		UUID uuid = UUID.randomUUID();
		String uuidAsString = uuid.toString();
		BitMatrix bitMatrix = qrCodeWriter.encode(url + uuidAsString, BarcodeFormat.QR_CODE, width, height);
		ByteArrayOutputStream pngOutputStream = new ByteArrayOutputStream();
		MatrixToImageConfig con = new MatrixToImageConfig(0xFF000001, 0xFFFFFFFF);
		MatrixToImageWriter.writeToStream(bitMatrix, "PNG", pngOutputStream, con);
		byte[] pngData = pngOutputStream.toByteArray();
		String qrCodeBase = Base64.getEncoder().encodeToString(pngData);
		scanResonse.setQrCodeImageBase64(qrCodeBase);
		scanResonse.setToken(uuidAsString);
		scanResonse.setUrl(url+uuidAsString);
		qrCode.setToken(uuidAsString);
		ocrDocument.setToken(uuidAsString);
		ocrDocument.setTypeDocument(typeDocument);
		ocrDocument.setDateMaj(new Date());
		ocrDocRepository.save(ocrDocument);
		qrCodeRepository.save(qrCode);
		log.info("End service : generate qr code ");
		return scanResonse;
		}else {
			throw new GlobalException("Type Document Invalid !");
		}
		
	}

	@Override
	public ScanResponse getTypeDocumentByToken(String token) {
		ScanResponse scanResponse=new ScanResponse();
		OcrDoc ocrDocument = ocrDocRepository.findByToken(token);
		log.info("ocrDocument "+ocrDocument);
		String typeDocument = null;
		if (ocrDocument != null) {
			typeDocument = ocrDocument.getTypeDocument();
			scanResponse.setTypeDocument(typeDocument);
			scanResponse.setToken(token);
			log.info("type de document returner pour le token '{}' est '{}'",token,typeDocument);
		} 
		return scanResponse;
	}
	
	@Override
	public OcrDocDto getocrDocumentByToken(String token) {
		OcrDocDto ocrDocumentDto = new OcrDocDto() ;
		OcrDoc ocrDocument = ocrDocRepository.findByToken(token);
		BeanUtils.copyProperties(ocrDocument, ocrDocumentDto);
		return ocrDocumentDto;
		
	}
}
