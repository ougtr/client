package ma.axa.inner.ged.config.properties;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GedAtProperties {

	@Bean
	@ConfigurationProperties(prefix = "axa.ged.at-temporary")
	public AtProperties atProperties() {
		return new AtProperties();
	}

	@Data
	@NoArgsConstructor
	public static class AtProperties {
		private String alfrescoSitePath;
		private String alfrescoRootFolder;
	}
}
