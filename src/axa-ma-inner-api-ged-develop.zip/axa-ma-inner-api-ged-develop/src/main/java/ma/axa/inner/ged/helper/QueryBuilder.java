package ma.axa.inner.ged.helper;

import com.beust.jcommander.internal.Lists;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.NonNull;
import ma.axa.inner.ged.domain.DossierSinistreAuto;
import ma.axa.inner.ged.domain.ESBulkOperationMetadata;
import ma.axa.inner.ged.domain.PreDeclarationTypeDoc;
import ma.axa.inner.ged.enums.AutoAtBranchEnum;
import ma.axa.inner.ged.enums.BoolQueryType;
import ma.axa.inner.ged.enums.ESOrderEnum;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.collections4.CollectionUtils;

import java.util.*;

public class QueryBuilder {
	
	private QueryBuilder() {
	    throw new IllegalStateException("Utility class");
	}

	public static RequestQuery dossierSinistreAutoRequestQueryBuilder(DossierSinistreAuto input) {
		var query = new Query();
		var bool = new Bool();
		bool.setMust(new ArrayList<>());
		query.setBool(bool);

		if(input.getId() != null) {
			query = addCriteria(CriteriaTypes.TERM, query,"_id", input.getId());
		}
		
		else if(input.getNumSinistre() != null) {
			if (StringUtils.isNotBlank(input.getNumSinistre().toString())) {
				query = addCriteria(CriteriaTypes.TERM, query,"numSinistre", input.getNumSinistre());
			}
		} else {
			if (input.getPredec() != null && StringUtils.isNotBlank(input.getPredec()))
				query = addCriteria(CriteriaTypes.MATCH_PHRASE, query,"predec", input.getPredec());
			
			if(input.getMatricule() != null && StringUtils.isNotBlank(input.getMatricule()))
				query = addCriteria(CriteriaTypes.MATCH_PHRASE, query,"matricule", input.getMatricule());
			
			if (input.getPolnum() != null && StringUtils.isNotBlank(input.getPolnum().toString()))
				query = addCriteria(CriteriaTypes.TERM, query,"polnum", input.getPolnum());
			
			if (input.getNomAssure() != null && StringUtils.isNotBlank(input.getNomAssure()))
				query = addCriteria(CriteriaTypes.MATCH_PHRASE, query,"nomAssure", input.getNomAssure());

			if (StringUtils.isNotBlank(String.valueOf(input.getCodeAgent())) && input.getCodeAgent() != 0)
				query = addCriteria(CriteriaTypes.TERM, query,"codeAgent", input.getCodeAgent());
			
			if (CollectionUtils.isNotEmpty(input.getNomVictimes()) && StringUtils.isNotBlank(input.getNomVictimes().get(0)))
				query = addCriteria(CriteriaTypes.FUZZY, query,"nomVictimes", input.getNomVictimes().get(0));
						
			if (CollectionUtils.isNotEmpty(input.getNumJuridiction()))
				query = addCriteria(CriteriaTypes.TERM, query,"numJuridiction", input.getNumJuridiction().get(0));
			
			if (input.getDateSinistre() != null && StringUtils.isNotBlank(input.getDateSinistre().toString()))
				query = addCriteria(CriteriaTypes.TERM, query,"dateSinistre", input.getDateSinistre());
		}

		var requestQuery = new RequestQuery();
		requestQuery.setQuery(query);
		
		return requestQuery; 
	}
	private static CriteriaTypes getCriteriaTypeForFieldInDocumentMetadata(String key){
		if(List.of("nSin","idPredeclaration","idTransaction","numeroDossier", "nomVictime").contains(key))
			return CriteriaTypes.MATCH;
		if(List.of("idAlfresco","userC","userM","nomFile","immatriculation").contains(key))
			return CriteriaTypes.MATCH_PHRASE;
		return CriteriaTypes.TERM;
	}

	private static CriteriaTypes getCriteriaTypeForFieldInDocumentATRequest(String key){

		if(List.of("numsinistre","numpolice", "preDeclarationNumber", "intermediaryCode", "codeDocument", "rightHolderId").contains(key))
			return CriteriaTypes.MATCH;
		if(List.of("idalfersco","uploadedby","nomdocument").contains(key))
			return CriteriaTypes.MATCH_PHRASE;
		return CriteriaTypes.TERM;
	}
	public static RequestQuery documentSinistreAutoRequestQueryBuilder(Map<String,Object> mapOfInfo){
		var query = new Query();
		var bool = new Bool();
		bool.setMust(new ArrayList<>());
		query.setBool(bool);
		var requestQuery = new RequestQuery();
		for(var entry: mapOfInfo.entrySet()){
			addCriteria(getCriteriaTypeForFieldInDocumentMetadata(entry.getKey()),query, entry.getKey(), entry.getValue());
		}
		requestQuery.setQuery(query);
		return requestQuery;
	}

	public static RequestQuery documentSinistreAutoRequestQueryBuilder(String key, Object value) {
		var query = new Query();
		var bool = new Bool();
		bool.setMust(new ArrayList<>());
		query.setBool(bool);

		var requestQuery = new RequestQuery();
		requestQuery.setQuery(addCriteria(getCriteriaTypeForFieldInDocumentMetadata(key), query, key, value));
		
		return requestQuery; 
	}
	
	public static Query addCriteria(CriteriaTypes type,Query query, String key, Object value) {
		Map<String, Map<String, Object> > criteria = new HashMap<>();
		Map<String, Object> map = new HashMap<>(); 
		
		map.put(key,value);
		criteria.put(type.value(),map);

		query.getBool().getMust().add(criteria);
		
		return query;
	}
	public static Query addCriteriaMustNot(CriteriaTypes type,Query query, String key, Object value) {
		Map<String, Map<String, Object> > criteria = new HashMap<>();
		Map<String, Object> map = new HashMap<>();

		map.put(key,value);
		criteria.put(type.value(),map);

		query.getBool().getMustNot().add(criteria);

		return query;
	}
	public static Query addCriteriaWithShould(CriteriaTypes type,Query query, String key, Object value) {
		Map<String, Map<String, Object> > criteria = new HashMap<>();
		Map<String, Object> map = new HashMap<>();

		map.put(key,value);
		criteria.put(type.value(),map);

		query.getBool().getShould().add(criteria);

		return query;
	}

	public static RequestQuery documentATRequestQueryBuilderWithMap(Map<String, Object> mapOfInfoAsMust, Map<String, Object> mapOfInfoAsMustNot, Map<String, Object> valuesMustBetweenThemOr, Integer page, Integer size) {
		var query = new Query();
		var bool = new Bool();
		if(!org.springframework.util.CollectionUtils.isEmpty(mapOfInfoAsMust))
			bool.setMust(new ArrayList<>());
		if(!org.springframework.util.CollectionUtils.isEmpty(mapOfInfoAsMustNot))
			bool.setMustNot(new ArrayList<>());
		query.setBool(bool);
		var requestQuery = new RequestQuery();
		requestQuery.setFrom(page*size);
		requestQuery.setSize(size);
		for(var entry: mapOfInfoAsMust.entrySet()){
			addCriteria(getCriteriaTypeForFieldInDocumentATRequest(entry.getKey()),query, entry.getKey(), entry.getValue());
		}
		for(var entry:mapOfInfoAsMustNot.entrySet()){
			addCriteriaMustNot(getCriteriaTypeForFieldInDocumentATRequest(entry.getKey()),query, entry.getKey(),entry.getValue());
		}

		if (!org.springframework.util.CollectionUtils.isEmpty(valuesMustBetweenThemOr)) {
			if (query.getBool().getMust() == null) {
				query.getBool().setMust(new ArrayList<>());
			}
			query.getBool().getMust().add(mapValuesMustBetweenThemOr(valuesMustBetweenThemOr));
		}
		requestQuery.setQuery(query);
		return requestQuery;
	}

	private static Map<String, Map<String, Object>> mapValuesMustBetweenThemOr(Map<String, Object> values) {
		List<Map<String, Map<String, Object>>> shouldList = new ArrayList<>();

		for (var entry : values.entrySet()) {
			var criteriaType = getCriteriaTypeForFieldInDocumentATRequest(entry.getKey());
			List<?> valueList = (entry.getValue() instanceof List<?>) ? (List<?>) entry.getValue() : List.of(entry.getValue());

			for (Object singleValue : valueList) {
				shouldList.add(Map.of(criteriaType.value(), Map.of(entry.getKey(), singleValue)));
			}
		}
		return Map.of(BoolQueryType.BOOL.getValue(), Map.of(BoolQueryType.OPTIONAL_MATCH.getValue(), shouldList));
	}

	public static RequestQuery documentSinistreAtRequestQueryBuilder(String key, Object value) {
		var query = new Query();
		var bool = new Bool();
		bool.setMust(new ArrayList<>());
		query.setBool(bool);

		var type = CriteriaTypes.TERM;

		if(key.equals("numsinistre"))
			type = CriteriaTypes.MATCH;
		if(key.equals("idalfersco"))
			type = CriteriaTypes.MATCH_PHRASE;

		var requestQuery = new RequestQuery();
		requestQuery.setQuery(addCriteria(type, query, key, value));

		return requestQuery;

	}

	public static RequestQuery documentSinistreAutoRequestQueryBuilderGetUnion(Map<Object,String> hashMap, @NonNull AutoAtBranchEnum branch) {
		var query = new Query();
		var bool = new Bool();
		bool.setShould(new ArrayList<>());
		query.setBool(bool);

		CriteriaTypes type;
		for(var entry  : hashMap.entrySet()){
			if(AutoAtBranchEnum.SAT.equals(branch))
				type=getCriteriaTypeForFieldInDocumentATRequest(entry.getValue());
			else
				type = getCriteriaTypeForFieldInDocumentMetadata(entry.getValue());
			addCriteriaWithShould(type, query, entry.getValue(), entry.getKey());
		}

		var requestQuery = new RequestQuery();

		requestQuery.setQuery(query);

		return requestQuery;
	}

	public static String createABulkQuery(HashMap<ESBulkOperationMetadata, Object> multiOperations) throws JsonProcessingException {
		var bulkQuery = new StringBuilder();
		var objectMapper = new ObjectMapper();
		for(var entry : multiOperations.entrySet()){
			bulkQuery.append("{"
					.concat("\""+entry.getKey().getOperation().getOperation()+"\"")
					.concat(":"));
			bulkQuery.append(objectMapper.writeValueAsString(entry.getKey()));
			bulkQuery.append("}");
			bulkQuery.append("\r\n");
			bulkQuery.append(objectMapper.writeValueAsString(entry.getValue()));
			bulkQuery.append("\r\n");
		}
		return bulkQuery.toString();
	}

	public static void addSortBy(RequestQuery requestQuery,String key,ESOrderEnum orderEnum){
		HashMap<String,SortConfig> sortMap=new HashMap<>();
		sortMap.put(key,SortConfig.builder()
						.order(orderEnum.getCode())
				.build());
		if(CollectionUtils.isNotEmpty(requestQuery.getSort()))
			requestQuery.getSort().add(sortMap);
		else
			requestQuery.setSort(Lists.newArrayList(sortMap));
	}
}
