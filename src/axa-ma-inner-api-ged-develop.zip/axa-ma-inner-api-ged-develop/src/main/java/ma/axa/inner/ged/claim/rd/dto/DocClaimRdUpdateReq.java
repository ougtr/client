package ma.axa.inner.ged.claim.rd.dto;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class DocClaimRdUpdateReq extends DocClaimRdBaseDto {
	@NotBlank(message = GlobalConstants.ERROR_MSG_RD_LASTUPDATEDBY_NOT_BLANK)
	private String lastUpdatedBy;

	private Integer brancheCode;
	private String brancheLabel;
	
	private String status ;
	private String repertoire;
	private String repertoireCode;
	private String emetteur;
}
