package ma.axa.inner.ged.repository;

import ma.axa.inner.ged.domain.TypeDocAs400;
import ma.axa.inner.ged.enums.AutoAtBranchEnum;
import ma.axa.inner.ged.util.jpa_query_filter.JpaQueryFilter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TypeDocRepository extends JpaRepository<TypeDocAs400,Integer> , JpaQueryFilter<TypeDocAs400> {
    List<TypeDocAs400> findByBranch(AutoAtBranchEnum branch);
    List<TypeDocAs400> findByBranchAndEntityId(AutoAtBranchEnum branch,Integer entityId);
}
