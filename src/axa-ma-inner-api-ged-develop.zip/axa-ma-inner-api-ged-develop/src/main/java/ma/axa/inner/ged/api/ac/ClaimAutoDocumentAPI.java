package ma.axa.inner.ged.api.ac;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.extern.slf4j.Slf4j;

import ma.axa.inner.ged.domain.DossierProductionTypeDoc;
import ma.axa.inner.ged.domain.IndexOrPathToUse;

import ma.axa.inner.ged.domain.*;
import ma.axa.inner.ged.dto.ChangesQueryDto;
import ma.axa.inner.ged.dto.CopyDocumentsQueryDto;
import org.apache.commons.lang3.StringUtils;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import ma.axa.inner.ged.service.ac.ClaimAutoDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springframework.web.server.ResponseStatusException;

@Tag(name = GlobalConstants.AUTO_GED_APIS_TAG)
@RestController
@RequestMapping("/v1/claims/ac")
@RequiredArgsConstructor
@Slf4j
public class ClaimAutoDocumentAPI {

    private final ClaimAutoDocumentService claimAutoDocumentService;

    @SneakyThrows
    @Operation(summary = "upload a claim document")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document added", content = {
                    @Content(mediaType = "multipart/form-data", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error while uploading the file", content = @Content)})
    @PostMapping(value = "/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public String uploadFile(@ParameterObject @Valid @ModelAttribute PreDeclarationTypeDoc documentSinistreAuto
            , @RequestParam(value = "file", required = true) MultipartFile file, @RequestParam(required = false) Boolean temporary) {
        log.info("Start api: Uploading file (document sinistre) '{}'", file.getOriginalFilename());
        final var indexToUse = (temporary == null || !temporary) ? IndexOrPathToUse.DEFAULT : IndexOrPathToUse.TEMPORARY;
        var id = claimAutoDocumentService.uploadFile(file, documentSinistreAuto, indexToUse);
        log.debug("File metadata '{}' and id '{}'", documentSinistreAuto, id);
        log.info("End api: File (document sinistre) uploaded '{}'", file.getOriginalFilename());
        return id;
    }

    @SneakyThrows
    @Operation(summary = "upload multiple claim documents (Automated tests only)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document added", content = {
                    @Content(mediaType = "multipart/form-data", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error while uploading the file", content = @Content)})
    @PostMapping(value = "/auto-tests/multi-documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public List<String> uploadTestFiles(@Valid @RequestPart(value = "data") List<PreDeclarationTypeDoc> documentSinistreAutoList
            , @RequestParam(value = "file", required = true) MultipartFile file, @RequestParam(required = false) Boolean temporary) {
        log.info("Start api: Uploading multiple test files (documents sinistre) '{}'", documentSinistreAutoList.size());
        List<String> ids = new ArrayList<>();
        IntStream.range(0, documentSinistreAutoList.size()).parallel().forEach(i -> {
            log.info("Uploading test file (document sinistre) '{}'", file.getOriginalFilename());
            final var indexToUse = (temporary == null || !temporary) ? IndexOrPathToUse.DEFAULT : IndexOrPathToUse.TEMPORARY;
            var id = claimAutoDocumentService.uploadTestFile(file, documentSinistreAutoList.get(i), indexToUse);
            ids.add(id);
            log.debug("Test file metadata '{}' and id '{}'", documentSinistreAutoList.get(i), id);
            log.info("Test file (document sinistre) uploaded '{}'", file.getOriginalFilename());
        });
        log.info("End api: Test files (documents sinistre) uploaded '{}'", documentSinistreAutoList.size());
        return ids;
    }

    @Operation(summary = "download a claim document by its alfresco id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was downloaded", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = Resource.class))}),
            @ApiResponse(responseCode = "404", description = "document not found with id", content = @Content),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})

    @GetMapping(value = "/documents/{document_id}/content", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<Resource> downloadFile(@NotNull(message = "{error.alfresco.id}") @PathVariable(value = "document_id", required = true) String alfrescoIdWithoutPrefix) {
        log.info("Start api: Downloading file with id '{}'", alfrescoIdWithoutPrefix);
        var resource = claimAutoDocumentService.downloadFile(alfrescoIdWithoutPrefix);

        var headers = new HttpHeaders();
        String headerKey = "X-filename";
        String headerValue = resource.getFilename();
        headers.set(headerKey, headerValue);

        log.info("End api: File downloaded !");
        return ResponseEntity.ok().headers(headers).body(resource);
    }

    @Operation(summary = "search claim document metadata")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was found", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = DossierProductionTypeDoc.class))}),
            @ApiResponse(responseCode = "400", description = "Request not valid", content = @Content),
            @ApiResponse(responseCode = "404", description = "claim document metadata not found", content = @Content)})
    @GetMapping("/folders")
    public List<DossierSinistreAuto> searchDossier(@NotEmpty(message = "{error.dossier.infomation}") @ParameterObject @ModelAttribute DossierSinistreAuto dossierSinistreAuto) {
        log.info("Start api: Search list of dossier sinistre with metadata '{}'", dossierSinistreAuto);
        var listDossiers = claimAutoDocumentService.getDossierSinAutoList(dossierSinistreAuto);
        log.debug("List of dossier sinistre loaded : '{}'", listDossiers);
        log.info("End api: Search list of dossier sinistre with metadata '{}'", dossierSinistreAuto);
        return listDossiers;
    }


    @Operation(summary = "search a claim using claim number")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "documents metadata were found", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = PreDeclarationTypeDoc.class))}),
            @ApiResponse(responseCode = "400", description = "Request not valid", content = @Content),
            @ApiResponse(responseCode = "404", description = "documents not found with claim number", content = @Content)}
    )
    @GetMapping("/documents/metadatas")
    public List<PreDeclarationTypeDoc> searchInDocuments(@RequestParam(required = false, value = "claim_number") String claimNumber, @RequestParam(required = false, value = "uploaded_by") String uploadedBy, @RequestParam(required = false) Boolean temporary) {
        log.info("Start api: Search list of documents with claimNumber '{}' and uploadedBy '{}' and isTemporary '{}'", claimNumber, uploadedBy, temporary);
        if (StringUtils.isBlank(claimNumber) && StringUtils.isBlank(uploadedBy)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        }
        final var indexOrPath = (temporary == null || !temporary) ? IndexOrPathToUse.DEFAULT : IndexOrPathToUse.TEMPORARY;
        var listDocuments = claimAutoDocumentService.getDocumentsList(indexOrPath, claimNumber, uploadedBy);
        log.info("End api: Search list of documents with claimNumber '{}' and uploadedBy '{}' and isTemporary '{}'", claimNumber, uploadedBy, temporary);
        return listDocuments;
    }

    @Operation(summary = "modify documents metadata")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "documents metadata were modified", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "404", description = "document not found with idAlfresco", content = @Content)}
    )

    @PutMapping("/documents/{document_id}")
    public String modifyMetadata(@NotEmpty(message = "{error.document.infomation}") @PathVariable(value = "document_id") String idAlfresco, @RequestBody PreDeclarationTypeDoc documentsMetadata, @RequestParam(required = false) Boolean temporary) {
        log.info("Start api: modify data of documents with alfresco id '{}'", idAlfresco);
        final var indexToUse = (temporary == null || !temporary) ? IndexOrPathToUse.DEFAULT : IndexOrPathToUse.TEMPORARY;
        var modificationResponse = claimAutoDocumentService.modifyDocumentsMetadata(indexToUse, idAlfresco, documentsMetadata);
        log.info("End api: modify data of documents with alfresco id '{}'", idAlfresco);
        return modificationResponse;
    }

    @Operation(summary = "delete documents metadata")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "documents metadata were deleted", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "404", description = "document not found with idAlfresco", content = @Content)}
    )

    @DeleteMapping("/documents/{document_id}")
    public String deleteMetadata(
            @PathVariable(value = "document_id") String idAlfresco,
            @RequestParam(required = false) Boolean temporary,
            @RequestParam(name = "metadata-only", required = false, defaultValue = "false") Boolean metadataOnly
    ) {
        log.info("Start api: delete data of documents with alfresco id '{}'", idAlfresco);
        final var indexToUse = (temporary == null || !temporary) ? IndexOrPathToUse.DEFAULT : IndexOrPathToUse.TEMPORARY;

        var deleteDocumentsMetadata = claimAutoDocumentService.deleteDocument(indexToUse, idAlfresco, metadataOnly);

        log.info("End api: delete data of documents with alfresco id '{}'", idAlfresco);
        return deleteDocumentsMetadata;
    }

    @Operation(summary = "delete tests documents metadata (Automated tests only)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "documents metadata were deleted", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "404", description = "document not found with idAlfresco", content = @Content)}
    )
    @DeleteMapping("/documents/auto-tests/cleanup")
    public List<String> deleteTestMetadatas(@RequestParam(value = "document_ids") List<String> idsAlfresco, @RequestParam(required = false) Boolean temporary) {
        log.info("Start api: delete data of multiple test documents '{}'", idsAlfresco.size());
        List<String> deleteDocumentsMetadatas = new ArrayList<>(idsAlfresco.size());

        idsAlfresco.parallelStream().forEach(idAlfresco -> {
            log.info("Start api: delete test data of documents with alfresco id '{}'", idAlfresco);
            final var indexToUse = (temporary == null || !temporary) ? IndexOrPathToUse.DEFAULT : IndexOrPathToUse.TEMPORARY;

            var deleteDocumentsMetadata = claimAutoDocumentService.deleteDocument(indexToUse, idAlfresco, false);
            deleteDocumentsMetadatas.add(deleteDocumentsMetadata);

            log.info("End api: delete test data of documents with alfresco id '{}'", idAlfresco);
        });
        log.info("End api: delete data of multiple test documents '{}'", idsAlfresco.size());

        return deleteDocumentsMetadatas;
    }

    @Operation(summary = "save temporary file to default")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document validated", content = {
                    @Content(mediaType = "multipart/form-data", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content)})
    @PostMapping("/documents/{documents_id}/validate")
    public String saveTempToDefault(@PathVariable(value = "documents_id") String idAlfresco, @RequestBody PreDeclarationTypeDoc documentsMetadata) {

        log.info("Start api : validate a temp file with alfresco id '{}'", idAlfresco);
        final var result = claimAutoDocumentService.validateTempFile(idAlfresco, documentsMetadata);
        log.info("End api : Temp file was save to default with alfresco id '{}'", idAlfresco);
        return result;
    }

    @Operation(summary = "copy files and metadata by AlfrescoIds")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document copied", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = List.class))}),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content)})
    @PostMapping("/documents/copy")
    public List<ChangesQueryDto> copyDocumentsByAlfrescoIds(@RequestParam(required = false) Boolean temporary, @RequestBody @Valid CopyDocumentsQueryDto copyDocumentsQueryDto) {
        log.info("Start api : copy files with alfresco's id's '{}' for user '{}'", copyDocumentsQueryDto.getChanges(), copyDocumentsQueryDto.getUserName());
        final var result = claimAutoDocumentService.copyDocumentsByAlfrescoIds(temporary, copyDocumentsQueryDto);
        log.info("End api : copy files with alfresco's id's '{}' for user '{}'", copyDocumentsQueryDto.getChanges(), copyDocumentsQueryDto.getUserName());
        return result;
    }

    @Operation(summary = "search in documents metadata by query")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "documents metadata", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = PreDeclarationTypeDoc[].class))}),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content)})
    @GetMapping("/documents/search")
    public List<PreDeclarationTypeDoc> searchInDocumentsByQuery(@RequestParam(required = false) Boolean temporary, PreDeclarationTypeDoc query) throws IllegalAccessException {
        log.info("Start api: search in documents metadata by query");
        final var indexOrPath = (temporary == null || !temporary) ? IndexOrPathToUse.DEFAULT : IndexOrPathToUse.TEMPORARY;
        var listDocuments = claimAutoDocumentService.searchInDocumentsByQuery(indexOrPath, query);
        log.info("End api: search in documents metadata by query");
        return listDocuments;
    }

}
