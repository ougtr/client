package ma.axa.inner.ged.service.at;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.domain.TypeDocAs400;
import ma.axa.inner.ged.dto.at.IntermediaryTypeDocDto;
import ma.axa.inner.ged.dto.at.TypeDocDto;
import ma.axa.inner.ged.enums.AutoAtBranchEnum;
import ma.axa.inner.ged.mapper.at.TypeDocAtMapper;
import ma.axa.inner.ged.repository.DocumentInfoRepository;
import ma.axa.inner.ged.repository.TypeDocRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class TypeDocumentsReferentialAtService {
    @Value("${axa.util.intermediary-doc-group}")
    private Integer intermediaryDocGroup;
    private final DocumentInfoRepository documentsRepository;
    private final TypeDocRepository typeDocRepository;
    private final TypeDocAtMapper autoMapper;

    public List<TypeDocDto> getAtListTypeDocs() {
        log.info("Start service: get documents types");
        List<TypeDocAs400> typeDocAs400List = typeDocRepository.findByBranch(AutoAtBranchEnum.SAT);
        final var typeDocResponseList = autoMapper.typeDocToTypeDocAt(typeDocAs400List);
        log.info("End service: get documents types size {}", typeDocResponseList.size());
        return typeDocResponseList;
    }

    public List<IntermediaryTypeDocDto> getIntermediaryTypeDocs() {
        log.info("Start service: get intermediary documents types");
        var result = documentsRepository.findByGroup(intermediaryDocGroup);
        var output = autoMapper.mapToIntermediaryTypeDocDto(result);
        log.info("End service: get intermediary documents types");
        return output;
    }
}
