package ma.axa.inner.ged.domain;


import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ESDocumentATRequest {
	@JsonProperty("idalfersco")
	String idAlfersco;
	@JsonProperty("iddocument")
	private String idDocument;
	@JsonProperty("nomdocument")
	private String nomDocument;
	@JsonProperty("numpolice")
	private BigDecimal numPolice;
	@JsonProperty("iddoc")
	String identifiantScaner;
	@JsonProperty("dateUpload")
	Date dateUpload;
	@JsonProperty("numsinistre")
	String numSinistre;
	@JsonProperty("uploadedby")
	String agentIndexation;
	@JsonProperty("typeDocument")
	String typeDocument;
	@JsonProperty("repertoire")
	String repertoire;
	@JsonProperty("dateSurvenance")
	String dateSurvenance;
	@JsonProperty("receptiondate")
	String receptionDate;
	String tag;
	@JsonProperty("dateEnvoi")
	String sendingDate;
	String sourceDossier; // SourceFilesATEnum
	String type; // DocumentTypeATEnum
	String numDossierBnej;
	String numDossierTribunal;
	Boolean isTemporary;
	Boolean isReturnedRO;
	@JsonProperty("numReglement")
	private String numReglement;
	private Integer intermediaryCode;
	Long size;
	Long uploadDateTimeStamp;
	private String preDeclarationNumber;
	private String intermediaryReference;
	private Integer sentToIntermediaryDate;
	private String userSenderToIntermediary;
    private String codeDocument;
	private String rightHolderId;
}