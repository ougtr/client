package ma.axa.inner.ged.repository;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.Result;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.bulk.BulkOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class ElasticSearchNewRepository {

	@Autowired
	ElasticsearchClient elasticsearchClient;

	/** =========== indices =========== **/

	public boolean updateIndexMappingFromJson(final String index, final InputStream is)
			throws IOException, ElasticsearchException {
		try {
			var updated = elasticsearchClient.indices()
					.putMapping(b -> b.index(index)
							.withJson(is));
			return updated != null && updated.acknowledged();
		} catch (IOException | ElasticsearchException e) {
			log.warn("[es-repo] Error during update mapping index [{}], err: {}", index, e.getMessage());
			throw e;
		}
	}

	public boolean createNewIndexFromJson(final String index, final InputStream isMapping)
			throws IOException, ElasticsearchException {
		try {
			var created = elasticsearchClient.indices()
					.create(b -> b.index(index)
							.mappings(f -> f.withJson(isMapping)));
			return created != null && created.acknowledged();
		} catch (IOException | ElasticsearchException e) {
			log.warn("[es-repo] Error during create new index [{}], err: {}", index, e.getMessage());
			throw e;
		}
	}

	public boolean deleteIndex(final String index) throws IOException, ElasticsearchException {
		try {
			if (StringUtils.equalsAnyIgnoreCase(index, "_all", "*")) {
				throw new IllegalArgumentException("Can't delete all index");
			}
			var response = elasticsearchClient.indices().delete(b -> b.index(index));
			return response.acknowledged();
		} catch (IOException | ElasticsearchException e) {
			log.debug("[es-repo] Error during delete index [{}], err: {}", index, e.getMessage());
			throw e;
		}
	}

	public boolean exists(final String index) throws IOException, ElasticsearchException {
		try {
			var response = elasticsearchClient.indices().exists(b -> b.index(index));
			return response.value();
		} catch (IOException | ElasticsearchException e) {
			log.warn("[es-repo] Error during check exists index [{}], err: {}", index, e.getMessage());
			throw e;
		}
	}

	/** =========== Documents =========== **/

	/**
	 * Create new Document in ElasticSearch
	 */
	public <T> String createNewDocument(final String index, final String id, final T metaData)
			throws ElasticsearchException, IOException {
		try {
			var response = elasticsearchClient.index(d -> d
					.index(index)
					.id(id)
					.document(metaData));

			if (response != null && Result.Created.equals(response.result())) {
				log.debug("[es-repo] Successfully created new document with id: {}", id);
				return response.id();
			}
		} catch (IOException | ElasticsearchException e) {
			log.error("[es-repo] Error during creating new document for id: {}, err: {} ", id, e.getMessage());
			throw e;
		}
		return null;
	}

	/**
	 * Update Document in ElasticSearch
	 */
	public <T> boolean updateDocument(final String index, final String id, final T metaData, boolean isUpsert,
			Class<T> clazz)
			throws ElasticsearchException, IOException {
		try {
			var response = elasticsearchClient.update(b -> b.index(index)
					.id(id)
					.doc(metaData)
					.docAsUpsert(isUpsert), clazz);
			log.debug("[es-repo] Successfully updatd document with id: {}", id);
			if (isUpsert)
				return Result.Updated.equals(response.result()) || Result.Created.equals(response.result());
			else
				return Result.Updated.equals(response.result());
		} catch (IOException | ElasticsearchException e) {
			log.error("[es-repo] Error during updating document with id:{}, err: {}", id, e.getMessage());
			throw e;
		}
	}

	/**
	 * Delete Document from ElasticSearch by ID
	 * 
	 * @param id The id of document
	 * @return
	 */
	public boolean deleteDocument(final String index, final String id) {
		try {
			var response = elasticsearchClient.delete(b -> b.index(index).id(id));
			if (response != null && Result.Deleted.equals(response.result())) {
				log.debug("[es-repo] Successfully deleted document with id: {}", id);
				return true;
			}
		} catch (IOException | ElasticsearchException e) {
			log.warn("[es-repo] Error deleting document by id: {}, err: {}", id, e.getMessage());
		}
		return false;
	}

	/**
	 * Find by ID
	 **/
	public <T> T findById(final String index, String id, Class<T> clazz) throws ElasticsearchException, IOException {
		var response = elasticsearchClient.get(b -> b.index(index).id(id), clazz);
		return response != null && response.found() ? response.source() : null;
	}

	/**
	 * Searching...
	 */
	public <T> SearchResponse<T> search(SearchRequest.Builder searchRequest, Class<T> clazz)
			throws ElasticsearchException, IOException {
		try {
			return elasticsearchClient.search(searchRequest.build(), clazz);
		} catch (ElasticsearchException | IOException e) {
			log.error("[es-repo] Error during elastic search, request: {}, err: {}", searchRequest.toString(),
					e.getMessage());
			throw e;
		}
	}

	/**
	 * Refresh Index
	 */
	public void refreshIndex(final String index) {
		try {
			elasticsearchClient.indices().refresh(r -> r.index(index));
		} catch (ElasticsearchException | IOException e) {
			log.error("[es-repo] Error during refresh index, err: {}", e.getMessage());
		}
	}

	/**
	 * Check if id exist
	 */
	public boolean existsDocument(final String index, String id) {
		try {
			var searchResponse = elasticsearchClient.exists(b -> b.index(index).id(id));
			return searchResponse != null && searchResponse.value();
		} catch (ElasticsearchException | IOException e) {
			log.error("[es-repo] Error during check if document exist by id: {}, err: {}", id, e.getMessage());
			return false;
		}
	}

	public boolean bulkDeleteDocument(final String index, List<String> ids) throws ElasticsearchException, IOException {
		try {
			List<BulkOperation> bulkList = ids.stream().map(d -> BulkOperation.of(o -> o.delete(i -> i.id(d))))
					.collect(Collectors.toList());
			elasticsearchClient.bulk(b -> b.index(index).operations(bulkList));
			return true;
		} catch (ElasticsearchException | IOException e) {
			log.warn("[es-repo] Error deleting documents by ids: {}, err: {}", ids, e.getMessage());
			throw e;
		}
	}
}
