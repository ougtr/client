package ma.axa.inner.ged.claim.rd.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(value = Include.NON_NULL)
public class DocClaimRdResponse extends DocClaimRdBaseDto {
	@JsonProperty(index = 1)
	private String id;
	private String reference;
	private String applicationCode;
	private String path;
	private Integer brancheCode;
	private String brancheLabel;
	private boolean draft;
	private String status;
	
    @JsonFormat(pattern = GlobalConstants.DATETIME_FORMAT_COMMON)
	private LocalDateTime createdAt;
    private String createdBy;
    
    @JsonFormat(pattern = GlobalConstants.DATETIME_FORMAT_COMMON)
	private LocalDateTime lastUpdatedAt;
    private String lastUpdatedBy;
    private String repertoire;
    private String repertoireCode;
	private String emetteur;
	private String filesize;
	private String filetype;
	

}
