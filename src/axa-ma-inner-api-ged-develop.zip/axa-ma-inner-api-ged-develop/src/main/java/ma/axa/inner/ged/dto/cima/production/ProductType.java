package ma.axa.inner.ged.dto.cima.production;

public enum ProductType {
    MRP,
    TRC,
    RCP
}
