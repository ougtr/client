package ma.axa.inner.ged.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;
import ma.axa.inner.ged.domain.ConfigParamAs400;
import ma.axa.inner.ged.dto.InfoSinistre;
import ma.axa.inner.ged.exception.CallStoredProcedureException;

@Repository
@RequiredArgsConstructor
@Slf4j
public class SinistreInfoRepository {

	private final JdbcTemplate jdbcTemplate;

	public InfoSinistre getInfoSinistre(final String numSinistre) {
		log.info("\n####################### Start: geting info from db with numSinistre '{}' #######################\n", numSinistre);
		List<InfoSinistre> list;
		try {
			list = jdbcTemplate.query("CALL MOBDONNE.INDEXSIN(?)", BeanPropertyRowMapper.newInstance(InfoSinistre.class),
					numSinistre);
		} catch (Exception e) {
			log.error("\n####################### can not call procedure : '{}' #######################\n", e.getMessage());
			throw new CallStoredProcedureException(e.getMessage());
		}

		if (list.isEmpty()) {
			log.error("\n####################### can not find nsin #######################\n");
			throw new CallStoredProcedureException("Sinistre non trouvé !");
		} else {
			log.info("\n####################### End: getInfoSinistre #######################\n");
			return list.get(0);
		}
	}

	public Map<String, ConfigParamAs400> getInfoTypeDocMap() {
		log.info("\n####################### Start: getting all document types  #######################\n");
		List<ConfigParamAs400> list;
		Map<String, ConfigParamAs400> infoTypeDocMap = null;
		try {
			list = jdbcTemplate.query("CALL MOBPGM.CNSINPARA(?)", BeanPropertyRowMapper.newInstance(ConfigParamAs400.class),
					"DOCAT");
			if (!list.isEmpty()) {
				infoTypeDocMap = new HashMap<>();
				for (ConfigParamAs400 type : list) {
					infoTypeDocMap.put(type.getVARCODE().trim(), type);
				}
			}
		} catch (Exception e) {
			log.error("\n####################### can not call procedure : '{}' #######################\n", e.getMessage());
			throw new CallStoredProcedureException(e.getMessage());
		}
		log.info("\n####################### End: getInfoTypeDocMap #######################\n");
		return infoTypeDocMap;
	}
	
	public Map<String, ConfigParamAs400> getTypeAndFamilleDocMap() {
		log.info("\n####################### Start: getting all document familles #######################\n");
		List<ConfigParamAs400> list;
		Map<String, ConfigParamAs400> infoTypeDocMap = null;
		try {
			list = jdbcTemplate.query("CALL MOBPGM.CNSINPARA(?)", BeanPropertyRowMapper.newInstance(ConfigParamAs400.class),
					"TYPEDOC");
			if (!list.isEmpty()) {
				infoTypeDocMap = new HashMap<>();
				for (ConfigParamAs400 type : list) {
					infoTypeDocMap.put(type.getVARCODE().trim(), type);
				}
			}
		} catch (Exception e) {
			log.error("\n####################### can not call procedure : '{}' #######################\n", e.getMessage());
			throw new CallStoredProcedureException(e.getMessage());
		}
		log.info("\n####################### End: getTypeAndFamilleDocMap #######################\n");
		return infoTypeDocMap;
	}
}
