package ma.axa.inner.ged.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.proxied.SignedPayloadDto;
import ma.axa.inner.ged.exception.BusinessException;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.ResourceNotFoundException;
import ma.axa.inner.ged.util.DateUtils;
import ma.axa.inner.ged.util.ResponseUtils;
import ma.axa.inner.ged.util.SigningUtils;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.net.URLConnection;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProxiedDocumentService {

    private final AlfrescoGedService alfrescoService;

    @Value("${axa.signature.secret-key:''}")
    private String secretKey;
    @Value("${axa.signature.expiration-duration:300}")
    private String expirationDuration;

    public SignedPayloadDto generateSignedPayload(String documentId) {
        log.info("Generating new signed payload for document {}", documentId);
        long expTimeMillis = DateUtils.getCurrentTime();
        expTimeMillis += 1000 * Integer.parseInt(expirationDuration);

        String signature = generateSignature(documentId, expTimeMillis, HttpMethod.GET);

        return SignedPayloadDto.builder()
                .documentId(documentId)
                .expiresAt(expTimeMillis)
                .signature(signature)
                .build();
    }

    public ResponseEntity<Resource> downloadDocument(String documentId, long expiresAt, String signature) {
        log.info("Downloading document {} with expiration date {} and signature {}", documentId, expiresAt, signature);
       /* if (validateSignedPayload(documentId, expiresAt, signature, HttpMethod.GET)) {
            if (isNotExpired(expiresAt))*/
                return downloadDocument(documentId);
           /* else {
                log.error("Expired signed playload passed for document {}", documentId);
                throw new BusinessException("Expired Payload");
            }
        }
        log.error("Invalid signature passed for document {}", documentId);
        throw new BusinessException("Invalid Signature");*/
    }

    private ResponseEntity<Resource> downloadDocument(String documentId) {
        log.info("Downloading document {} from alfresco", documentId);
        var document = getDocumentFromAlfresco(documentId);
        var isr = new InputStreamResource(document.getContentStream().getStream());
        var mimeType = document.getContentStreamMimeType();
        if (StringUtils.isBlank(mimeType) && StringUtils.isNotBlank(document.getName()))
            mimeType = URLConnection.guessContentTypeFromName(document.getName());
        var fileName = StringUtils.isNotBlank(document.getName()) ? document.getName() : "unknown_filename";
        var headers = ResponseUtils.getDownloadHeaders(fileName, document.getContentStreamLength(), mimeType);
        return ResponseEntity.ok().headers(headers).body(isr);

    }

    private Document getDocumentFromAlfresco(String documentId) {
        if (!alfrescoService.exists(documentId))
            throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
                    GlobalConstants.ERROR_MSG_RD_IDDOCUMENT_NOT_FOUND, new String[]{documentId});
        try {
            return alfrescoService.getDocument(documentId);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
        }
    }

    private boolean validateSignedPayload(String documentId, long expirationTime, String signature, HttpMethod httpMethod) {
        String generateSignature = generateSignature(documentId, expirationTime, httpMethod);
        return org.apache.commons.lang3.StringUtils.equals(generateSignature, signature);
    }

    private String generateSignature(String documentId, long expiration, HttpMethod httpMethod) {
        try {
            StringBuilder builder = new StringBuilder(httpMethod.name());
            builder
                    .append("\n").append("document_id=").append(documentId)
                    .append("\n").append("expires_at=").append(expiration);
            String request = builder.toString();

            String preSignature = SigningUtils.hashAndEncode(request);
            return SigningUtils.signAndEncode(preSignature, secretKey);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
        }
    }

    private boolean isNotExpired(long expiration) {
        return expiration >= DateUtils.getCurrentTime();
    }
}
