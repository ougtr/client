package ma.axa.inner.ged.service.production;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.GedProductionProperties;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.domain.ProductionTypeDoc;
import ma.axa.inner.ged.domain.production.ProductionDemandDoc;
import ma.axa.inner.ged.dto.DemandUploadResponseDto;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.helper.ElasticSearchHelper;
import ma.axa.inner.ged.mapper.DocumentMapper;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.service.ManageDocumentService;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;

@Service
@Slf4j
public class ProductionDocumentService extends ManageDocumentService {

    private final GedProductionProperties gedProductionProperties;
    private final ElasticSearchHelper elasticSearchHelper;

    public ProductionDocumentService(ClaimDocumentRepository claimDocumentRepository,
            GedProductionProperties gedProductionProperties, ElasticSearchHelper elasticSearchHelper) {
        super(claimDocumentRepository);
        this.gedProductionProperties = gedProductionProperties;
        this.elasticSearchHelper = elasticSearchHelper;
    }

    public String uploadDemandFile(GedDocument gedDocument, ProductionDemandDoc demandMeta) {
        var path = pathFromDateEffect(demandMeta);
        return uploadToAlfresco(gedDocument, path, null);
    }

    public Resource downloadFile(String id) {
        log.info("Start: Downloading file with id '{}'", id);
        var document = claimDocumentRepository.getFileDocument(id);

        log.debug("File downloaded : '{}'", document);
        log.info("Start: Downloading file with id '{}'", id);
        return new ByteArrayResource(document.getFileByte()) {
            @Override
            public String getFilename() {
                return document.getFileName();
            }
        };
    }

    public String uploadFile(MultipartFile file, ProductionTypeDoc productionDocumentMeta) {
        if (file != null && file.getOriginalFilename() != null && file.getContentType() != null) {
            String filename = file.getOriginalFilename();
            if (filename != null) {
                FileUtil.assertFileNameValid(filename);
            }
            var folder = createOrUpdateDirectory(productionDocumentMeta);
            var esDossierRequest = DocumentMapper.mapToESDossierProductionRequest(productionDocumentMeta,
                    folder.getId());
            elasticSearchHelper.addIndexDossierProduction(esDossierRequest, productionDocumentMeta.getPoliceNumber());
            var gedDocument = DocumentMapper.mapFileToGedDocument(file);
            var idAlfresco = uploadFile(gedDocument, productionDocumentMeta);
            if (StringUtils.isNotBlank(idAlfresco)) {
                var esDocumentATRequest = DocumentMapper.mapToESDocumentProductionRequest(productionDocumentMeta,
                        gedDocument.getFileName(), idAlfresco);
                elasticSearchHelper.addDocumentProduction(esDocumentATRequest, idAlfresco);
                return idAlfresco;
            }
            throw new InternalErrorException("Problème lors de l'upload du document !");
        }
        return null;
    }

    public List<DemandUploadResponseDto> uploadDemandFiles(List<MultipartFile> files, ProductionDemandDoc productionDemandDoc) {
        validateFiles(files);
        createOrUpdateDirectory(productionDemandDoc);
        List<DemandUploadResponseDto> demandUploadResponses = new ArrayList<>();
        for (MultipartFile file : files) {
            if (isFileValid(file)) {
                DemandUploadResponseDto responseDto = processFileUpload(file, productionDemandDoc);
                demandUploadResponses.add(responseDto);
            }
        }
        return demandUploadResponses;
     }
     private void validateFiles(List<MultipartFile> files) {
        for (MultipartFile file : files) {
            if (isFileValid(file)) {
                FileUtil.assertFileNameValid(file.getOriginalFilename());
            }
        }
     }
     private boolean isFileValid(MultipartFile file) {
        return file != null && file.getOriginalFilename() != null && file.getContentType() != null;
     }
     private DemandUploadResponseDto processFileUpload(MultipartFile file, ProductionDemandDoc productionDemandDoc) {
         GedDocument gedDocument = DocumentMapper.mapFileToGedDocument(file);
        String idAlfresco = uploadDemandFile(gedDocument, productionDemandDoc);
        return DemandUploadResponseDto.builder()
                .fileName(file.getOriginalFilename())
                .idAlfresco(idAlfresco)
                .build();
     }

    public String uploadFile(GedDocument gedDocument, ProductionTypeDoc documentProductionAT) {
        var path = pathFromDateEffect(documentProductionAT);

        return uploadToAlfresco(gedDocument, path, documentProductionAT);
    }

    private String uploadToAlfresco(GedDocument gedDocument, String path, ProductionTypeDoc documentProductionMeta) {
        log.info(
                "Start: creating arborecense in alfresco repository with path '{}'",
                gedProductionProperties.getOutbox() + path);
        var folder = claimDocumentRepository.createArboFoldersByPath(gedProductionProperties.getOutbox(), path);
        log.info(
                "End: creating arborecense in alfresco repository with path '{}'",
                gedProductionProperties.getOutbox() + path);
        if (folder == null) {
            log.error(
                    "can not create/open dossier (floder) is null");
            throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
        }
        Map<String, Object> properties = new HashMap<>();
        properties.put(AXADocPropertyIds.IDENTIFIANT_SCANER,
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
        properties.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
        if (documentProductionMeta != null) {
            properties.put(AXADocPropertyIds.NATURE_COURRIER, documentProductionMeta.getTypedocument());
        }
        var uploadOutput = uploadFile(properties, gedDocument, folder);
        return uploadOutput.get("idAlfresco");
    }

    private Folder createOrUpdateDirectory(ProductionTypeDoc documentProductionMeta) {
        var folder = claimDocumentRepository.createArboFoldersByPath(gedProductionProperties.getOutbox(),
                constructFolderPath(documentProductionMeta.getEffectDate(), documentProductionMeta.getPoliceNumber()));
        if (folder == null) {
            throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
        }
        folder.updateProperties(DocumentMapper.directoryProductionPropertiesConstructor(documentProductionMeta));
        return folder;
    }

    private String pathFromDateEffect(ProductionDemandDoc productionDemandDoc) {
        LocalDate datetime = productionDemandDoc.getEffectDate();
        return String.join("/", getDatePath(datetime), productionDemandDoc.getDemandId());

    }

    private String constructFolderPath(LocalDate effectDate, String policyNumber) {
        return String.join("/", getDatePath(effectDate), policyNumber);
    }

    private Folder createOrUpdateDirectory(ProductionDemandDoc productionDemandDoc) {
        var folder = claimDocumentRepository.createArboFoldersByPath(gedProductionProperties.getOutbox(),
                constructFolderPath(productionDemandDoc.getEffectDate(), productionDemandDoc.getDemandId()));
        if (folder == null) {
            throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
        }
        return folder;
    }

    private String getDatePath(LocalDate date) {
        var month = String.valueOf(date.getMonthValue());
        month = month.length() == 1 ? "0".concat(month) : month;

        var day = String.valueOf(date.getDayOfMonth());
        day = day.length() == 1 ? "0".concat(day) : day;
        return String.join("/", String.valueOf(date.getYear()), month, day);
    }

    private String pathFromDateEffect(ProductionTypeDoc documentProductionAT) {
        LocalDate datetime = documentProductionAT.getEffectDate();
        return String.join("/", getDatePath(datetime), documentProductionAT.getPoliceNumber());

    }

}
