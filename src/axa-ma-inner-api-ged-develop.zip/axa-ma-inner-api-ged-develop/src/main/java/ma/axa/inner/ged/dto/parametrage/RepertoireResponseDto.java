package ma.axa.inner.ged.dto.parametrage;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RepertoireResponseDto {
	
	private int codeRepertoire;
	private String libelleRepertoire;

}
