package ma.axa.inner.ged.mapper.production.rc;

import java.util.List;
import java.util.stream.Collectors;

import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import ma.axa.inner.ged.domain.production.rc.RcProductionDocumentEs;
import ma.axa.inner.ged.dto.production.rc.RcProductionDocumentRequest;
import ma.axa.inner.ged.dto.production.rc.RcProductionDocumentResponse;
import ma.axa.inner.ged.dto.production.rc.RcProductionDocumentUpdateRequest;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface RcProductionMapper {

    RcProductionDocumentEs fromDto(RcProductionDocumentRequest documentRes);
    List<RcProductionDocumentEs> fromDtos(List<RcProductionDocumentRequest> documentRes);

    RcProductionDocumentResponse toDto(RcProductionDocumentEs documentEs);
    
    List<RcProductionDocumentResponse> toDtos(List<RcProductionDocumentEs> documentEs);

    // -> update
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
    void updateFromDto(RcProductionDocumentUpdateRequest documentReq, @MappingTarget RcProductionDocumentEs document);

    // Others
    static Page<RcProductionDocumentEs> mapToPage(SearchResponse<RcProductionDocumentEs> searchResponse, int from,
            int size) {
        if (searchResponse == null || searchResponse.hits().hits().isEmpty() || searchResponse.hits().total() == null) {
            return Page.empty();
        } else {
            long totalElements = searchResponse.hits().total().value();
            List<RcProductionDocumentEs> results = searchResponse.hits().hits().stream()
                    .map(Hit::source)
                    .collect(Collectors.toList());
            PageRequest pageRequest = PageRequest.of(from, size);
            return new PageImpl<>(results, pageRequest, totalElements);
        }
    }
}
