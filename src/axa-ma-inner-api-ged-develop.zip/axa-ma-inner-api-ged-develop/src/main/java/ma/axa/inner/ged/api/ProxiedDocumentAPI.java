package ma.axa.inner.ged.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.proxied.SignedPayloadDto;
import ma.axa.inner.ged.service.ProxiedDocumentService;
import ma.axa.inner.ged.util.constants.PathConstants;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;


@Slf4j
@RestController
@Validated
@RequestMapping(PathConstants.GLOBAL_DOCUMENTS)
@RequiredArgsConstructor
public class ProxiedDocumentAPI {

    private final ProxiedDocumentService documentService;


    @Operation(summary = "Generate a signed payload")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document ID", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
    @GetMapping(path = "/{document_id}/signed-payload")
    public SignedPayloadDto generateSignedPayload(
            @PathVariable(name = "document_id") String documentId) {
        log.debug("Generating new signed payload for document {}", documentId);
        return documentService.generateSignedPayload(documentId);
    }


    @Operation(summary = "Get document content by signed payload")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document ID", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
    @GetMapping(path = "/content", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<Resource> downloadDocument(
            @RequestParam(name = "document_id") String documentId,
            @RequestParam(name = "expires_at") long expiresAt,
            @RequestParam(name = "signature") String signature) {
        log.debug("Downloading document {} with expiration date {} and signature {}", documentId, expiresAt, signature);
        return documentService.downloadDocument(documentId, expiresAt, signature);
    }
}