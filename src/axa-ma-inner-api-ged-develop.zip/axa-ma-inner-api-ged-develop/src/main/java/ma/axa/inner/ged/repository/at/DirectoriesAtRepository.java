package ma.axa.inner.ged.repository.at;

import ma.axa.inner.ged.domain.at.DirectoriesATGed;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DirectoriesAtRepository extends JpaRepository<DirectoriesATGed, Integer> {
}
