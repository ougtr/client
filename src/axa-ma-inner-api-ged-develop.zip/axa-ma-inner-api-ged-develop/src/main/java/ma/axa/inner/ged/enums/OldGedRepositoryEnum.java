package ma.axa.inner.ged.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import org.apache.commons.lang3.StringUtils;

@Getter
@AllArgsConstructor
@FieldDefaults(makeFinal = true, level = AccessLevel.PRIVATE)
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum OldGedRepositoryEnum {

    DECLARATION("1", "Déclaration", "130"),
    MEDICAL_MANAGEMENT_COMPENSATION("2", "Gestion médicale/compensation", "14"),
    TRANSACTION("3", "Transaction", "15"),
    LITIGATION_BNEJ("4", "Contentieux/BNEJ", "16"),
    GSR("5", "GSR", "17"),
    RECOURSE("6", "Recours", "27"),
    OTHERS("7", "Autres", null);

    private String code;
    private String label;
    private String correspondingNewGedId;

    public static OldGedRepositoryEnum getByCode(String code) {
        if (StringUtils.isBlank(code))
            return null;
        for (OldGedRepositoryEnum abCode : values()) {
            if (abCode.code.equals(code)) return abCode;
        }
        return null;
    }
}
