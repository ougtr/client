package ma.axa.inner.ged.domain.production;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class ProductionDemandDoc {

    @NotNull(message = "L'id de la demande est obligatoire")
    private String demandId;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@NotNull(message = "la date d'effet est obligatoire")
	private LocalDate effectDate;
	
}
