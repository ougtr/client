package ma.axa.inner.ged.util;

import co.elastic.clients.elasticsearch._types.FieldValue;
import co.elastic.clients.elasticsearch._types.query_dsl.*;
import co.elastic.clients.json.JsonData;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

@Slf4j
@UtilityClass
public class ElasticSearchUtils {

	public static void addTermQuery(String field, Object value, BoolQuery.Builder boolQuery) {
		if (value != null) {
			boolQuery.must(termQuery(field, value));
		}
	}

	public static void addDateRangeQuery(String field, LocalDate start, LocalDate end, BoolQuery.Builder boolQuery) {
		if (start != null && end != null && start.isAfter(end)) {
			throw new IllegalArgumentException(
					"Faild to build search request, Invalide date start: " + start + ", end:" + end);
		}
		var range = rangeQuery(field, start, end);
		if (range != null) {
			boolQuery.must(range);
		}
	}

	public static void addDateTimeRangeQuery(String field, LocalDateTime start, LocalDateTime end,
			BoolQuery.Builder boolQuery) {
		if (start != null && end != null && start.isAfter(end)) {
			throw new IllegalArgumentException(
					"Faild to build search request, Invalide date start: " + start + ", end:" + end);
		}
		var range = rangeQuery(field, start, end);
		if (range != null) {
			boolQuery.must(range);
		}
	}

	// ===== common ===== //

	public static Query matchAllQuery() {
		return MatchAllQuery.of(b1 -> b1)._toQuery();
	}

	public static Query matchQuery(String field, String textToMatch) {
		return MatchQuery.of(m -> m
				.field(field)
				.query(q -> q.stringValue(textToMatch))
				.autoGenerateSynonymsPhraseQuery(true))._toQuery();
	}

	public static Query termQuery(String field, Object value) {
		return termQuery(field, value, true);
	}

	public static Query termQuery(String field, Object value, boolean caseInsensitive) {
		return TermQuery.of(b1 -> b1
				.field(field)
				.value(mapFieldValue(value))
				.caseInsensitive(caseInsensitive))._toQuery();
	}

	public static <T> Query termsQuery(String field, Collection<T> values) {
		List<FieldValue> fieldValues = new ArrayList<>(values.size());
		for (T value : values) {
			fieldValues.add(mapFieldValue(value));
		}
		return TermsQuery.of(b1 -> b1
				.field(field)
				.terms(TermsQueryField.of(b2 -> b2.value(fieldValues))))._toQuery();
	}

	public static Query rangeQuery(String field, Object from, Object to) {
		if (from == null && to == null)
			return null;
		var b = new RangeQuery.Builder();
		b.field(field);
		if (from != null)
			b.gte(JsonData.of(from));
		if (to != null)
			b.lte(JsonData.of(to));
		return RangeQuery.of(b1 -> b)._toQuery();
	}

	private static FieldValue mapFieldValue(Object value) {
		var builder = new FieldValue.Builder();
		if (value instanceof String) {
			builder.stringValue((String) value);
		} else if (value instanceof Long || value instanceof Integer || value instanceof BigInteger) {
			builder.longValue(((Number) value).longValue());
		} else if (value instanceof Double || value instanceof BigDecimal || value instanceof Float) {
			builder.doubleValue(((Number) value).doubleValue());
		} else if (value instanceof Boolean) {
			builder.booleanValue((Boolean) value);
		} else if (value == null) {
			builder.nullValue();
		} else {
			log.warn("[es-util] unsupported type, type: [{}], value: [{}]", value.getClass(), value);
			builder.nullValue();
		}
		return builder.build();
	}


	public static Query getQueryForMultiSearch(Map<String, String> map) {
		var boolQuery = new BoolQuery.Builder();
		for (String key : map.keySet()) {
			addTermQuery(key, map.get(key), boolQuery);
		}
		return boolQuery.build()._toQuery();
	}
}
