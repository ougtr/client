package ma.axa.inner.ged.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Configuration
@EnableConfigurationProperties
@Data
@ConfigurationProperties("axa.ged.production")
public class GedProductionProperties {
	private String searchdoc;
	private String outbox;
	private String deletedDocument;
	private String agentInbox;
}
