package ma.axa.inner.ged.postels.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.inner.ged.postels.constants.GlobalConstants;

import javax.validation.constraints.Min;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SearchEsReq {
    private String idAlfresco;
    private String numPolice;
    private String numQuotation;
    private String reference;
    private String applicationCode = "POSTE-LS";
    @Min(value = 0, message = GlobalConstants.ERROR_MSG_SEARCH_PAGENUMBER_MIN)
    @Builder.Default
    private Integer pageNumber = 0;
    @Min(value = 1, message = GlobalConstants.ERROR_MSG_SEARCH_PAGESIZE_MIN)
    @Builder.Default
    private Integer pageSize = 10;
    private String integrationId;
    private String avenantId;
}
