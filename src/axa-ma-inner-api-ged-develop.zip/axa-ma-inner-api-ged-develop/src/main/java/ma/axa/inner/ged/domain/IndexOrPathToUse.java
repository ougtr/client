package ma.axa.inner.ged.domain;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public enum IndexOrPathToUse {

    DEFAULT("default"),
    TEMPORARY("temporary");

    private String value;

    public String value() {
        return this.value;
    }
}
