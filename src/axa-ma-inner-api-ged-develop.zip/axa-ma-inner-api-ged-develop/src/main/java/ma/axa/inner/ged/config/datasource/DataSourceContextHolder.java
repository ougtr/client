package ma.axa.inner.ged.config.datasource;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.NoArgsConstructor;
import ma.axa.inner.ged.dto.cima.auto.CountryCode;


@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
@NoArgsConstructor
@Component
public class DataSourceContextHolder {
    private static final ThreadLocal<CountryCode> threadLocal = new ThreadLocal<>();


    public void setCountryContext(CountryCode countryCode) {
        threadLocal.set(countryCode);
    }

    public CountryCode getCountryContext() {
        threadLocal.get();
        return threadLocal.get();
    }

    public static void clearCountryContext() {
        threadLocal.remove();
    }
}