package ma.axa.inner.ged.service.production.health.dim;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch.core.search.Hit;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.alfresco.DocumentAlfresco;
import ma.axa.inner.ged.domain.production.health.dim.DocumentHealthDIMEs;
import ma.axa.inner.ged.dto.CommonResponse;
import ma.axa.inner.ged.dto.production.health.dim.DocHealthDIMReq;
import ma.axa.inner.ged.dto.production.health.dim.DocHealthDIMResp;
import ma.axa.inner.ged.dto.production.health.dim.DocHealthDIMSearchParams;
import ma.axa.inner.ged.dto.production.health.dim.DocHealthDIMUpdateReq;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.exception.RequestValidationException;
import ma.axa.inner.ged.exception.ResourceNotFoundException;
import ma.axa.inner.ged.mapper.production.health.dim.HealthDIMAlfrescoMapper;
import ma.axa.inner.ged.mapper.production.health.dim.HealthDIMMapper;
import ma.axa.inner.ged.repository.production.health.dim.HealthDIMElasticRepository;
import ma.axa.inner.ged.service.AlfrescoGedService;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Slf4j
@Service
@RequiredArgsConstructor
public class HealthDIMDocumentService {

    private final BrancheProperties healthDIMProperties;
    private final HealthDIMMapper dimMapper;

    private final AlfrescoGedService alfrescoService;
    private final HealthDIMElasticRepository elasticHealthDIMRepository;


    /**
     * Searching documents in elasticSearch
     *
     * @param searchParams
     * @return {@link Page} of founded documents
     */
    public Page<DocHealthDIMResp> search(@NotNull DocHealthDIMSearchParams searchParams) {
        log.info("[health-dim-api] start multi search");
        var response = elasticHealthDIMRepository.findByCriteria(searchParams,false);
        var page = HealthDIMMapper.mapToPage(response, searchParams.getPageNumber(), searchParams.getPageSize());
        return page.map(dimMapper::toDto);
    }

    /**
     * Upload new document to Alfresco and index meta-data in ES
     *
     * @param metaData Meta data of document
     * @param files    Documents Content
     * @return
     * @throws Exception
     */
    public List<DocHealthDIMResp> uploadDocWithMetaData(DocHealthDIMReq metaData, List<MultipartFile> files) {
        log.info("[health-dim-api] upload document ");
        try {
            List<DocumentHealthDIMEs> esDocuments = new ArrayList<>();
            for (MultipartFile file : files) {
                var documentEs = dimMapper.fromDto(metaData);
                documentEs.setFilesize(file.getSize());
                if (FileUtil.isValidFile(file)) {
                    String filename = file.getOriginalFilename();
                    if (filename != null) {
                        FileUtil.assertFileNameValid(filename);
                    }
                    var folderProperties = HealthDIMAlfrescoMapper.toFolderProperties(metaData);
                    var targetFolder = alfrescoService.prepareDocumentFolder(healthDIMProperties.getAlfrescoRootFolder(),healthDIMProperties.getAlfrescoSitePath(),folderProperties,!StringUtils.isEmpty(metaData.getPolicyNumber())? metaData.getPolicyNumber() : metaData.getDemandReference());

                    // Upload Document to alfresco
                    DocumentAlfresco createdDocument = null;
                    Map<String, Object> properties = HealthDIMAlfrescoMapper.toDocumentProperties(metaData);
                    createdDocument = alfrescoService.createDocument(targetFolder, filename, file, properties, true);
                    if (createdDocument == null) {
                        return null;
                    }
                    // Indexing document in ES
                    alfrescoService.indexDocument(createdDocument,documentEs,GlobalConstants.HEALTH_DIM_GED_BRANCHE_LABEL);
                    elasticHealthDIMRepository.createNewDocument(documentEs.getId(), documentEs);
                    esDocuments.add(documentEs);
                }
            }
            return dimMapper.toDtoList(esDocuments);
        } catch (ElasticsearchException | IOException e) {
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
        }
    }

    public CommonResponse validationUpdateRequest(DocumentHealthDIMEs documentEs) {
        var response = CommonResponse.builder();
        var error = new HashMap<String, String>();
        if (!validStatus(documentEs.getStatus(), documentEs.getPolicyNumber())) {
            error.put("status", "Must fill policy Number number to update status = CLOTURE");
        }

        response.msgErrors(error);
        response.success(error.isEmpty());
        return response.build();
    }

    public static boolean validStatus(String status, String policyNumber) {
        if (null != status && status.equals("CLOTURE")) {
            return StringUtils.isNotBlank(policyNumber);
        }
        return true;
    }

    /**
     * @throws IOException
     * @throws ElasticsearchException
     * @throws ResourceNotFoundException
     **/
    public DocHealthDIMResp updateDocument(String documentId, DocHealthDIMUpdateReq metaData) {
        log.info("[health-dim-api] update document ");
        if (metaData == null)
            throw new NullPointerException("Document meta-data to be updated must no be null");
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("documentId must not be null");

        var isExistInElastic = elasticHealthDIMRepository.exists(documentId);
        if (!isExistInElastic)
            throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
                    "Document with id '{0}' not found", new String[]{documentId});
        var documentEs = elasticHealthDIMRepository.findById(documentId)
                .orElseThrow(() -> new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
                        "Document Not Found"));
        dimMapper.updateFromDto(metaData, documentEs);
        // validation
        var isValid = validationUpdateRequest(documentEs);
        if (isValid != null && !isValid.isSuccess()) {
            throw new RequestValidationException("Error validation", isValid.getMsgErrors());
        }
        try {
            // Update Alfresco meta-data, is optional
            updateDocumentAlfrescoProps(documentId, metaData);
            log.debug("[health-dim-service] start update elastic document properties...");
            elasticHealthDIMRepository.updateDocument(documentId, documentEs);
            var updated = elasticHealthDIMRepository.findById(documentId).orElse(null);
            return dimMapper.toDto(updated);
        } catch (Exception e) {
            var err = " when update Document, err: " + e.getMessage();
            log.error(err);
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, err);
        }
    }

    public void updateDocumentAlfrescoProps(String documentId, DocHealthDIMUpdateReq metaData) {
        try {
            log.info("[health-dim-service] start update alfresco document properties...");
            Map<String, Object> properties = HealthDIMAlfrescoMapper.toDocumentProperties(metaData);
            alfrescoService.updateDocumentProperties(documentId, properties);
        } catch (Exception e) {
            log.warn("[health-dim-service] Error during update alfresco meta-data for id: {}, err: {} ", documentId,
                    e.getMessage());
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
        }
    }

    public String deleteDocument(String id) {
        log.info("[health-dim-api] delete document " + id);
        // Delete doc from alfresco and ES
        try {
            alfrescoService.deleteDocument(id);
            elasticHealthDIMRepository.deleteDocument(id);
        } catch (Exception e) {
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR,
                    e.getMessage());
        }

        return id;
    }


    public void tagAllDocumentsByPolicyNumber(String policyNumber,String idQuotation,String userName) {
        log.info("[health-dim-api] tag documents by policyNumber " + policyNumber);
        DocHealthDIMSearchParams params = DocHealthDIMSearchParams.builder().idQuotation(idQuotation).build();
        var response = elasticHealthDIMRepository.findByCriteria(params,true);
        List<DocumentHealthDIMEs> results = response.hits().hits().stream()
                .map(Hit::source)
                .collect(Collectors.toList());
        for (DocumentHealthDIMEs doc :results) {
            indexDocByPolicyNumber(doc,policyNumber,userName);
        }
    }

    private void indexDocByPolicyNumber(DocumentHealthDIMEs doc, String policyNumber,String userName) {
        var documentEs = elasticHealthDIMRepository.findById(doc.getId())
                .orElseThrow(() -> new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
                        "Document Not Found"));
        documentEs.setPolicyNumber(policyNumber);
        documentEs.setLastUpdatedBy(userName);
        try {
            elasticHealthDIMRepository.updateDocument(doc.getId(), documentEs);
            //TODO remove this
            var updated = elasticHealthDIMRepository.findById(doc.getId()).orElse(null);
            dimMapper.toDto(updated);
        } catch (Exception e) {
            var err = " when update Document, err: " + e.getMessage();
            log.error(err);
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, err);
        }
    }

}