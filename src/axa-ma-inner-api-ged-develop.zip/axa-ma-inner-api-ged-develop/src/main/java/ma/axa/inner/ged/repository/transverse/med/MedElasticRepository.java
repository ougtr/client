package ma.axa.inner.ged.repository.transverse.med;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties;
import ma.axa.inner.ged.domain.transverse.med.MedDocumentEs;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.repository.ElasticSearchNewRepository;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.io.IOException;
@Repository
@RequiredArgsConstructor
@Slf4j
public class MedElasticRepository {

    private final AxaGedProperties.BrancheProperties medProperties;
    private final ElasticSearchNewRepository elasticRepository;

    public String createNewDocument(final String documentId, final MedDocumentEs metaData
                                    ) throws ElasticsearchException, IOException {
        validateDocumentId(documentId);
        validateMetaData(metaData);
        try {
            if (exists(documentId)) {
                throw new ResourceAlreadyExist(GlobalConstants.URI_RECORDE_ALREADY_EXIST,
                        "Document with id {0} already exist", new String[] { documentId });
            }
            String esIndex = String.join("-", medProperties.getEsDocIndex());
            var created = elasticRepository.createNewDocument(esIndex, documentId, metaData);
            if (created == null) {
                log.error("[es-repo] Error creating new document for id: {}", documentId);
                throw new GlobalException("Error creating new document for id :  {}", documentId);
            }
            log.info("[es-repo] Successfully created new med document with id: {}", documentId);
            return created;
        } catch (Exception e) {
            log.error("[es-repo] Error creating new document for id: {}, err: {} ", documentId, e.getMessage());
            throw e;
        }
    }

    private void validateDocumentId(String documentId) {
        if (StringUtils.isBlank(documentId)) {
            throw new IllegalArgumentException("ID Document must not be blank");
        }
    }

    private void validateMetaData(MedDocumentEs metaData) {
        if (metaData == null) {
            throw new IllegalArgumentException("Document must not be null");
        }
    }

    private boolean exists(String documentId) {
        return elasticRepository.existsDocument(medProperties.getEsDocIndex(), documentId);
    }
}
