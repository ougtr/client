package ma.axa.inner.ged.service.at;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.at.DirectoriesDto;
import ma.axa.inner.ged.mapper.at.DirectoryATMapper;
import ma.axa.inner.ged.repository.at.DirectoriesAtRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

import static ma.axa.inner.ged.util.constants.GlobalConstants.DIRECTORIES_AT_SORT;

@Service
@RequiredArgsConstructor
@Slf4j
public class DirectoriesATService {

    private final DirectoriesAtRepository directoriesRepository;
    private final DirectoryATMapper autoMapper;

    public List<DirectoriesDto> getAllRepositories() {
        log.info("Start Service : get all repositories.");
        final var repositoriesData = autoMapper.directoriesAtToDto(directoriesRepository.findAll(Sort.by(Sort.Direction.ASC, DIRECTORIES_AT_SORT)));
        log.info("End Service : get all repositories.");
        return repositoriesData;
    }
}
