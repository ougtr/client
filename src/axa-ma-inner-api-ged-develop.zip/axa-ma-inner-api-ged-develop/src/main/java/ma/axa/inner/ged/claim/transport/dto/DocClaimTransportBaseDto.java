package ma.axa.inner.ged.claim.transport.dto;

import javax.validation.constraints.NotBlank;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.claim.common.dto.DocClaimBaseDto;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class DocClaimTransportBaseDto extends DocClaimBaseDto {
	@NotBlank(message = GlobalConstants.ERROR_MSG_RD_REFERENCE_NOT_BLANK)
	private String reference;
	
	private String numCertificat;
	private String numOrder;
}
