package ma.axa.inner.ged.util;

import lombok.experimental.UtilityClass;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@UtilityClass
public class CommonUtils {

    public static String getPath(String path) {
        if (path == null) {
            return null;
        }
        var sb = new StringBuilder(path);
        if (path.endsWith(GlobalConstants.FOLDER_SEPARATOR)) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return sb.toString();
    }
}
