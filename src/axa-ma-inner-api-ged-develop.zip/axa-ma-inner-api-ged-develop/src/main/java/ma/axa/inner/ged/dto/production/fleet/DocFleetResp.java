package ma.axa.inner.ged.dto.production.fleet;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DocFleetResp {
    @JsonProperty(index = 1)
    private String id;
    private String policyNumber;
    private String quotationNumber;
    private String simulationNumber;
    private String idAlfresco;
    private String filename;
    private String uploadedBy;
    private String brancheLabel;
    private String typedocumentLabel;
    private String createdBy;
    private String createdAt;
    private String filesize;
    private String filetype;

}