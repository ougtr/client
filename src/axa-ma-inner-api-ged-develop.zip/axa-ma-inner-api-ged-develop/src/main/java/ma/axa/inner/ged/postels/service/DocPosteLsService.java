package ma.axa.inner.ged.postels.service;


import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.alfresco.DocumentAlfresco;
import ma.axa.inner.ged.exception.*;
import ma.axa.inner.ged.postels.constants.GlobalConstants;
import ma.axa.inner.ged.postels.dto.*;
import ma.axa.inner.ged.postels.mapper.DocPosteLsMapper;
import ma.axa.inner.ged.postels.mapper.IDocPosteLsMapper;
import ma.axa.inner.ged.postels.repository.DocPosteLsElasticSearchRepository;
import ma.axa.inner.ged.service.AlfrescoGedService;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.ResponseUtils;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotBlank;
import java.io.IOException;
import java.net.URLConnection;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class DocPosteLsService{

	    private final BrancheProperties posteLsProperties;
	    private final IDocPosteLsMapper docPosteLsMapper;
	    private final AlfrescoGedService alfrescoService;
	    private final DocPosteLsElasticSearchRepository docPosteLsElasticSearchRepository;

	/**
	 * Get document meta-data in elasticSearch by documentId
	 */
	public DocPosteLsResp getMetadataById(@NotBlank String documentId) {
		var isExistInElastic = docPosteLsElasticSearchRepository.exists(documentId);
		if (!isExistInElastic)
			throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
					GlobalConstants.ERROR_MSG_POSTELS_IDDOCUMENT_NOT_FOUND, new String[]{documentId});
		var response = docPosteLsElasticSearchRepository.findById(documentId).orElse(null);
		return docPosteLsMapper.toDto(response);
	}

	/**
	 * Searching documents in elasticSearch
	 *
	 * @param searchParams
	 * @return {@link Page} of founded documents
	 */
	public List<DocPosteLsResp> getMetadataByCriteria(SearchEsReq searchParams) {
		SearchResponse<DocPosteLsResp> response = docPosteLsElasticSearchRepository.findByCriteria(searchParams);
		// Transformer les résultats en une liste
		return response.hits().hits().stream()
				.map(hit -> hit.source())
				.collect(Collectors.toList());
	}

	/**
	 * Download file & Prepare response headers, used in rest controller
	 *
	 * @param idAlfresco id file in Alfresco
	 * @return byte content as {@link ResponseEntity}
	 */
	public ResponseEntity<Resource> downloadFile(final String idAlfresco) {
		var document = getFileFromAlfresco(idAlfresco);
		var is = document.getContentStream().getStream();
		try {
			var content = IOUtils.toByteArray(is);
			var bar = new ByteArrayResource(content);
			var mimeType = document.getContentStreamMimeType();
			if (StringUtils.isBlank(mimeType) && StringUtils.isNotBlank(document.getName()))
				mimeType = URLConnection.guessContentTypeFromName(document.getName());
			var fileName = StringUtils.isNotBlank(document.getName()) ? document.getName() : "unknown_filename";
			var headers = ResponseUtils.getDownloadHeaders(fileName, document.getContentStreamLength(), mimeType);
			return ResponseEntity.ok().headers(headers).body(bar);
		} catch (IOException e) {
			log.error("Error during reading inputStream, err: {} ", e.getMessage());
			return null;
		}
	}

	/**
	 * Get file content from Alfresco
	 *
	 * @param idAlfresco Id of document
	 */
	public Document getFileFromAlfresco(final String idAlfresco) {
		if (!alfrescoService.exists(idAlfresco))
			throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
					"Document with id {0} not found", new String[]{idAlfresco});
		try {
			return alfrescoService.getDocument(idAlfresco);
		} catch (Exception e) {
			var err = "Error during retreive document from alfresco, err: " + e.getMessage();
			log.error(err);
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, err);
		}
	}

	/**
	 * Upload new document to Alfresco and index meta-data in ES
	 *
	 * @param metaData Meta data of document
	 * @param file     Document Content
	 * @return
	 * @throws Exception
	 */
	public DocPosteLsResp uploadDocWithMetaData(final DocPosteLsReq metaData, final MultipartFile file) {
		// Extraire l'extension du fichier
		String originalFilename = file.getOriginalFilename();
		String fileExtension = "";

		if (originalFilename != null && originalFilename.contains(".")) {
			fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
		}

		// Générer un reference unique basé sur la date/heure du serveur
		String referenceUnique = generateUniqueFileNameFromServerDate();
		metaData.setReference(referenceUnique);
		// Générer un uniqueFileName basé sur la date/heure du serveur
		String uniqueFileName = referenceUnique + fileExtension;

		// Vérifier si la référence existe déjà
		var reference = metaData.getReference();
		var documentExist = docPosteLsElasticSearchRepository.findOneDocumentByReference(reference);
		if (documentExist != null) {
			throw new ResourceAlreadyExist(
					GlobalConstants.URI_RECORDE_ALREADY_EXIST,
					GlobalConstants.ERROR_MSG_POSTELS_REFERENCE_ALREADY_EXIST,
					new String[]{reference}
			);
		}

		// Mapping
		var documentEs = docPosteLsMapper.fromDto(metaData);

		try {
			// Préparer les propriétés du dossier
			var folderProperties = DocPosteLsMapper.toFolderProperties(metaData);
			var targetFolder = prepareDocumentFolder(folderProperties);

			// Upload du document vers Alfresco
			DocumentAlfresco createdDocument;
			Map<String, Object> properties = DocPosteLsMapper.toDocumentProperties(metaData);
			createdDocument = alfrescoService.createDocument(targetFolder, uniqueFileName, file, properties, true);

			if (createdDocument == null) {
				return null;
			}

			// Indexer le document dans Elasticsearch
			documentEs.setIdAlfresco(createdDocument.getId());
			documentEs.setFilename(createdDocument.getFilename());
			documentEs.setPath(createdDocument.getPath());
			documentEs.setBrancheLabel(GlobalConstants.POSTE_LS_GED_BRANCHE_LABEL);

			docPosteLsElasticSearchRepository.createNewDocument(documentEs.getIdAlfresco(), documentEs);

			return docPosteLsMapper.toDto(documentEs);

		} catch (ElasticsearchException | IOException e) {
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
		}
	}



	/**
	 * Check & create target folders before upload document
	 *
	 * @param properties
	 * @return
	 */
	public Folder prepareDocumentFolder(Map<String, Object> properties) {
		var branchePath = posteLsProperties.getAlfrescoRootFolder();
		var sitePath = posteLsProperties.getAlfrescoSitePath();
		var brancheFolderPath = FileUtil.appendDateAsSubFolders(branchePath);
		var createdFolder = alfrescoService.createTreeFolder(brancheFolderPath, sitePath, properties);
		if (createdFolder == null) {
			throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
		}
		return createdFolder;
	}

	/**
	 *
	 * @throws IOException
	 * @throws ElasticsearchException
	 * @throws ResourceNotFoundException
	 **/

	public DocPosteLsResp updateDocument(String documentId, DocPosteLsUpdateReq metaData) {
		if (metaData == null)
			throw new NullPointerException("Document meta-data to be updated must no be null");
		if (StringUtils.isBlank(documentId))
			throw new IllegalArgumentException("documentId must not be null");

		var isExistInElastic = docPosteLsElasticSearchRepository.exists(documentId);
		if (!isExistInElastic)
			throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
					"Document with id '{0}' not found", new String[]{documentId});
		var documentEs = docPosteLsElasticSearchRepository.findById(documentId)
				.orElseThrow(() -> new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
						"Document Not Found"));
		docPosteLsMapper.updateFromDto(metaData, documentEs);
		try {
			// Update Alfresco meta-data, is optional
			updateDocumentAlfrescoProps(documentId, metaData);
			log.debug("[ls-service] start update elastic document properties...");
			docPosteLsElasticSearchRepository.updateDocument(documentId, documentEs);
			var updated = docPosteLsElasticSearchRepository.findById(documentId).orElse(null);
			return docPosteLsMapper.toDto(updated);
		} catch (Exception e) {
			var err = " when update Document, err: " + e.getMessage();
			log.error(err);
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, err);
		}
	}

	public void updateDocumentAlfrescoProps(String documentId, DocPosteLsUpdateReq metaData) {
		try {
			log.debug("[ls-service] start update alfresco document properties...");
			Map<String, Object> properties = DocPosteLsMapper.toDocumentProperties(metaData);
			alfrescoService.updateDocumentProperties(documentId, properties);
		} catch (Exception e) {
			log.warn("[ls-service] Error during update alfresco meta-data for id: {}, err: {} ", documentId,
					e.getMessage());
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR,e.getMessage());
		}
	}

	public String deleteDocument(String id) {

		// Delete doc from alfresco and ES
		try {
			alfrescoService.deleteDocument(id);
			docPosteLsElasticSearchRepository.deleteDocument(id);
		} catch (Exception e) {
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR,
					e.getMessage());
		}

		return id;
	}

	private String generateUniqueFileNameFromServerDate() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyMMddHHmmss");
		// Récupère la date et l'heure du serveur dans le fuseau horaire par défaut
		ZonedDateTime serverDateTime = ZonedDateTime.now(ZoneId.systemDefault());
		return serverDateTime.format(formatter);
	}


	}

