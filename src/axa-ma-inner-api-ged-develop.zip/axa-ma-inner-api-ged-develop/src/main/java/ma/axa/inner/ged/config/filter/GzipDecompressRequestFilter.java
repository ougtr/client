package ma.axa.inner.ged.config.filter;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.cloud.openfeign.encoding.HttpEncoding;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.filter.wrapper.GzipRequestWrapper;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Slf4j
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class GzipDecompressRequestFilter extends AxaFilter {

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		log.debug("[gzip-request-filter] check if request contains compressed files...");
		var httpServletRequest = (HttpServletRequest) request;
		var httpServletResponse = (HttpServletResponse) response;
		var requestURI = httpServletRequest.getRequestURI();
		var gedContentEncoding = httpServletRequest.getHeader(GlobalConstants.HEADER_GED_CONTENT_ENCODING);
		var mustDecompress = StringUtils.isNotBlank(gedContentEncoding)
				&& gedContentEncoding.toLowerCase().indexOf(HttpEncoding.GZIP_ENCODING) != -1;
		if (mustDecompress) {
			var names = Arrays.asList(gedContentEncoding);
			log.debug("[gzip-request-filter] Decompressing request to {} with compressed parts with names {}",
					requestURI, names);
			var gzipRequest = new GzipRequestWrapper(httpServletRequest);
			chain.doFilter(gzipRequest, httpServletResponse);
		} else {
			chain.doFilter(httpServletRequest, httpServletResponse);
		}
	}
}