package ma.axa.inner.ged.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@Data
@ConfigurationProperties("axa.ged.openinsur")
public class OpenInsurClaimProperties {
    private String outbox;
}
