package ma.axa.inner.ged.dto.production.health.common;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DocHealthCommonReq extends DocHealthReq {
	@Builder.Default
	private String brancheLabel="Health Production Doc";
	private String integrationId;

}