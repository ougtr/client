package ma.axa.inner.ged.dto.production.health.amc;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
public class DocHealthAMCUpdateReq {
	private String policyNumber;
	private String typeDocumentCode;
	private String reference;
	private boolean isOriginal;
	private String status ;
}