package ma.axa.inner.ged.util.jpa_query_filter.enums;

public enum JpaQueryOperationEnum {
    IN,
    LIKE,
    EQUAL,
    NOT_EQUAL
}
