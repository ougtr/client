package ma.axa.inner.ged.config.datasource;

import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.stereotype.Component;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import ma.axa.inner.ged.config.datasource.config.DataSourceConfig;
import ma.axa.inner.ged.config.datasource.config.DataSourceProperties;
import ma.axa.inner.ged.dto.cima.auto.CountryCode;


@Component
public class DataSourceRouting extends AbstractRoutingDataSource {

    private final DataSourceProperties dataSourceProperties;

    private final DataSourceContextHolder dataSourceContextHolder;


    public DataSourceRouting(
            DataSourceProperties dataSourceProperties,
            DataSourceContextHolder dataSourceContextHolder
    ) {
        this.dataSourceProperties = dataSourceProperties;
        this.dataSourceContextHolder = dataSourceContextHolder;
        Map<Object, Object> dataSourceMap = new HashMap<>();
        dataSourceMap.put(CountryCode.MA, dataSourceMADataSource());
        dataSourceMap.put(CountryCode.SN, dataSourceSNDataSource());
        dataSourceMap.put(CountryCode.GA, dataSourceGADataSource());
        dataSourceMap.put(CountryCode.CI, dataSourceCIVDataSource());
        dataSourceMap.put(CountryCode.CA, dataSourceCADataSource());
        this.setTargetDataSources(dataSourceMap);
        this.setDefaultTargetDataSource(dataSourceCIVDataSource());
    }

    @Override
    protected Object determineCurrentLookupKey() {
        return dataSourceContextHolder.getCountryContext();
    }
    
    public HikariDataSource dataSourceMADataSource() {
        return new HikariDataSource(buildHikariConfig(dataSourceProperties.maDatasourceConfig()));
    }

    public HikariDataSource dataSourceSNDataSource() {
        return new HikariDataSource(buildHikariConfig(dataSourceProperties.snDatasourceConfig()));
    }

    public HikariDataSource dataSourceGADataSource() {
        return new HikariDataSource(buildHikariConfig(dataSourceProperties.gaDatasourceConfig()));
    }

    public HikariDataSource dataSourceCIVDataSource() {
        return new HikariDataSource(buildHikariConfig(dataSourceProperties.ciDatasourceConfig()));
    }

    public HikariDataSource dataSourceCADataSource() {
        return new HikariDataSource(buildHikariConfig(dataSourceProperties.caDatasourceConfig()));
    }

    private HikariConfig buildHikariConfig(DataSourceConfig dataSourceConfig) {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(dataSourceConfig.getUrl());
        config.setDriverClassName(dataSourceConfig.getDriverClassName());
        config.setUsername(dataSourceConfig.getUsername());
        config.setPassword(dataSourceConfig.getPassword());
        config.setPoolName(dataSourceConfig.getHikari().getPoolName());
        config.setMaximumPoolSize(dataSourceConfig.getHikari().getMaximumPoolSize());
        config.setMinimumIdle(dataSourceConfig.getHikari().getMinimumIdle());
        config.setMaxLifetime(dataSourceConfig.getHikari().getMaxLifetime());
        config.setIdleTimeout(dataSourceConfig.getHikari().getIdleTimeout());
        config.setAutoCommit(dataSourceConfig.getHikari().isAutoCommit());
        return config;
    }
}