package ma.axa.inner.ged.repository.ac;

import ma.axa.inner.ged.domain.GEDRepositoriesAS400;
import ma.axa.inner.ged.domain.ac.GedDirectory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DirectoriesRepository extends JpaRepository<GedDirectory,Integer> {
}
