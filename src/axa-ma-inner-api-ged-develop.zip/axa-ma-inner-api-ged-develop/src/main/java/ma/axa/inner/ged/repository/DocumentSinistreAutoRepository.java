package ma.axa.inner.ged.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ma.axa.inner.ged.domain.DocumentSinistre;

public interface DocumentSinistreAutoRepository extends JpaRepository<DocumentSinistre, Long>{

}
