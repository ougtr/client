package ma.axa.inner.ged.dto.cima.auto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CimaAutoSearchParams {
	@NotNull
	private CountryCode countryCode;
	private String typeDocument; // Typologie Document
	private String createdBy;
	private String numPolice; // N° Police
	private String ug; // unite de gestion
	private String codeIntermediaire; // Code Intermédiaire
	private String numDeclaration; // N° Déclaration

	@Min(value = 0, message = GlobalConstants.ERROR_MSG_SEARCH_PAGENUMBER_MIN)
	@Builder.Default
	private Integer pageNumber = 0;
	@Min(value = 1, message = GlobalConstants.ERROR_MSG_SEARCH_PAGESIZE_MIN)
	@Builder.Default
	private Integer pageSize = 10;

}
