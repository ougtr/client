package ma.axa.inner.ged.config.properties;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GedMobileScanPropreties {

	@Bean
	@ConfigurationProperties(prefix = "axa.ged.mobile-scan-temporary")
	public MsProperties msProperties() {
		return new MsProperties();
	}

	@Data
	@NoArgsConstructor
	public static class MsProperties {
		private String alfrescoSitePath;
		private String alfrescoRootFolder;
	}
}
