package ma.axa.inner.ged.util.converter;

import ma.axa.inner.ged.enums.TagTypeEnum;

import javax.persistence.AttributeConverter;

public class TagTypeEnumConverter implements AttributeConverter<TagTypeEnum , String> {
    @Override
    public String convertToDatabaseColumn(TagTypeEnum tagTypeEnum) {

        return tagTypeEnum == null ? null : tagTypeEnum.getCode();
    }

    @Override
    public TagTypeEnum convertToEntityAttribute(String s) {
        return TagTypeEnum.getByCode(s);
    }
}
