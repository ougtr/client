package ma.axa.inner.ged.claim.health.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GedHealthEntityAS400 {
    private String typedoc;
    private String ideged;
    private String nomdoc;
    private String typges;
    private String usercr;
}
