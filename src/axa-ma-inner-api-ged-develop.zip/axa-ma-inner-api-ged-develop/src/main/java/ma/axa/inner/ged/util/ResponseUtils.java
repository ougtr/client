package ma.axa.inner.ged.util;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;

import java.io.IOException;
import java.net.URLConnection;

@Slf4j
@UtilityClass
public class ResponseUtils {

	/**
	 * Prepare Http header for file downloading
	 */
	public static HttpHeaders getDownloadHeaders(final String fileName, final long length, final String mimeType) {
		var headers = new HttpHeaders();
		try {
			if (StringUtils.isNotBlank(mimeType))
				headers.setContentType(MediaType.parseMediaType(mimeType));
		} catch (Exception e) {
			log.warn("Error parse mediaType, filename: {}, mimeType: {}", fileName, mimeType);
		}
		headers.setContentDisposition(ContentDisposition.builder("inline").filename(fileName).build());
		headers.setCacheControl(CacheControl.noCache().mustRevalidate());
		headers.setPragma("no-cache");
		headers.setExpires(0);
		headers.setContentLength(length);
		return headers;
	}

	public static HttpHeaders getDownloadHeaders(String fileName, long length) {
		return getDownloadHeaders(fileName, length, null);
	}

	public <T> boolean is2xx(ResponseEntity<T> response) {
		return response != null && response.getStatusCode() != null && response.getStatusCode().is2xxSuccessful();
	}

	public <T> boolean is4xx(ResponseEntity<T> response) {
		return response != null && response.getStatusCode() != null && response.getStatusCode().is4xxClientError();
	}

	public ResponseEntity<Resource> constructDocumentResponse(Document doc) throws IOException {
		var stream = doc.getContentStream().getStream();
		var ct = IOUtils.toByteArray(stream);
		var br = new ByteArrayResource(ct);
		var contentStreamMimeType = doc.getContentStreamMimeType();
		if (StringUtils.isBlank(contentStreamMimeType) && StringUtils.isNotBlank(doc.getName()))
			contentStreamMimeType = URLConnection.guessContentTypeFromName(doc.getName());
		var fileTitle = StringUtils.isNotBlank(doc.getName()) ? doc.getName() : "unknown_filename";
		var headers = ResponseUtils.getDownloadHeaders(fileTitle, doc.getContentStreamLength(), contentStreamMimeType);
		return ResponseEntity.ok().headers(headers).body(br);
	}
}
