package ma.axa.inner.ged.dto.production.rc;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RcProductionDocumentRequest {
    
    @Builder.Default
    private String productCode = "20240";
    @Builder.Default
    private String brancheLabel="RC_GENERAL";
    private String demandReference;
    private Integer typedocumentCode;
    private String typedocumentLabel;
    private String quotationNumber;
    private String policyNumber;
    private String corporateName;
    private String status;
    private String repertoire;
    private String repertoireCode;
    @NotNull(message = "Le code intermediaire est obligatoire")
    private String intermediaryCode;
    private String createdBy;
    private LocalDateTime createdAt;
    private String lastUpdatedBy;
    private LocalDateTime lastUpdatedAt;
    private String filesize;
    private String filetype;
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    @NotNull(message = "La date d'effet ne doit pas être null")
    private LocalDate effectDate;
}
