package ma.axa.inner.ged.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;

import lombok.experimental.UtilityClass;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@UtilityClass
public class DateUtils {

    public static final String CASA_ID = "Africa/Casablanca";
    public static final ZoneId CASA_ZONE_ID = ZoneId.of(CASA_ID);
    public static final ZoneId DEFAULT_ZONE_ID = CASA_ZONE_ID;
    public static final DateTimeFormatter dateFormatter = DateTimeFormatter
            .ofPattern(GlobalConstants.DATE_FORMAT_COMMON);
    public static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter
            .ofPattern(GlobalConstants.DATETIME_FORMAT_COMMON);

    public static ZonedDateTime lastXYears(int years) {
        return ZonedDateTime.now(CASA_ZONE_ID).minusYears(years);
    }

	public static int getCurrenNanoDateTime() {
		return getCurrentDateTime().toLocalDateTime().getNano();
	}
	
	public static ZonedDateTime getCurrentDateTime() {
		return getCurrentDateTime(DEFAULT_ZONE_ID);
	}

    public static ZonedDateTime getCurrentDateTime(ZoneId zoneId) {
        return zoneId == null ? ZonedDateTime.now(DEFAULT_ZONE_ID) : ZonedDateTime.now(zoneId);
    }


    public static String convertGedDateToFrontCompatible(String dateToParse) {
        if (StringUtils.isEmpty(dateToParse) || dateToParse.isBlank()) {
            return null;
        }
        String dateToParseTrimmed = dateToParse.trim();
        String parsedDate = null;

        if (dateToParseTrimmed.length() == 8) {
            parsedDate = getParsableByFormat(dateToParseTrimmed, GlobalConstants.DATE_FORMAT_FOR_FRONT,
                    GlobalConstants.DATE_FORMAT_FOR_FRONT, Locale.US);

        } else if (dateToParseTrimmed.length() == 10) {
            parsedDate = getParsableByFormat(dateToParse, GlobalConstants.DATE_FORMAT_COMMON_FRENCH,
                    GlobalConstants.DATE_FORMAT_FOR_FRONT, Locale.US);
        } else if (dateToParseTrimmed.length() == GlobalConstants.DATE_TIME_FORMAT_COMMON_FRENCH.length()) {
            parsedDate = getParsableByFormat(dateToParse, GlobalConstants.DATE_TIME_FORMAT_COMMON_FRENCH,
                    GlobalConstants.DATE_FORMAT_FOR_FRONT, Locale.US);
        } else if (dateToParseTrimmed.length() == 45) {
            parsedDate = getParsableByFormat(dateToParse, GlobalConstants.LONG_DATE_FORMAT,
                    GlobalConstants.DATE_FORMAT_FOR_FRONT, Locale.US);
        }

        return parsedDate;
    }

	public static LocalDate parseDate(String date,String format){
		if(StringUtils.isBlank(date) || StringUtils.isBlank(format))
			return null;
		try{
		return LocalDate.parse(date,DateTimeFormatter.ofPattern(format));
		}catch (DateTimeParseException | IllegalArgumentException ex){
			return null;
		}
	}

	public static Date parseToDate(String date,String format){
		if(StringUtils.isBlank(date) || StringUtils.isBlank(format))
			return null;
		try{
			return (new SimpleDateFormat(format)).parse(date);
		}catch (ParseException ex){
			return null;
		}
	}
	public static String getParsableByFormat(String toParse, String format, String lastFormat, Locale locale) {
		Date date;
		if (locale == null) {
			locale = Locale.US;
		}
		SimpleDateFormat dateFormat = new SimpleDateFormat(format, locale);
		dateFormat.setLenient(false);
		try {
			date = dateFormat.parse(toParse);
		} catch (ParseException e) {
			return null;
		}
		return new SimpleDateFormat(lastFormat, locale).format(date);
	}

	public static Long getMillisFromDate(String date,String dateFormat) {
		try {
			return new java.text.SimpleDateFormat(dateFormat).parse(date).getTime();
		}catch (ParseException | NullPointerException e){
			return 0L;
		}
	}

	public static Date fromBackDateToObjectDate(Integer intDate){
		if(intDate == null)
			return null;
		try{
			return (new SimpleDateFormat(GlobalConstants.DATE_FORMAT_FOR_FRONT)).parse(String.valueOf(intDate));
		}catch (ParseException ex){
			return null;
		}
	}

	public static Date toDate(LocalDate date) {
		if (date == null)
			return null;
		return Date.from(date.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
	}
    public static long getCurrentTime() {
        return new Date().getTime();
    }

	public static String dateFormatter(Date toDate, String yyyyMMdd) {
		return toDate != null ? new SimpleDateFormat(yyyyMMdd).format(toDate) : null;
	}
	public static String gregorianCalendarToFormat(GregorianCalendar date,String format){
		if(date == null)
			return null;
		else
			return dateFormatter(date.getTime(),format);
	}
	public static String getDatePath(LocalDate date) {
		var month = String.valueOf(date.getMonthValue());
		month = month.length() == 1 ? "0".concat(month) : month;

		var day = String.valueOf(date.getDayOfMonth());
		day = day.length() == 1 ? "0".concat(day) : day;
		return String.join("/", String.valueOf(date.getYear()), month, day);
	}

	public static LocalDate parseDateStrToLocalDate(String value){
		LocalDate localDate=null;
		if(StringUtils.isNotBlank(value)){
			if(StringUtils.trim(value).length() == 8)
				localDate = DateUtils.parseDate(value, GlobalConstants.DATE_FORMAT_FOR_FRONT);
			else if(StringUtils.trim(value).length() == GlobalConstants.DATE_OBJECT_STRING_FORMAT_UTC.length())
				localDate=DateUtils.parseDate(value, GlobalConstants.DATE_OBJECT_STRING_FORMAT_UTC);
			else
				localDate = DateUtils.parseDate(value,GlobalConstants.DATE_OBJECT_STRING_FORMAT);
		}
		return localDate;
	}

	public static Date parseDateStrToDate(String value){
		Date localDate=null;
		if(StringUtils.isNotBlank(value)){
			if(StringUtils.trim(value).length() == 8)
				localDate = DateUtils.parseToDate(value, GlobalConstants.DATE_FORMAT_FOR_FRONT);
			else if(StringUtils.trim(value).length() == GlobalConstants.DATE_OBJECT_STRING_FORMAT_UTC.length())
				localDate=DateUtils.parseToDate(value, GlobalConstants.DATE_OBJECT_STRING_FORMAT_UTC);
			else
				localDate = DateUtils.parseToDate(value,GlobalConstants.DATE_OBJECT_STRING_FORMAT);
		}
		return localDate;
	}
}
