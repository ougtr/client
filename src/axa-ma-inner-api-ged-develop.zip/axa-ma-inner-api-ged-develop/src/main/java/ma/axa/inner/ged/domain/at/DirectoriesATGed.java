package ma.axa.inner.ged.domain.at;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.domain.GEDRepositoriesAS400;
import ma.axa.inner.ged.enums.AutoAtBranchEnum;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;


@Entity
@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@DiscriminatorValue(value= AutoAtBranchEnum.Values.SAT)
public class DirectoriesATGed extends GEDRepositoriesAS400 {
    private Integer sort;
}
