package ma.axa.inner.ged.api.production;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.domain.ProductionTypeDoc;
import ma.axa.inner.ged.domain.production.ProductionDemandDoc;
import ma.axa.inner.ged.dto.DemandUploadResponseDto;
import ma.axa.inner.ged.service.production.HealthProdDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@Tag(name = GlobalConstants.AT_GED_APIS_TAG)
@RestController
@RequestMapping("/v1/production/health")
@RequiredArgsConstructor
@Slf4j
public class HealthProductionDocumentAPI {
	
	private final HealthProdDocumentService documentService;

	@SneakyThrows
	@Operation(summary = "uploader un document production")
	@PostMapping(path="/upload",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public String uploadFile(@ParameterObject @ModelAttribute @Valid ProductionTypeDoc documentAtProduction
			,@RequestParam(value = "file", required = true) MultipartFile file){
		log.info("Start: Uploading file (document production) '{}'", file.getOriginalFilename());
		var id = documentService.uploadFile(file, documentAtProduction);
		log.debug("File metadata '{}' and id '{}'", documentAtProduction, id);
		log.info("End: File (document production) uploaded '{}'", file.getOriginalFilename());
		return id;
	}
	@Operation(summary = "download a production document by alfresco_id without prefix")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was downloaded", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = Resource.class))}),
            @ApiResponse(responseCode = "404", description = "document not found with id", content = @Content),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<Resource> downloadFile(@NotNull(message = "{error.alfresco.id}") @PathVariable(value = "id", required = true) String alfrescoId) {
        log.info("Start Downloading file with id '{}'", alfrescoId);
        var document = documentService.downloadFile(alfrescoId);
        var headers = new HttpHeaders();
        String headerKey = "X-filename";
        String headerValue = document.getFilename();
        headers.set(headerKey,headerValue);

        log.info("End api: File downloaded !");
        return ResponseEntity.ok().headers(headers).body(document);
    }


	@Operation(summary = "uploader un document production pour une demand")
	@PostMapping(path="/demands/upload",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public List<DemandUploadResponseDto> uploadDemandFile(@ParameterObject @ModelAttribute @Valid ProductionDemandDoc productionDemandDoc,
														  @RequestPart(value = "files", required = true) List<MultipartFile> files){
		log.info("Start: Uploading file (document demand production)");
		var ids = documentService.uploadDemandFiles(files, productionDemandDoc);
		return ids;
	}
	
	
}
