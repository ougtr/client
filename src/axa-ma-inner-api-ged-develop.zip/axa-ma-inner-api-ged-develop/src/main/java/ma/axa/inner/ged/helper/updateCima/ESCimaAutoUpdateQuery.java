package ma.axa.inner.ged.helper.updateCima;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ESCimaAutoUpdateQuery {
    private ESCimaAutoDoc doc;
}
