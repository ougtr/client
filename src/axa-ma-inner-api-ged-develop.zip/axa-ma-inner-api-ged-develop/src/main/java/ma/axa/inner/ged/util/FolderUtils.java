package ma.axa.inner.ged.util;


import lombok.experimental.UtilityClass;

@UtilityClass
public class FolderUtils {

    public static String constructBranchFolderPath(String branchePath, String id) {
        var brancheFolderPathWithReference = FileUtil.appendStringToFolderPath(branchePath, id);
        return FileUtil.appendDateAsSubFolders(brancheFolderPathWithReference);
    }
}
