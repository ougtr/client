package ma.axa.inner.ged.util.jpa_query_filter.exceptions;

public class ConflictingFieldsException extends RuntimeException {
    public ConflictingFieldsException(String msg) {
        super(msg);
    }
}
