package ma.axa.inner.ged.exception;

import ma.axa.inner.ged.util.constants.GlobalConstants;

public class BusinessException extends GlobalException {

	private static final long serialVersionUID = 3919144827096539206L;

	public BusinessException(String message) {
		super (GlobalConstants.URI_DEFAULT, message);
	}
}
