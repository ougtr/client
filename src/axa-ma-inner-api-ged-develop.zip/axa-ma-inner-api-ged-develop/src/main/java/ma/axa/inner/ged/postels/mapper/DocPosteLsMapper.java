package ma.axa.inner.ged.postels.mapper;

import ma.axa.inner.ged.mapper.AlfrescoPropsMapper;
import ma.axa.inner.ged.postels.dto.DocPosteLsReq;
import ma.axa.inner.ged.postels.dto.DocPosteLsUpdateReq;

import java.util.Collections;
import java.util.Map;

public class DocPosteLsMapper extends AlfrescoPropsMapper {

	private DocPosteLsMapper() throws InstantiationException {
		throw new InstantiationException("Instances of this type are forbidden");
	}

	// Folders

	public static Map<String, Object> toFolderProperties(DocPosteLsReq metaData) {
		return toFolderProperties(metaData, null);
	}

	public static Map<String, Object> toFolderProperties(DocPosteLsReq metaData, Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();

		var alfrescoProps = AlfrescoFolderProperties.builder()
				.numeroSinistreDossier(metaData.getNumPolice())
				.build();

		return toFolderProperties(properties, alfrescoProps);
	}

	// Documents

	public static Map<String, Object> toDocumentProperties(DocPosteLsReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocPosteLsReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numPolice(metaData.getNumPolice())
				.identifiantScaner(metaData.getReference())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}

	public static Map<String, Object> toDocumentProperties(DocPosteLsUpdateReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocPosteLsUpdateReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numPolice(metaData.getNumPolice())
				.isAuthentique(metaData.isOriginal())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}
}
