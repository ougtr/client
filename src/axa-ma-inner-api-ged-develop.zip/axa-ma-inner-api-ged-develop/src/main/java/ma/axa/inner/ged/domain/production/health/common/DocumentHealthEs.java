package ma.axa.inner.ged.domain.production.health.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.domain.production.ProductionDocumentEs;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentHealthEs extends ProductionDocumentEs {
    @JsonProperty("policy_number")
    private String policyNumber;
    @JsonProperty("integration_id")
    private String integrationId ;
    @JsonProperty("quotation_id")
    private String quotationNumber;
}