package ma.axa.inner.ged.config.security;

import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Value("${axa.security.enabled:true}")
    private boolean securityEnabled;

    @Value("${axa.security.allowed-origin:*}")
    private String allowedOriginPattern;

    @Override
    public void configure(HttpSecurity http) throws Exception {
        // @formatter:off
        if (!securityEnabled) {
            http.authorizeRequests().anyRequest().permitAll();
        } else {
            http
                    .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                    .and()
                    .authorizeRequests(authRequests -> {
                                authRequests.mvcMatchers("/v1/**").hasAuthority(GlobalConstants.SCOPE_GED);
                                // Management endpoints
                                authRequests.mvcMatchers("/management/**", "/docs/**", "/webjars/**","/v1/documents/content/**").permitAll();
                                authRequests.anyRequest().authenticated();
                            }
                    );

            http.oauth2ResourceServer().jwt();
        }

        // Other config
        http.cors().and()
                .csrf().disable() //NOSONAR
                .exceptionHandling()
                .accessDeniedHandler(securityAccessDeniedHandler())
                .authenticationEntryPoint(securityAuthEntryPoint());
        // @formatter:on
    }


    @Bean
    public CorsFilter corsFilter() {
        var source = new UrlBasedCorsConfigurationSource();
        var config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.addAllowedOriginPattern(allowedOriginPattern);
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }

    @Bean
    public AccessDeniedHandler securityAccessDeniedHandler() {
        return new SecurityAccessDeniedHandler();
    }

    @Bean
    public AuthenticationEntryPoint securityAuthEntryPoint() {
        return new SecurityAuthEntryPoint();
    }
}
