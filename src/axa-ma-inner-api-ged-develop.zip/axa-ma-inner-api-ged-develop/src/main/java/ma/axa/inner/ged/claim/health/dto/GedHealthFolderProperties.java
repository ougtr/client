package ma.axa.inner.ged.claim.health.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.chemistry.opencmis.client.api.Folder;

import java.util.Map;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GedHealthFolderProperties {
    private Map<String, Object> properties;
    private Folder folder;
}
