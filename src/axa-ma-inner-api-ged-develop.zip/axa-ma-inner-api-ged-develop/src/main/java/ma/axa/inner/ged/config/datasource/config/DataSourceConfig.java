package ma.axa.inner.ged.config.datasource.config;

import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.inner.ged.config.datasource.hikari_config.HikariProperties;

@NoArgsConstructor
@Data
public class DataSourceConfig {
    private String url;
    private String password;
    private String username;
    private String driverClassName;
    private HikariProperties hikari;

}
