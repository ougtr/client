package ma.axa.inner.ged.dto.transverse.med;

import lombok.Builder;
import lombok.Data;
import ma.axa.inner.ged.dto.transverse.med.HistoriqueRequestDto;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;


@Data
@Builder
public class MEDDocumentRequest {
	String typeQuittance;
	String typeAnnotation;






}