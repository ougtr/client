package ma.axa.inner.ged.claim.ls.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
public class DocClaimLsUpdateReq {
	private String sinistreNumber;
	private String typeDocumentCode;
	private String reference;
	private boolean isOriginal;
	private String status ;
}
