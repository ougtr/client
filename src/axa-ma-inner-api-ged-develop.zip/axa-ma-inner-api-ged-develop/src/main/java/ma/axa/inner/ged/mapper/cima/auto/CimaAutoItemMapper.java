package ma.axa.inner.ged.mapper.cima.auto;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import ma.axa.inner.ged.domain.cima.auto.CimaAutoItemEs;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoItemResponse;
import ma.axa.inner.ged.mapper.MapstructUtil;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = MapstructUtil.class)
public interface CimaAutoItemMapper {

	@Mapping(source = "id", target = "id",qualifiedByName = "trim")
	@Mapping(source = "lib", target = "lib",qualifiedByName = "trim")
	@Mapping(source = "description", target = "desc")
    CimaAutoItemResponse toResponse(CimaAutoItemEs itemEs);
    List<CimaAutoItemResponse> toResponses(List<CimaAutoItemEs> items);
    CimaAutoItemEs fromDto(CimaAutoItemResponse item);
}
