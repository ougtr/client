package ma.axa.inner.ged.util.constants;

public enum MobileScanStatutEnum {
	ENCOURS, OCIRISER, INDEXE
}
