package ma.axa.inner.ged.config;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.elasticsearch.client.RestClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.json.jackson.JacksonJsonpMapper;
import co.elastic.clients.transport.ElasticsearchTransport;
import co.elastic.clients.transport.TransportUtils;
import co.elastic.clients.transport.rest_client.RestClientTransport;
import lombok.RequiredArgsConstructor;
import ma.axa.inner.ged.config.properties.ElasticSearchProperties;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Import({ ElasticSearchProperties.class })
@Configuration
@RequiredArgsConstructor
public class ElasticSearchConfig {

	private final ElasticSearchProperties props;

	private ObjectMapper buildObjectMapper() {
		return Jackson2ObjectMapperBuilder.json()
				.serializationInclusion(JsonInclude.Include.NON_NULL)
				.featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
				.modules(new JavaTimeModule())
				.build();
	}

	@Bean
	public ElasticsearchTransport elasticsearchTransport() {
		final var host = new HttpHost(props.getHost(), props.getPort(), props.getSchema());
		final var restClientBuilder = RestClient.builder(host);
		final var credentials = new UsernamePasswordCredentials(props.getUsername(), props.getPassword());
		var credsProv = new BasicCredentialsProvider();
		credsProv.setCredentials(AuthScope.ANY, credentials);
		try {
			SSLContext sslContext = TransportUtils.sslContextFromCaFingerprint(props.getFingerprint());
			restClientBuilder.setHttpClientConfigCallback(builder -> builder
					.setSSLContext(sslContext)
					.setDefaultCredentialsProvider(credsProv));
		} catch (Exception e) {
			throw new GlobalException(GlobalConstants.URI_INIT_CONFIGURATION,
					"Failed to create SSLContext for Elasticsearch, err: " + e.getMessage());
		}

		var restClient = restClientBuilder.build();
		var objectMapper = this.buildObjectMapper();
		var jacksonJsonpMapper = new JacksonJsonpMapper(objectMapper);
		return new RestClientTransport(restClient, jacksonJsonpMapper);
	}

	@Bean
	public ElasticsearchClient elasticsearchClient() {
		return new ElasticsearchClient(elasticsearchTransport());
	}

}
