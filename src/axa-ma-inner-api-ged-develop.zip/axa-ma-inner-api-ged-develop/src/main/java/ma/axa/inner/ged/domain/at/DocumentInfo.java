package ma.axa.inner.ged.domain.at;

import lombok.*;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.domain.TypeDocAs400;

import javax.persistence.*;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode
@Entity
@Table(schema = "ASADONNE",name = "PREDOCMNT")
public class DocumentInfo {
    @Id
    @Column(name = "ID")
    private Integer id;
    @Column(name = "Label")
    private String label;
    @Column(name = "TYPE")
    private Integer type;
    @Column(name = "GROUP")
    private Integer group;
    @ManyToOne
    @JoinColumn(name = "TYPEDOCID", referencedColumnName = "ID")
    private TypeDocAs400 typology;
    @ManyToOne
    @JoinColumn(name = "TYPEDOCID2", referencedColumnName = "ID")
    private TypeDocAs400 secondTypology;
}
