package ma.axa.inner.ged.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LsGedResponse {
    private String typeDoc;
    private String idAlfresco;
}
