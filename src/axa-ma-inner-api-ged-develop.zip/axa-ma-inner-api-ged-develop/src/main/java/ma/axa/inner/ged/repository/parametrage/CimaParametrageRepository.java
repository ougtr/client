package ma.axa.inner.ged.repository.parametrage;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.domain.cima.auto.CimaAutoDocumentsTypeEs;
import ma.axa.inner.ged.domain.cima.auto.CimaAutoItemEs;
import ma.axa.inner.ged.exception.CallStoredProcedureException;

@Repository
@Slf4j
@RequiredArgsConstructor
public class CimaParametrageRepository {

	private static final String ERROR = "error {}";
	private final JdbcTemplate jdbcTemplate;

	@SneakyThrows
	public List<CimaAutoItemEs> findDirectories() {
		try {
			List<CimaAutoItemEs> list;
			log.info("Start calling for all Directories");
			list = jdbcTemplate.query("SELECT * FROM DIRECTORY",
					BeanPropertyRowMapper.newInstance(CimaAutoItemEs.class));
			log.info("End calling for all Directories");
			return list;
		} catch (Exception e) {
			log.error(ERROR, e);
			throw new CallStoredProcedureException("Error findDirectories : ".concat(e.getMessage()));
		}
	}

	@SneakyThrows
	public List<CimaAutoItemEs> findBranches() {
		try {
			List<CimaAutoItemEs> list;
			log.info("Start calling for all branches");
			list = jdbcTemplate.query("SELECT * FROM BRANCHE ",
					BeanPropertyRowMapper.newInstance(CimaAutoItemEs.class));
			log.info("End calling for all branches");

			return list;
		} catch (Exception e) {
			log.error(ERROR, e);
			throw new CallStoredProcedureException("Error findBranches : ".concat(e.getMessage()));
		}
	}

	@SneakyThrows
	public List<CimaAutoItemEs> findEntities(Long brancheId) {
		try {
			List<CimaAutoItemEs> list;
			log.info("Start calling for Entities");
			list = jdbcTemplate.query("SELECT * FROM ENTITY WHERE ID_BRANCHE = ? ",
					BeanPropertyRowMapper.newInstance(CimaAutoItemEs.class), brancheId);
			log.info("End calling for Entities");

			return list;
		} catch (Exception e) {
			log.error(ERROR, e);
			throw new CallStoredProcedureException("Error findEntities : ".concat(e.getMessage()));
		}
	}

	@SneakyThrows
	public List<CimaAutoItemEs> findDocumentTypes(Long entityId, Long directoryId) {
		try {
			List<CimaAutoItemEs> list;
			log.info("Start calling for DocumentTypes");
			list = jdbcTemplate.query("SELECT * FROM DOCUMENT WHERE ID_ENT = ? AND ID_DIR = ?",
					BeanPropertyRowMapper.newInstance(CimaAutoItemEs.class), entityId, directoryId);
			log.info("End calling for DocumentTypes");

			return list;
		} catch (Exception e) {
			log.error(ERROR, e);
			throw new CallStoredProcedureException("Error findDocumentTypes : ".concat(e.getMessage()));
		}
	}

	public List<CimaAutoDocumentsTypeEs> findAllDocumentTypes() {
		try {
			List<CimaAutoDocumentsTypeEs> list;
			log.info("Start calling for all DocumentTypes");
			list = jdbcTemplate.query(
					"SELECT D.ID, D.LIB, D.ID_DIR, D.ID_ENT, E.LIB AS ENTITYNAME, T.LIB AS DIRECTORYNAME"
							+ " FROM DOCUMENT D" + " JOIN ENTITY E ON D.ID_ENT = E.ID "
							+ " JOIN DIRECTORY T ON D.ID_DIR = T.ID",
					BeanPropertyRowMapper.newInstance(CimaAutoDocumentsTypeEs.class));
			log.info("End calling for all DocumentTypes");

			return list;
		} catch (Exception e) {
			log.error(ERROR, e);
			throw new CallStoredProcedureException("Error findAllDocumentTypes : ".concat(e.getMessage()));
		}
	}

}
