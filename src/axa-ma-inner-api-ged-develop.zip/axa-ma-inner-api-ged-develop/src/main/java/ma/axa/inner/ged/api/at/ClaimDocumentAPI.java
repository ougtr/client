package ma.axa.inner.ged.api.at;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.domain.at.DocumentSinistreATES;
import ma.axa.inner.ged.dto.DocClaimAtReqDto;
import ma.axa.inner.ged.dto.DocumentInfoDto;
import ma.axa.inner.ged.dto.DocumentSinistreAT;
import ma.axa.inner.ged.dto.at.*;
import ma.axa.inner.ged.exception.FileNameNotValidException;
import ma.axa.inner.ged.service.at.ClaimATDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;

@Tag(name = GlobalConstants.AT_GED_APIS_TAG)
@RestController
    @RequestMapping("/v1/claims/at/documents")
@RequiredArgsConstructor
@Slf4j
public class ClaimDocumentAPI {

    private final ClaimATDocumentService claimATDocumentService;

    @Operation(summary = "upload document claim AT")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document added", content = {
                    @Content(mediaType = "multipart/form-data", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "400", description = "request not valid", content = @Content)})
    @PostMapping(consumes = MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> uploadFileAT(@Valid @ModelAttribute DocumentSinistreAT documentSinistreAT,
                                               @RequestPart(value = "file") MultipartFile file) throws FileNameNotValidException {
        log.info("Start: Uploading file AT '{}'", file.getOriginalFilename());
        String idAlfresco = claimATDocumentService.uploadFile(documentSinistreAT, file);
        log.debug("Output '{}'", idAlfresco);
        log.info("End: File AT uploaded '{}'", file.getOriginalFilename());
        return new ResponseEntity<>(idAlfresco, HttpStatus.CREATED);
    }

    /***
     * Upload temporary documents without claim number"
     * @param file file to upload
     * @param docClaimAtReqDto for metadata
     ***/

    @Operation(summary = "upload document claim AT")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document added", content = {
                    @Content(mediaType = "multipart/form-data", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "400", description = "request not valid", content = @Content)})
    @PostMapping(value = "/temporary", consumes = MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> uploadTemporaryFileAT(@ParameterObject @Valid @ModelAttribute DocClaimAtReqDto docClaimAtReqDto,
                                                        @Parameter(description = "Content of the document") @RequestPart(value = "file") MultipartFile file) {
        log.info("Start: Uploading file AT '{}'", file.getOriginalFilename());
        String idAlfresco = claimATDocumentService.uploadFileAt(docClaimAtReqDto, file);
        log.info("End: File AT uploaded '{}'", file.getOriginalFilename());
        return new ResponseEntity<>(idAlfresco, HttpStatus.CREATED);
    }

    @Operation(summary = "Récupérer la liste des documents manquants")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "liste des documents manquants", content = {
            @Content(mediaType = "application/json", array = @ArraySchema(
                    schema = @Schema(implementation = DocumentInfoDto.class)))})})
    @GetMapping("/missing-documents")
    public List<DocumentInfoDto> getMissingDocumentsByQuery(MissingDocumentQuery query) {
        log.info("Start api: Get list of missing documents by query {}", query);
        final var missingDocs = claimATDocumentService.getMissingDocumentsByQuery(query);
        log.info("End api: Get list of missing documents by query {}", query);
        return missingDocs;
    }

    /***
     * download file document by idAlfresco
     * @param documentId
     ***/
    @Operation(summary = "download a claim document by its alfresco id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was downloaded", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = Resource.class))}),
            @ApiResponse(responseCode = "404", description = "document not found with id", content = @Content),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
    @GetMapping(value = "/{document_id}/content", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<Resource> downloadFile(@NotNull(message = "{error.alfresco.id}") @PathVariable(value = "document_id") String documentId) {
        log.info("Start api: Downloading file with id '{}'", documentId);
        var resource = claimATDocumentService.downloadAtFile(documentId);

        var headers = new HttpHeaders();
        String headerKey = "X-filename";
        String headerValue = resource.getFilename();
        headers.set(headerKey, headerValue);

        log.info("End api: File downloaded !");
        return ResponseEntity.ok().headers(headers).body(resource);
    }

    /***
     * search a claim at using claim number
     * @param claimNumber
     ***/
    @Operation(summary = "search a claim at using claim number")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "documents metadata were found", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = DocumentSinistreATES.class))}),
            @ApiResponse(responseCode = "400", description = "Request not valid", content = @Content),
            @ApiResponse(responseCode = "404", description = "documents not found with claim number", content = @Content)}
    )
    @GetMapping("/metadatas")
    public List<DocumentSinistreATES> searchClaimAtDocumentsByClaimNumber(@RequestParam(value = "claim_number") String claimNumber) {
        log.info("Start api: Search list of documents with claim number '{}'", claimNumber);
        var listDocuments = claimATDocumentService.retriveAtDocumentsList(claimNumber);
        log.info("End api: Search list of documents with claim number '{}'", claimNumber);
        return listDocuments;
    }

    /***
     * Modify documents metadata"
     * @param documentId for identify document
     * @param documentsMetadata for metadata
     ***/
    @Operation(summary = "Modify documents metadata")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "documents metadata were modified", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "404", description = "document not found with idAlfresco", content = @Content)}
    )
    @PutMapping("/{document_id}")
    public String modifyMetadata(@NotEmpty(message = "{error.document.infomation}") @PathVariable(value = "document_id") String documentId
            , @Valid @RequestBody DocClaimAtReqDto documentsMetadata) {
        log.info("Start api: modify data of documents with alfresco id '{}'", documentId);
        var modificationResponse = claimATDocumentService.modifyAtDocMetadata(documentId, documentsMetadata);
        log.info("End api: modify data of documents with alfresco id '{}'", documentId);
        return modificationResponse;
    }

    /**
     * Delete documents from alfresco and es"
     *
     * @param documentId for identify document
     *                   *
     */
    @Operation(summary = "delete documents metadata")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "documents metadata were deleted", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "404", description = "document not found with idAlfresco", content = @Content)}
    )
    @DeleteMapping("/{document_id}")
    public String deleteAtDocument(@PathVariable(value = "document_id") String documentId) {
        log.info("Start api: delete data of documents with alfresco id '{}'", documentId);
        var deleteDocumentsMetadata = claimATDocumentService.deleteAtDocument(documentId);
        log.info("End api: delete data of documents with alfresco id '{}'", documentId);
        return deleteDocumentsMetadata;
    }

    @Operation(summary = "search in documents metadata by query")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "documents metadata", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = DocumentSinistreATES[].class))}),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content)})
    @GetMapping("/search")
    public PageDto<DocClaimAtReqDto> searchInDocumentsByQuery(DocumentMetadataQueryDto query) {
        log.info("Start api: search in documents metadata by query '{}'", query);
        var listDocuments = claimATDocumentService.searchInDocumentsByQuery(query);
        log.info("End api: search in documents metadata by query '{}'", query);
        return listDocuments;
    }

    @Operation(summary = "copy files and metadata by AlfrescoIds")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document copied", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = List.class))}),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content)})
    @PostMapping("/copy")
    public List<ChangesQueryDto> copyDocumentsByAlfrescoIds(@RequestParam(required = false) Boolean temporary, @RequestBody @Valid CopyDocumentsQueryDto copyDocumentsQueryDto) {
        log.info("Start api : copy files with alfresco's id's '{}' for user '{}'", copyDocumentsQueryDto.getChanges(), copyDocumentsQueryDto.getUserName());
        final var result = claimATDocumentService.copyDocumentsByAlfrescoIds(temporary, copyDocumentsQueryDto);
        log.info("End api : copy files with alfresco's id's '{}' for user '{}'", copyDocumentsQueryDto.getChanges(), copyDocumentsQueryDto.getUserName());
        return result;
    }

}