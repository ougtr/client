package ma.axa.inner.ged.exception;

public class FileNameNotValidException extends RuntimeException {

	private static final long serialVersionUID = -5010466988171111869L;
	
	public FileNameNotValidException(String message) {
		super(message);
	}

}
