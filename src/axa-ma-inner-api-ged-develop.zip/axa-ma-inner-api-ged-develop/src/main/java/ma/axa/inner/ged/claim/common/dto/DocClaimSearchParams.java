package ma.axa.inner.ged.claim.common.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.validation.constraints.Min;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class DocClaimSearchParams {
	// pagination params
	@Min(value = 0, message = GlobalConstants.ERROR_MSG_SEARCH_PAGENUMBER_MIN)
	@Builder.Default
	private Integer pageNumber = 0;
	@Min(value = 1, message = GlobalConstants.ERROR_MSG_SEARCH_PAGESIZE_MIN)
	@Builder.Default
	private Integer pageSize = 10;

	protected String id;
	protected String reference;
	protected String sinistreNumber;
	protected String numPolice;
	protected Boolean isDraft;
	private String createdBy;
	private String lastUpdatedBy;
	protected String status;

	protected Integer brancheCode;
	protected String brancheLabel;
	protected Integer produitCode;
	protected String produitLabel;
	protected String assureNom;
	protected String assurePrenom;
	protected Integer intermediaireCode;
	
	private Integer entityCode;
	private Integer typeDocumentCode;
	private String repertoire;
	private String repertoireCode;
	
	//TODO
	//NEW information
	private String valeur_juridiction;
	private String num_tribunal;
	private String numAdhesion;
	private String libBanque;
	private String numDeclaration;
	private String correspondance_G;

	// CreatedAt
	@DateTimeFormat(pattern = GlobalConstants.DATETIME_FORMAT_COMMON, fallbackPatterns = {GlobalConstants.DATETIME_FORMAT_YYYYMMDD})
	@JsonFormat(pattern = GlobalConstants.DATETIME_FORMAT_COMMON, shape = JsonFormat.Shape.STRING)
	private LocalDateTime createdAtFrom;
	@DateTimeFormat(pattern = GlobalConstants.DATETIME_FORMAT_COMMON, fallbackPatterns = {GlobalConstants.DATETIME_FORMAT_YYYYMMDD})
	@JsonFormat(pattern = GlobalConstants.DATETIME_FORMAT_COMMON, shape = JsonFormat.Shape.STRING)
	private LocalDateTime createdAtTo;

	// LastUpdateAt
	@DateTimeFormat(pattern = GlobalConstants.DATETIME_FORMAT_COMMON, fallbackPatterns = {GlobalConstants.DATETIME_FORMAT_YYYYMMDD})
	@JsonFormat(pattern = GlobalConstants.DATETIME_FORMAT_COMMON, shape = JsonFormat.Shape.STRING)
	private LocalDateTime lastUpdateAtFrom;
	@DateTimeFormat(pattern = GlobalConstants.DATETIME_FORMAT_COMMON, fallbackPatterns = {GlobalConstants.DATETIME_FORMAT_YYYYMMDD})
	@JsonFormat(pattern = GlobalConstants.DATETIME_FORMAT_COMMON, shape = JsonFormat.Shape.STRING)
	private LocalDateTime lastUpdateAtTo;

	@DateTimeFormat(pattern = GlobalConstants.DATE_FORMAT_COMMON, fallbackPatterns = {GlobalConstants.DATE_FORMAT_YYYYMMDD})
	protected LocalDate dateReceptionFrom;
	@DateTimeFormat(pattern = GlobalConstants.DATE_FORMAT_COMMON, fallbackPatterns = {GlobalConstants.DATE_FORMAT_YYYYMMDD})
	@JsonFormat(pattern = GlobalConstants.DATE_FORMAT_COMMON, shape = JsonFormat.Shape.STRING)
	protected LocalDate dateReceptionTo;

	@DateTimeFormat(pattern = GlobalConstants.DATE_FORMAT_COMMON, fallbackPatterns = {GlobalConstants.DATE_FORMAT_YYYYMMDD})
	protected LocalDate dateNumerisationFrom;
	@DateTimeFormat(pattern = GlobalConstants.DATE_FORMAT_COMMON, fallbackPatterns = {GlobalConstants.DATE_FORMAT_YYYYMMDD})
	protected LocalDate dateNumerisationTo;

	@DateTimeFormat(pattern = GlobalConstants.DATE_FORMAT_COMMON, fallbackPatterns = {GlobalConstants.DATE_FORMAT_YYYYMMDD})
	protected LocalDate dateSurvenanceFrom;
	@DateTimeFormat(pattern = GlobalConstants.DATE_FORMAT_COMMON, fallbackPatterns = {GlobalConstants.DATE_FORMAT_YYYYMMDD})
	protected LocalDate dateSurvenanceTo;
	
}
