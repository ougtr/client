package ma.axa.inner.ged.claim.health.service;


import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.health.dto.DocumentUploadInvoiceRequest;
import ma.axa.inner.ged.claim.health.repository.SehassurHealthDocumentsRepository;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.mapper.DocumentMapper;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.service.ManageDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;

@Service
@Slf4j
public class SehassurHealthDocumentService extends ManageDocumentService {


 
    private final SehassurHealthDocumentsRepository sehassurHealthDocumentsRepository;
    private final ClaimHealthDocumentService claimHealthDocumentService;

   
    public SehassurHealthDocumentService(ClaimDocumentRepository claimDocumentRepository,SehassurHealthDocumentsRepository sehassurRepository,ClaimHealthDocumentService claimService) {
		super(claimDocumentRepository);
		sehassurHealthDocumentsRepository = sehassurRepository;
		this.claimHealthDocumentService = claimService;
 
	}


	@SneakyThrows
    public String uploadFacture(MultipartFile file, DocumentUploadInvoiceRequest docInfo) {
    	var idAlfresco =  "";
        log.info("Start : uploadFile  with data '{}'", docInfo);
        if (file != null && file.getOriginalFilename() != null && file.getContentType() != null) {
            var folderProprites = claimHealthDocumentService.indexDossier(file);
            try {
             	idAlfresco = claimHealthDocumentService.uploadFile(folderProprites.getProperties(), DocumentMapper.mapFileToGedDocument(file), folderProprites.getFolder()).get("idAlfresco");
                log.info("processed : file uploadith with id '{}'", idAlfresco);
                docInfo.setIdGed(StringUtils.removeStartIgnoreCase(idAlfresco, GlobalConstants.PREFIX_IN_ALFRESCO_ID));
 
                sehassurHealthDocumentsRepository.updateIdGed(docInfo);
 
            } catch (Exception e) {
                log.error("can not upload document or save metadata in as400 error '{}'", e.getMessage());
                throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
            }
        }
        return idAlfresco;
   
    }
 

    public String pathFromDateDoc() {
        var date = LocalDate.now();
        return date.getYear() + "/" + date.getMonthValue() + "/" + date.getDayOfMonth();
    }

 
   
}
