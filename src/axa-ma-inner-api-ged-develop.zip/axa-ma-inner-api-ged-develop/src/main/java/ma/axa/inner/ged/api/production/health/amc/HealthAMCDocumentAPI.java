package ma.axa.inner.ged.api.production.health.amc;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCReq;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCResp;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCSearchParams;
import ma.axa.inner.ged.dto.production.health.amc.DocHealthAMCUpdateReq;
import ma.axa.inner.ged.service.production.health.amc.HealthAMCDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/v1/health/amc/documents")
@Tag(name = GlobalConstants.TAG_HEALTH_AMC_APIS, description = GlobalConstants.TAG_DESC_HEALTH_AMC_APIS)
@RequiredArgsConstructor
public class HealthAMCDocumentAPI {
    private final HealthAMCDocumentService service;

    @Operation(summary = "Upload new Health AMC document and index meta-data")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document ID", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = DocHealthAMCReq.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<List<DocHealthAMCResp>> uploadHealthAMCDoc(
            @ParameterObject @ModelAttribute @Valid DocHealthAMCReq documentHealthAMCReq,
            @RequestPart(value = "files", required = true) List<MultipartFile> files) {
        log.info("[health-amc-api] Start Uploading files:  {}", files.size());
        var createdDocument = service.uploadDocWithMetaData(documentHealthAMCReq, files);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdDocument);
    }


    @Operation(summary = "Update Health AMC document by document_id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was updated", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = DocHealthAMCResp.class))}),
            @ApiResponse(responseCode = "404", description = "document not found", content = @Content),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
    @PutMapping(value = "/{document_id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<DocHealthAMCResp> updateHealthAMCDoc(
            @NotBlank(message = "Document id must not be empty") @PathVariable(value = "document_id") String documentId,
            @Valid @RequestBody DocHealthAMCUpdateReq documentReq) {
        log.info("[health-amc-api] Start update document : " +documentId);
        var updatedDoc = service.updateDocument(documentId, documentReq);
        return ResponseEntity.ok(updatedDoc);
    }


    @Operation(summary = "Search Health AMC Documents by policy number")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was downloaded", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = Page.class))}),
            @ApiResponse(responseCode = "404", description = "document not found", content = @Content),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
    @GetMapping
    public ResponseEntity<Page<DocHealthAMCResp>> searchHealthAMC(@Valid DocHealthAMCSearchParams params) {
        log.info("[API] Multi Searching documents AMC...");
        var pageResult = service.search(params);
        return ResponseEntity.ok(pageResult);
    }

    @Operation(summary = "Delete Health AMC document by document_id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "document was deleted", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "404", description = "document not found", content = @Content),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
    @DeleteMapping(value = "/{document_id}")
    public ResponseEntity<String> deleteDocument(
            @NotBlank(message = GlobalConstants.ERROR_MSG_RD_ID_NOT_BLANK) @PathVariable(value = "document_id") String documentId) {
        log.info("[health-amc-api] Start delete document : " +documentId);
        return ResponseEntity.ok(service.deleteDocument(documentId));
    }

    @Operation(summary = "tag amc documents by policy number")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "documents were tagged", content = {
                    @Content(mediaType = "text/plain", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "400", description = "not valid request", content = @Content)})
    @PutMapping(value = "/tag")
    public ResponseEntity tagAllDocumentByPolicyNumber(
            @NotBlank(message = GlobalConstants.ERROR_HEALTH_QUOTATION_ID_NOT_EMPTY) @RequestParam(value = "quotation_id") String idQuotation,
            @NotBlank(message = GlobalConstants.ERROR_HEALTH_POLICY_NUMBER_NOT_EMPTY) @RequestParam(value = "policy_number") String policyNum,
            @NotBlank(message = GlobalConstants.ERROR_HEALTH_USER_NAME_NOT_EMPTY) @RequestParam(value = "user_name") String userName) {
        log.info("[health-amc-api] Tag documents by policy number : " + policyNum);
        service.tagAllDocumentsByPolicyNumber(policyNum,idQuotation,userName);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}