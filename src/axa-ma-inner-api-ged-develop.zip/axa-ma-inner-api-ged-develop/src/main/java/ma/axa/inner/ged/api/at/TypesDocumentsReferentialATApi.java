package ma.axa.inner.ged.api.at;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.at.IntermediaryTypeDocDto;
import ma.axa.inner.ged.dto.at.TypeDocDto;
import ma.axa.inner.ged.service.at.TypeDocumentsReferentialAtService;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = GlobalConstants.AT_GED_APIS_TAG)
@RestController
@RequestMapping("/v1/claims/at")
@RequiredArgsConstructor
@Slf4j
public class TypesDocumentsReferentialATApi {

    private final TypeDocumentsReferentialAtService typeDocumentsReferentialService;

    @Operation(summary = "Retrieve the list of intermediary document types (typologies)")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "intermediary documents type retrieved", content = {
            @Content(mediaType = "application/json", array =@ArraySchema(schema = @Schema(implementation = IntermediaryTypeDocDto.class)))}),
            @ApiResponse(responseCode = "400", description = "bad request", content = @Content)})
    @GetMapping("/intermediary/params/type-documents")
    public List<IntermediaryTypeDocDto> getIntermediaryTypeDocs() {
        log.info("Start API: get intermediary documents types");
        var output = typeDocumentsReferentialService.getIntermediaryTypeDocs();
        log.info("End API: get intermediary documents types");
        return output;
    }

    @Operation(summary = "Retrieve the list of document types (typologies)")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "documents type retrieved", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = TypeDocDto.class))}),
            @ApiResponse(responseCode = "404", description = "no document type is found", content = @Content),
            @ApiResponse(responseCode = "400", description = "bad request", content = @Content)})
    @GetMapping("/params/type-documents")
    public List<TypeDocDto> getListTypeDocs() {
        log.info("Start api: get documents types for at.");
        final var typesDocs = typeDocumentsReferentialService.getAtListTypeDocs();
        log.info("End api: get documents types for at.");
        return typesDocs;
    }

}
