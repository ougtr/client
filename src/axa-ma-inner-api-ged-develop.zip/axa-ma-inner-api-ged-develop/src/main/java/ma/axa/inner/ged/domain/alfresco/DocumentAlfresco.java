package ma.axa.inner.ged.domain.alfresco;

import java.io.InputStream;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DocumentAlfresco {
	private String id;
	private String filename;
	private String path;
	private String mimeType;
	private Long contentLength;
	private InputStream contentStream;
}
