package ma.axa.inner.ged.mapper.transverse.med;

import ma.axa.inner.ged.domain.transverse.med.MedDocumentEs;
import ma.axa.inner.ged.dto.transverse.med.MEDDocumentRequest;
import ma.axa.inner.ged.dto.transverse.med.MEDDocumentResponse;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface MedDocumentMapper {
	
    MedDocumentEs fromDto(MEDDocumentRequest document);
    MEDDocumentResponse toDto(MedDocumentEs documentEs);
}
