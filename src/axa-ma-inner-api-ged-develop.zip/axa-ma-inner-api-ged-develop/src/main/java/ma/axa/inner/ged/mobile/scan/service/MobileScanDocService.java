package ma.axa.inner.ged.mobile.scan.service;

import org.springframework.web.multipart.MultipartFile;

import ma.axa.inner.ged.mobile.scan.dto.OcrDoc;
import ma.axa.inner.ged.mobile.scan.dto.OcrDocDto;

public interface MobileScanDocService {

	void indexDocument(String token);

	OcrDoc uploadFileTemp(MultipartFile file1, MultipartFile file2, OcrDocDto ocrDocumentDto, String token);

}
