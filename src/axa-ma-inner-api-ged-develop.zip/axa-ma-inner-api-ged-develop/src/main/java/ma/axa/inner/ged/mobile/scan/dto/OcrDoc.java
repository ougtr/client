package ma.axa.inner.ged.mobile.scan.dto;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity(name = "OcrDoc")
@Table(name = "OCRDOC")
public class OcrDoc {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	private Integer id;
	@Column(name = "TYPEDOC")
	private String typeDocument;
	@Column(name = "TOKEN")
	private String token;
	@Column(name = "NOMDOC")
	private String nomDocument;
	@Column(name = "DATEMAJ")
	private Date dateMaj;
	@Column(name = "USER")
	private String user;
	@Column(name = "NOM")
	private String nom;
	@Column(name = "PRENOM")
	private String prenom;
	@Column(name = "NUMCIN")
	private String numCin;
	@Column(name = "ADRESSE")
	private String adresse;
	@Column(name = "DATEVAL")
	private String dateFinValidite;
	@Column(name = "DATENAIS")
	private String dateNaissance;
	@Column(name = "LIEUNAIS")
	private String lieuNaissance;
	@Column(name = "SEXE")
	private String sexe;
	@Column(name = "NPERMIS")
	private String numeroPermis;
	@Column(name = "Marque")
	private String marque;
	@Column(name = "TYPE")
	private String type;
	@Column(name = "MODELE")
	private String modele;
	@Column(name = "TYPECARB")
	private String typeCarburant;
	@Column(name = "NBCYLI")
	private String nombreCylindres;
	@Column(name = "NIMMATRI")
	private String numeroImmatriculation;
	@Column(name = "DATEDLV")
	private String dateDelivrance;
	@Column(name = "VILLEDLV")
	private String villeDelivrance;
	@Column(name = "GENRE")
	private String genre;
	@Column(name = "PFISCALE")
	private String puissanceFiscale;
	@Column(name = "IMMATANT")
	private String immatriculationAnterieure;
	@Column(name = "PREMEC")
	private String premiereMiseEnCirculation;
	@Column(name = "PTAC")
	private String ptac;
	@Column(name = "POIDVIDE")
	private String poidsvide;
	@Column(name = "PTRA")
	private String ptra;
	@Column(name = "RESTRICT")
	private String restrictions;
	@Column(name = "MCMAROC")
	private String mcAuMaroc;
	@Column(name = "MUTATION")
	private String mutationLe;
	@Column(name = "JSON")
	private String json;
	@Column(name = "IDALRECTO")
	private String idAlfrescoRecto;
	@Column(name = "IDALVERSO")
	private String idAlfrescoVerso;
	@Column(name = "STATUT")
	private String statut;

}
