package ma.axa.inner.ged.repository.production.health.dim;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.production.health.dim.DocumentHealthDIMEs;
import ma.axa.inner.ged.dto.production.health.dim.DocHealthDIMSearchParams;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.repository.ElasticSearchNewRepository;
import ma.axa.inner.ged.util.ElasticSearchUtils;
import ma.axa.inner.ged.util.constants.ElasticConstants;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static ma.axa.inner.ged.util.ElasticSearchUtils.termQuery;

@Repository
@RequiredArgsConstructor
@Slf4j
public class HealthDIMElasticRepository {
    private final BrancheProperties healthDIMProperties;
    private final ElasticSearchNewRepository elasticRepository;


    /**
     * Create new Document in ElasticSearch
     */
    public String createNewDocument(final String documentId, final DocumentHealthDIMEs metaData)
            throws ElasticsearchException, IOException {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("ID Document must not be blank");
        if (metaData == null)
            throw new NullPointerException("Document Health DIM must not be null");

        try {
            if (exists(documentId)) {
                throw new ResourceAlreadyExist(GlobalConstants.URI_RECORDE_ALREADY_EXIST,
                        "Document with id {0} already exist",
                        new String[]{documentId});
            }

            var created = elasticRepository.createNewDocument(healthDIMProperties.getEsDocIndex(), documentId, metaData);
            if (created != null) {
                log.info("[es-repo] Successfully created new document Health DIM with id: {}", documentId);
                return created;
            }
        } catch (Exception e) {
            log.error("[es-repo] Error creating new document for id: {}, err: {} ", documentId, e.getMessage());
            throw e;
        }
        return null;
    }

    // Update

    public boolean updateDocument(final String documentId, final DocumentHealthDIMEs metaData)
            throws ElasticsearchException, IOException {
        return updateDocument(documentId, metaData, false);
    }


    /**
     * Update Document in ElasticSearch
     */
    private boolean updateDocument(final String documentId, final DocumentHealthDIMEs metaData,
                                   boolean isUpsert)
            throws ElasticsearchException, IOException {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("Document ID must not be blank");
        if (metaData == null)
            throw new NullPointerException("Document Health DIM must not be null");

        try {
            var response = elasticRepository.updateDocument(healthDIMProperties.getEsDocIndex(), documentId, metaData,
                    isUpsert,
                    DocumentHealthDIMEs.class);
            log.info("[es-repo] Successfully updatd new document Health DIM with id: {}", documentId);
            return response;
        } catch (Exception e) {
            log.error("[es-repo] Error updating  document with id:{}, err: {}", documentId, e.getMessage());
            throw e;
        }
    }

    /**
     * find document by criteria
     *
     * @param searchParams
     */

    public SearchResponse<DocumentHealthDIMEs> findByCriteria(DocHealthDIMSearchParams searchParams, boolean findAll) {
        elasticRepository.refreshIndex(healthDIMProperties.getEsDocIndex());
        try {
            var boolQuery = new BoolQuery.Builder();
            var query = ElasticSearchUtils.getQueryForMultiSearch(constructSearchMap(searchParams));
            boolQuery.must(query);
            int from = searchParams.getPageNumber() * searchParams.getPageSize();

            var searchRequest = new SearchRequest.Builder();
            searchRequest.index(healthDIMProperties.getEsDocIndex())
                    .query(q -> q
                            .bool(boolQuery.build()));

            if (!findAll) {
                searchRequest.from(from).size(searchParams.getPageSize());
            }
            return elasticRepository.search(searchRequest, DocumentHealthDIMEs.class);
        } catch (Exception e) {
            log.error("Error during elastic search", e);
            return null;
        }
    }


    /**
     * Check if document id exist
     *
     * @param documentId
     */
    public boolean exists(String documentId) {
        return elasticRepository.existsDocument(healthDIMProperties.getEsDocIndex(), documentId);
    }
    private Map<String, String> constructSearchMap(DocHealthDIMSearchParams searchParams) {
        Map<String,String> searchMap= new HashMap<>();
        searchMap.put(ElasticConstants.QUOTATION_NUMBER, searchParams.getIdQuotation());
        searchMap.put(ElasticConstants.TYPE_DOCUMENT_LABEL, searchParams.getTypeDocument());
        searchMap.put(ElasticConstants.POLICY_NUMBER, searchParams.getPolicyNumber());
        return searchMap;
    }

    public Optional<DocumentHealthDIMEs> findById(String id) {
        try {
            elasticRepository.refreshIndex(healthDIMProperties.getEsDocIndex());
            return Optional.of(elasticRepository.findById(healthDIMProperties.getEsDocIndex(), id, DocumentHealthDIMEs.class));
        } catch (Exception e) {
            log.error("[es-repo] Error find document with id:{}, err: {}", id, e.getMessage());
            return Optional.empty();
        }
    }

    public DocumentHealthDIMEs findOneDocumentByReference(String reference) {
        elasticRepository.refreshIndex(healthDIMProperties.getEsDocIndex());
        BoolQuery.Builder boolQuery = new BoolQuery.Builder();
        boolQuery.must(termQuery(ElasticConstants.REFERENCE, reference));
        try {
            var searchRequest = new SearchRequest.Builder();
            searchRequest.index(healthDIMProperties.getEsDocIndex())
                    .query(q -> q.bool(boolQuery.build()));
            var searchResponse = elasticRepository.search(searchRequest, DocumentHealthDIMEs.class);
            if (searchResponse != null && !searchResponse.hits().hits().isEmpty()) {
                return searchResponse.hits().hits().get(0).source();
            }
        } catch (Exception e) {
            log.error("[es-repo] Error during search by reference: {} , err: {}", reference, e.getMessage());
        }
        return null;
    }

    public boolean deleteDocument(String documentId) {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("documentId must not be blank");
        try {
            var response = elasticRepository.deleteDocument(healthDIMProperties.getEsDocIndex(), documentId);
            if (response) {
                log.debug("[es-repo]Successfully deleted document Health DIM with id: {}", documentId);
                return true;
            }
        } catch (Exception e) {
            log.warn("[es-repo] Error deleting document by id: {}, err: {}", documentId, e.getMessage());
        }
        return false;
    }
}