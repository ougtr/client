package ma.axa.inner.ged.helper;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RequestQuery {
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer size=500;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer from = 0;
	private Query query;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<Map<String,SortConfig>> sort;
}
