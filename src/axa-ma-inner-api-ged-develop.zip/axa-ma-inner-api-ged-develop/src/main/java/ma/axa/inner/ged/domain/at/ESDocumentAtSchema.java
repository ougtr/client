package ma.axa.inner.ged.domain.at;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import ma.axa.inner.ged.domain.Shards;

@Data
public class ESDocumentAtSchema {
    private int took;
    @JsonProperty("timed_out")
    private Boolean timedOut;
    @JsonProperty("_shards")
    private Shards shards;
    private DocClaimAtHits hits;
}
