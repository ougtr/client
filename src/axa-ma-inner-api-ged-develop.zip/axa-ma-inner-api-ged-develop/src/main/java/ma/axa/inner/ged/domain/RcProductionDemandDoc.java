package ma.axa.inner.ged.domain;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class RcProductionDemandDoc {

    @NotNull(message = "La reference de la demande est obligatoire")
    private String reference;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@NotNull(message = "la date d'effet est obligatoire")
	private LocalDate effectDate;
	
}
