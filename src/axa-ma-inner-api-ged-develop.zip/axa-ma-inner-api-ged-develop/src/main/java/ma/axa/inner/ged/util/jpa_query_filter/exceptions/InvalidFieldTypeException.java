package ma.axa.inner.ged.util.jpa_query_filter.exceptions;

public class InvalidFieldTypeException extends RuntimeException {
    public InvalidFieldTypeException(String msg) {
        super(msg);
    }
}
