package ma.axa.inner.ged.mobile.scan.dto;

import java.util.Date;

import lombok.Data;

@Data
public class OcrDocDto {

	private Integer id;

	private String typeDocument;

	private String token;

	private String nomDocument;

	private Date dateMaj;

	private String user;

	private String nom;

	private String prenom;

	private String numCin;

	private String adresse;

	private String dateFinValidite;

	private String dateNaissance;

	private String lieuNaissance;

	private String sexe;

	private String numeroPermis;

	private String dateDelivrance;

	private String villeDelivrance;

	private String genre;

	private String puissanceFiscale;

	private String immatriculationAnterieure;

	private String premiereMiseEnCirculation;

	private String marque;

	private String type;

	private String modele;

	private String typeCarburant;

	private String nombreCylindres;

	private String numeroImmatriculation;
	
	private String ptac;

	private String poidsvide;

	private String ptra;

	private String restrictions;

	private String mcAuMaroc;

	private String mutationLe;

	private String usage;

	private String json;

	private String idAlfrescoRecto;

	private String idAlfrescoVerso;

	private String statut;

}
