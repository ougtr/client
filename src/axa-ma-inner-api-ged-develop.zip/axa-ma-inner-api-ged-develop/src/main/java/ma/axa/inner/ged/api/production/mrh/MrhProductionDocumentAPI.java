package ma.axa.inner.ged.api.production.mrh;

import javax.validation.Valid;

import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import ma.axa.inner.ged.domain.ProductionTypeDoc;
import ma.axa.inner.ged.service.production.ProductionDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Tag(name = GlobalConstants.MRH_GED_APIS_TAG)
@RestController
@RequestMapping("/v1/production/mrh/documents")
@RequiredArgsConstructor
public class MrhProductionDocumentAPI {

    private final ProductionDocumentService documentService;

    @Operation(summary = "Upload new production mrh document and index meta-data")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document ID", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = ProductionTypeDoc.class)) }),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content) })
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> uploadMrhProductionDocuments(
            @ParameterObject @ModelAttribute @Valid ProductionTypeDoc documentMeta,
            @RequestParam(value = "file", required = true) MultipartFile file) {
        var createdDocument = documentService.uploadFile(file,documentMeta);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdDocument);
    }

    @GetMapping(path = "/{docId}")
    public ResponseEntity<Resource> downloadDocument(@PathVariable(name = "docId", required = true) String docId) {
        var document = documentService.downloadFile(docId);
        return ResponseEntity.status(HttpStatus.OK).body(document);
    }
   
}
