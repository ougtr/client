package ma.axa.inner.ged.claim.health.dto;

import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocumentUploadInvoiceRequest {
 
 
	private String referenceDossier;
	private String nom;
	private String prenom;
	private String codePrestataire;
	private String codeMedcin;
	private String inpe;
	private String idGed;
	private BigDecimal montant;
	@DateTimeFormat(iso=ISO.DATE)
	private Date dateFacture;
	@DateTimeFormat(iso=ISO.DATE)
	private Date dateConsultation;
	private String type;
 
 
}
