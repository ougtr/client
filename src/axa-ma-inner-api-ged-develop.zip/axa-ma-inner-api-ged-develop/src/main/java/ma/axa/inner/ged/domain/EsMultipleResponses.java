package ma.axa.inner.ged.domain;

import lombok.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode
public class EsMultipleResponses {
    private Integer took;
    private Boolean errors;
    private List<Map.Entry<String,ESResponse>> items;
}
