package ma.axa.inner.ged.mapper;


import ma.axa.inner.ged.domain.SearchLsPrevoyanceAs400;
import ma.axa.inner.ged.dto.SearchLsPrevoyanceResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface LsPrevoyanceMapper {

    @Mapping(source = "ideged",target = "idAlfresco")
    @Mapping(source = "idgest",target = "idGestion")
    @Mapping(source = "cplglg",target = "ligneNumber")
    @Mapping(source = "typdoc",target = "typeDocument")
    @Mapping(source = "nomdoc",target = "libDocument")
    @Mapping(source = "usercr",target = "uploadedBy")
    @Mapping(source = "acdcre",target = "CreationDate")
    public SearchLsPrevoyanceResponse toDto(SearchLsPrevoyanceAs400 searchLsPrevoyanceAs400);

    public List<SearchLsPrevoyanceResponse> toDto(List<SearchLsPrevoyanceAs400> searchLsPrevoyanceAs400);
}
