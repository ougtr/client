package ma.axa.inner.ged.mobile.scan.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MobileScanDocReqDto {
    private String idAlfresco;
    private String numSinistre;
    @NotBlank(message = "Type document est obligatoire !")
    private String typeDocument;
    private String nomDocument;
    private String uploadedby;
    private String repertoire;
}
