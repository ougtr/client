package ma.axa.inner.ged.config.filter.wrapper;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

public class GZipResponseWrapper extends HttpServletResponseWrapper {

	private HttpServletResponse response;
	private GZipOutputStream gzipOutputStream;
	private PrintWriter writer;

	public GZipResponseWrapper(HttpServletResponse response) throws IOException {
		super(response);
		this.response = response;
	}

	@Override
	public ServletOutputStream getOutputStream() throws IOException {
		if (gzipOutputStream == null) {
			gzipOutputStream = new GZipOutputStream(response);
		}
		return gzipOutputStream;
	}

	@Override
	public PrintWriter getWriter() throws IOException {
		if (writer == null) {
			writer = new PrintWriter(new OutputStreamWriter(new GZipOutputStream(response), StandardCharsets.UTF_8));
		}
		return writer;
	}

	@Override
	public void setContentLength(int contentLength) {
		// Do nothing
	}

	@Override
	public void flushBuffer() throws IOException {
		gzipOutputStream.flush();
	}

	public void finishResponse() throws IOException {
		if (gzipOutputStream != null) {
			gzipOutputStream.close();
		}
		if (writer != null) {
			writer.close();
		}
	}

}
