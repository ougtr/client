package ma.axa.inner.ged.mapper.production.fleet;

import ma.axa.inner.ged.dto.production.fleet.DocFleetReq;
import ma.axa.inner.ged.mapper.AlfrescoPropsMapper;

import java.util.Collections;
import java.util.Map;

public class FleetAlfrescoMapper extends AlfrescoPropsMapper {

	private FleetAlfrescoMapper() throws InstantiationException {
		throw new InstantiationException("Instances of this type are forbidden");
	}

	// Folders

	public static Map<String, Object> toFolderProperties(DocFleetReq metaData) {
		return toFolderProperties(metaData, null);
	}

	public static Map<String, Object> toFolderProperties(DocFleetReq metaData, Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();

		var alfrescoProps = AlfrescoFolderProperties.builder()
				.numeroPoliceDossier(metaData.getPolicyNumber())
				.build();

		return toFolderProperties(properties, alfrescoProps);
	}

	// Documents

	public static Map<String, Object> toDocumentProperties(DocFleetReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocFleetReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numPolice(metaData.getPolicyNumber())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}
}