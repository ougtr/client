package ma.axa.inner.ged.util;

public enum TypeDocumentEnum {
	
	cin, permis, carte_grise

}
