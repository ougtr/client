package ma.axa.inner.ged.claim.common.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.chemistry.opencmis.client.api.Folder;

import java.util.Map;



@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GedFolderProperties {
    private Map<String, Object> properties;
    private Folder folder;
}
