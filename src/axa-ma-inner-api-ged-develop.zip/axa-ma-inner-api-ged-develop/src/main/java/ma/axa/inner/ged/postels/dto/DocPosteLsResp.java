package ma.axa.inner.ged.postels.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.*;


@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class DocPosteLsResp extends DocPosteLsReq {
	private String idAlfresco;
	@NotBlank(message = "CreatedBy est requis")
	private String createdAt;
	private String updatedAt;
}
