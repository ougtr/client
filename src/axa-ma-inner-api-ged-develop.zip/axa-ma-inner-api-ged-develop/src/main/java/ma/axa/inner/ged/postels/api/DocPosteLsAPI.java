package ma.axa.inner.ged.postels.api;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.postels.constants.GlobalConstants;
import ma.axa.inner.ged.postels.dto.*;
import ma.axa.inner.ged.postels.service.DocPosteLsService;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.io.IOException;
import java.util.List;


@Tag(name = GlobalConstants.POSTE_LS_GED_APIS_TAG)

@RestController
@RequestMapping("/v1/postels/")
@RequiredArgsConstructor
@Slf4j
public class DocPosteLsAPI {


	private final DocPosteLsService DocumentService;


	@Operation(summary = "Poste-ls Upload Document and index meta-data")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Document ID", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = DocPosteLsReq.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid request", content = @Content) })
	@PostMapping(path = "souscription/documents",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<DocPosteLsResp> uploadPosteLsDoc(
			@ParameterObject @ModelAttribute @Valid DocPosteLsReq documentLsReq,
			@Parameter(description = "Content of the document") @RequestPart(value = "file") MultipartFile file) throws IOException {
		log.info("[api] Start uploading file: {}, size: {} bytes", file.getOriginalFilename(), file.getSize());

		var createdDocument = DocumentService.uploadDocWithMetaData(documentLsReq, file);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdDocument);
	}

	@Operation(summary = "Download a Poste Ls document by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was downloaded", content = {
					@Content(mediaType = MediaType.APPLICATION_OCTET_STREAM_VALUE, schema = @Schema(implementation = Resource.class, format = "binary")) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping(value = "souscription/documents/{document_id}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<Resource> downloadPosteLsDocContent(
			@Parameter(required = true, description = "The document id (Alfresco ID)") @NotBlank(message = "Document id must not be empty") @PathVariable(value = "document_id") String documentId) {
		return DocumentService.downloadFile(documentId);
	}

	@Operation(summary = "Search PosteLs Metadata by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Documents metadata was found", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = Page.class)) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping(value = "souscription/documents/metadata/{document_id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DocPosteLsResp> searchPosteLsMetadataByDocumentId(
			@NotBlank(message = "Document id must not be empty") @PathVariable(value = "document_id") String documentId){
		var pageResult = DocumentService.getMetadataById(documentId);
		return ResponseEntity.ok(pageResult);
	}

	@Operation(summary = "Search PosteLs Metadata by Criteria")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Documents metadata was found", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = DocPosteLsResp.class)) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@PostMapping(value = "souscription/documents/metadata", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<DocPosteLsResp>> searchPosteLsMetadataByCriteria(@RequestBody SearchEsReq searchParams) {
		try {
		List<DocPosteLsResp> results = DocumentService.getMetadataByCriteria(searchParams);
		return ResponseEntity.ok(results);
	} catch (Exception e) {
		log.error("Error while searching documents: {}", e.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	}
}

	@Operation(summary = "Update Poste LS document by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was updated", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = DocPosteLsResp.class)) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@PutMapping(value = "souscription/documents/{document_id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DocPosteLsResp> updatePosteLsDoc(
			@NotBlank(message = "Document id must not be empty") @PathVariable(value = "document_id") String documentId,
			@Valid @RequestBody DocPosteLsUpdateReq documentReq) {
		var updatedDoc = DocumentService.updateDocument(documentId, documentReq);
		return ResponseEntity.ok(updatedDoc);
	}


	@Operation(summary = "Delete Poste Ls document by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was deleted", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = String.class)) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@DeleteMapping(value = "souscription/documents/{document_id}")
	public ResponseEntity<String> deleteDocument(
			@NotBlank(message = GlobalConstants.ERROR_MSG_POSTELS_ID_NOT_BLANK) @PathVariable(value = "document_id") String documentId) {
		return ResponseEntity.ok(DocumentService.deleteDocument(documentId));
	}

}
