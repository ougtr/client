package ma.axa.inner.ged.postels.repository;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.postels.constants.GlobalConstants;
import ma.axa.inner.ged.postels.domain.DocPosteLsEs;
import ma.axa.inner.ged.postels.dto.DocPosteLsResp;
import ma.axa.inner.ged.postels.dto.SearchEsReq;
import ma.axa.inner.ged.repository.ElasticSearchNewRepository;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.util.Optional;

import static ma.axa.inner.ged.util.ElasticSearchUtils.addTermQuery;
import static ma.axa.inner.ged.util.ElasticSearchUtils.termQuery;

@Repository
@RequiredArgsConstructor
@Slf4j
public class DocPosteLsElasticSearchRepository {
    private final BrancheProperties posteLsProperties;
    private final ElasticSearchNewRepository elasticRepository;


    /**
     * Create new Document in ElasticSearch
     */
    public String createNewDocument(final String documentId, final DocPosteLsEs metaData)
            throws ElasticsearchException, IOException {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("ID Document must not be blank");
        if (metaData == null)
            throw new NullPointerException("Document Poste LS must not be null");

        try {
            if (exists(documentId)) {
                throw new ResourceAlreadyExist(GlobalConstants.URI_RECORDE_ALREADY_EXIST,
                        "Document with id {0} already exist",
                        new String[] { documentId });
            }
            var created = elasticRepository.createNewDocument(posteLsProperties.getEsDocIndex(), documentId, metaData);
            if (created != null) {
                log.info("[es-repo] Successfully created new document poste ls with id: {}", documentId);
                return created;
            }
        } catch (Exception e) {
            log.error("[es-repo] Error creating new document for id: {}, err: {} ", documentId, e.getMessage());
            throw e;
        }
        return null;
    }

    // Update

    public boolean updateDocument(final String documentId, final DocPosteLsEs metaData)
            throws ElasticsearchException, IOException {
        return updateDocument(documentId, metaData, false);
    }


    /**
     * Update Document in ElasticSearch
     */
    private boolean updateDocument(final String documentId, final DocPosteLsEs metaData,
                                   boolean isUpsert)
            throws ElasticsearchException, IOException {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("Document ID must not be blank");
        if (metaData == null)
            throw new NullPointerException("Document Poste ls must not be null");

        try {
            var response = elasticRepository.updateDocument(posteLsProperties.getEsDocIndex(), documentId, metaData,
                    isUpsert,
                    DocPosteLsEs.class);
            log.info("[es-repo] Successfully updatd new document poste ls with id: {}", documentId);
            return response;
        } catch (Exception e) {
            log.error("[es-repo] Error updating  document with id:{}, err: {}", documentId, e.getMessage());
            throw e;
        }
    }

    /**
     * find document by criteria
     *
     * @param searchParams
     */

    public SearchResponse<DocPosteLsResp> findByCriteria(SearchEsReq searchParams) {
        // Validation des paramètres
        if (searchParams == null) {
            throw new IllegalArgumentException("Search parameters must not be null");
        }
        if (searchParams.getPageNumber() < 0 || searchParams.getPageSize() <= 0) {
            throw new IllegalArgumentException("Invalid pagination parameters: pageNumber and pageSize must be >= 0 and > 0 respectively");
        }

        // Calculer la pagination
        int from = searchParams.getPageNumber() * searchParams.getPageSize();
        if (from < 0) {
            throw new IllegalArgumentException("Page number is too large, resulting in negative `from` value");
        }

        refreshIndex(); // Assurez-vous que cette méthode est idempotente et bien gérée.

        try {
            // Construire la requête booléenne
            BoolQuery.Builder boolQuery = new BoolQuery.Builder();

            // Ajouter les critères générés par `getQueryForMultiSearch`
            var query = getQueryForMultiSearch(searchParams);
            if (query != null) {
                boolQuery.must(query);
            }

            // Construire la requête de recherche
            SearchRequest.Builder searchRequest = new SearchRequest.Builder();
            searchRequest.index(posteLsProperties.getEsDocIndex()) // Index Elasticsearch
                    .query(q -> q.bool(boolQuery.build())) // Ajout de la requête booléenne
                    .from(from) // Définir la pagination (début)
                    .size(searchParams.getPageSize()); // Taille de page

            // Exécuter la recherche via le repository
            return elasticRepository.search(searchRequest, DocPosteLsResp.class);

        } catch (Exception e) {
            log.error("[ElasticSearch-Repository] Error during search with criteria: {}, error: {}", searchParams, e.getMessage());
            throw new RuntimeException("Failed to execute search", e); // Lever une exception pour les erreurs inattendues
        }
    }


    /**
     * Check if document id exist
     *
     * @param documentId
     */
    public boolean exists(String documentId) {
        return elasticRepository.existsDocument(posteLsProperties.getEsDocIndex(), documentId);
    }

    /**
     * Refresh Index
     */
    public void refreshIndex() {
        try {
            elasticRepository.refreshIndex(posteLsProperties.getEsDocIndex());
        } catch (Exception e) {
            log.error("[ES] Error during refresh index, err: {}", e.getMessage());
        }
    }

    // =========== Utils ===========

    public static Query getQueryForMultiSearch(SearchEsReq searchParams) {
        var boolQuery = new BoolQuery.Builder();
        // Ajouter des critères de `term` pour chaque champ si les valeurs existent
        addTermQuery(GlobalConstants.ID_ALFRESCO, searchParams.getIdAlfresco(), boolQuery);
        addTermQuery(GlobalConstants.NUM_POLICE, searchParams.getNumPolice(), boolQuery);
        addTermQuery(GlobalConstants.NUM_QUOTATION, searchParams.getNumQuotation(), boolQuery);
        addTermQuery(GlobalConstants.REFERENCE, searchParams.getReference(), boolQuery);
        addTermQuery(GlobalConstants.INTEGRATION_ID, searchParams.getIntegrationId(), boolQuery);
        addTermQuery(GlobalConstants.AVENANT_ID, searchParams.getAvenantId(), boolQuery);
        return boolQuery.build()._toQuery();
    }


    public Optional<DocPosteLsEs> findById(String id) {
        try {
            refreshIndex();
            return Optional.of(elasticRepository.findById(posteLsProperties.getEsDocIndex(), id, DocPosteLsEs.class));
        } catch (Exception e) {
            log.error("[es-repo] Error find document with id:{}, err: {}", id, e.getMessage());
            return Optional.empty();
        }
    }

    public DocPosteLsEs findOneDocumentByReference(String reference) {
        refreshIndex();
        BoolQuery.Builder boolQuery = new BoolQuery.Builder();
        boolQuery.must(termQuery(GlobalConstants.REFERENCE, reference));
        try {
            var searchRequest = new SearchRequest.Builder();
            searchRequest.index(posteLsProperties.getEsDocIndex())
                    .query(q -> q.bool(boolQuery.build()));
            var searchResponse = elasticRepository.search(searchRequest, DocPosteLsEs.class);
            if (searchResponse != null && !searchResponse.hits().hits().isEmpty()) {
                return searchResponse.hits().hits().get(0).source();
            }
        } catch (Exception e) {
            log.error("[es-repo] Error during search by reference: {} , err: {}", reference, e.getMessage());
        }
        return null;
    }

    public boolean deleteDocument(String documentId) {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("documentId must not be blank");
        try {
            var response = elasticRepository.deleteDocument(posteLsProperties.getEsDocIndex(), documentId);
            if (response) {
                log.debug("[es-repo]Successfully deleted document poste ls with id: {}", documentId);
                return true;
            }
        } catch (Exception e) {
            log.warn("[es-repo] Error deleting document by id: {}, err: {}", documentId, e.getMessage());
        }
        return false;
    }
}


