package ma.axa.inner.ged.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum BoolQueryType {
    BOOL("bool"),
    REQUIRED_MATCH("must"),
    OPTIONAL_MATCH("should");

    final String value;
}
