package ma.axa.inner.ged.helper;

import com.beust.jcommander.internal.Lists;
import com.fasterxml.jackson.core.JsonProcessingException;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.ConcurrentCompletableFuture;
import ma.axa.inner.ged.domain.*;
import ma.axa.inner.ged.domain.at.DocClaimAtHit;
import ma.axa.inner.ged.domain.at.DocumentSinistreATES;
import ma.axa.inner.ged.dto.CimaRequestDocument;
import ma.axa.inner.ged.dto.DocClaimAtReqDto;
import ma.axa.inner.ged.dto.at.DocumentMetadataQueryDto;
import ma.axa.inner.ged.dto.at.PageDto;
import ma.axa.inner.ged.enums.AutoAtBranchEnum;
import ma.axa.inner.ged.enums.ESBulkOperationsEnum;
import ma.axa.inner.ged.enums.ESOrderEnum;
import ma.axa.inner.ged.exception.ESIndexingException;
import ma.axa.inner.ged.helper.update.ESDoc;
import ma.axa.inner.ged.helper.update.ESUpdateQuery;
import ma.axa.inner.ged.helper.updateAt.ESAtDoc;
import ma.axa.inner.ged.helper.updateAt.ESAtUpdateQuery;
import ma.axa.inner.ged.mapper.DocumentMapper;
import ma.axa.inner.ged.repository.ElasticSearchDocumentRepository;
import ma.axa.inner.ged.util.*;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class ElasticSearchHelper {

    private final ElasticSearchDocumentRepository elasticSearchDocumentRepository;
    private final EsPropertiesAutoDocument esPropertiesAutoDocument;
    private final EsPropertiesAtDoc esPropertiesAtDoc;
    private final EsPropertiesCimaDoc esPropertiesCimaDoc;

    public List<DossierSinistreAuto> getDossierSinAutoList(DossierSinistreAuto dossierSinistreAuto) {
        log.info("Start: Search list of dossier");
        return elasticSearchDocumentRepository
                .getDossiers(QueryBuilder.dossierSinistreAutoRequestQueryBuilder(dossierSinistreAuto))
                .getHits()
                .getHits()
                .stream()
                .map(DossierSinistreAutoHit::getSource)
                .collect(Collectors.toList());
    }

    public PageDto<DocClaimAtReqDto> searchInDocumentsListsByQuery(IndexOrPathToUse indexOrPathToUse, DocumentMetadataQueryDto metadata, Integer page, Integer size) {
        log.info("Start : Search list of documents by query '{}'", metadata);
        var query = DocumentMapper.mapFromMetadataQueryToATES(metadata);
        final var retrievedValues = ObjectUtils.extractFieldValues(query);
        var orQuery = DocumentMapper.mapMetadataOrQuery(metadata);
        final var valuesMustBetweenThemOr = ObjectUtils.extractFieldValues(orQuery);
        final var mustNotBeValues = new HashMap<String, Object>();
        final var isTemporaryLiteral = "isTemporary";
        final var isReturnedROLiteral = "isReturnedRO";
        var totalElements = 0;
        if (org.springframework.util.CollectionUtils.isEmpty(retrievedValues)) {
            return PageDto.<DocClaimAtReqDto>builder()
                    .pageNumber(page)
                    .totalElements(0)
                    .totalPages(0)
                    .content(CollectionUtils.emptyCollection())
                    .build();
        }
        var listOfDocuments = new ArrayList<DocumentSinistreATES>();
        if (retrievedValues.containsKey(isReturnedROLiteral) && Objects.equals(retrievedValues.get(isReturnedROLiteral), false)) {
            retrievedValues.remove(isReturnedROLiteral);
            mustNotBeValues.put(isReturnedROLiteral, true);
        }

        if (IndexOrPathToUse.TEMPORARY.equals(indexOrPathToUse)) {
            retrievedValues.put(isTemporaryLiteral, true);
            var requestQuery = QueryBuilder.documentATRequestQueryBuilderWithMap(retrievedValues, mustNotBeValues, valuesMustBetweenThemOr, page, size);
            QueryBuilder.addSortBy(requestQuery, "uploadDateTimeStamp", ESOrderEnum.ASC);
            final var getAtDocuments = elasticSearchDocumentRepository.getAtDocuments(getAtIndex(indexOrPathToUse, false), requestQuery);
            totalElements = getAtDocuments.getHits().getTotal();
            listOfDocuments.addAll(
                    getAtDocuments.getHits().getHits().stream().map(DocClaimAtHit::getSource).collect(Collectors.toList())
            );
        } else {
            retrievedValues.remove(isTemporaryLiteral);
            final var defaultRequestQuery = QueryBuilder.documentATRequestQueryBuilderWithMap(retrievedValues, mustNotBeValues, valuesMustBetweenThemOr, page, size);
            retrievedValues.put(isTemporaryLiteral, false);
            final var temporaryRequestQuery = QueryBuilder.documentATRequestQueryBuilderWithMap(retrievedValues, mustNotBeValues, valuesMustBetweenThemOr, page, size);

            final var defaultIndex = getAtIndex(IndexOrPathToUse.DEFAULT, false);
            final var temporaryIndex = getAtIndex(IndexOrPathToUse.TEMPORARY, false);
            defaultRequestQuery.setSize(null);
            defaultRequestQuery.setFrom(null);
            temporaryRequestQuery.setSize(null);
            temporaryRequestQuery.setFrom(null);
            final var countFromDefault = elasticSearchDocumentRepository.countAtDocumentsByQuery(defaultIndex, defaultRequestQuery).getCount();
            final var countFromTemporary = elasticSearchDocumentRepository.countAtDocumentsByQuery(temporaryIndex, temporaryRequestQuery).getCount();
            final var fromWhereToWhereInDefaultAndTemporary = PaginationATHelper.getObjectOfStartAndSizeToGetFrom(countFromDefault, countFromTemporary, size, page);

            defaultRequestQuery.setFrom(fromWhereToWhereInDefaultAndTemporary.getKey().getKey());
            defaultRequestQuery.setSize(fromWhereToWhereInDefaultAndTemporary.getValue().getKey());

            temporaryRequestQuery.setFrom(fromWhereToWhereInDefaultAndTemporary.getKey().getValue());
            temporaryRequestQuery.setSize(fromWhereToWhereInDefaultAndTemporary.getValue().getValue());
            // sort from last uploaded
            QueryBuilder.addSortBy(defaultRequestQuery, "uploadDateTimeStamp", ESOrderEnum.DESC);
            QueryBuilder.addSortBy(temporaryRequestQuery, "uploadDateTimeStamp", ESOrderEnum.DESC);
            QueryBuilder.addSortBy(defaultRequestQuery, "dateUpload", ESOrderEnum.DESC);
            listOfDocuments.addAll(elasticSearchDocumentRepository
                    .getAtDocuments(defaultIndex, defaultRequestQuery)
                    .getHits()
                    .getHits()
                    .stream().map(DocClaimAtHit::getSource).collect(Collectors.toList())
            );
            listOfDocuments.addAll(elasticSearchDocumentRepository
                    .getAtDocuments(temporaryIndex, temporaryRequestQuery)
                    .getHits()
                    .getHits()
                    .stream().map(DocClaimAtHit::getSource).collect(Collectors.toList())
            );

            listOfDocuments = listOfDocuments.stream().sorted((o1, o2) -> comparator(ESOrderEnum.ASC, o1, o2)).collect(Collectors.toCollection(ArrayList::new));
            totalElements = countFromDefault + countFromTemporary;
        }
        log.info("End : Search list of documents by query '{}'", query);

        return PageDto.<DocClaimAtReqDto>builder()
                .totalElements(totalElements)
                .pageNumber(page)
                .totalPages(Math.floorDiv(totalElements, size) + 1)
                .content(
                        listOfDocuments
                                .stream()
                                .map(DocumentMapper::mapFromDocumentATESToDocClaimAtReqDto)
                                .collect(Collectors.toList())
                )
                .build();
    }

    public List<DocumentSinistreATES> getAllInDocumentsMetadataAt(IndexOrPathToUse indexOrPathToUse, DocumentMetadataQueryDto metadata) {
        log.info("Start : Search list of documents by query '{}'", metadata);
        var query = DocumentMapper.mapFromMetadataQueryToATES(metadata);
        final var retrievedValues = ObjectUtils.extractFieldValues(query);
        var orQuery = DocumentMapper.mapMetadataOrQuery(metadata);
        final var valuesMustBetweenThemOr = ObjectUtils.extractFieldValues(orQuery);
        final var mustNotBeValues = new HashMap<String, Object>();
        final var isTemporaryLiteral = "isTemporary";
        final var isReturnedROLiteral = "isReturnedRO";
        List<DocumentSinistreATES> listOfDocuments = Lists.newArrayList();

        if (org.springframework.util.CollectionUtils.isEmpty(retrievedValues)) {
            return listOfDocuments;
        }
        if (retrievedValues.containsKey(isReturnedROLiteral) && Objects.equals(retrievedValues.get(isReturnedROLiteral), false)) {
            retrievedValues.remove(isReturnedROLiteral);
            mustNotBeValues.put(isReturnedROLiteral, true);
        }
        final var defaultIndex = getAtIndex(IndexOrPathToUse.DEFAULT, false);
        final var temporaryIndex = getAtIndex(IndexOrPathToUse.TEMPORARY, false);

        if (IndexOrPathToUse.TEMPORARY.equals(indexOrPathToUse)) {
            retrievedValues.put(isTemporaryLiteral, true);
            var requestQuery = QueryBuilder.documentATRequestQueryBuilderWithMap(retrievedValues, mustNotBeValues, valuesMustBetweenThemOr, 0, GlobalConstants.PAGE_SIZE_ELASTIC_SEARCH);
            final var countFromTemporary = elasticSearchDocumentRepository.countAtDocumentsByQuery(temporaryIndex, requestQuery).getCount();
            requestQuery.setSize(countFromTemporary);
            requestQuery.setFrom(0);
            QueryBuilder.addSortBy(requestQuery, "uploadDateTimeStamp", ESOrderEnum.ASC);

            final var getAtDocuments = elasticSearchDocumentRepository.getAtDocuments(getAtIndex(indexOrPathToUse, false), requestQuery);
            listOfDocuments.addAll(
                    getAtDocuments.getHits().getHits().stream().map(DocClaimAtHit::getSource).collect(Collectors.toList())
            );
        } else {
            retrievedValues.remove(isTemporaryLiteral);
            final var defaultRequestQuery = QueryBuilder.documentATRequestQueryBuilderWithMap(retrievedValues, mustNotBeValues, valuesMustBetweenThemOr, 0, GlobalConstants.PAGE_SIZE_ELASTIC_SEARCH);
            retrievedValues.put(isTemporaryLiteral, false);
            final var temporaryRequestQuery = QueryBuilder.documentATRequestQueryBuilderWithMap(retrievedValues, mustNotBeValues, valuesMustBetweenThemOr, 0, GlobalConstants.PAGE_SIZE_ELASTIC_SEARCH);
            defaultRequestQuery.setSize(null);
            defaultRequestQuery.setFrom(null);
            temporaryRequestQuery.setSize(null);
            temporaryRequestQuery.setFrom(null);
            AtomicInteger countFromDefault = new AtomicInteger();
            AtomicInteger countFromTemporary = new AtomicInteger();
            var concurrent = ConcurrentCompletableFuture.allOf(
                    ConcurrentCompletableFuture.runAsync(() -> {
                        countFromDefault.set(elasticSearchDocumentRepository.countAtDocumentsByQuery(defaultIndex, defaultRequestQuery).getCount());
                    })
                    , ConcurrentCompletableFuture.runAsync(() -> {
                        countFromTemporary.set(elasticSearchDocumentRepository.countAtDocumentsByQuery(temporaryIndex, temporaryRequestQuery).getCount());
                    })
            );
            concurrent.join();
            defaultRequestQuery.setSize(countFromDefault.get());
            defaultRequestQuery.setFrom(0);
            temporaryRequestQuery.setSize(countFromTemporary.get());
            temporaryRequestQuery.setFrom(0);
            // sort from last uploaded
            QueryBuilder.addSortBy(defaultRequestQuery, "uploadDateTimeStamp", ESOrderEnum.DESC);
            QueryBuilder.addSortBy(temporaryRequestQuery, "uploadDateTimeStamp", ESOrderEnum.DESC);
            QueryBuilder.addSortBy(defaultRequestQuery, "dateUpload", ESOrderEnum.DESC);
            concurrent = ConcurrentCompletableFuture.allOf(
                    ConcurrentCompletableFuture.runAsync(() -> listOfDocuments.addAll(elasticSearchDocumentRepository
                            .getAtDocuments(defaultIndex, defaultRequestQuery)
                            .getHits()
                            .getHits()
                            .stream().map(DocClaimAtHit::getSource).collect(Collectors.toList())
                    )), ConcurrentCompletableFuture.runAsync(() -> listOfDocuments.addAll(elasticSearchDocumentRepository
                            .getAtDocuments(temporaryIndex, temporaryRequestQuery)
                            .getHits()
                            .getHits()
                            .stream().map(DocClaimAtHit::getSource).collect(Collectors.toList())
                    ))
            );
            concurrent.join();
        }
        log.info("End : Search list of documents by query '{}'", query);

        return listOfDocuments;
    }

    public List<PreDeclarationTypeDoc> searchInDocumentsListsByQuery(IndexOrPathToUse indexOrPathToUse, PreDeclarationTypeDoc query) {
        log.info("Start: Search list of documents by query '{}'", query);

        final var retrievedValues = ObjectUtils.extractFieldValues(query);

        if (org.springframework.util.CollectionUtils.isEmpty(retrievedValues)) {
            return List.of();
        }
        return elasticSearchDocumentRepository
                .getDocuments(getIndex(indexOrPathToUse), QueryBuilder.documentSinistreAutoRequestQueryBuilder(retrievedValues))
                .getHits()
                .getHits()
                .stream()
                .map(documentSinistreAutoHit -> {
                    final var preDeclarationToTransform = documentSinistreAutoHit.getSource();
                    preDeclarationToTransform.setReceptionDate(DateUtils.convertGedDateToFrontCompatible(
                            preDeclarationToTransform.getReceptionDate()
                    ));
                    preDeclarationToTransform.setSurvenanceDate(
                            DateUtils.convertGedDateToFrontCompatible(
                                    preDeclarationToTransform.getSurvenanceDate()
                            )
                    );

                    return preDeclarationToTransform;
                })
                .collect(Collectors.toList());
    }

    public List<PreDeclarationTypeDoc> getDocumentsList(IndexOrPathToUse indexOrPathToUse, String key, Object value) {
        log.info("Start: Search list of documents key '{}' and value '{}'", key, value);

        return elasticSearchDocumentRepository
                .getDocuments(getIndex(indexOrPathToUse), QueryBuilder.documentSinistreAutoRequestQueryBuilder(key, value))
                .getHits()
                .getHits()
                .stream()
                .map(documentSinistreAutoHit -> {
                    final var preDeclarationToTransform = documentSinistreAutoHit.getSource();
                    preDeclarationToTransform.setReceptionDate(DateUtils.convertGedDateToFrontCompatible(
                            preDeclarationToTransform.getReceptionDate()
                    ));
                    preDeclarationToTransform.setSurvenanceDate(
                            DateUtils.convertGedDateToFrontCompatible(
                                    preDeclarationToTransform.getSurvenanceDate()
                            )
                    );

                    return preDeclarationToTransform;
                })
                .collect(Collectors.toList());
    }

    public ESResponse addDossierSinistre(DossierSinistreAuto dossierSinistreAuto) {
        var id = UUID.randomUUID().toString();
        if (dossierSinistreAuto != null
                && (dossierSinistreAuto.getNatureSinistre() != null || dossierSinistreAuto.getPredec() != null)) {
            log.info("received a dossier sinistre with predec or numsin");

            var dSAutoFinder = new DossierSinistreAuto();

            dSAutoFinder.setNumSinistre(dossierSinistreAuto.getNumSinistre());
            dSAutoFinder.setPredec(dossierSinistreAuto.getPredec());

            var listDossierSinAuto = getDossierSinAutoList(dSAutoFinder);

            if (CollectionUtils.isNotEmpty(listDossierSinAuto)) {
                log.info("get id from old dossiers");
                dossierSinistreAuto.setId(listDossierSinAuto.get(0).getId());
            } else {
                if (dossierSinistreAuto.getId() == null || "".equals(dossierSinistreAuto.getId())) {
                    log.info("generate random id for dossier sinistre");
                    dossierSinistreAuto.setId(id);
                }
            }

            if (dossierSinistreAuto.getPredec() != null) {
                dossierSinistreAuto.setPredec(dossierSinistreAuto.getPredec().trim());
            }

            if (dossierSinistreAuto.getNomVictimes() == null) {
                dossierSinistreAuto.setNomVictimes(new ArrayList<>());
            }

            if (dossierSinistreAuto.getNumJuridiction() == null) {
                dossierSinistreAuto.setNumJuridiction(new ArrayList<>());
            }

        }
        log.info("indexing dossier  with metadata '{}' and id '{}'", dossierSinistreAuto, id);
        return elasticSearchDocumentRepository.addIndexDossierSinAuto(dossierSinistreAuto, id);
    }

    @SneakyThrows
    public ESResponse addDossierSinAutoAndSinistres(DossierSinistreAuto dossierSinistreAuto) {
        if (dossierSinistreAuto.getNumSinistre() == null) {
            var documentsList = getDocumentsList(IndexOrPathToUse.DEFAULT, "idPredeclaration", dossierSinistreAuto.getPredec());

            if (CollectionUtils.isNotEmpty(documentsList) && dossierSinistreAuto.getPredec() != null) {

                for (PreDeclarationTypeDoc doc : documentsList) {
                    doc.setNumPreDeclaration(dossierSinistreAuto.getPredec());
                    addDocumentSinistre(doc, URLEncoder.encode(doc.getIdAlfresco(), StandardCharsets.UTF_8), IndexOrPathToUse.DEFAULT);
                }
            }
        } else {
            var documentsList = getDocumentsList(IndexOrPathToUse.DEFAULT, "nSin", dossierSinistreAuto.getNumSinistre());

            if (CollectionUtils.isNotEmpty(documentsList) && dossierSinistreAuto.getNumSinistre() != null) {

                for (PreDeclarationTypeDoc doc : documentsList) {
                    doc.setNSin(dossierSinistreAuto.getNumSinistre().toString());
                    var out = addDocumentSinistre(doc, URLEncoder.encode(doc.getIdAlfresco(), StandardCharsets.UTF_8), IndexOrPathToUse.DEFAULT);
                    log.debug("Document '{}'", out);
                }
            }
        }
        return addDossierSinistre(dossierSinistreAuto);
    }

    public ESResponse addDocumentSinistre(PreDeclarationTypeDoc preDeclarationTypeDoc, String idAlfresco, IndexOrPathToUse esIndexToUse) {
        preDeclarationTypeDoc.setIdAlfresco(idAlfresco);
        log.info("Start: indexing doc  with metadata '{}' and id '{}'", preDeclarationTypeDoc, idAlfresco);
        ESResponse output = ESResponse.builder().build();
        if (esIndexToUse.equals(IndexOrPathToUse.DEFAULT)) {
            output = elasticSearchDocumentRepository.addIndex(preDeclarationTypeDoc, esPropertiesAutoDocument.getIndex(), idAlfresco);
        } else if (esIndexToUse.equals(IndexOrPathToUse.TEMPORARY)) {
            createIndexIfNotExist();
            output = elasticSearchDocumentRepository.addIndex(preDeclarationTypeDoc, esPropertiesAutoDocument.getTempIndex(), idAlfresco);
        }

        log.info("end: indexing doc  with metadata '{}' and id '{}'", preDeclarationTypeDoc, idAlfresco);
        return output;
    }


    public ESResponse addDocumentProduction(ESDocumentProductionRequest esDocumentProductionRequest,
                                            String idAlfresco) {
        log.info("Start: indexing doc  with metadata '{}' and id '{}'", esDocumentProductionRequest, idAlfresco);
        var output = elasticSearchDocumentRepository.addIndexProduction(esDocumentProductionRequest, idAlfresco);
        log.info("end: indexing doc  with metadata '{}' and id '{}'", esDocumentProductionRequest, idAlfresco);
        return output;
    }

    public ESResponse addIndexDossierProduction(ESDossierProductionRequest esDossierProductionRequest,
                                                String policyNumber) throws FeignException {
        try {
            log.info("Start: indexing dossier AT  with metadata '{}' and numSinistre '{}'", esDossierProductionRequest, policyNumber);
            var esResponse = elasticSearchDocumentRepository.addIndexDossierProduction(esDossierProductionRequest, policyNumber);
            log.info("End: indexing dossier AT  with output '{}'", esResponse);
            return esResponse;
        } catch (FeignException e) {
            log.error("can not index dossier At : '{}'", e.getMessage());
            throw new ESIndexingException(e.getMessage());
        }

    }

    public ESResponse addIndexDossierProductionHealth(ESDossierProductionRequest esDossierProductionRequest,
                                                      String policyNumber) throws FeignException {
        try {
            log.info("Start: indexing dossier HEALTH  with metadata '{}' and numSinistre '{}'", esDossierProductionRequest, policyNumber);
            var esResponse = elasticSearchDocumentRepository.addIndexDossierProductionHealth(esDossierProductionRequest, policyNumber);
            log.info("End: indexing dossier HEALTH  with output '{}'", esResponse);
            return esResponse;
        } catch (FeignException e) {
            log.error("can not index dossier HEALTH : '{}'", e.getMessage());
            throw new ESIndexingException(e.getMessage());
        }

    }

    public ESResponse updateMetadata(IndexOrPathToUse indexOrPathToUse, PreDeclarationTypeDoc preDeclarationTypeDoc, String idAlfresco) {
        log.info("Start helper: update metadata of a document with alfresco id'{}' and metadatas '{}'", idAlfresco, preDeclarationTypeDoc);
        final var id = GlobalConstants.PREFIX_IN_ALFRESCO_ID + idAlfresco;
        ESUpdateQuery updateQuery = ESUpdateQuery.builder()
                .doc(new ESDoc(preDeclarationTypeDoc))
                .build();

        ESResponse result;
        try {
            result = elasticSearchDocumentRepository.updateMetadata(updateQuery, id, getIndex(indexOrPathToUse));
        } catch (Exception e) {
            log.warn("Update with prefixed id failed, retrying with idAlfresco. Error: {}", e.getMessage());
            result = elasticSearchDocumentRepository.updateMetadata(updateQuery, idAlfresco, getIndex(indexOrPathToUse));
        }
        log.info("End helper: update metadata of a document with output '{}'", result);
        return result;
    }


    public ESResponse deleteMetadata(String idAlfresco, IndexOrPathToUse indexOrPathToUse) {
        log.info("Start helper: delete metadata of a document with alfresco id '{}' and idexPath '{}'", idAlfresco, indexOrPathToUse.value());
        final var id = GlobalConstants.PREFIX_IN_ALFRESCO_ID + idAlfresco;

        final var result = elasticSearchDocumentRepository.deleteDocumentsMetadata(getIndex(indexOrPathToUse), id);
        log.info("End helper: delete metadata of a document with output '{}'", result);
        return result;
    }


    @SneakyThrows
    private void createIndexIfNotExist() {
        log.info("Start Helper : create temporary index if it doesn't exist");
        if (!isIndexExistInES(esPropertiesAutoDocument.getTempIndex())) {
            final var resp = elasticSearchDocumentRepository.createTemporaryIndex();
            if (resp.getAcknowledged()) {
                log.info("End helper : index created successfully");
            } else {

                log.error("End helper : index wasn't created");
                throw new ESIndexingException("elastic search index can't be created by third party");
            }
        }

    }

    public List<DocumentSinistreATES> getATUnionOfMetadatasWithFieldQuery(IndexOrPathToUse indexOrPathToUse, Map<Object, String> hashMap) {
        log.info("Start helper : get metadatas where at least one (key,value) matches its fields '{}'", hashMap);
        if (org.springframework.util.CollectionUtils.isEmpty(hashMap) || indexOrPathToUse == null) {
            return List.of();
        }
        final var output = elasticSearchDocumentRepository
                .getAtDocuments(getAtIndex(indexOrPathToUse, false), QueryBuilder.documentSinistreAutoRequestQueryBuilderGetUnion(hashMap, AutoAtBranchEnum.SAT))
                .getHits()
                .getHits()
                .stream().map(DocClaimAtHit::getSource).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(output)) {

        }
        log.info("End helper : get metadata where at least one (key,value) matches its fields '{}'", hashMap);
        return output;
    }

    public List<PreDeclarationTypeDoc> getUnionOfMetadatasWithFieldQuery(IndexOrPathToUse indexOrPathToUse, HashMap<Object, String> hashMap) {
        log.info("Start helper : get metadatas where at least one (key,value) matches its fields '{}'", hashMap);
        if (org.springframework.util.CollectionUtils.isEmpty(hashMap) || indexOrPathToUse == null) {
            return List.of();
        }
        final var output = elasticSearchDocumentRepository
                .getDocuments(getIndex(indexOrPathToUse), QueryBuilder.documentSinistreAutoRequestQueryBuilderGetUnion(hashMap, AutoAtBranchEnum.SAC))
                .getHits()
                .getHits()
                .stream()
                .map(documentSinistreAutoHit -> {
                    final var preDeclarationToTransform = documentSinistreAutoHit.getSource();
                    preDeclarationToTransform.setReceptionDate(DateUtils.convertGedDateToFrontCompatible(
                            preDeclarationToTransform.getReceptionDate()
                    ));
                    preDeclarationToTransform.setSurvenanceDate(
                            DateUtils.convertGedDateToFrontCompatible(
                                    preDeclarationToTransform.getSurvenanceDate()
                            )
                    );

                    return preDeclarationToTransform;
                })
                .collect(Collectors.toList());
        log.info("End helper : get metadata where at least one (key,value) matches its fields '{}'", hashMap);
        return output;
    }

    public Map<String, Boolean> insertATMultipleMetadatas(IndexOrPathToUse indexOrPathToUse, List<DocumentSinistreATES> documentsMetadatas) throws JsonProcessingException {
        log.info("Start helper : insert multiple metadata in elastic search to  '{}'", indexOrPathToUse);
        final var hashMap = new HashMap<ESBulkOperationMetadata, Object>();
        var result = new HashMap<String, Boolean>();
        for (final var documentMetadata : documentsMetadatas) {
            hashMap.put(
                    ESBulkOperationMetadata.builder()
                            .index(getAtIndex(indexOrPathToUse, false))
                            .type(esPropertiesAtDoc.getType())
                            .id(documentMetadata.getIdalfersco())
                            .operation(ESBulkOperationsEnum.CREATE)
                            .build(),
                    documentMetadata
            );
        }
        final var bulkQuery = QueryBuilder.createABulkQuery(hashMap);

        final var output = elasticSearchDocumentRepository.multipleActionRequests(bulkQuery);
        for (var item : output.getItems()) {
            if (item != null && item.getValue() != null) {
                result.put(item.getValue().getId(), HttpStatus.CREATED.value() == item.getValue().getStatus());
            }
        }
        log.info("End helper : insert multiple metadata in elastic search to  '{}'", indexOrPathToUse);
        return result;
    }

    @SneakyThrows
    public Map<String, Boolean> insertMultipleMetadatas(IndexOrPathToUse indexOrPathToUse, List<PreDeclarationTypeDoc> documentsMetadatas) {
        log.info("Start helper : insert multiple metadata in elastic search to  '{}'", indexOrPathToUse);
        final var hashMap = new HashMap<ESBulkOperationMetadata, Object>();
        var result = new HashMap<String, Boolean>();
        for (final var documentMetadata : documentsMetadatas) {
            hashMap.put(
                    ESBulkOperationMetadata.builder()
                            .index(getIndex(indexOrPathToUse))
                            .type(esPropertiesAutoDocument.getType())
                            .id(documentMetadata.getIdAlfresco())
                            .operation(ESBulkOperationsEnum.CREATE)
                            .build(),
                    documentMetadata
            );
        }
        final var bulkQuery = QueryBuilder.createABulkQuery(hashMap);

        final var output = elasticSearchDocumentRepository.multipleActionRequests(bulkQuery);
        for (var item : output.getItems()) {
            if (item != null && item.getValue() != null) {
                result.put(item.getValue().getId(), HttpStatus.CREATED.value() == item.getValue().getStatus());
            }
        }
        log.info("End helper : insert multiple metadata in elastic search to  '{}'", indexOrPathToUse);
        return result;
    }

    private String getIndex(IndexOrPathToUse indexOrPathToUse) {
        var index = esPropertiesAutoDocument.getIndex();
        if (indexOrPathToUse.equals(IndexOrPathToUse.TEMPORARY)) {
            createIndexIfNotExist();
            index = esPropertiesAutoDocument.getTempIndex();
        }
        return index;
    }

    private boolean isIndexExistInES(String index) {
        log.info("Start Helper : check is index in elastic search");
        try {
            elasticSearchDocumentRepository.checkIndexExistence(index);
        } catch (FeignException exception) {
            log.info("End Helper : index doesn't exist in elastic search");
            return false;
        }
        log.info("End Helper : index exist in elastic search");
        return true;
    }

    public ESResponse addIndexDossierAT(ESDossierATRequest esDossierAT, String numSinistre) throws FeignException {
        try {
            log.info("Start: indexing dossier AT  with metadata '{}' and numSinistre '{}'", esDossierAT, numSinistre);
            var esResponse = elasticSearchDocumentRepository.addIndexDossierAT(esDossierAT, numSinistre);
            log.info("End: indexing dossier AT  with output '{}'", esResponse);
            return esResponse;
        } catch (FeignException e) {
            log.error("can not index dossier At : '{}'", e.getMessage());
            throw new ESIndexingException(e.getMessage());
        }

    }

    public ESResponse addIndexDocumentAT(ESDocumentATRequest esDocumentAT) {
        try {
            log.info("Start: indexing document AT with request '{}'",
                    esDocumentAT);
            var esResponse = elasticSearchDocumentRepository.addIndexDocumentAT(esDocumentAT);
            log.info("End: indexing document AT with output '{}'", esResponse);
            return esResponse;
        } catch (FeignException e) {
            log.error("can not index doc At : '{}'", e.getMessage());
            throw new ESIndexingException(e.getMessage());
        }
    }


    public ESResponse addAtDocument(IndexOrPathToUse index, ESDocumentATRequest esDocumentATRequest, String idAlfresco) {
        esDocumentATRequest.setIdAlfersco(idAlfresco);
        log.info("Start: indexing  At document  with metadata '{}' and id '{}'", esDocumentATRequest, idAlfresco);
        ESResponse output = null;
        output = elasticSearchDocumentRepository.addAtIndex(getAtIndex(index, Boolean.FALSE), esDocumentATRequest, idAlfresco);
        log.info("end: indexing At document with metadata '{}' and id '{}'", esDocumentATRequest, idAlfresco);
        return output;
    }

    public List<DocumentSinistreATES> getAtDocumentsList(IndexOrPathToUse indexAt, String key, Object value) {
        log.info("Start: Search list of documents key '{}' and value '{}'", key, value);

        return elasticSearchDocumentRepository
                .getAtDocuments(getAtIndex(indexAt, Boolean.FALSE), QueryBuilder.documentSinistreAtRequestQueryBuilder(key, value))
                .getHits()
                .getHits()
                .stream()
                .map(DocClaimAtHit::getSource)
                .collect(Collectors.toList());
    }


    public ESResponse updateAtMetadata(IndexOrPathToUse indexAt, ESDocumentATRequest docClaimAtReqDto, String idAlfresco) {

        log.info("Start helper: update metadata of a document with alfresco id'{}' and metadatas '{}'", idAlfresco, docClaimAtReqDto);
        final var id = GlobalConstants.PREFIX_IN_ALFRESCO_ID + idAlfresco;
        ESAtUpdateQuery updateQuery = ESAtUpdateQuery.builder()
                .doc(new ESAtDoc(docClaimAtReqDto))
                .build();

        final var result = elasticSearchDocumentRepository.updateAtMetadata(updateQuery, id, getAtIndex(indexAt, Boolean.FALSE));
        log.info("End helper: update metadata of a document with output '{}'", result);
        return result;

    }

    public ESResponse deleteAtMetadata(IndexOrPathToUse indexAt, String idAlfresco) {
        log.info("Start helper: delete metadata of a document with alfresco id '{}'", idAlfresco);
        final var id = GlobalConstants.PREFIX_IN_ALFRESCO_ID + idAlfresco;

        final var result = elasticSearchDocumentRepository.deleteAtDocumentsMetadata(getAtIndex(indexAt, Boolean.FALSE), id);
        log.info("End helper: delete metadata of a document with output '{}'", result);
        return result;
    }

    private String getAtIndex(IndexOrPathToUse indexOrPathToUse, Boolean isClaimMandatory) {
        var index = esPropertiesAtDoc.getIndex();
        if (indexOrPathToUse.equals(IndexOrPathToUse.TEMPORARY)) {
            createIndexAtIfNotExist(isClaimMandatory);
            index = Boolean.FALSE.equals(isClaimMandatory) ? esPropertiesAtDoc.getClaimTempIndex() : esPropertiesAtDoc.getTempIndex();
        }
        return index;
    }


    @SneakyThrows
    private void createIndexAtIfNotExist(Boolean isClaimMandatory) {
        log.info("Start Helper : create temporary index if it doesn't exist");
        if (!isIndexExistInES(esPropertiesAtDoc.getTempIndex())) {
            final var resp = elasticSearchDocumentRepository.createAtTemporaryIndex(Boolean.FALSE.equals(isClaimMandatory) ? esPropertiesAtDoc.getClaimTempIndex() : esPropertiesAtDoc.getTempIndex());
            if (Boolean.TRUE.equals(resp.getAcknowledged())) {
                log.info("End helper : index created successfully");
            } else {

                log.error("End helper : index wasn't created");
                throw new ESIndexingException("elastic search index can't be created by third party");
            }
        }

    }

    public int comparator(ESOrderEnum order, DocumentSinistreATES o1, DocumentSinistreATES o2) {
        if ((o1 == null || o1.getUploadDateTimeStamp() == null) && (o2 == null || o2.getUploadDateTimeStamp() == null)) {
            return comparatorWithUploadDate(order, o1, o2); // Both are null, consider them equal
        } else if (o1 == null || o1.getUploadDateTimeStamp() == null) {
            return 1; // o1 is null, consider it greater
        } else if (o2 == null || o2.getUploadDateTimeStamp() == null) {
            return -1; // o2 is null, consider it greater
        } else {
            // Compare in ascending order
            return ((int) Math.pow(-1, ESOrderEnum.ASC.equals(order) ? 1 : 0)) * Long.compare(o2.getUploadDateTimeStamp(), o1.getUploadDateTimeStamp());
        }
    }

    public int comparatorWithUploadDate(ESOrderEnum order, DocumentSinistreATES o1, DocumentSinistreATES o2) {
        if ((o1 == null || o1.getDateUpload() == null) && (o2 == null || o2.getDateUpload() == null)) {
            return 0; // Both are null, consider them equal
        } else if (o1 == null || DateUtils.parseDateStrToLocalDate(o1.getDateUpload()) == null) {
            return 1; // o1 is null, consider it greater
        } else if (o2 == null || DateUtils.parseDateStrToLocalDate(o2.getDateUpload()) == null) {
            return -1; // o2 is null, consider it greater
        } else {
            // Compare in ascending order
            return ((int) Math.pow(-1, ESOrderEnum.ASC.equals(order) ? 1 : 0)) * Long.compare(DateUtils.parseDateStrToLocalDate(o2.getDateUpload()).toEpochDay(), DateUtils.parseDateStrToLocalDate(o1.getDateUpload()).toEpochDay());
        }
    }

    public ESResponse addMobileScanDocument(IndexOrPathToUse index, ESDocMobileScanRequest esDocMobileScanRequest, String idAlfresco) {
        esDocMobileScanRequest.setIdAlfersco(idAlfresco);
        log.info("Start: indexing  mobile scan document  with metadata '{}' and id '{}'", esDocMobileScanRequest, idAlfresco);
        ESResponse output = null;
        output = elasticSearchDocumentRepository.addMobileScanIndex(getAtIndex(index, true),
                esDocMobileScanRequest, idAlfresco);
        log.info("end: indexing mobile scan  document with metadata '{}' and id '{}'", esDocMobileScanRequest, idAlfresco);
        return output;
    }

    public ESResponse addCimaDocument(CimaRequestDocument cimaRequestDocument, String idAlfresco) {
        cimaRequestDocument.setIdAlfresco(idAlfresco);
        log.info("Start: indexing  cima document  with metadata '{}' and id '{}'", cimaRequestDocument, idAlfresco);
        if (!isIndexExistInES(esPropertiesCimaDoc.getIndex())) {
            final var resp = elasticSearchDocumentRepository.createCimaIndex();
            if (resp.getAcknowledged()) {
                log.info("End helper : index created successfully");
            } else {
                log.error("End helper : index wasn't created");
                throw new ESIndexingException("elastic search index can't be created by third party");
            }
        }
        ESResponse output = elasticSearchDocumentRepository.addDocumentCima(cimaRequestDocument, idAlfresco);
        log.info("end: indexing cima document with metadata '{}' and id '{}'", cimaRequestDocument, idAlfresco);
        return output;
    }
}
