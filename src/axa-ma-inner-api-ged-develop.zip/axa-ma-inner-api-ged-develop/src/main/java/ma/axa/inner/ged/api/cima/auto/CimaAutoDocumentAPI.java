package ma.axa.inner.ged.api.cima.auto;

import static ma.axa.inner.ged.util.constants.CimaConstants.CIMA_AUTO_BASE_URL;
import static ma.axa.inner.ged.util.constants.CimaConstants.TAG_CIMA_AUTO_GED_APIS;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.domain.cima.auto.CimaAutoDocumentEs;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentRequest;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentResponse;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoDocumentTypeResponse;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoItemResponse;
import ma.axa.inner.ged.dto.cima.auto.CimaAutoSearchParams;
import ma.axa.inner.ged.dto.cima.auto.CountryCode;
import ma.axa.inner.ged.service.cima.auto.CimaAutoDocumentService;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Tag(name = TAG_CIMA_AUTO_GED_APIS)
@RestController
@RequestMapping(CIMA_AUTO_BASE_URL)
@RequiredArgsConstructor
@Slf4j
public class CimaAutoDocumentAPI {
	private final CimaAutoDocumentService service;

	@Operation(summary = "Upload new document and index meta-data")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Document ID", content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = CimaAutoDocumentRequest.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid request", content = @Content) })
	@PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)

	public ResponseEntity<CimaAutoDocumentResponse> uploadAutoDocuments(
			@Valid @ParameterObject @ModelAttribute CimaAutoDocumentRequest document,
			@RequestPart(value = "file") MultipartFile file) {
		log.info("Uploading new cima auto {} document and index meta-data {}, filename {}", document.getTypeDocument(),
				document, file.getOriginalFilename());
		var createdDocument = service.uploadFile(document, file);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdDocument);

	}

	@Operation(summary = "Update document and index meta-data")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Document ID", content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = CimaAutoDocumentRequest.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid request", content = @Content) })
	@PutMapping(value = "/{document_Id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)

	public ResponseEntity<CimaAutoDocumentResponse> updateAutoDocuments(
			@NotNull(message = "{error.alfresco.id}") @PathVariable(value = "document_Id", required = true) String documentId,
			@ParameterObject @ModelAttribute CimaAutoDocumentRequest document,
			@RequestPart(value = "file") MultipartFile file) {
		log.info("Uploading new cima auto {} document and index meta-data {}, filename {}", document.getTypeDocument(),
				document, file.getOriginalFilename());
		var createdDocument = service.updateAutoDocuments(documentId, document, file);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdDocument);
	}

	@Operation(summary = "download a document by its alfresco id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was downloaded", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = Resource.class)) }),
			@ApiResponse(responseCode = "404", description = "Not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping(value = "/{document_Id}/content", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<Resource> download(
			@NotNull(message = "{error.alfresco.id}") @PathVariable(value = "document_Id", required = true) String documentId) {
		log.info("Start api: Downloading file with id '{}'", documentId);
		var resource = service.downloadDocByIdAlfresco(documentId);
		var headers = new HttpHeaders();
		String headerKey = "X-filename";
		String headerValue = resource.getFilename();
		headers.set(headerKey, headerValue);

		log.info("End api: File downloaded !");
		return ResponseEntity.ok().headers(headers).body(resource);
	}

	@Operation(summary = "Delete claim auto document by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was deleted", content = {
					@Content(mediaType=MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = String.class)) }),
			@ApiResponse(responseCode = "404", description = "Not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@DeleteMapping(value = "/{document_id}")

	public ResponseEntity<String> deleteDocument(
			@NotBlank(message = GlobalConstants.ERROR_MSG_RD_ID_NOT_BLANK) @PathVariable(value = "document_id") String documentId) {
		return ResponseEntity.ok(service.deleteDocument(documentId));
	}

	@Operation(summary = "Find Branches")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "OK", content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = CimaAutoItemResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "Not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping(value = "/params/branches", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<CimaAutoItemResponse>> findBranches(
			@RequestHeader(required = true) CountryCode countryCode) {
		log.info("Start api: find Branches :'{}'", countryCode);
		List<CimaAutoItemResponse> result = service.findBranches();
		log.info("End api: find Branches !");
		return ResponseEntity.ok().body(result);
	}

	@Operation(summary = "Find entities")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "OK", content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = CimaAutoItemResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "Not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping(value = "/params/braches/{branche_id}/entities", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<CimaAutoItemResponse>> findEntities(
			@RequestHeader(required = true) CountryCode countryCode,
			@PathVariable(value = "branche_id") Long brancheId) {
		log.info("Start api: find entities :'{}'", countryCode);
		List<CimaAutoItemResponse> result = service.findEntities(brancheId);
		log.info("End api: find entities !");
		return ResponseEntity.ok().body(result);
	}

	@Operation(summary = "Find Directories")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "OK", content = {
			@Content(mediaType =MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = CimaAutoItemResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "Not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping(value = "/params/directories", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<CimaAutoItemResponse>> findDirectories(
			@RequestHeader(required = true) CountryCode countryCode) {
		log.info("Start api: find Directories :'{}'", countryCode);
		List<CimaAutoItemResponse> result = service.findDirectories();
		log.info("End api: find Directories !");
		return ResponseEntity.ok().body(result);
	}

	@Operation(summary = "Find document types")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "OK", content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = CimaAutoItemResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "Not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping(value = "/params/entities/{entity_id}/directories/{directory_id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<CimaAutoItemResponse>> findDocumentTypes(
			@RequestHeader(required = true) CountryCode countryCode, 
			@PathVariable(value = "entity_id") Long entityId,
			@PathVariable(value = "directory_id") Long directoryId) {
		log.info("Start api: find document types :'{}'", countryCode);
		List<CimaAutoItemResponse> result = service.findDocumentTypes(entityId, directoryId);
		log.info("End api: find document types !");
		return ResponseEntity.ok().body(result);
	}
	
	@Operation(summary = "Find all document types")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "OK", content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = CimaAutoDocumentTypeResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "Not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping(value = "/params/documenttypes", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<CimaAutoDocumentTypeResponse>> findAllDocumentTypes(
			@RequestHeader(required = true) CountryCode countryCode) {
		log.info("Start api:all document types countryCode:'{}'", countryCode);
		List<CimaAutoDocumentTypeResponse> result = service.findAllDocumentTypes();
		log.info("End api: all document types");
		return ResponseEntity.ok().body(result);
	}
	

	@Operation(summary = "Find By Criteria")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Documents list", content = {
			@Content(mediaType = "text/plain", schema = @Schema(implementation = CimaAutoItemResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@PostMapping(value = "/search", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<CimaAutoDocumentEs>> findByCriteria(@Valid @RequestBody CimaAutoSearchParams cimaAutoSearchParams) {
		log.info("Start api: findByCriteria :'{}'", cimaAutoSearchParams);
		List<CimaAutoDocumentEs> result = service.findByCriteria(cimaAutoSearchParams);
		log.info("End api: findByCriteria");
		return ResponseEntity.ok().body(result);
	}

	@Operation(summary = "Find By Criteria and get documents with their content")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Documents list", content = {
			@Content(mediaType = "text/plain", schema = @Schema(implementation = CimaAutoItemResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@PostMapping(value = "/zip", produces = "application/zip")
	public ResponseEntity<byte[]> downloadZip(@Valid @RequestBody CimaAutoSearchParams cimaAutoSearchParams, HttpServletResponse response) throws IOException {
		log.info("Start API: downloadZip :'{}'", cimaAutoSearchParams);

		byte[] zipBytes = service.streamDocumentsZip(cimaAutoSearchParams);

		return ResponseEntity.ok()
				.contentType(MediaType.APPLICATION_OCTET_STREAM)
				.contentLength(zipBytes.length)
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=documents.zip")
				.body(zipBytes);
	}

}
