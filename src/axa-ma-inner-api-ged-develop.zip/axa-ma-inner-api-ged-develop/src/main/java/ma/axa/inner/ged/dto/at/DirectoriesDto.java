package ma.axa.inner.ged.dto.at;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class DirectoriesDto {
    private Integer id;
    private String gedDirectory;
    private String directoryColor;
}
