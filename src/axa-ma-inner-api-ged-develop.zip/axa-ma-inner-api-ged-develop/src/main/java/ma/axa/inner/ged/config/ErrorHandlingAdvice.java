package ma.axa.inner.ged.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.error.ApiError;
import ma.axa.inner.ged.dto.error.ApiErrorItem;
import ma.axa.inner.ged.dto.error.ViolationErrorResponse;
import ma.axa.inner.ged.exception.*;
import ma.axa.inner.ged.util.MessageUtils;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.request.RequestFacade;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.support.MissingServletRequestPartException;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Collectors;

@Slf4j
@RestControllerAdvice
@RequiredArgsConstructor
public class ErrorHandlingAdvice {

    private final MessageSource messageSource;
    private final RequestFacade requestFacade;

    @ExceptionHandler(MissingServletRequestParameterException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ApiError onMissingServletRequestParameterException(
            MissingServletRequestParameterException e) {
        log.error(e.getMessage(), e);
        return ViolationErrorResponse.builder()
                .type(GlobalConstants.URI_MISSING_REQUEST_PARAMETER)
                .title("Missing Request Parameter").detail(e.getMessage())
                .status(HttpStatus.BAD_REQUEST.value())
                .errors(Collections.singletonList(ApiErrorItem.builder()
                        .target(e.getParameterName())
                        .message(e.getMessage()).build()))
                .build();
    }

    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ViolationErrorResponse onConstraintValidationException(
            ConstraintViolationException e) {
        log.error(e.getMessage(), e);
        return ViolationErrorResponse.builder()
                .type(GlobalConstants.URI_VALIDATION_CONSTRAINT_VIOLATION)
                .title("Field validation").detail(e.getMessage())
                .status(HttpStatus.BAD_REQUEST.value())
                .instance(e.getClass().getCanonicalName())
                .errors(e.getConstraintViolations().stream()
                        .map(violation -> ApiErrorItem.builder()
                                .target(violation.getPropertyPath().toString())
                                .message(getMessage(violation.getMessage(), null)).build())
                        .collect(Collectors.toList()))
                .build();
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ViolationErrorResponse onMethodArgumentNotValidException(
            MethodArgumentNotValidException e) {
        log.error(e.getMessage(), e);
        return ViolationErrorResponse.builder()
                .type(GlobalConstants.URI_METHOD_ARGUMENT_NOT_VALID)
                .title("Method Argument Not Valid").detail(e.getMessage())
                .status(HttpStatus.BAD_REQUEST.value())
                .instance(e.getClass().getCanonicalName())
                .errors(e.getBindingResult().getFieldErrors().stream()
                        .map(fieldError -> ApiErrorItem.builder()
                                .target(fieldError.getField())
                                .message(getMessage(fieldError.getDefaultMessage(), fieldError.getArguments()))
                                .build())
                        .collect(Collectors.toList()))
                .build();
    }

    @ExceptionHandler(BusinessException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ApiError onBusinessException(BusinessException e) {
        log.error(e.getMessage(), e);
        return ApiError.builder()
                .type(e.getType())
                .title("Parameters error")
                .detail(e.getMessage())
                .status(HttpStatus.BAD_REQUEST.value())
                .build();
    }

    @ExceptionHandler(value = DirectoryNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ApiError handleInvalidPath(DirectoryNotValidException e) {
        log.error(e.getMessage(), e);
        return ApiError.builder()
                .type(GlobalConstants.URI_DEFAULT)
                .title(e.getMessage())
                .detail("It seems that the path that you provided is not valid, please check if the path is exist in your local machine")
                .instance(e.getClass().getCanonicalName())
                .status(HttpStatus.BAD_REQUEST.value())
                .build();
    }

    @ExceptionHandler(value = FileNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ApiError handleFileNotValid(FileNotValidException e) {
        log.error(e.getMessage(), e);
        return ApiError.builder()
                .type(GlobalConstants.URI_DEFAULT)
                .title(e.getMessage())
                .detail("It seems that the file that you selected is not exist, please check if the file is exist in your local machine")
                .instance(e.getClass().getCanonicalName())
                .status(HttpStatus.BAD_REQUEST.value())
                .build();
    }

    @ExceptionHandler(value = DocumentNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ApiError handleDocumentNotFound(DocumentNotFoundException e) {
        log.error(e.getMessage(), e);
        return ApiError.builder()
                .type(GlobalConstants.URI_DEFAULT)
                .title(e.getMessage())
                .detail("It seems that the document that you are looking for is not found, make sure that its ID is correct")
                .instance(e.getClass().getCanonicalName())
                .status(HttpStatus.NOT_FOUND.value())
                .build();
    }

    @ExceptionHandler(value = FolderNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ApiError handleFolderNotFound(FolderNotFoundException e) {
        log.error(e.getMessage(), e);
        return ApiError.builder()
                .type(GlobalConstants.URI_DEFAULT)
                .title(e.getMessage())
                .detail("It seems that the parent folder that you are trying to reach is not found, make sure that its path is correct")
                .instance(e.getClass().getCanonicalName())
                .status(HttpStatus.NOT_FOUND.value())
                .build();
    }

    @ExceptionHandler(value = FileNameNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ApiError handleFileNameNotValid(FileNameNotValidException e) {
        log.error(e.getMessage(), e);
        return ApiError.builder()
                .type(GlobalConstants.URI_DEFAULT)
                .title(e.getMessage())
                .detail("Make sure to write a valid filename")
                .instance(e.getClass().getCanonicalName())
                .status(HttpStatus.BAD_REQUEST.value())
                .build();
    }

    @ExceptionHandler(MissingServletRequestPartException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ViolationErrorResponse onMissingServletRequestPartException(MissingServletRequestPartException e,
                                                                final HttpServletRequest request) {
        log.error(e.getMessage(), e);
        return ViolationErrorResponse.builder()
                .type(GlobalConstants.URI_MISSING_REQUEST_PARAMETER)
                .title("Make sure to import a file")
                .detail(e.getMessage())
                .status(HttpStatus.BAD_REQUEST.value())
                .instance(request.getRequestURI())
                .build();
    }

    @ExceptionHandler(value = IOFileException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ApiError handleIOFileException(IOFileException e) {
        log.error(e.getMessage(), e);
        return ApiError.builder()
                .type(e.getType())
                .title("I/O file exception")
                .detail(e.getMessage())
                .instance(e.getClass().getCanonicalName())
                .status(HttpStatus.BAD_REQUEST.value())
                .build();
    }

    @ExceptionHandler(value = InternalErrorException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    ApiError handleInternalErrorExceptionl(InternalErrorException e) {
        log.error(e.getMessage(), e);
        return ApiError.builder()
                .type(e.getType())
                .title("Erreur interne")
                .detail(e.getMessage())
                .instance(e.getClass().getCanonicalName())
                .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .build();
    }

    @ExceptionHandler(value = ESIndexingException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    ApiError handleESIndexingException(ESIndexingException e) {
        log.error(e.getMessage(), e);
        return ApiError.builder()
                .type(e.getType())
                .title("Erreur indexation ES")
                .detail(e.getMessage())
                .instance(e.getClass().getCanonicalName())
                .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .build();
    }

    @ExceptionHandler(CallStoredProcedureException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ApiError onCallStoredProcedureException(CallStoredProcedureException e) {
        log.error(e.getMessage(), e);
        return ApiError.builder()
                .type(e.getType())
                .title("Database error")
                .detail(e.getMessage())
                .status(HttpStatus.BAD_REQUEST.value())
                .build();
    }

    @ExceptionHandler(GlobalException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    ViolationErrorResponse onGlobalException(GlobalException e, final HttpServletRequest request) {
        log.error(e.getMessage(), e);
        return ViolationErrorResponse.builder()
                .type(e.getType())
                .title("Inernal Error")
                .detail(getMessage(e.getMessage(), null))
                .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .instance(request.getRequestURI())
                .build();
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    ViolationErrorResponse onHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException e,
                                                                    final HttpServletRequest request) {
        log.error(e.getMessage(), e);
        return ViolationErrorResponse.builder()
                .type(GlobalConstants.URI_METHOD_NOT_ALLOWED)
                .title("Request method not supported")
                .detail(getMessage(e.getMessage(), null))
                .status(HttpStatus.METHOD_NOT_ALLOWED.value())
                .instance(request.getRequestURI())
                .build();
    }

    @ExceptionHandler(BindException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ViolationErrorResponse onBindException(BindException e, final HttpServletRequest request) {
        log.error(e.getMessage(), e);
        return ViolationErrorResponse.builder()
                .type(GlobalConstants.URI_VALIDATION_CONSTRAINT_VIOLATION)
                .title("Field validation")
                .detail(e.getMessage())
                .status(HttpStatus.BAD_REQUEST.value())
                .instance(request.getRequestURI())
                .errors(e.getFieldErrors().stream()
                        .map(ef -> ApiErrorItem.builder()
                                .target(ef.getField())
                                .message(getMessage(ef.getDefaultMessage(), ef.getArguments())).build())
                        .collect(Collectors.toList()))
                .build();
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ViolationErrorResponse onHttpMessageNotReadableException(HttpMessageNotReadableException e,
                                                             final HttpServletRequest request) {
        log.error(e.getMessage(), e);
        return ViolationErrorResponse.builder()
                .type(GlobalConstants.URI_HTTP_MESSAGE_NOT_READABLE)
                .title("Field validation")
                .detail(e.getMessage())
                .status(HttpStatus.BAD_REQUEST.value())
                .instance(request.getRequestURI())
                .build();
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    ApiError onRecordNotFoundException(ResourceNotFoundException e, final HttpServletRequest request) {
        log.error(e.getMessage(), e);
        return ApiError.builder()
                .type(e.getType())
                .title("Not Found")
                .detail(getMessage(e.getMessage(), e.getArgs()))
                .status(HttpStatus.NOT_FOUND.value())
                .instance(request.getRequestURI())
                .build();
    }

    @ExceptionHandler(ResourceAlreadyExist.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ApiError onRecordNotFoundException(ResourceAlreadyExist e, final HttpServletRequest request) {
        log.error(e.getMessage(), e);
        return ApiError.builder()
                .type(e.getType())
                .title("Resource Already Exist")
                .detail(getMessage(e.getMessage(), e.getArgs()))
                .status(HttpStatus.BAD_REQUEST.value())
                .instance(request.getRequestURI())
                .build();
    }

    @ExceptionHandler(RequestValidationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    ViolationErrorResponse onRequestValidationException(RequestValidationException e,
                                                        final HttpServletRequest request) {
        log.error(e.getMessage(), e);
        var errors = new ArrayList<ApiErrorItem>();
        if (e.getErrors() != null && !e.getErrors().isEmpty()) {
            e.getErrors().forEach(
                    (k, v) -> errors.add(ApiErrorItem.builder().target(k).message(getMessage(v)).build()));
        }
        return ViolationErrorResponse.builder()
                .type(GlobalConstants.URI_BUSINESS_REQUEST_VALIDATION)
                .title("Error validation")
                .detail(e.getMessage())
                .status(HttpStatus.BAD_REQUEST.value())
                .instance(request.getRequestURI())
                .errors(errors)
                .build();
    }


    @ExceptionHandler({RuntimeException.class})
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public final ApiError onTechnicalException(Exception e) {
        log.error(e.getMessage(), e);

        String traceId = requestFacade.getTraceId();
        String message = getMessage("technical.error.message", traceId);


        return ApiError.builder()
                .traceId(traceId)
                .title("Technical Error")
                .detail(message)
                .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .type(GlobalConstants.URI_UNEXPECTED_TECHNICAL_ERROR)
                .build();
    }

    private String getMessage(String code, Object... args) {
        return MessageUtils.getMessage(messageSource, code, args);
    }
}
