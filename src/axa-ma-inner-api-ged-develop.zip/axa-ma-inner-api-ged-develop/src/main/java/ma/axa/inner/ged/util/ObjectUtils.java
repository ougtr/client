package ma.axa.inner.ged.util;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.enums.ESOrderEnum;
import ma.axa.inner.ged.exception.TechnicalException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Slf4j
public class ObjectUtils {

    public static Map<String, Object> extractFieldValues(Object obj) {
        Map<String, Object> fieldValues = new HashMap<>();
        if (obj == null || isPrimitiveOrWrapper(obj.getClass())) {
            return fieldValues;
        }

        extractFieldValues(obj, obj.getClass(), fieldValues);
        return fieldValues;
    }

    private static void extractFieldValues(Object obj, Class<?> clazz, Map<String, Object> fieldValues) {
        if (clazz == null || clazz == Object.class) {
            return;
        }
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            try {
                String fieldName = field.getName();
                Object fieldValue = getFieldValue(obj, clazz, fieldName);
                if (fieldValue == null || (field.getType() == String.class && StringUtils.isBlank((String) fieldValue))) {
                    continue;
                }
                addFieldToMap(field, fieldName, fieldValue, fieldValues);
            } catch (Exception e) {
                log.error("an exception occurred while extracting field : '{}' , '{}'",e.getMessage(),e.getCause());

            }
        }
        extractFieldValues(obj, clazz.getSuperclass(), fieldValues);
    }

    private static Object getFieldValue(Object obj, Class<?> clazz, String fieldName) throws BeansException, InvocationTargetException, IllegalAccessException {
        final  var propertyDescriptor = BeanUtils.getPropertyDescriptor(clazz, fieldName);
        return (propertyDescriptor != null) ? propertyDescriptor.getReadMethod().invoke(obj) : null;
    }

    private static void addFieldToMap(Field field, String fieldName, Object fieldValue, Map<String, Object> fieldValues) {
        if (field.isAnnotationPresent(JsonProperty.class)) {
            JsonProperty jsonPropertyAnnotation = field.getAnnotation(JsonProperty.class);
            String jsonPropertyName = jsonPropertyAnnotation.value();
            fieldValues.put(jsonPropertyName, fieldValue);
        } else {
            fieldValues.put(fieldName, fieldValue);
        }
    }

    private static boolean isPrimitiveOrWrapper(Class<?> clazz) {
        return clazz == null || clazz.isPrimitive() || isWrapperType(clazz);
    }

    public static int comparator(ESOrderEnum order, Long o1, Long o2){
        if ((o1 == null ) && (o2 == null)) {
            return 0; // Both are null, consider them equal
        } else {
            double pow = Math.pow(-1, ESOrderEnum.ASC.equals(order) ? 0 : 1);
            if (o1 == null) {
                return ((int) pow)*-1; // o1 is null, consider it greater
            } else if (o2 == null ) {
                return ((int) pow); // o2 is null, consider it greater
            } else {
                return ((int) pow)*Long.compare(o1,o2);
            }
        }
    }
    private static boolean isWrapperType(Class<?> clazz) {
        return List.of(String.class,Integer.class,Long.class,Double.class,Boolean.class).contains(clazz);
    }

    public static <T> T cleanNullValues(T object) {
        if (object == null) {
            return null;
        }
        try {
            var fields = object.getClass().getDeclaredFields();
            for (var field : fields) {
                field.setAccessible(true);
                var value = field.get(object);
                if (value == null || (value instanceof String && "null".equalsIgnoreCase((String) value))) {
                    field.set(object, null);
                }
            }
        } catch (IllegalAccessException e) {
            throw new TechnicalException(e);
        }
        return object;
    }
}
