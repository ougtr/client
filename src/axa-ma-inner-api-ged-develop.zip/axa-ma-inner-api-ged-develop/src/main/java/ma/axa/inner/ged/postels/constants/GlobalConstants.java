package ma.axa.inner.ged.postels.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;


@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class GlobalConstants {

	/**
	 * OpenApi
	 **/
	public static final String POSTE_LS_GED_APIS_TAG = "Poste-ls APIs";
	public static final String POSTE_LS_GED_BRANCHE_LABEL = "LS-PREVOYANCE";

	/**
	 * API ERROR CODES
	 **/
	private static final String BASE_URI = "/problem";
	public static final String URI_RECORDE_ALREADY_EXIST = BASE_URI + "/record-already-exist";
	public static final String URI_RECORDE_DOC_ID_NOT_FOUND = BASE_URI + "/documents/id-not-found";
	public static final String URI_INTERNAL_ERROR = BASE_URI + "/internal-error";

	/**
	 * POSTE LS ERROR MESSAGES
	 **/
	public static final String ERROR_MSG_POSTELS_IDDOCUMENT_NOT_FOUND = "error.rd.doc.id.not-found";
	public static final String ERROR_MSG_POSTELS_REFERENCE_ALREADY_EXIST = "error.rd.doc.reference.already-exist";
	public static final String ERROR_MSG_POSTELS_ID_NOT_BLANK = "error.rd.doc.id.not-blank";
	public static final String ERROR_MSG_SEARCH_PAGENUMBER_MIN = "error.request.search.page-number.min";
	public static final String ERROR_MSG_SEARCH_PAGESIZE_MIN = "error.request.search.page-size.min";

	/** REQUEST HEADERS **/
	public static final String HEADER_GED_CONTENT_ENCODING = "X-Ged-Content-Encoding";

	/** Elastic Search Constants **/
	public static final String ID_ALFRESCO = "idAlfresco";
	public static final String REFERENCE = "reference";
	public static final String NUM_POLICE = "numPolice";
	public static final String NUM_QUOTATION = "numQuotation";
	public static final String INTEGRATION_ID = "integrationId";
	public static final String AVENANT_ID = "avenantId";



}