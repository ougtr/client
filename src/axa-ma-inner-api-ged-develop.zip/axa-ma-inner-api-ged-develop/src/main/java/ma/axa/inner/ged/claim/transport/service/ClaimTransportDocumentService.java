package ma.axa.inner.ged.claim.transport.service;

import java.net.URLConnection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.transport.domain.DocumentClaimTransportEs;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportAddReq;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportResponse;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportSearchParams;
import ma.axa.inner.ged.claim.transport.dto.DocClaimTransportUpdateReq;
import ma.axa.inner.ged.claim.transport.mapper.ClaimTransportAlfrescoMapper;
import ma.axa.inner.ged.claim.transport.mapper.ClaimTransportMapper;
import ma.axa.inner.ged.claim.transport.repository.ClaimTransportElasticRepository;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.alfresco.DocumentAlfresco;
import ma.axa.inner.ged.dto.CommonResponse;
import ma.axa.inner.ged.enums.Branche;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.exception.RequestValidationException;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.exception.ResourceNotFoundException;
import ma.axa.inner.ged.service.AlfrescoGedService;
import ma.axa.inner.ged.util.DateUtils;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.MessageUtils;
import ma.axa.inner.ged.util.ResponseUtils;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Slf4j
@Service
@RequiredArgsConstructor
public class ClaimTransportDocumentService {

	private final BrancheProperties transportProperties;
	private final ClaimTransportMapper transportMapper;

	private final AlfrescoGedService alfrescoService;
	private final ClaimTransportElasticRepository elasticRepository;

	private final MessageSource messageSource;

	private String getMessage(String code, Object[] args) {
		return MessageUtils.getMessage(messageSource, code, args);
	}

	/** ======== Searching ======== **/

	/**
	 * Get document meta-data in elasticSearch by documentId
	 */
	public DocClaimTransportResponse getDocumentById(@NotBlank String documentId) {
		var isExistInElastic = elasticRepository.exists(documentId);
		if (!isExistInElastic)
			throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
					GlobalConstants.ERROR_MSG_RD_IDDOCUMENT_NOT_FOUND, new String[] { documentId });

		var response = elasticRepository.findById(documentId).orElse(null);
		return transportMapper.toDto(response);
	}

	/**
	 * Searching documents in elasticSearch
	 * 
	 * @param searchParams
	 * @return {@link Page} of founded documents
	 */
	public Page<DocClaimTransportResponse> search(@NotNull DocClaimTransportSearchParams searchParams) {
		var response = elasticRepository.findByCriteria(searchParams);
		var page = ClaimTransportMapper.mapToPage(response, searchParams.getPageNumber(), searchParams.getPageSize());
		return page.map(transportMapper::toDto);
	}

	/** ======== Download ======== **/

	/**
	 * Download file & Prepare response headers, used in rest controller
	 * 
	 * @param idAlfresco id file in Alfresco
	 * @return byte content as {@link ResponseEntity}
	 */
	public ResponseEntity<Resource> downloadFile(final String idAlfresco) {
		var document = getFileFromAlfresco(idAlfresco);
		var isr = new InputStreamResource(document.getContentStream().getStream());
		var mimeType = document.getContentStreamMimeType();
		if (StringUtils.isBlank(mimeType) && StringUtils.isNotBlank(document.getName()))
			mimeType = URLConnection.guessContentTypeFromName(document.getName());
		var fileName = StringUtils.isNotBlank(document.getName()) ? document.getName() : "unknown_filename";
		var headers = ResponseUtils.getDownloadHeaders(fileName, document.getContentStreamLength(), mimeType);
		return ResponseEntity.ok().headers(headers).body(isr);
	}

	/**
	 * Get file content from Alfresco
	 * 
	 * @param id Id Alfresco of document
	 */
	public Document getFileFromAlfresco(final String idAlfresco) {
		if (!alfrescoService.exists(idAlfresco))
			throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
					GlobalConstants.ERROR_MSG_RD_IDDOCUMENT_NOT_FOUND, new String[] { idAlfresco });
		try {
			return alfrescoService.getDocument(idAlfresco);
		} catch (Exception e) {
			var err = "Error during retreive document from alfresco, err: " + e.getMessage();
			log.error(err);
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, err);
		}
	}

	/** ======== Upload ======== **/

	/**
	 * Upload new document to Alfresco and index meta-data in ES
	 * 
	 * @param metaData Meta data of document
	 * @param file     Document Content
	 * @return
	 * @throws Exception
	 */
	public DocClaimTransportResponse uploadDocumentWithMetaData(final DocClaimTransportAddReq metaData,
			final MultipartFile file) {
		// Check if reference already exist
		String reference = metaData.getReference();
		if(metaData.isEnableGestionnaire()) {
		var documentExist = elasticRepository.findOneDocumentByReference(reference);
		if (documentExist != null)
			throw new ResourceAlreadyExist(GlobalConstants.URI_RECORDE_ALREADY_EXIST,
					GlobalConstants.ERROR_MSG_RD_REFERENCE_ALREADY_EXIST,
					new String[] { reference });
		}
		// Mapping
		var documentEs = transportMapper.fromDto(metaData);
		// validation
		var isValid = validationRequest(documentEs);
		if (isValid != null && !isValid.isSuccess()) {
			throw new RequestValidationException("Error validation", isValid.getMsgErrors());
		}

		try {
			var folderPproperties = ClaimTransportAlfrescoMapper.toFolderProperties(metaData);
			var targetFolder = prepareDocumentFolder(folderPproperties);
			var filename = StringUtils.isBlank(metaData.getFilename()) ? file.getOriginalFilename()
					: metaData.getFilename();
			// Upload Document to alfresco
			DocumentAlfresco createdDocument = null;
			Map<String, Object> properties = ClaimTransportAlfrescoMapper.toDocumentProperties(metaData);
			createdDocument = alfrescoService.createDocument(targetFolder, filename, file, properties, true);
			if (createdDocument == null) {
				return null;
			}
			// Indexing document in ES
			documentEs.setBrancheCode(Branche.TRANSPORT.getCode());
			documentEs.setBrancheLabel(Branche.TRANSPORT.getLabel());
			documentEs.setId(createdDocument.getId());
			documentEs.setFilename(createdDocument.getFilename());
			documentEs.setPath(createdDocument.getPath());
			documentEs.setCreatedAt(DateUtils.getCurrentDateTime().toLocalDateTime());
			documentEs.setApplicationCode("200");
		
			elasticRepository.createNewDocument(documentEs.getId(), documentEs);
			return transportMapper.toDto(documentEs);
		} catch (Exception e) {
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
		}
	}

	/**
	 * Check & create target folders before upload document
	 * 
	 * @param properties
	 * @return
	 */
	public Folder prepareDocumentFolder(Map<String, Object> properties) {
		var branchePath = transportProperties.getAlfrescoRootFolder();
		var sitePath = transportProperties.getAlfrescoSitePath();
		var brancheFolderPath = FileUtil.appendDateAsSubFolders(branchePath);
		var createdFolder = alfrescoService.createTreeFolder(brancheFolderPath, sitePath, properties);
		if (createdFolder == null) {
			throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
		}
		return createdFolder;
	}

	/** ======== Update ======== **/

	public DocClaimTransportResponse updateDocument(String documentId, DocClaimTransportUpdateReq metaData) {
		if (metaData == null)
			throw new NullPointerException("Document meta-data to be updated must no be null");
		if (StringUtils.isBlank(documentId))
			throw new IllegalArgumentException("documentId must not be null");

		try {
			var isExistInElastic = elasticRepository.exists(documentId);
			if (!isExistInElastic)
				throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
						GlobalConstants.ERROR_MSG_RD_IDDOCUMENT_NOT_FOUND, new String[] { documentId });

			var documentEs = elasticRepository.findById(documentId)
					.orElseThrow(() -> new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
							"Document Not Found"));
			transportMapper.updateFromDto(metaData, documentEs);

			// validation
			var isValid = validationRequest(documentEs);
			if (isValid != null && !isValid.isSuccess()) {
				throw new RequestValidationException("Error validation", isValid.getMsgErrors());
			}

			// Update Alfresco meta-data, is optional
			updateDocumentAlfrescoProps(documentId, metaData);

			log.debug("[transport-service] start update elastic document properties...");
			elasticRepository.updateDocument(documentId, documentEs);
			var updated = elasticRepository.findById(documentId).orElse(null);
			return transportMapper.toDto(updated);
		} catch (Exception e) {
			log.error("Error when update Document id {}, err: {}", documentId, e.getMessage());
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
		}
	}

	/** ======== Inputs Validation ======== **/

	public CommonResponse validationRequest(DocumentClaimTransportEs documentEs) {
		var response = CommonResponse.builder();
		var error = new HashMap<String, String>();
		if (!validStatus(documentEs.getStatus(), documentEs.getSinistreNumber())) {
			error.put("status", "Must fill sinistre number to update status = IDENTIFIE");
		}

		response.msgErrors(error);
		response.success(error.isEmpty());
		return response.build();
	}

	public static boolean validStatus(String status, String numSinistre) {
		if (null != status && status.equalsIgnoreCase("Identifié")) {
			return StringUtils.isNotBlank(numSinistre);
		}
		return true;
	}

	private boolean updateDocumentAlfrescoProps(String documentId, DocClaimTransportUpdateReq metaData) {
		try {
			log.debug("[transport-service] start update alfresco document properties...");
			Map<String, Object> properties = ClaimTransportAlfrescoMapper.toDocumentProperties(metaData);
			alfrescoService.updateDocumentProperties(documentId, properties);
			return true;
		} catch (Exception e) {
			log.warn("[transport-service] Error during update alfresco meta-data for id: {}, err: {} ", documentId,
					e.getMessage());
			return false;
		}
	}

	/** ======== Delete ======== **/

	/**
	 * Delete document from ElasticSearch & Alfresco
	 * 
	 * @see ClaimTransportDocumentService#deleteDocument(String, boolean)
	 */
	public CommonResponse deleteDocument(String id) {
		return deleteDocument(id, true);
	}

	/**
	 * Delete multiple document by id
	 * 
	 * @param ids
	 * @return
	 */
	public CommonResponse deleteDocument(
			@NotEmpty(message = GlobalConstants.ERROR_MSG_RD_IDS_NOT_EMPTY) List<String> ids) {
		if (ids == null || ids.isEmpty())
			return null;
		var response = CommonResponse.builder();
		Map<String, String> errors = new HashMap<>();
		Map<String, String> success = new HashMap<>();
		for (var i = 0; i < ids.size(); i++) {
			try {
				var deleted = deleteDocument(ids.get(i));
				if (deleted != null && deleted.isSuccess())
					success.put(ids.get(i), "true");
				else
					errors.put(ids.get(i), "can't delete this document");
			} catch (Exception e) {
				var msg = getMessage(e.getMessage(), new String[] { ids.get(i) });
				errors.put(ids.get(i), msg);
			}
		}
		return response.success(!errors.isEmpty())
				.msgErrors(!errors.isEmpty() ? errors : null)
				.msgSuccess(!success.isEmpty() ? success : null)
				.build();
	}

	/**
	 * Delete document Alfresco
	 * 
	 * @param id           The id of document
	 * @param withMetaData if {@code true} delete Elasticsearch document
	 */
	public CommonResponse deleteDocument(
			@NotBlank(message = GlobalConstants.ERROR_MSG_RD_ID_NOT_BLANK) String id, boolean withMetaData) {

		// Check if id exist
		var isExistInAlfresco = alfrescoService.exists(id);
		var isExistInElastic = elasticRepository.exists(id);
		if (!isExistInElastic && !isExistInAlfresco)
			throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
					GlobalConstants.ERROR_MSG_RD_IDDOCUMENT_NOT_FOUND, new String[] { id });

		var response = CommonResponse.builder();
		Map<String, String> errors = new HashMap<>();
		Map<String, String> success = new HashMap<>();

		// Delete doc from alfresco
		if (isExistInAlfresco) {
			var isDeletedFromAlfresco = false;
			try {
				isDeletedFromAlfresco = alfrescoService.deleteDocument(id);
			} catch (Exception e) {
				var err = String.format("Can't delete document with id [%s] from alfresco, err: %s", id,
						e.getMessage());
				log.error("[CLAIM-RD] " + err);
				errors.put("ALFRESCO", err);
				isDeletedFromAlfresco = false;
			}
			success.put("ALFRESCO", String.valueOf(isDeletedFromAlfresco));
		}

		// Delete doc from ES
		var isDeletedFromEs = false;
		if (isExistInElastic && withMetaData) {
			try {
				isDeletedFromEs = elasticRepository.deleteDocument(id);
			} catch (Exception e) {
				var err = String.format("Can't delete document with id [%s] from elastic, err: %s", id, e.getMessage());
				log.error("[CLAIM-RD] " + err);
				errors.put("ELASTIC", err);
				isDeletedFromEs = false;
			}
			success.put("ELASTIC", String.valueOf(isDeletedFromEs));
		}

		return response.success(isDeletedFromEs)
				.msgErrors(!errors.isEmpty() ? errors : null)
				.msgSuccess(!success.isEmpty() ? success : null)
				.build();

	}

}
