package ma.axa.inner.ged.dto;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CimaRequestDocument {
    private String countryCode;
    private String contractNumber;
    private String idAlfresco;
}
