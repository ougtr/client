package ma.axa.inner.ged.service.ls;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import ma.axa.inner.ged.dto.DocumentRequest;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.postels.constants.GlobalConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.GedLsProperties;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.helper.ElasticSearchHelper;
import ma.axa.inner.ged.mapper.DocumentMapper;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.service.ManageDocumentService;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;

@Service
@Slf4j
public class LsDocumentsService extends ManageDocumentService {

    private final GedLsProperties gedProductionProperties;
    private final ElasticSearchHelper elasticSearchHelper;
    private final ClaimDocumentRepository claimDocumentRepository;


    public LsDocumentsService(ClaimDocumentRepository claimDocumentRepository,
                              GedLsProperties gedProductionProperties, ElasticSearchHelper elasticSearchHelper) {
        super(claimDocumentRepository);
        this.gedProductionProperties = gedProductionProperties;
        this.elasticSearchHelper = elasticSearchHelper;
        this.claimDocumentRepository = claimDocumentRepository;
    }


    @SneakyThrows
    public String uploadFile(MultipartFile file) {
        var idAlfresco = "";


        if (file != null && file.getOriginalFilename() != null && file.getContentType() != null) {
            String filename = file.getOriginalFilename();
            if (filename != null) {
                FileUtil.assertFileNameValid(filename);
            }
            idAlfresco = uploadFile(DocumentMapper.mapFileToGedDocument(file));

        }
        return idAlfresco;
    }


    public Resource downloadFile(String id) {
        log.info("Start: Downloading file with id '{}'", id);
        var document = claimDocumentRepository.getFileDocument(id);
        log.debug("File downloaded : '{}'", document);
        log.info("Start: Downloading file with id '{}'", id);
        return new ByteArrayResource(document.getFileByte()) {
            @Override
            public String getFilename() {
                return document.getFileName();
            }
        };
    }


    private String pathFromDateDoc() {
        var date = LocalDate.now();
        return date.getYear() + "/" + date.getMonthValue() + "/" + date.getDayOfMonth();
    }


    public String uploadFile(GedDocument gedDocument) {

        var path = pathFromDateDoc();
        log.info("Start: creating arborecense in alfresco repository with path '{}'", gedProductionProperties.getLsDoc() + path);
        var folder = claimDocumentRepository.createArboFoldersByPath(gedProductionProperties.getLsDoc(), path);
        log.info("End: creating arborecense in alfresco repository with path '{}'", gedProductionProperties.getLsDoc() + path);
        if (folder == null) {
            log.error("can not create/open dossier (floder) is null");
            throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
        }
        Map<String, Object> properties = new HashMap<>();
        properties.put(AXADocPropertyIds.IDENTIFIANT_SCANER, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
        properties.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
        var uploadOutput = uploadFile(properties, gedDocument, folder);
        return uploadOutput.get("idAlfresco");
    }


    public String deleteDocument(String id) {
        try {
			log.info("Start: Deleting LS document with id '{}'", id);
            claimDocumentRepository.deleteFile(id);
			log.info("End: Deleting LS document with id '{}'", id);
        } catch (Exception e) {
			log.error("Erreur Deleting LS document with id '{}'", id , e);
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR,
                    e.getMessage());
        }
        return id;
    }

}

