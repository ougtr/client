package ma.axa.inner.ged.mapper;

import ma.axa.inner.ged.domain.at.DocumentInfo;
import ma.axa.inner.ged.dto.DocumentInfoDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface DocumentInfoMapper {
	@Mapping(target = "typology", source = "typology.id")
	@Mapping(target = "secondTypology", source = "secondTypology.id")
	DocumentInfoDto toMissingDocumentDto(DocumentInfo documentsDtoInfo);
	List<DocumentInfoDto> toMissingDocumentDtoList(List<DocumentInfo> documentsDtoInfo);
}
