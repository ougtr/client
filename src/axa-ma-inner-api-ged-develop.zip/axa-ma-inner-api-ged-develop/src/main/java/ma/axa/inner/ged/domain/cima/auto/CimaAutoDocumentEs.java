package ma.axa.inner.ged.domain.cima.auto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.axa.inner.ged.dto.cima.auto.AutoDocumentStatus;
import ma.axa.inner.ged.dto.cima.auto.CountryCode;
import ma.axa.inner.ged.enums.Nature;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)

public class CimaAutoDocumentEs {
	private String id;
	@JsonProperty("country_code")
	private CountryCode countryCode; 
	@JsonProperty("ug")
	private String ug;
	@JsonProperty("type_document")
	private String typeDocument;
	@JsonProperty("num_declaration")
	private String numDeclaration;
	@JsonProperty("num_sinistre")
	private String numSinistre;
	@JsonProperty("num_police")
	private String numPolice;
	@JsonProperty("immatriculation")
	private String immatriculation;
	@JsonProperty("date_survenace")
	private LocalDate dateSurvenace;
	@JsonProperty("date_effet")
	private LocalDate dateEffet;
	@JsonProperty("compagnied_adverse")
	private String compagnieAdverse;
	@JsonProperty("code_intermediaire")
	private String codeIntermediaire;
	@JsonProperty("nom_intermediaire")
	private String nomIntermediaire;
	@JsonProperty("ref_prestataire")
	private String refPrestataire;
	@JsonProperty("ref_moyena_piement")
	private String refMoyenPaiement;
	@JsonProperty("date_reception")
	private LocalDate dateReception;
	@JsonProperty("date_numerisation")
	private LocalDate dateNumerisation;
	@JsonProperty("entite_emetteur")
	private String entiteEmetteur;
	@JsonProperty("statut")
	private AutoDocumentStatus statut;
	@JsonProperty("branche")
	private String branche;
	@JsonProperty("created_by")
	private String createdBy;
	@JsonProperty("created_at")
	private LocalDateTime createdAt;
	@JsonProperty("file_name")
	private String filename;
	
	@JsonProperty("path")
	private String path;

	@JsonProperty("document_type_code")
	private String documentTypeCode;

	@JsonProperty("document_type_label")
	private String documentTypeLabel;

	@JsonProperty("policy_number")
	private String policyNumber;

	@JsonProperty("intermediary_code")
	private String agentCode;

	@JsonProperty("product_code")
	private String productCode;
	
	@JsonProperty("nature")
	private Nature nature;

}
