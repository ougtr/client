package ma.axa.inner.ged.dto.at;

import lombok.*;

import java.util.List;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DocumentMetadataOrQueryDto {
    private Integer intermediaryCode;
    private List<String> typeDocument;
    private String repertoire;
}
