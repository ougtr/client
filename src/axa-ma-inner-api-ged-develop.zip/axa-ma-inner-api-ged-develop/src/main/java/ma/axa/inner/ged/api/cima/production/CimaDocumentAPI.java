package ma.axa.inner.ged.api.cima.production;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.cima.production.CimaDocumentRequest;
import ma.axa.inner.ged.dto.cima.production.CimaDocumentResponse;
import ma.axa.inner.ged.dto.production.rc.RcProductionDocumentRequest;
import ma.axa.inner.ged.service.cima.production.CimaDocumentService;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;

import static ma.axa.inner.ged.util.constants.CimaConstants.CIMA_PROD_BASE_URL;
import static ma.axa.inner.ged.util.constants.CimaConstants.TAG_CIMA_PROD_GED_APIS;

@Tag(name = TAG_CIMA_PROD_GED_APIS)
@RestController
@RequestMapping(CIMA_PROD_BASE_URL)
@RequiredArgsConstructor
@Slf4j
public class CimaDocumentAPI {
    private final CimaDocumentService service;

    @Operation(summary = "Upload new cima document and index meta-data")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Document ID", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = RcProductionDocumentRequest.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid request", content = @Content)})
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<CimaDocumentResponse> uploadRcProductionDocuments(
            @ParameterObject @ModelAttribute @Valid CimaDocumentRequest document,
            @RequestPart(value = "file") MultipartFile file) {
        log.info("Uploading new cima {} document and index meta-data {}, filename {}", document.getProductType().name(), document, file.getOriginalFilename());
        var createdDocument = service.uploadFile(document, file);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdDocument);
    }
}
