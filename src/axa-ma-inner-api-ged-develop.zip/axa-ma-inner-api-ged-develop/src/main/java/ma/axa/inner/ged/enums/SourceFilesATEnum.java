package ma.axa.inner.ged.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum SourceFilesATEnum {
    FRONT_CLIENT(1,"front client"),
    REGISTRY(2,"Bureaux d'ordre"),
    PRECONTENTIEUX(3,"Précontentieux");
    private Integer id;
    private String label;
}
