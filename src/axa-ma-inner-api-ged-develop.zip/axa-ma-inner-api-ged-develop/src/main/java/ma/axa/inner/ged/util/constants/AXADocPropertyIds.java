package ma.axa.inner.ged.util.constants;

public class AXADocPropertyIds {

	private AXADocPropertyIds() {
		throw new IllegalStateException("Cannot instantiate from this class");
	}

	public static final String AXA_DOC_ID_PREDECLARATION = "axa:sinmat:numpredeclaration";
	public static final String AXA_DOC_NUM_POLICE = "axa:sinmat:police";
	public static final String AXA_DOC_NUM_SINISTRE = "axa:sinmat:sinistre";

	public static final String AXA_DOC_TYPE = "D:axa:doc";
	public static final String IDENTIFIANT_SCANER = "axa:scanId";
	public static final String NUMERO_POLICE = "axa:numPolice";
	public static final String NUMERO_SINISTRE = "axa:numSinistre";
	public static final String DATE_ARRIVEE = "axa:dateArrivee";

	public static final String AXA_DOSSIER_TYPE = "F:axa:dossier";

	public static final String NATURE_COURRIER = "axa:natureCourrier";
	public static final String TYPE_COURRIER = "axa:typeCourrier";
	public static final String TYPE_EXPIDITEUR = "axa:typeExpediteur";
	public static final String DATE_SURVENANACE_DOSSIER = "axa:dossier:dateSurvenance";
	public static final String DATE_DECLARATION_DOSSIER = "axa:dossier:dateDeclaration";

	public static final String SOURCE = "axa:source";
	public static final String AUTHENTIQUE = "axa:authentique";
	public static final String COMMENTAIRE_DOCUMENT = "axa:commentaire";
	public static final String AGENT_NUMERISATION = "axa:AgentDeNumerisation";
	public static final String AGENT_INDEXATION = "axa:AgentDindexation";
	public static final String AGENT_INTERMEDIAIRE = "axa:intermediaire";
	public static final String DOCUMENT_OUVERTURE = "axa:docOuverture";

	public static final String CODE_PRODUIT = "axa:dossier:codeProduit";
	public static final String CLASSE_SINISTRE = "axa:dossier:classeSinistre";
	public static final String NUMERO_POLICE_DOSSIER = "axa:dossier:numPolice";
	public static final String NUMERO_SINISTRE_DOSSIER = "axa:dossier:numSinistre";
	public static final String NOM_VICTIME = "axa:dossier:nomVictime";
	public static final String DATE_SURVENANACE = "axa:dossier:dateSurvenance";
	public static final String COMMENTAIRE = "axa:dossier:commentaire";

	public static final String INTERMEDIARE_DOSSIER = "axa:dossier:codeIntermediaire";
	public static final String NOM_VICTIME_DOSSIER = "axa:dossier:nomVictime";

	public static final String PRODUCTION_PRODUCT_CODE = "axa:dossierPolice:codeProduit";
	public static final String PRODUCTION_INTERMEDIARY_CODE = "axa:dossierPolice:codeIntermediaire";
	public static final String PRODUCTION_EFFECT_DATE = "axa:dossierPolice:dateEffet";
	public static final String PRODUCTION_CLIENT_NAME = "axa:dossierPolice:nomClient";
	public static final String PRODUCTION_POLICY_CREATION_DATE = "axa:dossierPolice:dateCreationPolice";
	public static final String PRODUCTION_POLICE_NUMBER = "axa:dossierPolice:numPolice";

	public static final String CREATED_BY = "cmis:createdBy";
	public static final String CMIS_FOLDER = "cmis:folder";
	
	public static final String VALEUR_JURIDIQUE_DOSSIER = "axa:dossier:valeur_juridiction";
	public static final String NUM_TRIBUNAL_DOSSIER = "axa:dossier:num_tribunal";
	
	public static final String NUMERO_ADHESION_DOSSIER = "axa:dossier:numAdhesion";
	public static final String LIB_BANQUE_DOSSIER = "axa:dossier:libBanque";
	public static final String NUM_DECLARATION_DOSSIER = "axa:dossier:numDeclaration";
	public static final String CORRESPONDANCE_G_DOSSIER = "axa:dossier:correspondance_G";

	//public static final String NUMERO_QUITTANCE_DOSSIER = "axa:dossier:numQuittance";
	//public static final String NUMERO_QUITTANCE = "axa:numQuittance";
}
