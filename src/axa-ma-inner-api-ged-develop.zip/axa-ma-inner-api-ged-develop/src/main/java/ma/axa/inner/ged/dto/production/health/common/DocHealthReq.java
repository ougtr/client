package ma.axa.inner.ged.dto.production.health.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;


@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DocHealthReq {
	private String idAlfresco;
	private String filename;
	private String reference;
	private Integer typedocumentCode;
	private String typedocumentLabel;
	private String quotationNumber;
	private String policyNumber;
	private String corporateName;
	private String status;
	private String repertoire;
	private String repertoireCode;
	private String intermediaryCode;
	private String createdBy;
	private String createdAt;
	private String lastUpdatedBy;
	private LocalDateTime lastUpdatedAt;
	private String filesize;
	private String filetype;
	private String demandReference;
}