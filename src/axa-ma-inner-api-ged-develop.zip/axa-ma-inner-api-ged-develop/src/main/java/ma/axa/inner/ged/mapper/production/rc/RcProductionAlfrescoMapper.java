package ma.axa.inner.ged.mapper.production.rc;

import java.util.Collections;
import java.util.Map;

import ma.axa.inner.ged.dto.production.rc.RcProductionDocumentRequest;
import ma.axa.inner.ged.dto.production.rc.RcProductionDocumentUpdateRequest;
import ma.axa.inner.ged.mapper.AlfrescoPropsMapper;

public class RcProductionAlfrescoMapper extends AlfrescoPropsMapper {
    private RcProductionAlfrescoMapper() throws InstantiationException {
        throw new InstantiationException("Instances of this type are forbidden");
    }

    public static Map<String, Object> toFolderProperties(RcProductionDocumentRequest metaData) {
        return toFolderProperties(metaData, null);
    }

    public static Map<String, Object> toFolderProperties(RcProductionDocumentRequest metaData,
            Map<String, Object> properties) {
        if (metaData == null)
            return Collections.emptyMap();

        var alfrescoProps = AlfrescoFolderProperties.builder()
                .numeroPoliceDossier(metaData.getPolicyNumber())
                .build();

        return toFolderProperties(properties, alfrescoProps);
    }

    public static Map<String, Object> toDocumentProperties(RcProductionDocumentRequest metaData) {
        return toDocumentProperties(metaData, null);
    }

    public static Map<String, Object> toDocumentProperties(RcProductionDocumentRequest metaData,
            Map<String, Object> properties) {
        if (metaData == null)
            return Collections.emptyMap();
        var alfrescoProps = AlfrescoDocumentProperties.builder()
                .numPolice(metaData.getPolicyNumber())
                .build();
        return toDocumentProperties(properties, alfrescoProps);
    }

    public static Map<String, Object> toDocumentProperties(RcProductionDocumentUpdateRequest metaData) {
        return toDocumentProperties(metaData, null);
    }

    public static Map<String, Object> toDocumentProperties(RcProductionDocumentUpdateRequest metaData,
            Map<String, Object> properties) {
        if (metaData == null)
            return Collections.emptyMap();
        var alfrescoProps = AlfrescoDocumentProperties.builder()
                .numPolice(metaData.getPolicyNumber())
                // .identifiantScaner(metaData.getReference())
                // .isAuthentique(metaData.isOriginal())
                .build();
        return toDocumentProperties(properties, alfrescoProps);
    }
}
