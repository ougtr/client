package ma.axa.inner.ged.helper.updateAt;

import com.fasterxml.jackson.annotation.JsonInclude;
import ma.axa.inner.ged.domain.ESDocumentATRequest;
import org.springframework.beans.BeanUtils;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ESAtDoc extends ESDocumentATRequest {
    public ESAtDoc(ESDocumentATRequest esDocumentATRequest){

        BeanUtils.copyProperties(esDocumentATRequest,this);

    }
}
