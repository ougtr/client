package ma.axa.inner.ged.dto.production.rc;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RcProductionDocumentUpdateRequest {
    
    private String policyNumber;
    private Integer typedocument;
    private String typedocumentLabel;
    private String idAlfresco;
    private String status;
    
}
