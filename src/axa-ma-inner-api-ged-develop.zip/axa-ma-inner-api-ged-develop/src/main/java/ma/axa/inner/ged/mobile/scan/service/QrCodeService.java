package ma.axa.inner.ged.mobile.scan.service;

import java.io.IOException;

import com.google.zxing.WriterException;

import ma.axa.inner.ged.mobile.scan.dto.OcrDocDto;
import ma.axa.inner.ged.mobile.scan.dto.ScanResponse;

public interface QrCodeService {

	ScanResponse generateQRCode(String string, int i, int j) throws WriterException, IOException;

	ScanResponse getTypeDocumentByToken(String token);

	OcrDocDto getocrDocumentByToken(String token);

}
