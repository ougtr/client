package ma.axa.inner.ged.dto;

import lombok.Builder;
import lombok.Data;
import ma.axa.inner.ged.enums.TagTypeEnum;

@Data
@Builder
public class TypeDocResponse {
    private Integer id;
    private Integer entityId;
    private String label;
    private Integer repositoryId;
    private TagTypeEnum tagType;
    private String outgoingPerimeter;
}
