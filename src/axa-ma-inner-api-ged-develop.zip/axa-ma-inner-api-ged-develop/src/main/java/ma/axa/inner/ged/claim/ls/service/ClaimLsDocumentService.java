package ma.axa.inner.ged.claim.ls.service;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import lombok.RequiredArgsConstructor;
import ma.axa.inner.ged.claim.ls.domain.DocumentClaimLsEs;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsReq;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsResp;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsSearchParams;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsUpdateReq;
import ma.axa.inner.ged.claim.ls.mapper.ClaimLsAlfrescoMapper;
import ma.axa.inner.ged.claim.ls.mapper.ClaimLsMapper;
import ma.axa.inner.ged.claim.ls.repository.ClaimLsElasticRepository;
import ma.axa.inner.ged.domain.alfresco.DocumentAlfresco;
import ma.axa.inner.ged.dto.CommonResponse;
import ma.axa.inner.ged.exception.*;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.service.AlfrescoGedService;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.ResponseUtils;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import lombok.extern.slf4j.Slf4j;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;


@Slf4j
@Service
@RequiredArgsConstructor
public class ClaimLsDocumentService {

	private final BrancheProperties lsProperties;
	private final ClaimLsMapper lsMapper;

	private final AlfrescoGedService alfrescoService;
	private final ClaimLsElasticRepository elasticLsRepository;


	/**
	 * Get document meta-data in elasticSearch by documentId
	 */
	public DocClaimLsResp getDocumentById(@NotBlank String documentId) {
		var isExistInElastic = elasticLsRepository.exists(documentId);
		if (!isExistInElastic)
			throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
					GlobalConstants.ERROR_MSG_RD_IDDOCUMENT_NOT_FOUND, new String[]{documentId});
		var response = elasticLsRepository.findById(documentId).orElse(null);
		return lsMapper.toDto(response);
	}

	/**
	 * Searching documents in elasticSearch
	 *
	 * @param searchParams
	 * @return {@link Page} of founded documents
	 */
	public Page<DocClaimLsResp> search(@NotNull DocClaimLsSearchParams searchParams) {
		var response = elasticLsRepository.findByCriteria(searchParams);
		var page = ClaimLsMapper.mapToPage(response, searchParams.getPageNumber(), searchParams.getPageSize());
		return page.map(lsMapper::toDto);
	}


	/**
	 * Download file & Prepare response headers, used in rest controller
	 *
	 * @param idAlfresco id file in Alfresco
	 * @return byte content as {@link ResponseEntity}
	 */
	public ResponseEntity<Resource> downloadFile(final String idAlfresco) {
		var document = getFileFromAlfresco(idAlfresco);
		var is = document.getContentStream().getStream();
		try {
			var content = IOUtils.toByteArray(is);
			var bar = new ByteArrayResource(content);
			var mimeType = document.getContentStreamMimeType();
			if (StringUtils.isBlank(mimeType) && StringUtils.isNotBlank(document.getName()))
				mimeType = URLConnection.guessContentTypeFromName(document.getName());
			var fileName = StringUtils.isNotBlank(document.getName()) ? document.getName() : "unknown_filename";
			var headers = ResponseUtils.getDownloadHeaders(fileName, document.getContentStreamLength(), mimeType);
			return ResponseEntity.ok().headers(headers).body(bar);
		} catch (IOException e) {
			log.error("Error during reading inputStream, err: {} ", e.getMessage());
			return null;
		}
	}

	/**
	 * Get file content from Alfresco
	 *
	 * @param idAlfresco Id of document
	 */
	public Document getFileFromAlfresco(final String idAlfresco) {
		if (!alfrescoService.exists(idAlfresco))
			throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
					"Document with id {0} not found", new String[]{idAlfresco});
		try {
			return alfrescoService.getDocument(idAlfresco);
		} catch (Exception e) {
			var err = "Error during retreive document from alfresco, err: " + e.getMessage();
			log.error(err);
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, err);
		}
	}

	/**
	 * Upload new document to Alfresco and index meta-data in ES
	 *
	 * @param metaData Meta data of document
	 * @param file     Document Content
	 * @return
	 * @throws Exception
	 */
	public DocClaimLsResp uploadDocWithMetaData(final DocClaimLsReq metaData,
													 final MultipartFile file) {
		// Check if reference already exist
		var reference = metaData.getReference();
		var documentExist = elasticLsRepository.findOneDocumentByReference(reference);
		if (documentExist != null)
			throw new ResourceAlreadyExist(GlobalConstants.URI_RECORDE_ALREADY_EXIST,
					GlobalConstants.ERROR_MSG_RD_REFERENCE_ALREADY_EXIST,
					new String[]{reference});
		// Mapping
		var documentEs = lsMapper.fromDto(metaData);
		// validation
		var isValid = validationRequest(documentEs);
		if (isValid != null && !isValid.isSuccess()) {
			throw new RequestValidationException("Error validation", isValid.getMsgErrors());
		}
		try {
			var folderProperties = ClaimLsAlfrescoMapper.toFolderProperties(metaData);
			var targetFolder = prepareDocumentFolder(folderProperties);
			var filename = StringUtils.isBlank(metaData.getFilename()) ? file.getOriginalFilename()
					: metaData.getFilename();
			// Upload Document to alfresco
			DocumentAlfresco createdDocument = null;
			Map<String, Object> properties = ClaimLsAlfrescoMapper.toDocumentProperties(metaData);
			createdDocument = alfrescoService.createDocument(targetFolder, filename, file, properties, true);
			if (createdDocument == null) {
				return null;
			}
			// Indexing document in ES
			documentEs.setId(createdDocument.getId());
			documentEs.setFilename(createdDocument.getFilename());
			documentEs.setPath(createdDocument.getPath());
			documentEs.setBrancheLabel(GlobalConstants.LS_GED_BRANCHE_LABEL);


			elasticLsRepository.createNewDocument(documentEs.getId(), documentEs);
			return lsMapper.toDto(documentEs);
		} catch (ElasticsearchException | IOException e) {
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
		}
	}

	/**
	 * Check & create target folders before upload document
	 *
	 * @param properties
	 * @return
	 */
	public Folder prepareDocumentFolder(Map<String, Object> properties) {
		var branchePath = lsProperties.getAlfrescoRootFolder();
		var sitePath = lsProperties.getAlfrescoSitePath();
		var brancheFolderPath = FileUtil.appendDateAsSubFolders(branchePath);
		var createdFolder = alfrescoService.createTreeFolder(brancheFolderPath, sitePath, properties);
		if (createdFolder == null) {
			throw new InternalErrorException("Erreur lors de la création/ouverture du dossier");
		}
		return createdFolder;
	}

	/**
	 *
	 * @throws IOException
	 * @throws ElasticsearchException
	 * @throws ResourceNotFoundException
	 **/

	public DocClaimLsResp updateDocument(String documentId, DocClaimLsUpdateReq metaData) {
		if (metaData == null)
			throw new NullPointerException("Document meta-data to be updated must no be null");
		if (StringUtils.isBlank(documentId))
			throw new IllegalArgumentException("documentId must not be null");

		var isExistInElastic = elasticLsRepository.exists(documentId);
		if (!isExistInElastic)
			throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
					"Document with id '{0}' not found", new String[]{documentId});
		var documentEs = elasticLsRepository.findById(documentId)
				.orElseThrow(() -> new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
						"Document Not Found"));
		lsMapper.updateFromDto(metaData, documentEs);
		// validation
		var isValid = validationRequest(documentEs);
		if (isValid != null && !isValid.isSuccess()) {
			throw new RequestValidationException("Error validation", isValid.getMsgErrors());
		}
		try {
			// Update Alfresco meta-data, is optional
			updateDocumentAlfrescoProps(documentId, metaData);
			log.debug("[ls-service] start update elastic document properties...");
			elasticLsRepository.updateDocument(documentId, documentEs);
			var updated = elasticLsRepository.findById(documentId).orElse(null);
			return lsMapper.toDto(updated);
		} catch (Exception e) {
			var err = " when update Document, err: " + e.getMessage();
			log.error(err);
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, err);
		}
	}

	// Inputs Validation


	public CommonResponse validationRequest(DocumentClaimLsEs documentEs) {
		var response = CommonResponse.builder();
		var error = new HashMap<String, String>();
		if (!validStatus(documentEs.getStatus(), documentEs.getSinistreNumber())) {
			error.put("status", "Must fill sinistre number to update status = IDENTIFIE");
		}

		response.msgErrors(error);
		response.success(error.isEmpty());
		return response.build();
	}

	public static boolean validStatus(String status, String numSinistre) {
		if (status.equals("Identifié")) {
			return StringUtils.isNotBlank(numSinistre);
		}
		return true;
	}

	public void updateDocumentAlfrescoProps(String documentId, DocClaimLsUpdateReq metaData) {
		try {
			log.debug("[ls-service] start update alfresco document properties...");
			Map<String, Object> properties = ClaimLsAlfrescoMapper.toDocumentProperties(metaData);
			alfrescoService.updateDocumentProperties(documentId, properties);
		} catch (Exception e) {
			log.warn("[ls-service] Error during update alfresco meta-data for id: {}, err: {} ", documentId,
					e.getMessage());
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR,e.getMessage());
		}
	}

	public String deleteDocument(String id) {

		// Delete doc from alfresco and ES
			try {
				alfrescoService.deleteDocument(id);
				elasticLsRepository.deleteDocument(id);
			} catch (Exception e) {
				throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR,
						e.getMessage());
			}

		return id;
	}
}
