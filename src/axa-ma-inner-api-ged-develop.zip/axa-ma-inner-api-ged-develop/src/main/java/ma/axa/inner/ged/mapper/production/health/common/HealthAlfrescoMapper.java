package ma.axa.inner.ged.mapper.production.health.common;

import ma.axa.inner.ged.dto.production.health.common.DocHealthCommonReq;
import ma.axa.inner.ged.mapper.AlfrescoPropsMapper;

import java.util.Collections;
import java.util.Map;

public class HealthAlfrescoMapper extends AlfrescoPropsMapper {

	private HealthAlfrescoMapper() throws InstantiationException {
		throw new InstantiationException("Instances of this type are forbidden");
	}

	// Folders

	public static Map<String, Object> toFolderProperties(DocHealthCommonReq metaData) {
		return toFolderProperties(metaData, null);
	}

	public static Map<String, Object> toFolderProperties(DocHealthCommonReq metaData, Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();

		var alfrescoProps = AlfrescoFolderProperties.builder()
				.numeroPoliceDossier(metaData.getPolicyNumber())
				.build();

		return toFolderProperties(properties, alfrescoProps);
	}

	// Documents

	public static Map<String, Object> toDocumentProperties(DocHealthCommonReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocHealthCommonReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numPolice(metaData.getPolicyNumber())
				.identifiantScaner(metaData.getReference())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}
}