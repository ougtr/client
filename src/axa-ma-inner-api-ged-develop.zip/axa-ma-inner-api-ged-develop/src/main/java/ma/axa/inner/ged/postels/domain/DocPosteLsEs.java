package ma.axa.inner.ged.postels.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocPosteLsEs {
    private String idAlfresco;
    @JsonProperty("filename")
    private String filename;
    @JsonProperty("numPolice")
    private String numPolice;
    @JsonProperty("numQuotation")
    private String numQuotation;
    @NotBlank(message = "Reference est requis")
    @JsonProperty("reference")
    private String reference;
    @NotBlank(message = "CreatedBy est requis")
    @JsonProperty("createdBy")
    private String createdBy;
    @JsonProperty("updatedBy")
    private String updatedBy;
    @JsonProperty("createdAt")
    private String createdAt;
    @JsonProperty("updatedAt")
    private String updatedAt;
    @JsonProperty("applicationCode")
    private String applicationCode = "POSTE-LS";
    @JsonProperty("comment")
    private String comment;
    @JsonProperty("original")
    private boolean original;
    @JsonProperty("typeDocumentCode")
    private String typeDocumentCode;
    @JsonProperty("repertoire")
    private String repertoire;
    @JsonProperty("repertoireCode")
    private String repertoireCode;
    @JsonProperty("path")
    private String path;
    @JsonProperty("branche_label")
    private String brancheLabel;
    @JsonProperty("type_document_label")
    private String typeDocumentLabel;
    @JsonProperty("integrationId")
    private String integrationId;
    @JsonProperty("avenantId")
    private String avenantId;

}
