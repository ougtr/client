package ma.axa.inner.ged.listner;

import ma.axa.inner.ged.dto.cima.production.CountryCode;
import ma.axa.inner.ged.dto.cima.production.ProductType;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.repository.ElasticSearchNewRepository;
import ma.axa.inner.ged.util.constants.ElasticConstants;

@Slf4j
@Component
@Profile("!test")
@RequiredArgsConstructor
public class ElasticInitialization implements ApplicationListener<ApplicationReadyEvent> {
	private final ElasticSearchNewRepository elasticRepository;
	private final ResourceLoader loader;
	private final BrancheProperties rdProperties;
	private final BrancheProperties transportProperties;
	private final BrancheProperties lsProperties;
	private final BrancheProperties rcProperties;
	private final BrancheProperties healthAMCProperties;
	private final BrancheProperties healthDIMProperties;
	private final BrancheProperties healthCommonProperties;
	private final BrancheProperties cimaProperties;
	private final BrancheProperties fleetProperties;
	private final BrancheProperties cimaAutoProperties;
	private final BrancheProperties posteLsProperties;

	private final BrancheProperties medProperties;

	@Override
	public void onApplicationEvent(ApplicationReadyEvent event) {
		try {
			initIndex(rdProperties.getEsDocIndex(), ElasticConstants.IDX_CLAIM_RD_SCHEMA);
			initIndex(transportProperties.getEsDocIndex(), ElasticConstants.IDX_CLAIM_TRANSPORT_SCHEMA);
			initIndex(lsProperties.getEsDocIndex(), ElasticConstants.IDX_CLAIM_LS_SCHEMA);
			initIndex(cimaAutoProperties.getEsDocIndex(), ElasticConstants.IDX_CIMA_AUTO_SCHEMA);
			initCimaIndexes();
			initCimaAutoIndexes();
			initIndex(rcProperties.getEsDocIndex(), ElasticConstants.IDX_PRODUCTION_RC_SCHEMA);
			initHealthIndexes();
			initFlotteIndexes();
			initIndex(posteLsProperties.getEsDocIndex(), ElasticConstants.IDX_POSTE_LS_SCHEMA);
			initIndex(medProperties.getEsDocIndex(), ElasticConstants.IDX_TRANSVERSE_MED_SCHEMA);
		} catch (Exception e) {
			log.error("[es-init] Error init elasticsearch, err: {}", e.getMessage());
		}
	}

	private void initCimaIndexes() {
		for (CountryCode countryCode : CountryCode.values()) {
			for(ProductType productType: ProductType.values()) {
				final var index = String.join("-", countryCode.name().toLowerCase(), cimaProperties.getEsDocIndex(), productType.name().toLowerCase());
				initIndex(index, ElasticConstants.IDX_CIMA_MRP_SCHEMA);
			}
		}
	}
	
	private void initCimaAutoIndexes() {
		for (CountryCode countryCode : CountryCode.values()) {
			for(ProductType productType: ProductType.values()) {
				final var index = String.join("-", countryCode.name().toLowerCase(), cimaProperties.getEsDocIndex(), productType.name().toLowerCase());
				initIndex(index, ElasticConstants.IDX_CIMA_AUTO_SCHEMA);
			}
		}
	}

private void initFlotteIndexes() {
		initIndex(fleetProperties.getEsDocIndex(), ElasticConstants.IDX_PRODUCTION_FLOTTE_SCHEMA);
	}

	private void initHealthIndexes() {
		initIndex(healthAMCProperties.getEsDocIndex(), ElasticConstants.IDX_PRODUCTION_HEALTH_AMC_SCHEMA);
		initIndex(healthDIMProperties.getEsDocIndex(), ElasticConstants.IDX_PRODUCTION_HEALTH_DIM_SCHEMA);
		initIndex(healthCommonProperties.getEsDocIndex(), ElasticConstants.IDX_PRODUCTION_HEALTH_COMMON_SCHEMA);
	}

	private boolean initIndex(final String index, final String mappingFilePath) {
		log.info("[es-init] Start Elastic Initialization for index: {}", index);

		final var resource = loader.getResource("classpath:" + mappingFilePath);
		try (var is = resource.getInputStream()) {
			var isExist = elasticRepository.exists(index);
			if (isExist) {
				log.info("[es-init] Index: [{}] Already exists", index);

				// Update
				log.info("[es-init] Index: [{}]  Update Mapping ... ", index);
				var updated = elasticRepository.updateIndexMappingFromJson(index, is);
				if (updated) {
					log.info("[es-init] Index: [{}] mapping has been updated successfully", index);
				}
				return true;
			}
			// Create if index not found
			log.info("[es-init] Index: [{}] Creating ... ", index);
			var created = elasticRepository.createNewIndexFromJson(index, is);
			if (created) {
				log.info("[es-init] Index: [{}], has been created successfully", index);
			}
		} catch (Exception e) {
			log.error("[es-init] Error during init index: [{}], err: {}", index, e.getMessage());
			return false;
		}
		return true;
	}

}