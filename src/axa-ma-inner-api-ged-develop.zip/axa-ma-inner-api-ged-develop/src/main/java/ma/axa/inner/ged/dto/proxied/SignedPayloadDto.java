package ma.axa.inner.ged.dto.proxied;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SignedPayloadDto {

    private String documentId;
    private long expiresAt;
    private String signature;

}
