package ma.axa.inner.ged.claim.transport.dto;

import javax.validation.constraints.NotBlank;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class DocClaimTransportUpdateReq extends DocClaimTransportBaseDto {
	@NotBlank(message = GlobalConstants.ERROR_MSG_RD_LASTUPDATEDBY_NOT_BLANK)
	private String lastUpdatedBy;

	private Integer brancheCode;
	private String brancheLabel;
	
	protected String status;
	private String repertoire;
	private String repertoireCode;
}
