package ma.axa.inner.ged.service.production.health.common;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.alfresco.DocumentAlfresco;
import ma.axa.inner.ged.domain.production.health.common.DocumentHealthEs;
import ma.axa.inner.ged.dto.production.health.common.DocHealthCommonReq;
import ma.axa.inner.ged.dto.production.health.common.DocHealthCommonResp;
import ma.axa.inner.ged.dto.production.health.common.DocHealthSearchParams;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.ResourceNotFoundException;
import ma.axa.inner.ged.mapper.production.health.common.HealthAlfrescoMapper;
import ma.axa.inner.ged.mapper.production.health.common.HealthDocMapper;
import ma.axa.inner.ged.repository.production.health.common.HealthCommonElasticRepository;
import ma.axa.inner.ged.service.AlfrescoGedService;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.ResponseUtils;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Slf4j
@Service
@RequiredArgsConstructor
public class HealthDocumentService {

	private final AlfrescoGedService alfrescoService;
	private final HealthDocMapper healthDocMapper;
	private final BrancheProperties healthCommonProperties;
	private final HealthCommonElasticRepository elasticRepository;


	/**
	 * Download file & Prepare response headers, used in rest controller
	 *
	 * @param idAlfresco id file in Alfresco
	 * @return byte content as {@link ResponseEntity}
	 */
	public ResponseEntity<Resource> downloadFile(final String idAlfresco) {
		log.info("[health-common-api] start download file " + idAlfresco) ;
		var doc = getDocumentFromAlfresco(idAlfresco);
		try {
			return ResponseUtils.constructDocumentResponse(doc);
		} catch (IOException e) {
			log.error("Error during reading inputStream, err: {} ", e.getMessage());
			return null;
		}
	}

	/**
	 * Get file content from Alfresco
	 *
	 * @param idAlfresco Id of document
	 */
	public Document getDocumentFromAlfresco(final String idAlfresco) {
		if (!alfrescoService.exists(idAlfresco))
			throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
					"Document {0} not found", new String[]{idAlfresco});
		try {
			return alfrescoService.getDocument(idAlfresco);
		} catch (Exception e) {
			var err = "Error during retreive document from alfresco, err: " + e.getMessage();
			log.error(err);
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, err);
		}
	}


	public List<DocHealthCommonResp> uploadHealthDocument(DocHealthCommonReq metaData, List<MultipartFile> files) {
		log.info("[health-common-api] upload health document ") ;
		try {
			List<DocumentHealthEs> esDocuments = new ArrayList<>();
			for (MultipartFile file : files) {
				var documentEs = healthDocMapper.fromDto(metaData);
				documentEs.setFilesize(file.getSize());
				if (FileUtil.isValidFile(file)) {
					String filename = file.getOriginalFilename();
					if (filename != null) {
						FileUtil.assertFileNameValid(filename);
					}
					var folderProperties = HealthAlfrescoMapper.toFolderProperties(metaData);
					var targetFolder = alfrescoService.prepareDocumentFolder(healthCommonProperties.getAlfrescoRootFolder(), healthCommonProperties.getAlfrescoSitePath(),folderProperties,!StringUtils.isEmpty(metaData.getPolicyNumber())? metaData.getPolicyNumber() : metaData.getDemandReference());

					// Upload Document to alfresco
					DocumentAlfresco createdDocument = null;
					Map<String, Object> properties = HealthAlfrescoMapper.toDocumentProperties(metaData);
					createdDocument = alfrescoService.createDocument(targetFolder, filename, file, properties, true);
					if (createdDocument == null) {
						return null;
					}
					// Indexing document in ES
					alfrescoService.indexDocument(createdDocument,documentEs,GlobalConstants.HEALTH_COMMON_GED_BRANCHE_LABEL);
					elasticRepository.createNewDocument(documentEs.getId(), documentEs);
					esDocuments.add(documentEs);
				}
			}
			return healthDocMapper.toDtoList(esDocuments);
		} catch (ElasticsearchException | IOException e) {
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
		}
	}

	public String deleteDocument(String id) {
		log.info("[health-common-api] delete document " + id) ;
		// Delete doc from alfresco and ES
		try {
			alfrescoService.deleteDocument(id);
			elasticRepository.deleteDocument(id);
		} catch (Exception e) {
			throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR,
					e.getMessage());
		}
		return id;
	}

	public Page<DocHealthCommonResp> search(@NotNull DocHealthSearchParams searchParams) {
		log.info("[health-common-api] start multi search");
		var response = elasticRepository.findByCriteria(searchParams,false);
		var page = HealthDocMapper.mapToPage(response, searchParams.getPageNumber(), searchParams.getPageSize());
		return page.map(healthDocMapper::toDto);
	}

}