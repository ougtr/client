package ma.axa.inner.ged.claim.health.repository;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.health.domain.GedHealthEntityAS400;
import ma.axa.inner.ged.claim.health.domain.GedHealthEntityRes;
import ma.axa.inner.ged.claim.health.domain.GedProductionHealthEntityAS400;
import ma.axa.inner.ged.claim.health.domain.UploadedDocumentAs400;
import ma.axa.inner.ged.exception.CallStoredProcedureException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;


@Repository
@RequiredArgsConstructor
@Slf4j
public class HealthDocumentsRepository {

    private final JdbcTemplate jdbcTemplate;

    @SneakyThrows
    public String addMetaDataDocument(GedHealthEntityAS400 request) {
        try {

            return jdbcTemplate.queryForObject("CALL LGRPP.PSGDCV010(?,?,?,?,?)", String.class,
                    request.getTypges(), request.getNomdoc(), request.getTypedoc(),
                    request.getIdeged(), request.getUsercr());
        } catch (Exception e) {
            log.error("cannot call procedure to save metadata '{}'", e.getMessage());
            throw new CallStoredProcedureException(e.getMessage());
        }

    }

    @SneakyThrows
    public List<GedHealthEntityRes> getDocuments(String typeGestion, String nomDoc) {
        try {
            log.info("Start: get Doc health by '{}' et '{}'", typeGestion, nomDoc);
            var list = jdbcTemplate.query("CALL LGRPP.PSGDCV011(?,?)",
                    BeanPropertyRowMapper.newInstance(GedHealthEntityRes.class),
                    typeGestion,
                    nomDoc);
            log.info("End repository: Searching sinistre by params '{}' et '{}'", typeGestion, nomDoc);
            return list;
        } catch (Exception e) {
            log.error("cannot call procedure to get sinistre by claim number : '{}'", e.getMessage());
            throw new CallStoredProcedureException(e.getMessage());
        }
    }

    @SneakyThrows
    public String deleteHealthMetadata(String nomDoc, String typeDoc) {
        try {
            return jdbcTemplate.queryForObject("CALL LGRPP.PSGDCV013(?,?)", String.class,
                    nomDoc, typeDoc);
        } catch (Exception e) {
            log.error("cannot call procedure to delete metadata '{}'", e.getMessage());
            throw new CallStoredProcedureException(e.getMessage());
        }
    }

    public String addMetaDataDocumentPsi(GedProductionHealthEntityAS400 request) {
        try {
            return jdbcTemplate.queryForObject("CALL LGRPP.PSGAMD003(?,?,?,?,?,?,?,?,?)", String.class,
                    request.getCodpro(), request.getIdeamc(), request.getColng4(),
                    request.getIdeged(), request.getBdlusr(), request.getRectype(), request.getPonpo1(), request.getPonpo2(), request.getMenuor());
        } catch (Exception e) {
            log.error("cannot call procedure to save metadata '{}'", e.getMessage());
            throw new CallStoredProcedureException(e.getMessage());
        }

    }
    @SneakyThrows
    public List<UploadedDocumentAs400> getUploadedDocuments(String codeProduct, BigDecimal idQuotation, Integer orderNumber) {
        try {

            return jdbcTemplate.query("CALL LGRPP.PSGAMD001(?,?,?)",
                    BeanPropertyRowMapper.newInstance(UploadedDocumentAs400.class), codeProduct, idQuotation, orderNumber);

        } catch (Exception e) {
            throw new CallStoredProcedureException(e.getMessage());
        }
    }

}

