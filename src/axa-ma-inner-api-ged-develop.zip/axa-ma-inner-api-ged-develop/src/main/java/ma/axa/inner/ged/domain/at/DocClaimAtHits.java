package ma.axa.inner.ged.domain.at;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class DocClaimAtHits {
    private Integer total;
    @JsonProperty("max_score")
    private Double maxScore;
    private List<DocClaimAtHit> hits;
}
