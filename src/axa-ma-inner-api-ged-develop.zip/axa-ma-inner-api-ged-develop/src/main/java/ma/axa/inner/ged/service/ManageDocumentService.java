package ma.axa.inner.ged.service;

import java.util.HashMap;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.commons.exceptions.CmisContentAlreadyExistsException;

import lombok.RequiredArgsConstructor;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.util.StringUtil;

@RequiredArgsConstructor
@Slf4j
public class ManageDocumentService {

	protected final ClaimDocumentRepository claimDocumentRepository;

 
	public Map<String,String> uploadFile(Map<String, Object> metadata, GedDocument gedDocument, Folder folder) {
		log.info("Start: Uploading file  '{}' with metadata '{}'", gedDocument.getFileName(),metadata);

		String idAlfresco = null;
		var output = new HashMap<String,String>();
		var filename = gedDocument.getFileName();
		var changeName = false;
		var i = 1;
		do {
			if (changeName) {
				filename = StringUtil.incrementExistingFilename(filename, i);
				changeName = false;
				i++;
				gedDocument.setFileName(filename);
			}
			try {
				log.debug("Start: create document '{}' in repository ",gedDocument.getFileName());
				var uploadedDocument = claimDocumentRepository.createDocument(folder, gedDocument);
				if (uploadedDocument == null) {
					log.error("can not create document '{}' in repository ",gedDocument.getFileName());
					throw new InternalErrorException("Erreur lors de l'upload du document");
				}
				log.debug("End: create document '{}' in repository ",gedDocument.getFileName());
				uploadedDocument.updateProperties(metadata);
				idAlfresco = uploadedDocument.getVersionSeriesId();
			} catch (CmisContentAlreadyExistsException e) {
				changeName = true;
			}
		} while (changeName);
		output.put("idAlfresco",idAlfresco);
		output.put("filename", filename);
		log.info("End: File uploaded '{}' with output '{}' and '{}'", gedDocument.getFileName(),output,gedDocument.getMimeType());
		return output;
	}

	public Map<String,String> uploadTestFile(Map<String, Object> metadata, GedDocument gedDocument, Folder folder) {
		log.info("Start: Uploading file  '{}' with metadata '{}'", gedDocument.getFileName(),metadata);

		String idAlfresco = null;
		var output = new HashMap<String,String>();
		var filename = gedDocument.getFileName();
		var changeName = false;
		do {
			if (changeName) {
				filename = StringUtil.makeExistingFileNameUnique(filename);
				changeName = false;
				gedDocument.setFileName(filename);
			}
			try {
				log.debug("Start: create document '{}' in repository ",gedDocument.getFileName());
				var uploadedDocument = claimDocumentRepository.createDocument(folder, gedDocument);
				if (uploadedDocument == null) {
					log.error("can not create document '{}' in repository ",gedDocument.getFileName());
					throw new InternalErrorException("Erreur lors de l'upload du document");
				}
				log.debug("End: create document '{}' in repository ",gedDocument.getFileName());
				uploadedDocument.updateProperties(metadata);
				idAlfresco = uploadedDocument.getVersionSeriesId();
			} catch (CmisContentAlreadyExistsException e) {
				changeName = true;
			}
		} while (changeName);
		output.put("idAlfresco",idAlfresco);
		output.put("filename", filename);
		log.info("End: File uploaded '{}' with output '{}' and '{}'", gedDocument.getFileName(),output,gedDocument.getMimeType());
		return output;
	}
}
