package ma.axa.inner.ged.repository.production.health.common;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.production.health.common.DocumentHealthEs;
import ma.axa.inner.ged.dto.production.health.common.DocHealthSearchParams;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.repository.ElasticSearchNewRepository;
import ma.axa.inner.ged.util.ElasticSearchUtils;
import ma.axa.inner.ged.util.constants.ElasticConstants;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


@Repository
@RequiredArgsConstructor
@Slf4j
public class HealthCommonElasticRepository {
    private final BrancheProperties healthCommonProperties;
    private final ElasticSearchNewRepository elasticRepository;


    /**
     * Create new Document in ElasticSearch
     */
    public String createNewDocument(final String documentId, final DocumentHealthEs metaData)
            throws ElasticsearchException, IOException {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("ID Document must not be blank");
        if (metaData == null)
            throw new NullPointerException("Document Health AMC must not be null");

        try {
            if (exists(documentId)) {
                throw new ResourceAlreadyExist(GlobalConstants.URI_RECORDE_ALREADY_EXIST,
                        "Document with id {0} already exist",
                        new String[] { documentId });
            }

            var created = elasticRepository.createNewDocument(healthCommonProperties.getEsDocIndex(), documentId, metaData);
            if (created != null) {
                log.info("[es-repo] Successfully created new document Health AMC with id: {}", documentId);
                return created;
            }
        } catch (Exception e) {
            log.error("[es-repo] Error creating new document for id: {}, err: {} ", documentId, e.getMessage());
            throw e;
        }
        return null;
    }

    /**
     * Check if document id exist
     *
     * @param documentId
     */
    public boolean exists(String documentId) {
        return elasticRepository.existsDocument(healthCommonProperties.getEsDocIndex(), documentId);
    }

    public boolean deleteDocument(String documentId) {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("documentId must not be blank");
        try {
            var response = elasticRepository.deleteDocument(healthCommonProperties.getEsDocIndex(), documentId);
            if (response) {
                log.debug("[es-repo]Successfully deleted document Health AMC with id: {}", documentId);
                return true;
            }
        } catch (Exception e) {
            log.warn("[es-repo] Error deleting document by id: {}, err: {}", documentId, e.getMessage());
        }
        return false;
    }


    public SearchResponse<DocumentHealthEs> findByCriteria(DocHealthSearchParams searchParams, boolean findAll) {
        elasticRepository.refreshIndex(healthCommonProperties.getEsDocIndex());
        try {
            var boolQuery = new BoolQuery.Builder();
            var query = ElasticSearchUtils.getQueryForMultiSearch(constructSearchMap(searchParams));
            boolQuery.must(query);
            int from = searchParams.getPageNumber() * searchParams.getPageSize();
            var searchRequest = new SearchRequest.Builder();
            searchRequest.index(healthCommonProperties.getEsDocIndex())
                    .query(q -> q
                            .bool(boolQuery.build()));
            if (!findAll) {
                searchRequest.from(from).size(searchParams.getPageSize());
            }
            return elasticRepository.search(searchRequest, DocumentHealthEs.class);
        } catch (Exception e) {
            log.error("Error during elastic search", e);
            return null;
        }
    }

    private Map<String, String> constructSearchMap(DocHealthSearchParams searchParams) {
        Map<String,String> searchMap= new HashMap<>();
        searchMap.put(ElasticConstants.POLICY_NUMBER, searchParams.getPolicyNumber());
        searchMap.put(ElasticConstants.INTEGRATION_ID, searchParams.getIntergationId());
        return searchMap;
    }




}