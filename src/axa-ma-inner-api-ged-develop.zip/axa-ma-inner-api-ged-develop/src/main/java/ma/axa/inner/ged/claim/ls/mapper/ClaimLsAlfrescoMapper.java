package ma.axa.inner.ged.claim.ls.mapper;

import ma.axa.inner.ged.claim.ls.dto.DocClaimLsReq;
import ma.axa.inner.ged.claim.ls.dto.DocClaimLsUpdateReq;
import ma.axa.inner.ged.mapper.AlfrescoPropsMapper;

import java.util.Collections;
import java.util.Map;

public class ClaimLsAlfrescoMapper extends AlfrescoPropsMapper {

	private ClaimLsAlfrescoMapper() throws InstantiationException {
		throw new InstantiationException("Instances of this type are forbidden");
	}

	// Folders

	public static Map<String, Object> toFolderProperties(DocClaimLsReq metaData) {
		return toFolderProperties(metaData, null);
	}

	public static Map<String, Object> toFolderProperties(DocClaimLsReq metaData, Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();

		var alfrescoProps = AlfrescoFolderProperties.builder()
				.numeroSinistreDossier(metaData.getSinistreNumber())
				.build();

		return toFolderProperties(properties, alfrescoProps);
	}

	// Documents

	public static Map<String, Object> toDocumentProperties(DocClaimLsReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocClaimLsReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numSinistre(metaData.getSinistreNumber())
				.identifiantScaner(metaData.getReference())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}

	public static Map<String, Object> toDocumentProperties(DocClaimLsUpdateReq metaData) {
		return toDocumentProperties(metaData, null);
	}

	public static Map<String, Object> toDocumentProperties(DocClaimLsUpdateReq metaData,
			Map<String, Object> properties) {
		if (metaData == null)
			return Collections.emptyMap();
		var alfrescoProps = AlfrescoDocumentProperties.builder()
				.numSinistre(metaData.getSinistreNumber())
				.identifiantScaner(metaData.getReference())
				.isAuthentique(metaData.isOriginal())
				.build();
		return toDocumentProperties(properties, alfrescoProps);
	}
}
