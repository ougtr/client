package ma.axa.inner.ged.postels.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.*;


@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DocPosteLsReq {
	protected String filename;
	protected String reference;
	protected String numPolice;
	protected String numQuotation;
	@NotBlank(message = "CreatedBy est requis")
	protected String createdBy;
	@NotBlank(message = "updatedBy est requis")
	protected String updatedBy;
	protected String applicationCode = "POSTE-LS";
	protected String comment;
	protected boolean original;
	protected String typeDocumentCode;
	protected String repertoire;
	protected String repertoireCode;
	protected String path;
	protected String brancheLabel;
	protected String typeDocumentLabel;
	protected String integrationId;
    protected String avenantId;
}
