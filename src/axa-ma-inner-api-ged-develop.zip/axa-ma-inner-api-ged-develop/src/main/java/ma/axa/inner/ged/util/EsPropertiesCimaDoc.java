package ma.axa.inner.ged.util;


import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@Setter
@Getter
@ConfigurationProperties("axa.es.cima.document")
public class EsPropertiesCimaDoc {
    private String index;
    private String type;
}
