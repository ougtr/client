package ma.axa.inner.ged.claim.rd.api;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import org.springdoc.api.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdAddReq;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdResponse;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdSearchParams;
import ma.axa.inner.ged.claim.rd.dto.DocClaimRdUpdateReq;
import ma.axa.inner.ged.claim.rd.service.ClaimRdDocumentService;
import ma.axa.inner.ged.dto.CommonResponse;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.constants.PathConstants;

@Slf4j
@RestController
@Validated
@RequestMapping(PathConstants.CLAIM_RD_DOCUMENTS)
@Tag(name = GlobalConstants.TAG_CLAIM_RD_APIS, description = GlobalConstants.TAG_DESC_CLAIM_RD_APIS)
@RequiredArgsConstructor
public class ClaimRdDocumentAPI {

	private final ClaimRdDocumentService service;

	/** ========== Upload Operations ========== **/

	@Operation(summary = "Upload new claim RD document and index meta-data")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Document ID", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = DocClaimRdResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid request", content = @Content) })
	@PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<DocClaimRdResponse> uploadNewDocument(
			@ParameterObject @ModelAttribute @Valid DocClaimRdAddReq documentRdReq,
			@Parameter(description = "Content of the document") @RequestPart(value = "file") MultipartFile file) {
		log.debug("[claim-rd-api] Start Uploading file:  {}", file.getName());
		var createdDocument = service.uploadDocumentWithMetaData(documentRdReq, file);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdDocument);
	}

	/** ========== Download Operations ========== **/

	@Operation(summary = "Download a claim RD document by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was downloaded", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = Resource.class, format = "byte")) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping(value = "/{document_id}/content", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<Resource> downloadDocumentContent(
			@Parameter(required = true, description = "The document id (Alfresco ID)") @NotBlank(message = GlobalConstants.ERROR_MSG_RD_ID_NOT_BLANK) @PathVariable(value = "document_id") String documentId) {
		return service.downloadFile(documentId);
	}

	/** ========== Update Operations ========== **/

	@Operation(summary = "Update claim RD document by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was updated", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = DocClaimRdResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@PutMapping(value = "/{document_id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DocClaimRdResponse> updateDocument(
			@NotBlank(message = GlobalConstants.ERROR_MSG_RD_ID_NOT_BLANK) @PathVariable(value = "document_id") String documentId,
			@Valid @RequestBody DocClaimRdUpdateReq documentReq) {
		var updatedDoc = service.updateDocument(documentId, documentReq);
		return ResponseEntity.ok(updatedDoc);
	}

	/** ========== Delete Operations ========== **/

	@Operation(summary = "Delete claim RD document by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was deleted", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = Boolean.class)) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@DeleteMapping(value = "/{document_id}")
	public ResponseEntity<CommonResponse> deleteDocument(
			@NotBlank(message = GlobalConstants.ERROR_MSG_RD_ID_NOT_BLANK) @PathVariable(value = "document_id") String documentId) {
		return ResponseEntity.ok(service.deleteDocument(documentId));
	}



	/** ========== Search Operations ========== **/

	@Operation(summary = "Get claim RD Document by document_id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was downloaded", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = DocClaimRdResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping(value = "/{document_id}")
	public ResponseEntity<DocClaimRdResponse> getDocument(
			@NotBlank(message = GlobalConstants.ERROR_MSG_RD_ID_NOT_BLANK) @PathVariable(value = "document_id") String documentId) {
		log.debug("[API] Get document by ID [{}] ...", documentId);
		var result = service.getDocumentById(documentId);
		return ResponseEntity.ok(result);
	}

	@Operation(summary = "Search claim RD Documents by multiple criteria")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "document was downloaded", content = {
					@Content(mediaType = "text/plain", schema = @Schema(implementation = Page.class)) }),
			@ApiResponse(responseCode = "404", description = "document not found", content = @Content),
			@ApiResponse(responseCode = "400", description = "not valid request", content = @Content) })
	@GetMapping
	public ResponseEntity<Page<DocClaimRdResponse>> searchDocuments(@Valid DocClaimRdSearchParams searchParams) {
		log.debug("[API] Multi Searching documents...");
		var pageResult = service.search(searchParams);
		return ResponseEntity.ok(pageResult);
	}

}
