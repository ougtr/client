package ma.axa.inner.ged.domain.at;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import ma.axa.inner.ged.domain.Shards;

@Data
public class EsDocumentAtCountSchema {
    private int count;
    @JsonProperty("_shards")
    private Shards shards;
}
