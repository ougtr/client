package ma.axa.inner.ged.repository.production.fleet;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.production.fleet.DocumentFleetEs;
import ma.axa.inner.ged.dto.production.fleet.DocFleetSearchParam;
import ma.axa.inner.ged.exception.ResourceAlreadyExist;
import ma.axa.inner.ged.repository.ElasticSearchNewRepository;
import ma.axa.inner.ged.util.ElasticSearchUtils;
import ma.axa.inner.ged.util.constants.ElasticConstants;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;


@Repository
@RequiredArgsConstructor
@Slf4j
public class FleetElasticRepository {
    private final BrancheProperties fleetProperties;
    private final ElasticSearchNewRepository elasticRepository;


    /**
     * Create new Document in ElasticSearch
     */
    public String createNewDocument(final String documentId, final DocumentFleetEs metaData)
            throws ElasticsearchException, IOException {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("ID Document must not be blank");
        if (metaData == null)
            throw new NullPointerException("Document Flotte AMC must not be null");

        try {
            if (exists(documentId)) {
                throw new ResourceAlreadyExist(GlobalConstants.URI_RECORDE_ALREADY_EXIST,
                        "Document with id {0} already exist",
                        new String[]{documentId});
            }

            var created = elasticRepository.createNewDocument(fleetProperties.getEsDocIndex(), documentId, metaData);
            if (created != null) {
                log.info("[es-repo] Successfully created new document Flotte AMC with id: {}", documentId);
                return created;
            }
        } catch (Exception e) {
            log.error("[es-repo] Error creating new document for id: {}, err: {} ", documentId, e.getMessage());
            throw e;
        }
        return null;
    }

    public SearchResponse<DocumentFleetEs> findByCriteria(DocFleetSearchParam searchParams, boolean findAll) {
        elasticRepository.refreshIndex(fleetProperties.getEsDocIndex());
        try {
            var boolQuery = new BoolQuery.Builder();
            var query = ElasticSearchUtils.getQueryForMultiSearch(constructSearchMap(searchParams));
            boolQuery.must(query);
            int from = searchParams.getPageNumber() * searchParams.getPageSize();
            var searchRequest = new SearchRequest.Builder();
            searchRequest.index(fleetProperties.getEsDocIndex())
                    .query(q -> q
                            .bool(boolQuery.build()));
            if (!findAll) {
                searchRequest.from(from).size(searchParams.getPageSize());
            }
            return elasticRepository.search(searchRequest, DocumentFleetEs.class);
        } catch (Exception e) {
            log.error("Error during elastic search", e);
            return null;
        }
    }

    /**
     * Check if document id exist
     *
     * @param documentId
     */
    public boolean exists(String documentId) {
        return elasticRepository.existsDocument(fleetProperties.getEsDocIndex(), documentId);
    }

    public Optional<DocumentFleetEs> findById(String id) {
        try {
            elasticRepository.refreshIndex(fleetProperties.getEsDocIndex());
            return Optional.of(elasticRepository.findById(fleetProperties.getEsDocIndex(), id, DocumentFleetEs.class));
        } catch (Exception e) {
            log.error("[es-repo] Error find document with id:{}, err: {}", id, e.getMessage());
            return Optional.empty();
        }
    }

    public boolean deleteDocument(String documentId) {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("documentId must not be blank");
        try {
            var response = elasticRepository.deleteDocument(fleetProperties.getEsDocIndex(), documentId);
            if (response) {
                log.debug("[es-repo]Successfully deleted document Flotte AMC with id: {}", documentId);
                return true;
            }
        } catch (Exception e) {
            log.warn("[es-repo] Error deleting document by id: {}, err: {}", documentId, e.getMessage());
        }
        return false;
    }

    public boolean updateDocument(String documentId, final DocumentFleetEs metadata) throws ElasticsearchException, IOException {
        return updateDocument(documentId, metadata, false);
    }

    private boolean updateDocument(final String documentId, final DocumentFleetEs metaData,
                                   boolean isUpsert)
            throws ElasticsearchException, IOException {
        if (StringUtils.isBlank(documentId))
            throw new IllegalArgumentException("Document ID must not be blank.");
        if (metaData == null)
            throw new NullPointerException("Document Fleet must not be null.");

        try {
            var response = elasticRepository.updateDocument(fleetProperties.getEsDocIndex(), documentId, metaData,
                    isUpsert,
                    DocumentFleetEs.class);
            log.info("[es-repo] Successfully updated new document Fleet with id: {}", documentId);
            return response;
        } catch (Exception e) {
            log.error("[es-repo] Error updating  document Fleet with id:{}, err: {}", documentId, e.getMessage());
            throw e;
        }
    }

    private Map<String, String> constructSearchMap(DocFleetSearchParam searchParams) {
        Map<String, String> searchMap = new HashMap<>();
        searchMap.put(ElasticConstants.POLICY_NUMBER, searchParams.getPolicyNumber());
        searchMap.put(ElasticConstants.TYPE_DOCUMENT_LABEL, searchParams.getTypeDocument());
        searchMap.put(ElasticConstants.QUOTATION_NUMBER, searchParams.getIdQuotation());
        searchMap.put(ElasticConstants.SIMULATION_NUMBER, searchParams.getIdSimulation());
        return searchMap;
    }
}