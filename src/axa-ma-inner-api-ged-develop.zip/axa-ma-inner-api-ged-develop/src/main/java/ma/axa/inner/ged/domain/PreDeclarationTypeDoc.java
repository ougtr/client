package ma.axa.inner.ged.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.List;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(value={ "connexeSinistres" }, allowSetters = true)
public class PreDeclarationTypeDoc {

	@JsonProperty("nSin")
	@Pattern(regexp = "^(|\\d{12})$", message = "Le N° de sinistre doit contenir 12 chiffres")
	private String nSin;
	private String idAlfresco;
	@Pattern(regexp = "^$|(?!0+$)\\d{12,16}$", message = "Le N° de police doit contenir moins de 16 chiffres et plus de 12 chiffres")
	private String polnum;
	private String statutBordereau;
	@JsonProperty("typeDoc")
	private String typeDocument;
	@JsonProperty("nomFile")
	private String libDocument;
	private BigDecimal codeExp;
	private String userC;
	private String userM;
	private BigDecimal dateC;
	private BigDecimal dateA;
	private BigDecimal heureC;
	private BigDecimal dateM;
	private BigDecimal heureM;
	@JsonProperty("idPredeclaration")
	private String numPreDeclaration;
	@JsonProperty("formDoc")
	private String formaDoc;
	private String nomVictime;
	private String emplacement;
	@JsonProperty("Aclasser")
	private Integer aclasser;
	@JsonProperty("AclasserPar")
	private String aclasserPar;
	@JsonProperty("AclasserLe")
	private BigDecimal aclasserLe;
	private String dateHeureC;
	private String tpi;
	@Pattern(regexp = "^\\d+/\\d{1,4}/\\d{1,4}$", message = "Merci de respecter la forme correcte de numéro de dossier")
	private String numeroDossier;
	private Boolean documentOriginal;
	@Size(max = 255, message = "La taille max du champ Commentaire est 255 caractères")
	private String commentaire;
	private String entiteEnregistrement;
	private Integer intermediaire ;
	private String immatriculation;
	private String idDocument;
	private String receptionDate;
	private String survenanceDate;
	private String typeDocLabel;
	private String tagLabel;
	private String type;
	private String sendingDate;
	private Long size;
	private List<String> connexeSinistres;
	private String repositoryId;
	private String objectHash;
	private String idTransaction;
}
