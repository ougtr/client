package ma.axa.inner.ged.helper.updateAt;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ESAtUpdateQuery {
    private ESAtDoc doc;
}
