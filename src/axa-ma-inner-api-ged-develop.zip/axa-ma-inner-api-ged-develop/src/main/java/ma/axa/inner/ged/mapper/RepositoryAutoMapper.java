package ma.axa.inner.ged.mapper;


import java.util.List;

import ma.axa.inner.ged.domain.ac.GedDirectory;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import ma.axa.inner.ged.dto.DirectoryResponseDto;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface RepositoryAutoMapper {

    public DirectoryResponseDto toGedRepositoryResponse(GedDirectory gedRepositoriesAS400);

    public List<DirectoryResponseDto> toGedRepositoryResponseList(List<GedDirectory> gedRepositoriesAS400List);

}
