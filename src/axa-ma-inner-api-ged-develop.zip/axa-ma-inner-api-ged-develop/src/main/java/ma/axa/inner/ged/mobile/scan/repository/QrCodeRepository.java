package ma.axa.inner.ged.mobile.scan.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ma.axa.inner.ged.mobile.scan.dto.QrCode;


@Repository
public interface QrCodeRepository extends JpaRepository<QrCode, Integer> {
	

}
