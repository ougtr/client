package ma.axa.inner.ged.domain.production.rc;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RcProductionDocumentEs {
    private String id;
    @JsonProperty("filename")
    private String filename;
    @JsonProperty("path")
    private String path;
    @JsonProperty("reference")
    private String reference;
    @JsonProperty("branche_label")
    private String brancheLabel;
    @JsonProperty("type_document_code")
    private Integer typeDocumentCode;
    @JsonProperty("type_document_label")
    private String typeDocumentLabel;
    @JsonProperty("quotation_number")
    private String quotationNumber;
    @JsonProperty("policy_number")
    private String policyNumber;
    @JsonProperty("corporate_name")
    private String corporateName;
    private String status;
    @JsonProperty("repertoire")
    private String repertoire;
    @JsonProperty("repertoire_code")
    private String repertoireCode;
    @JsonProperty("intermediary_code")
    private Integer intermediaryCode;
    @JsonProperty("created_by")
    private String createdBy;
    @JsonProperty("created_at")
    private LocalDateTime createdAt;
    @JsonProperty("last_updated_by")
    private String lastUpdatedBy;
    @JsonProperty("last_updated_at")
    private LocalDateTime lastUpdatedAt;
    @JsonProperty("filesize")
    private String filesize;
    @JsonProperty("filetype")
    private String filetype;
    @JsonProperty("demand_reference")
    private String demandReference;
    @JsonProperty("product_code")
    private String productCode;
    //TODO : REMOVE Quotation number
    
}
