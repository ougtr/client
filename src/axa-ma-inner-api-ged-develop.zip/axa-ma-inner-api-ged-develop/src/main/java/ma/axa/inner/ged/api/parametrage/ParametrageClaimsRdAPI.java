package ma.axa.inner.ged.api.parametrage;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.dto.parametrage.BrancheResponseDto;
import ma.axa.inner.ged.dto.parametrage.EntityResponseDto;
import ma.axa.inner.ged.dto.parametrage.RepertoireResponseDto;
import ma.axa.inner.ged.dto.parametrage.TypeDocumentResponseDto;
import ma.axa.inner.ged.service.parametrage.ParametrageService;
import ma.axa.inner.ged.util.constants.ClaimsConstants;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import ma.axa.inner.ged.util.constants.PathConstants;

@Slf4j
@RestController
@RequestMapping(PathConstants.CLAIM_RD_PARAMS)
@Tag(name = GlobalConstants.TAG_CLAIM_RD_APIS, description = GlobalConstants.TAG_DESC_CLAIM_RD_APIS)
@RequiredArgsConstructor
public class ParametrageClaimsRdAPI {
	
	public final ParametrageService parametrageService;

	@Operation(summary = "Get all branches")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Branche list fetched", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = BrancheResponseDto.class)) }),
			@ApiResponse(responseCode = "500", description = "internal error", content = @Content) })
	@GetMapping(path = "/branches", produces = { "application/json" })
	public List<BrancheResponseDto> getListBranche() {
		log.info("Start Api BRANCHE");
		var listBranche = parametrageService.getAllBranches();
		log.info("End Api BRANCHE");
		return listBranche;
	}

	@Operation(summary = "Get RD entity by code branche")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Entity RD list fetched", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = EntityResponseDto.class)) }),
			@ApiResponse(responseCode = "500", description = "internal error", content = @Content) })
	@GetMapping(path = "/entities", produces = { "application/json" })
	public List<EntityResponseDto> getListEntitiesRD() {
		log.info("Start Api ENTITY");
		var listEntity = parametrageService.getEntityByBranche(ClaimsConstants.BRANCH_RD_CODE);
		log.info("End Api ENTITY");
		return listEntity;
	}

	@Operation(summary = "Get Type Document RD by code entity")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = " RD Type Document list fetched", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = TypeDocumentResponseDto.class)) }),
			@ApiResponse(responseCode = "500", description = "internal error", content = @Content) })
	@GetMapping(path = "/entities/{entity_code}/type-documents", produces = { "application/json" })
	public List<TypeDocumentResponseDto> getListTypeDocumentByIdEntityRD(
			@PathVariable(value = "entity_code") int idEntity) {
		log.info("Start Api Type Document");
		var listTypeDocument = parametrageService.getTypeDocumentByEntity(idEntity);
		log.info("End Api Type Document");
		return listTypeDocument;
	}

	@Operation(summary = "Get Repertoire by type document RD")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "RD Repertoire list fetched", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = RepertoireResponseDto.class)) }),
			@ApiResponse(responseCode = "500", description = "internal error", content = @Content) })
	@GetMapping(path = "/type-documents/{entity_code}/{type_document_code}/directories", produces = { "application/json" })
	public List<RepertoireResponseDto> getListRepertoireByIdTypeDocumentRD(
			@PathVariable(value = "entity_code") int idEntity, @PathVariable(value = "type_document_code") int idTypeDocument) {
		log.info("Start Api Repertoire");
		var listRepertoire = parametrageService.getListRepertoireByIdTypeDocument(idEntity,idTypeDocument);
		log.info("End Api Repertoire");
		return listRepertoire;
	}

	@Operation(summary = "Get Repertoire RD")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "RD Repertoire list fetched", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = RepertoireResponseDto.class)) }),
			@ApiResponse(responseCode = "500", description = "internal error", content = @Content) })
	@GetMapping(path = "/type-documents/directories", produces = { "application/json" })
	public List<RepertoireResponseDto> getListRepertoireRD() {
		log.info("Start Api Repertoire");
		var listRepertoire = parametrageService.getListRepertoire();
		log.info("End Api Repertoire");
		return listRepertoire;
	}
}
