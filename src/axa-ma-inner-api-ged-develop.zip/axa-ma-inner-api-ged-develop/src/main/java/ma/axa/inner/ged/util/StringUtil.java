package ma.axa.inner.ged.util;

import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.UUID;

public class StringUtil {

	private StringUtil() {
		throw new IllegalStateException("Utility class");
	}

	public static String incrementExistingFilename(String oldFilename, int index) {
		if (index > 1) {
			return oldFilename.replace("_" + (index - 1) + ".", "_" + index + ".");
		} else {
			return oldFilename.replace(".", "_" + index + ".");
		}
	}

	public static String makeExistingFileNameUnique(String oldFileName) {
		return addToExistingFilename(oldFileName, UUID.randomUUID().toString());
	}

	public static String addToExistingFilename(String oldFilename, String size) {


			return StringUtils.replace(oldFilename,".", "_" + size + ".");

	}

	public static String addTimestampToExistingFileNameWithoutFileNameAlteration(String oldFileName){
		return addToExistingFilename(oldFileName,String.valueOf((new Date()).getTime()));
	}

	public static String addTimestampToExistingFileName(String oldFileName){
		return addToExistingFilename(replaceExistingFileNameTemporaryIterations(oldFileName),String.valueOf((new Date()).getTime()));
	}

	public static String replaceExistingFileNameTemporaryIterations(String oldFileName){
		return oldFileName.replaceAll("_\\d+.",".");
	}
	
	public static <U extends Number> String toString(U value) {
		return value == null ? null : String.valueOf(value);
	}

	public static String prettyIdAlfresco(String idAlfresco) {
		return idAlfresco != null ? idAlfresco.replace("workspace://SpacesStore/", "") : null;
	}
}
