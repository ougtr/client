package ma.axa.inner.ged.claim.health.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.validation.constraints.NotBlank;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DocClaimHealthReq {
    @NotBlank(message = "Type document obligatoire")
    private String typeDoc;
    @NotBlank(message = "Nom document obligatoire")
    private String nomDoc;
    private String idAlfresco;
    @NotBlank(message = "Type gestion obligatoire")
    private String typeGestion;
    private String uploadedBy;

}
