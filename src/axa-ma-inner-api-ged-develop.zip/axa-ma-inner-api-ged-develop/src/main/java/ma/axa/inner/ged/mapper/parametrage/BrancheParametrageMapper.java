package ma.axa.inner.ged.mapper.parametrage;

import java.math.BigDecimal;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import ma.axa.inner.ged.domain.parametrage.BrancheParametrage;
import ma.axa.inner.ged.dto.parametrage.BrancheResponseDto;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface BrancheParametrageMapper {

	@Mapping(source = "code", target = "codeBranche", qualifiedByName = "convertBigDec")
	@Mapping(source = "libelle", target = "libelleBranche")
	public BrancheResponseDto mapToBrancheDto(BrancheParametrage bp);
	public List<BrancheResponseDto> mapToBrancheDtoList(List<BrancheParametrage> bps);
	
	
	@Named("convertBigDec")
	 default int convertBigDec(BigDecimal code){
        return Integer.valueOf(code.toString());
    }
}
