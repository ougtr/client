package ma.axa.inner.ged.dto.production.health.common;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;


@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DocHealthResp {
	private String policyNumber;
	private String idAlfresco;
	private String filename;
	private String uploadedBy;
	private String repertoire;
	private String repertoireCode;
	private String path;
	private String brancheLabel;
	private String typedocumentLabel;
	private String quotationNumber;
	private String corporateName;
	private String status;
	private Integer intermediaryCode;
	private String createdBy;
	private String createdAt;
	private String filesize;
	private String filetype;
	private String productCode;
	private String demandReference;

}