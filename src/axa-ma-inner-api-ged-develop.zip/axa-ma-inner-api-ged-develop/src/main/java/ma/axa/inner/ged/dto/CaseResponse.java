package ma.axa.inner.ged.dto;

import lombok.Data;

@Data
public class CaseResponse {

	private String caseNumber;
	private String id;
	
}
