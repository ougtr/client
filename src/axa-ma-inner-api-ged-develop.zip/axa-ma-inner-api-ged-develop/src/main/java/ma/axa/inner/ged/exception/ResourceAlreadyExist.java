package ma.axa.inner.ged.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Thrown whenever a record not exist on database.
 */
@Data
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ResourceAlreadyExist extends RuntimeException {
	private static final long serialVersionUID = 4786368668233461454L;

	private final transient Object[] args; // used as msg placeholders
	private final String type;

	public ResourceAlreadyExist(String type, String detail, Object[] args) {
		super(detail);
		this.type = type;
		this.args = args;
	}
}
