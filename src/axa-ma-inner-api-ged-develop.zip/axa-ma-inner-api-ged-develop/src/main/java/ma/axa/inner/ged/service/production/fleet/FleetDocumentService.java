package ma.axa.inner.ged.service.production.fleet;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch.core.search.Hit;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.properties.AxaGedProperties.BrancheProperties;
import ma.axa.inner.ged.domain.alfresco.DocumentAlfresco;
import ma.axa.inner.ged.domain.production.fleet.DocumentFleetEs;
import ma.axa.inner.ged.dto.production.fleet.DocFleetReq;
import ma.axa.inner.ged.dto.production.fleet.DocFleetResp;
import ma.axa.inner.ged.dto.production.fleet.DocFleetSearchParam;
import ma.axa.inner.ged.exception.GlobalException;
import ma.axa.inner.ged.exception.ResourceNotFoundException;
import ma.axa.inner.ged.mapper.production.fleet.FleetAlfrescoMapper;
import ma.axa.inner.ged.mapper.production.fleet.FleetDocMapper;
import ma.axa.inner.ged.repository.production.fleet.FleetElasticRepository;
import ma.axa.inner.ged.service.AlfrescoGedService;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.ResponseUtils;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.apache.chemistry.opencmis.client.api.Document;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Slf4j
@Service
@RequiredArgsConstructor
public class FleetDocumentService {

    private final AlfrescoGedService alfrescoService;
    private final FleetDocMapper fleetDocMapper;
    private final BrancheProperties fleetProperties;
    private final FleetElasticRepository elasticRepository;


    /**
     * Download file & Prepare response headers, used in rest controller
     *
     * @param idAlfresco id file in Alfresco
     * @return byte content as {@link ResponseEntity}
     */
    public ResponseEntity<Resource> downloadFile(final String idAlfresco) {
        log.info("[flotte-common-api] start download file {} ", idAlfresco);
        var doc = getDocumentFromAlfresco(idAlfresco);
        try {
            return ResponseUtils.constructDocumentResponse(doc);
        } catch (IOException e) {
            log.error("Error during reading file : {} ", e.getMessage());
            return null;
        }
    }

    /**
     * Get file content from Alfresco
     *
     * @param id Id of document
     */
    public Document getDocumentFromAlfresco(final String id) {
        if (!alfrescoService.exists(id))
            throw new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
                    "Document {0} not found", new String[]{id});
        try {
            return alfrescoService.getDocument(id);
        } catch (Exception e) {
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, "Error during retreive document from alfresco, err: " + e.getMessage());
        }
    }

    /***
     *
     * @param metaData
     * @param files
     * @return
     */
    public List<DocFleetResp> uploadFleetDocument(DocFleetReq metaData, List<MultipartFile> files) {
        log.info("[flotte-api] upload flotte document ");
        try {
            List<DocumentFleetEs> esDocuments = new ArrayList<>();
            for (MultipartFile file : files) {
                var documentEs = fleetDocMapper.fromDto(metaData);
                documentEs.setFilesize(file.getSize());
                if (FileUtil.isValidFile(file)) {
                    String filename = file.getOriginalFilename();
                    if (filename != null) {
                        FileUtil.assertFileNameValid(filename);
                    }
                    var folderProperties = FleetAlfrescoMapper.toFolderProperties(metaData);
                    var targetFolder = alfrescoService.prepareDocumentFolder(fleetProperties.getAlfrescoRootFolder(), fleetProperties.getAlfrescoSitePath(), folderProperties, metaData.getPolicyNumber());

                    // Upload Fleet Document to alfresco
                    DocumentAlfresco createdDocument = null;
                    Map<String, Object> properties = FleetAlfrescoMapper.toDocumentProperties(metaData);
                    createdDocument = alfrescoService.createDocument(targetFolder, filename, file, properties, true);
                    if (createdDocument == null) {
                        return null;
                    }
                    // Indexing Fleet document in ES
                    alfrescoService.indexDocument(createdDocument, documentEs, GlobalConstants.FLOTTE_GED_BRANCHE_LABEL);
                    elasticRepository.createNewDocument(documentEs.getId(), documentEs);
                    esDocuments.add(documentEs);
                }
            }
            return fleetDocMapper.toDtoList(esDocuments);
        } catch (ElasticsearchException | IOException e) {
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, e.getMessage());
        }
    }

    /***
     *
     * @param idAflr
     * @return
     */
    public String deleteDocument(String idAflr) {
        log.info("[flotte-api] delete document {}", idAflr);
        // Delete doc
        try {
            alfrescoService.deleteDocument(idAflr);
            elasticRepository.deleteDocument(idAflr);
        } catch (Exception e) {
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR,
                    e.getMessage());
        }
        return idAflr;
    }

    /***
     *
     * @param quotationNumber
     * @param simulationId
     * @param userName
     */
    public void tagAllDocumentsByQuotationNumber(String quotationNumber, String simulationId, String userName) {
        log.info("[FLEET] tag documents by quotationId {}", quotationNumber);
        DocFleetSearchParam params = DocFleetSearchParam.builder().idSimulation(simulationId).build();
        var response = elasticRepository.findByCriteria(params, true);
        List<DocumentFleetEs> results = response.hits().hits().stream()
                .map(Hit::source)
                .collect(Collectors.toList());
        for (DocumentFleetEs doc : results) {
            indexDocByQuotationNumber(doc, quotationNumber, userName);
        }
    }

    /***
     *
     * @param policyNumber
     * @param quotationNumber
     * @param userName
     */
    public void tagAllDocumentsByPolicyNumber(String policyNumber, String quotationNumber, String userName, String amendmentNumber) {
        log.info("[FLEET] tag documents by policyId {}", policyNumber);
        DocFleetSearchParam params = DocFleetSearchParam.builder().idQuotation(quotationNumber).build();
        var response = elasticRepository.findByCriteria(params, true);
        List<DocumentFleetEs> results = response.hits().hits().stream()
                .map(Hit::source)
                .collect(Collectors.toList());
        for (DocumentFleetEs doc : results) {
            indexDocByPolicyNumberAndAmendmentNumber(doc, policyNumber, userName, amendmentNumber);
        }
    }

    /***
     *
     * @param doc
     * @param quotationNumber
     * @param userName
     */
    private void indexDocByQuotationNumber(DocumentFleetEs doc, String quotationNumber, String userName) {
        var documentEs = elasticRepository.findById(doc.getId())
                .orElseThrow(() -> new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
                        "Document Not Found"));
        documentEs.setQuotationId(quotationNumber);
        updateDocument(doc, userName, documentEs);
    }

    /***
     *
     * @param doc
     * @param policyNumber
     * @param userName
     */
    private void indexDocByPolicyNumberAndAmendmentNumber(DocumentFleetEs doc, String policyNumber, String userName, String avenantNumber) {
        var documentEs = elasticRepository.findById(doc.getId())
                .orElseThrow(() -> new ResourceNotFoundException(GlobalConstants.URI_RECORDE_DOC_ID_NOT_FOUND,
                        "Document Not Found"));
        documentEs.setPolicyNumber(policyNumber);
        documentEs.setAmendmentNumber(avenantNumber);
        updateDocument(doc, userName, documentEs);
    }

    /***
     *
     * @param doc
     * @param userName
     * @param documentEs
     */
    private void updateDocument(DocumentFleetEs doc, String userName, DocumentFleetEs documentEs) {
        documentEs.setLastUpdatedBy(userName);
        try {
            elasticRepository.updateDocument(doc.getId(), documentEs);
        } catch (Exception e) {
            var error = " when update Fleet Document, err: " + e.getMessage();
            log.error(error);
            throw new GlobalException(GlobalConstants.URI_INTERNAL_ERROR, error);
        }
    }
}