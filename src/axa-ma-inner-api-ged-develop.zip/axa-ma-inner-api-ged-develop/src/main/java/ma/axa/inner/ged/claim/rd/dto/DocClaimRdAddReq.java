package ma.axa.inner.ged.claim.rd.dto;

import javax.validation.constraints.NotBlank;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import ma.axa.inner.ged.util.constants.GlobalConstants;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class DocClaimRdAddReq extends DocClaimRdBaseDto {
	@NotBlank(message = GlobalConstants.ERROR_MSG_RD_CREATEDBY_NOT_BLANK)
	private String createdBy;
	
	@NotBlank(message = GlobalConstants.ERROR_MSG_RD_APPLICATIONCODE_NOT_BLANK)
	private String applicationCode;
	
	@Builder.Default
	@Schema(defaultValue = "true", description = "If true documens put in draft state")
	private boolean draft = true;
	

	private String status;
	
	private String repertoire;
	private String repertoireCode;
	private String emetteur;

	private boolean enableGestionnaire;
	private String filesize;
	private String filetype;
}
