package ma.axa.inner.ged.mobile.scan.dto;

import lombok.Data;

@Data
public class ScanResponse {
	private String token;
	private String url;
	private String qrCodeImageBase64;
	private String typeDocument;
}
