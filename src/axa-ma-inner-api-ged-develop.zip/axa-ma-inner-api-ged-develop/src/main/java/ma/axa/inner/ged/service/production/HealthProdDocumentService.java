package ma.axa.inner.ged.service.production;

import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.config.GedProductionProperties;
import ma.axa.inner.ged.domain.GedDocument;
import ma.axa.inner.ged.domain.ProductionTypeDoc;
import ma.axa.inner.ged.domain.production.ProductionDemandDoc;
import ma.axa.inner.ged.dto.DemandUploadResponseDto;
import ma.axa.inner.ged.exception.InternalErrorException;
import ma.axa.inner.ged.helper.ElasticSearchHelper;
import ma.axa.inner.ged.mapper.DocumentMapper;
import ma.axa.inner.ged.repository.ClaimDocumentRepository;
import ma.axa.inner.ged.service.ManageDocumentService;
import ma.axa.inner.ged.util.DateUtils;
import ma.axa.inner.ged.util.FileUtil;
import ma.axa.inner.ged.util.constants.AXADocPropertyIds;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@Slf4j
public class HealthProdDocumentService extends ManageDocumentService {

    private final GedProductionProperties gedProductionProperties;
    private final ElasticSearchHelper elasticSearchHelper;
    private final ClaimDocumentRepository claimDocumentRepository;


    public HealthProdDocumentService(ClaimDocumentRepository claimDocumentRepository,
                                 GedProductionProperties gedProductionProperties, ElasticSearchHelper elasticSearchHelper) {
        super(claimDocumentRepository);
        this.gedProductionProperties = gedProductionProperties;
        this.elasticSearchHelper = elasticSearchHelper;
        this.claimDocumentRepository = claimDocumentRepository;
    }

    public String uploadFile(MultipartFile file, ProductionTypeDoc documentProductionHealth) {
        if (isValidFile(file)) {
            String filename = file.getOriginalFilename();
            if (filename != null) {
                FileUtil.assertFileNameValid(filename);
            }
            var folder = createOrUpdateDirectory(documentProductionHealth);
            var esDossierHealthRequest = DocumentMapper.mapToESDossierProductionHealthRequest(documentProductionHealth,
                    folder.getId());
            elasticSearchHelper.addIndexDossierProductionHealth(esDossierHealthRequest, documentProductionHealth.getPoliceNumber());
            var gedDocument = DocumentMapper.mapFileToGedDocument(file);
            var idAlfresco = uploadFile(gedDocument, documentProductionHealth);
            if (StringUtils.isNotBlank(idAlfresco)) {
                var esDocumentHealthRequest = DocumentMapper.mapToESDocumentProductionRequest(documentProductionHealth,
                        gedDocument.getFileName(), idAlfresco);
                elasticSearchHelper.addDocumentProduction(esDocumentHealthRequest, idAlfresco);
                return idAlfresco;
            }

            throw new InternalErrorException("Document upload error !");
        }
        return null;
    }

    private Folder createOrUpdateDirectory(ProductionTypeDoc documentProductionHealth) {
        var folder = claimDocumentRepository.createArboFoldersByPath(gedProductionProperties.getOutbox(),
                constructFolderPath(documentProductionHealth.getEffectDate(), documentProductionHealth.getPoliceNumber()));
        if (folder == null) {
            throw new InternalErrorException("create document error");
        }
        folder.updateProperties(DocumentMapper.directoryProductionPropertiesConstructor(documentProductionHealth));
        return folder;
    }

    public String uploadFile(GedDocument gedDocument, ProductionTypeDoc documentProductionHealth) {
        var path = pathFromDateEffect(documentProductionHealth);

        return uploadToAlfresco(gedDocument, path, documentProductionHealth);
    }


    private String pathFromDateEffect(ProductionTypeDoc documentProductionHealth) {
        LocalDate datetime = documentProductionHealth.getEffectDate();
        return String.join("/", DateUtils.getDatePath(datetime), documentProductionHealth.getPoliceNumber());

    }
    public Resource downloadFile(String id) {
        var document = claimDocumentRepository.getFileDocument(id);
        return new ByteArrayResource(document.getFileByte()){
            @Override
            public String getFilename(){
                return document.getFileName();
            }
        };
    }


    private String constructFolderPath(LocalDate effectDate, String policyNumber) {
        return String.join("/", DateUtils.getDatePath(effectDate), policyNumber);
    }

    private String uploadToAlfresco(GedDocument gedDocument, String path, ProductionTypeDoc documentProductionHealth) {
        log.info(
                "Start: creating arborecense in alfresco repository with path '{}'",
                gedProductionProperties.getOutbox() + path);
        var folder = claimDocumentRepository.createArboFoldersByPath(gedProductionProperties.getOutbox(), path);
        log.info(
                "End: creating arborecense in alfresco repository with path '{}'",
                gedProductionProperties.getOutbox() + path);
        if (folder == null) {
            log.error(
                    "Error null folder");
            throw new InternalErrorException("Error creation/opening directory");
        }
        Map<String, Object> props = new HashMap<>();
        props.put(AXADocPropertyIds.IDENTIFIANT_SCANER,
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS")));
        props.put(AXADocPropertyIds.DATE_ARRIVEE, new Date());
        if(documentProductionHealth != null) {
            props.put(AXADocPropertyIds.NATURE_COURRIER, documentProductionHealth.getTypedocument());
        }
        var uploadOutput = uploadFile(props, gedDocument, folder);
        return uploadOutput.get("idAlfresco");
    }

    public List<DemandUploadResponseDto> uploadDemandFiles(List<MultipartFile> files,
                                                           ProductionDemandDoc productionDemandDoc) {

        for (MultipartFile file : files) {
            if (isValidFile(file)) {
                String filename = file.getOriginalFilename();
                if (filename != null) {
                    FileUtil.assertFileNameValid(filename);
                }
            }

        }
        createOrUpdateDirectory(productionDemandDoc);
        // An Other loop
        List<DemandUploadResponseDto> demandUploadResponseDtos = new ArrayList<>();
        for (MultipartFile file : files) {
            var gedDocument = DocumentMapper.mapFileToGedDocument(file);

            var idAlfresco = uploadDemandFile(gedDocument, productionDemandDoc);
            demandUploadResponseDtos.add(DemandUploadResponseDto.builder().fileName(file.getOriginalFilename())
                    .idAlfresco(idAlfresco).build());

        }
        return demandUploadResponseDtos;
    }

    public String uploadDemandFile(GedDocument gedDocument, ProductionDemandDoc documentProductionHealth) {
        var path = pathFromDateEffect(documentProductionHealth);
        return uploadToAlfresco(gedDocument, path, null);
    }

    private Folder createOrUpdateDirectory(ProductionDemandDoc productionDemandDoc) {
        var folder = claimDocumentRepository.createArboFoldersByPath(gedProductionProperties.getOutbox(),
                constructFolderPath(productionDemandDoc.getEffectDate(), productionDemandDoc.getDemandId()));
        if (folder == null) {
            throw new InternalErrorException("Error creation/opening directory");
        }
        return folder;
    }


    private String pathFromDateEffect(ProductionDemandDoc productionDemandDoc) {
        LocalDate datetime = productionDemandDoc.getEffectDate();
        return String.join("/", DateUtils.getDatePath(datetime), productionDemandDoc.getDemandId());

    }

    private boolean isValidFile(MultipartFile file) {
        return file != null && file.getOriginalFilename() != null && file.getContentType() != null;
    }


}
