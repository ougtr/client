package ma.axa.inner.ged.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import ma.axa.inner.ged.util.constants.GlobalConstants;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DocClaimAtReqDto {
    private String idAlfresco;
    private String idDocument;
    private String numSinistre;
    private String preDeclarationNumber;
    private BigDecimal numPolice;
    private String typeDocument;
    private String nomDocument;
    private String regulationNumber;
    private String numReglement;
    private String transactionId;
    private String uploadedby;
    private String repertoire;
    @DateTimeFormat(pattern = GlobalConstants.DATE_FORMAT_FOR_FRONT, fallbackPatterns = {GlobalConstants.DATE_FORMAT_FOR_FRONT})
    @JsonFormat(pattern = GlobalConstants.DATE_FORMAT_FOR_FRONT, shape = JsonFormat.Shape.STRING)
    private LocalDate receptionDate;
    @DateTimeFormat(pattern = GlobalConstants.DATE_FORMAT_FOR_FRONT, fallbackPatterns = {GlobalConstants.DATE_FORMAT_FOR_FRONT})
    @JsonFormat(pattern = GlobalConstants.DATE_FORMAT_FOR_FRONT, shape = JsonFormat.Shape.STRING)
    protected LocalDate dateSurvenance;
    private String sourceDossier; // SourceFilesATEnum
    private String type; // DocumentTypeATEnum
    private String numDossierBnej;
    private String numDossierTribunal;
    private Integer intermediaryCode;
    private Long size;
    private String tag;
    @DateTimeFormat(pattern = GlobalConstants.DATE_FORMAT_FOR_FRONT, fallbackPatterns = {GlobalConstants.DATE_FORMAT_FOR_FRONT})
    @JsonFormat(pattern = GlobalConstants.DATE_FORMAT_FOR_FRONT, shape = JsonFormat.Shape.STRING)
    private LocalDate sendingDate;
    @Builder.Default private Boolean isReturnedRO = false;
    private Long creationTimeStamp;
    @Builder.Default
    private Boolean isTemporary = false;
    private String intermediaryReference;
    private Integer sentToIntermediaryDate;
    private String userSenderToIntermediary;
    private String codeDocument;
    private String rightHolderId;
}
