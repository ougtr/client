package ma.axa.inner.ged.config.filter.wrapper;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;

import javax.servlet.http.Part;

public class GzipDecompressedPart implements Part {

	private final Part origin;
	private final long size;
	private final InputStream stream;

	public GzipDecompressedPart(Part origin, long size, InputStream stream) {
		this.origin = origin;
		this.size = size;
		this.stream = stream;
	}

	@Override
	public InputStream getInputStream() throws IOException {
		return this.stream;
	}

	@Override
	public String getContentType() {
		return this.origin.getContentType();
	}

	@Override
	public String getName() {
		return this.origin.getName();
	}

	@Override
	public String getSubmittedFileName() {
		return this.origin.getSubmittedFileName();
	}

	@Override
	public long getSize() {
		return this.size;
	}

	@Override
	public void write(String fileName) throws IOException {
		this.origin.write(fileName);
	}

	@Override
	public void delete() throws IOException {
		this.origin.delete();
	}

	@Override
	public String getHeader(String name) {
		return this.origin.getHeader(name);
	}

	@Override
	public Collection<String> getHeaders(String name) {
		return this.origin.getHeaders(name);
	}

	@Override
	public Collection<String> getHeaderNames() {
		return this.origin.getHeaderNames();
	}
}