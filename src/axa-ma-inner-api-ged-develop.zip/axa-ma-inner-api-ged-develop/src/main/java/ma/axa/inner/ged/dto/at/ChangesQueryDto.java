package ma.axa.inner.ged.dto.at;

import lombok.*;

import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode
public class ChangesQueryDto {
    private Long id;
    @NotBlank
    private String alfrescoId;
    private String claimNumber;
    private Integer occurrenceDate;
    private Integer typology;
    private Integer repository;
    private String oldAlfrescoId;
    private Boolean isCopied;
}
