package ma.axa.inner.ged.config.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.Data;
import lombok.NoArgsConstructor;

@Configuration
public class AxaGedProperties {

	@Bean
	@ConfigurationProperties(prefix = "axa.ged.transport")
	public BrancheProperties transportProperties() {
		return new BrancheProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "axa.ged.rd")
	public BrancheProperties rdProperties() {
		return new BrancheProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "axa.ged.ls")
	public BrancheProperties lsProperties() {
		return new BrancheProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "axa.ged.production.rc")
	public BrancheProperties rcProperties() {
		return new BrancheProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "axa.ged.cima.pc.production.mrp")
	public BrancheProperties cimaProperties() {
		return new BrancheProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "axa.ged.cima.auto")
	BrancheProperties cimaAutoProperties() {
		return new BrancheProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "axa.ged.production.health.amc")
	public BrancheProperties healthAMCProperties() {
		return new BrancheProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "axa.ged.production.health.dim")
	public BrancheProperties healthDIMProperties() {
		return new BrancheProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "axa.ged.production.health.common")
	public BrancheProperties healthCommonProperties() {
		return new BrancheProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "axa.ged.production.flotte")
	public BrancheProperties fleetProperties() {
		return new BrancheProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "axa.ged.transverse.med")
	public BrancheProperties medProperties() {
		return new BrancheProperties();}
	@Bean
	@ConfigurationProperties(prefix = "axa.ged.poste-ls")
	public BrancheProperties posteLsProperties() {
		return new BrancheProperties();
	}

	@Data
	@NoArgsConstructor
	public static class BrancheProperties {
		private String alfrescoSitePath;
		private String alfrescoRootFolder;
		private String esDocIndex;
		private String esDocType;
	}
}