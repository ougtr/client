package ma.axa.inner.ged.claim.health.repository;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import ma.axa.inner.ged.claim.health.domain.GedHealthEntityAS400;
import ma.axa.inner.ged.claim.health.domain.GedHealthEntityRes;
import ma.axa.inner.ged.claim.health.domain.GedProductionHealthEntityAS400;
import ma.axa.inner.ged.claim.health.dto.DocumentUploadInvoiceRequest;
import ma.axa.inner.ged.exception.CallStoredProcedureException;
import ma.axa.inner.ged.util.FormatterUtils;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
@RequiredArgsConstructor
@Slf4j
public class SehassurHealthDocumentsRepository {

    private final JdbcTemplate jdbcTemplate;
    
    private final FormatterUtils formatter;

    @SneakyThrows
    public int updateIdGed(DocumentUploadInvoiceRequest request) {
        try {
            log.info("Start: SehassurHealthDocumentsRepository updateIdGed '{}' ", request);

         	return jdbcTemplate.update("CALL LGRPP.PSGDDC012(?,?,?,?,?,?,?,?,?,?,?)",
                    request.getReferenceDossier(), request.getNom(), request.getPrenom(),request.getCodePrestataire(),request.getCodeMedcin(),request.getInpe(),
                    request.getIdGed(),request.getMontant(),formatter.toBigDecimal(request.getDateFacture()),formatter.toBigDecimal(request.getDateConsultation()),request.getType());
        } catch (CallStoredProcedureException e) {
            log.error("cannot call procedure to update Id Ged '{}'", e.getMessage());
            throw new CallStoredProcedureException(e.getMessage());
        }

    }
 
}

