## Jira Ticket
**Ticket:** [XX-XXXX](https://jira.axa.com/jira/browse/XXX-XXXX)

## Jenkins build
**URL:** [Build #6](https://jenkins-cicd-dev-axa-ma.axa-ma-dev-int.merlot.eu-central-1.aws.openpaas.axa-cloud.com/view/Skeleton/job/axa-ma-inner-api-skeleton_buildPR/6/)

## Summary
Describe what this PR does and its purpose.

## Motivation & Context
- Explain why this PR is needed. What problem does it solve and how does it address the issue(s) mentioned in the ticket?

## Additional Notes
Any other information that reviewers might need.