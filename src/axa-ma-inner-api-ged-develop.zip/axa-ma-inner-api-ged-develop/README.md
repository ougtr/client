# AXA Inner Skeleton API

A spring boot skeleton (template), for AXA inner APIs.

## Requirements
> Please follow [Developer Workplace](#) wiki to get/install your devTools.
* [Open JDK-11+](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Developer-Workplace#java)
* [Maven 3](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Developer-Workplace#maven)
* [Spring Tool Suite IDE](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Developer-Workplace#spring-tool-suite)
       - Mandatory Plugins: Lombok
> Make sure you'r using OpenJDK-11, check your java version with : `java -version`.

## How create new project from this Template

Please follow this wiki [Creating a Repository from a Template](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Create-First-Java-Project)

## Project Structure:

### Main folders

The project follows a standard spring project structure,is decomposed into multiple folders:

- **api**: contains different server Rest Controller, defining the various endpoints.
- **config**: contains project configuration like: openApi, security and web config.
- **domain**: contains the app's business objects.
- **dto**: contains objects representing requests and responses for various external systems (Client services, Axa Inner Services).
- **enums**: contains Enumerations.
- **exception**: contains objects used in exceptions management.
- **mapper**: contains the app's mapper classes.
- **repository**: contains the database communication layer.
- **service**: contains the service layer.
- **util**: contains utility classes.
- **util/constants**: contains constants classes.

### Files Compression 

The project contains two gzip compress filters inside the  **config/filter** package:

- **GzipCompressResponseFilter**: For response compression, To get a compressed file from GED, you must add a `X-Ged-Accept-Encoding: gzip` to your http header.
- **GzipDecompressRequestFilter**:  For request decompression, you should send a compressed file with the header `X-Ged-Content-Encoding: gzip`, This filter is responsible for decompressing your request before calling your controller API class.

### Test folders

All Test classes, must be under `/src/main/test`:

- **api**: contains unit testing for API layer.
- **repository**: contains Unit testing for repository layer.
- **service**: contains Unit testing for service layer.
- **util**: contains Test utility classes.

## Run & Build application

### Locally

1. To build the project locally, run the following command:   

```
 mvn clean install
```

2. To run the application locally, run the following command:

```
 mvn spring-boot:run
```

### With Jenkins

1. Create your project on [Jenkins Build](#) and [Jenkin Local Deploy](#)
2. Build project with jenkins pipeline, follow the instructions [WIKI](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/DevOps-Factory#jenkins-build).
3. Deploy the application use Local jenkins, follow the instructions [WIKI](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/DevOps-Factory#jenkins-deploy).

## Test your Rest APIs with Postman

1. Open your Postman. (If not installed yet, follow [Install Postman](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Developer-Workplace#postman))
2. Read the wiki [How to test your APIs](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Postman#how-to-test-your-apis-with-postman).

## Security Management

1. To enable/disable spring security, You must update the property `axa.security.enabled` (by default is `true`) in the application.yml file :

     ```
      axa:
        security:
          enabled: false
     ```
2. In case the spring security enabled, You should generate a Token and add it to your `http Authorization header`, Follow the wiki [How to Generate & add token with Postman](https://github.axa.com/axa-ma/axa-ma-documentation/wiki/Postman#how-to-generate--add-token-with-postman).

## links

| Tools       | Discription                             |
| ----------- | --------------------------------------- |
| [JIRA](https://jira.axa.com/)        | A proprietary issue tracking product.   |
| [Jenkins](https://jenkins-cicd-dev-axa-ma.axa-ma-dev-int.merlot.eu-central-1.aws.openpaas.axa-cloud.com)     | An open source automation server.       |
| [AXA MA Documentation](https://github.axa.com/axa-ma/axa-ma-documentation/wiki) | A web-based corporate wiki.                   |

